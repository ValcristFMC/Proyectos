# CriteriaApi
##### Versión: 1.0.0
##### Último autor:  Francisco Bernal 
##### Fecha:  27 de Mayo del 2020

Configuación técnica
-------------

- IDE: Netbeans IDE 7.1
- Lenguaje: Java 1.6

Librerias Internas (Grupo Castores )
-------------
- No contiene ninguna

Librerias Externas
-------------
- No contiene ninguna
