/**
 *
 * (c) 2011 Transportes Castores de Baja California
 *
 */
package com.castores.criteriaapi.core;

import java.util.ArrayList;

/**
 * Permite construir criterios de busqueda para lenguaje sql programaticamente
 */
public class CriteriaBuilder implements Cloneable {

    private ArrayList<Criteria> conditionList;
    private ArrayList<Object> valuesList;
    private ArrayList<CriteriaOrder> orderList;
    private ArrayList<GroupOrder> groupList;
    private long limitMin;
    private long limitMax;
    private String conditionHaving;

    public CriteriaBuilder() {
    }

    /**
     * Clona el objeto CriteriaBuilder
     */
    @Override
    public Object clone() throws CloneNotSupportedException {
        CriteriaBuilder obj = null;
        obj = (CriteriaBuilder) super.clone();

        if (conditionList != null) {
            obj.conditionList = (ArrayList<Criteria>) obj.conditionList.clone();
        }
        if (valuesList != null) {
            obj.valuesList = (ArrayList<Object>) obj.valuesList.clone();
        }
        if (orderList != null) {
            obj.orderList = (ArrayList<CriteriaOrder>) obj.orderList.clone();
        }
        if (groupList != null) {
            obj.groupList = (ArrayList<GroupOrder>) obj.groupList.clone();
        }
        return obj;
    }

    public ArrayList<Object> getValuesList() {
        return valuesList;
    }

    /**
     * Retorna un String con el criterio de busqueda listo para un
     * java.sql.PreparedStatement en sql Ej. campo1 = ? AND campo2 > ?
     */
    public String getPreparedCriteria() {
        return buildPreparedStatement() + getGroupStatement() + getHavingStatement() + getOrderStatement() + getLimitStatement();
    }

    /**
     * construye el prepared statement
     */
    private String buildPreparedStatement() {
        StringBuilder sb = new StringBuilder();
        if (conditionList != null) {
            for (int i = 0; i < conditionList.size() - 1; i++) {
                sb.append(conditionList.get(i).toString()).append(" ").append(conditionList.get(i).getBool());
            }
            sb.append(conditionList.get(conditionList.size() - 1).toString());
            return sb.toString();
        } else {
            return "";
        }
    }

    /**
     * Retorna un String con el criterio de busqueda listo para un
     * java.sql.Statement en sql Ej. campo1 = valor1 AND campo2 > valor2
     */
    public String getCriteria() {
        String prepared = buildPreparedStatement();
        if (valuesList != null) {
            for (int i = 0; i < valuesList.size(); i++) {
                if (valuesList.get(i) instanceof String) {
                    prepared = prepared.replaceFirst("\\?", "'" + valuesList.get(i).toString() + "'");
                } else {
                    prepared = prepared.replaceFirst("\\?", valuesList.get(i).toString());
                }
            }
        }
        return prepared + getGroupStatement() + getHavingStatement() + getOrderStatement() + getLimitStatement();
    }

    private String getOrderStatement() {
        StringBuilder sb = new StringBuilder();
        if (orderList != null) {
            if (orderList.size() > 0) {
                sb.append(" ORDER BY");
            }
            for (int i = 0; i < orderList.size() - 1; i++) {
                sb.append(orderList.get(i).toString()).append(",");
            }
            sb.append(orderList.get(orderList.size() - 1).toString());
            return sb.toString();
        } else {
            return "";
        }
    }

    private String getGroupStatement() {
        StringBuilder sb = new StringBuilder();
        if (groupList != null) {
            if (groupList.size() > 0) {
                sb.append(" GROUP BY");
            }
            for (int i = 0; i < groupList.size() - 1; i++) {
                sb.append(groupList.get(i).toString()).append(",");
            }
            sb.append(groupList.get(groupList.size() - 1).toString());
            return sb.toString();
        } else {
            return "";
        }
    }
    
    private String getHavingStatement(){
        StringBuilder sb = new StringBuilder();
        if(conditionHaving != null)
        {
            sb.append(" HAVING ");
            sb.append(conditionHaving);
            return sb.toString();
        }
        else
            {
                return "";
            }
    }

    private String getLimitStatement() {
        if (limitMin >= 0 && limitMax > 0) {
            return " LIMIT " + limitMin + ", " + limitMax;
        } else {
            return "";
        }

    }

    /**
     * Limpia todos los criterios del CriteriaBuilder
     */
    public void clear() {
        conditionList = null;
        valuesList = null;
        limitMax = 0;
        limitMin = 0;
        orderList = null;
        conditionHaving = null;
        groupList = null;
    }

    private void addCriteria(Criteria c) {
        if (conditionList == null) {
            conditionList = new ArrayList<Criteria>();
        }
        conditionList.add(c);
    }

    
    private void addCriteriaHaving(String c) {
        if (conditionHaving == null) {
            conditionHaving = "";
        }
        conditionHaving = c;
    }
    
    private void addValue(Object o) {
        if (valuesList == null) {
            valuesList = new ArrayList<Object>();
        }
        valuesList.add(o);
    }

    /**
     * Agrega un criterio a buscar, por defecto se aplica el conector AND al
     * final.
     *
     * @param field campo de la tabla
     * @param condition condicional ej Criteria.CRITERIA.CRITERIA_EQ
     * @param value valor con el cual se aplicara la condición
     */
    public void add(String field, String condition, Object value) {
        addCriteria(new Criteria(field, condition, Criteria.BOOL_AND));
        addValue(value);
    }
    
    public void addHaving(String condition){
        addCriteriaHaving(condition);
    }

    /**
     * Agrega un criterio de orden
     *
     * @param field campo de la tabla
     * @param order condicional ej. CriteriaOrder.ASC
     */
    @Deprecated
    public void addOrder(String field, String order) {
        if (orderList == null) {
            orderList = new ArrayList<CriteriaOrder>();
        }
        CriteriaOrder c = new CriteriaOrder(field, order);
        orderList.add(c);
    }

    /**
     * Agrega un criterio de orden ascendente
     *
     * @param field campo de la tabla
     */
    public void orderAsc(String field) {
        if (orderList == null) {
            orderList = new ArrayList<CriteriaOrder>();
        }
        CriteriaOrder c = new CriteriaOrder(field, CriteriaOrder.ASC);
        orderList.add(c);
    }

    /**
     * Agrega un criterio de orden descendente
     *
     * @param field campo de la tabla
     */
    public void orderDesc(String field) {
        if (orderList == null) {
            orderList = new ArrayList<CriteriaOrder>();
        }
        CriteriaOrder c = new CriteriaOrder(field, CriteriaOrder.DESC);
        orderList.add(c);
    }

    /**
     * Agrega un criterio de agrupación ascendente GROUP BY <field> ASC
     *
     * @param field campo de la tabla
     */
    public void groupAsc(String field) {
        if (groupList == null) {
            groupList = new ArrayList<GroupOrder>();
        }
        GroupOrder c = new GroupOrder(field, GroupOrder.ASC);
        groupList.add(c);
    }

    /**
     * Agrega un criterio de agrupación ascendente GROUP BY <field> DESC
     *
     * @param field campo de la tabla
     */
    public void groupDesc(String field) {
        if (groupList == null) {
            groupList = new ArrayList<GroupOrder>();
        }
        GroupOrder c = new GroupOrder(field, GroupOrder.DESC);
        groupList.add(c);
    }

    /**
     * Agrega un limite al criterio de busqueda
     *
     * @param limitMin registro inicial
     * @param limitMax registro final
     */
    public void setlimit(long limitMin, long limitMax) {
        this.limitMin = limitMin;
        this.limitMax = limitMax;
    }

    /**
     * Agrega un limite al criterio de busqueda, de inicio 0 hasta limitMax
     *
     * @param limitMax registro final
     */
    public void setlimit(long limitMax) {
        setlimit(0, limitMax);
    }

    /**
     * Agrega un criterio a buscar con conector OR al final.
     *
     * @param field campo de la tabla
     * @param condition condicional ej Criteria.CRITERIA.CRITERIA_EQ
     * @param value valor con el cual se aplicara la condición
     */
    public void addOr(String field, String condition, Object value) {
        addCriteria(new Criteria(field, condition, Criteria.BOOL_OR));
        addValue(value);
    }

    /**
     * Agrega un criterio de la forma: field = value AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void eq(String field, Object value) {
        add(field, Criteria.CRITERIA_EQ, value);
    }

    /**
     * Agrega un criterio de la forma: field = value OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void eqOr(String field, Object value) {
        addOr(field, Criteria.CRITERIA_EQ, value);
    }

    /**
     * Agrega un criterio de la forma: field <> value AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void neq(String field, Object value) {
        add(field, Criteria.CRITERIA_NEQ, value);
    }

    /**
     * Agrega un criterio de la forma: field <> value OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void neqOr(String field, Object value) {
        addOr(field, Criteria.CRITERIA_NEQ, value);
    }

    /**
     * Agrega un criterio de la forma: field > value AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void gt(String field, Object value) {
        add(field, Criteria.CRITERIA_GT, value);
    }

    /**
     * Agrega un criterio de la forma: field > value OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void gtOr(String field, Object value) {
        addOr(field, Criteria.CRITERIA_GT, value);
    }

    /**
     * Agrega un criterio de la forma: field >= value AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void gte(String field, Object value) {
        add(field, Criteria.CRITERIA_GTE, value);
    }

    /**
     * Agrega un criterio de la forma: field >= value OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void gteOr(String field, Object value) {
        addOr(field, Criteria.CRITERIA_GTE, value);
    }

    /**
     * Agrega un criterio de la forma: field < value AND
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void lt(String field, Object value) {
        add(field, Criteria.CRITERIA_LT, value);
    }

    /**
     * Agrega un criterio de la forma: field < value OR
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void ltOr(String field, Object value) {
        addOr(field, Criteria.CRITERIA_LT, value);
    }

    /**
     * Agrega un criterio de la forma: field <= value AND
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void lte(String field, Object value) {
        add(field, Criteria.CRITERIA_LTE, value);
    }

    /**
     * Agrega un criterio de la forma: field <= value OR 
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void lteOr(String field, Object value) {
        addOr(field, Criteria.CRITERIA_LTE, value);
    }

    /**
     * Agrega un criterio de la forma: field BETWEEN min AND max
     *
     * @param field campo de la tabla.
     * @param min valor minimo con el cual se aplicara la condición.
     * @param max valor maximo con el cual se aplicara la condición.
     */
    public void between(String field, Object min, Object max) {
        addCriteria(new Criteria(field, Criteria.CRITERIA_BTW, Criteria.BOOL_AND));
        addValue(min);
        addValue(max);
    }

    /**
     * Agrega un criterio de la forma: field IN ( values) AND
     *
     * @param field campo de la tabla.
     * @param values valor con el cual se aplicara la condición.
     */
    public void in(String field, Object[] values) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_IN, Criteria.BOOL_AND);
        c.setPlaceHolders(values.length);
        addCriteria(c);
        for (Object o : values) {
            if (o instanceof String) {
                addValue(o.toString().trim());
            } else {
                addValue(o);
            }
        }
    }

    /**
     * Agrega un criterio de la forma: field NOT IN ( values) AND
     *
     * @param field campo de la tabla.
     * @param values valor con el cual se aplicara la condición.
     */
    public void nin(String field, Object[] values) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_NIN, Criteria.BOOL_AND);
        c.setPlaceHolders(values.length);
        addCriteria(c);
        for (Object o : values) {
            if (o instanceof String) {
                addValue(o.toString().trim());
            } else {
                addValue(o);
            }
        }
    }

    /**
     * Agrega un criterio de la forma: field IN ( values) OR
     *
     * @param field campo de la tabla.
     * @param values valor con el cual se aplicara la condición.
     */
    public void inOr(String field, Object[] values) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_IN, Criteria.BOOL_OR);
        c.setPlaceHolders(values.length);
        addCriteria(c);
        for (Object o : values) {
            if (o instanceof String) {
                addValue(o.toString().trim());
            } else {
                addValue(o);
            }
        }
    }

    /**
     * Agrega un criterio de la forma: field NOT IN ( values) OR
     *
     * @param field campo de la tabla.
     * @param values valor con el cual se aplicara la condición.
     */
    public void ninOr(String field, Object[] values) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_NIN, Criteria.BOOL_OR);
        c.setPlaceHolders(values.length);
        addCriteria(c);
        for (Object o : values) {
            if (o instanceof String) {
                addValue(o.toString().trim());
            } else {
                addValue(o);
            }
        }
    }

    /**
     * Agrega un criterio de la forma: field LIKE %value% AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void like(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_LIKE, Criteria.BOOL_AND);
        addCriteria(c);
        addValue("%" + value + "%");
    }

    /**
     * Agrega un criterio de la forma: field LIKE value% AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void likep(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_LIKE, Criteria.BOOL_AND);
        addCriteria(c);
        addValue(value + "%");
    }

    /**
     * Agrega un criterio de la forma: field LIKE %value AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void plike(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_LIKE, Criteria.BOOL_AND);
        addCriteria(c);
        addValue("%" + value);
    }

    /**
     * Agrega un criterio de la forma: field LIKE %value% OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void likeOr(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_LIKE, Criteria.BOOL_OR);
        addCriteria(c);
        addValue("%" + value + "%");
    }

    /**
     * Agrega un criterio de la forma: field LIKE value% OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void likepOr(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_LIKE, Criteria.BOOL_OR);
        addCriteria(c);
        addValue(value + "%");
    }

    /**
     * Agrega un criterio de la forma: field LIKE %value OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void plikeOr(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_LIKE, Criteria.BOOL_OR);
        addCriteria(c);
        addValue("%" + value);
    }

    /**
     * Agrega un criterio de la forma: field NOT LIKE %value% AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void nlike(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_NLIKE, Criteria.BOOL_AND);
        addCriteria(c);
        addValue("%" + value + "%");
    }

    /**
     * Agrega un criterio de la forma: field NOT LIKE value% AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void nlikep(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_NLIKE, Criteria.BOOL_AND);
        addCriteria(c);
        addValue(value + "%");
    }

    /**
     * Agrega un criterio de la forma: field NOT LIKE %value AND
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void nplike(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_NLIKE, Criteria.BOOL_AND);
        addCriteria(c);
        addValue("%" + value);
    }

    /**
     * Agrega un criterio de la forma: field NOT LIKE %value% OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void nlikeOr(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_NLIKE, Criteria.BOOL_OR);
        addCriteria(c);
        addValue("%" + value + "%");
    }

    /**
     * Agrega un criterio de la forma: field NOT LIKE value% OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void nlikepOr(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_NLIKE, Criteria.BOOL_OR);
        addCriteria(c);
        addValue(value + "%");
    }

    /**
     * Agrega un criterio de la forma: field NOT LIKE %value OR
     *
     * @param field campo de la tabla.
     * @param value valor con el cual se aplicara la condición.
     */
    public void nplikeOr(String field, String value) {
        Criteria c = new Criteria(field, Criteria.CRITERIA_NLIKE, Criteria.BOOL_OR);
        addCriteria(c);
        addValue("%" + value);
    }

    /**
     * Agrega un criterio de la forma: field IS NULL AND
     *
     * @param field campo de la tabla.
     */
    public void isNull(String field) {
        if (valuesList == null) {
            valuesList = new ArrayList<Object>();
        }
        if (valuesList.isEmpty()) {
            eq("666", 666);
        }
        Criteria c = new Criteria(field, Criteria.CRITERIA_IS, Criteria.BOOL_AND);
        addCriteria(c);
    }

    /**
     * Agrega un criterio de la forma: field IS NULL OR
     *
     * @param field campo de la tabla.
     */
    public void isNullOr(String field) {
        if (valuesList == null) {
            valuesList = new ArrayList<Object>();
        }
        if (valuesList.isEmpty()) {
            eq("666", 666);
        }
        Criteria c = new Criteria(field, Criteria.CRITERIA_IS, Criteria.BOOL_OR);
        addCriteria(c);
    }

    /**
     * Agrega un criterio de la forma: field IS NOT NULL AND
     *
     * @param field campo de la tabla.
     */
    public void isNotNull(String field) {
        if (valuesList == null) {
            valuesList = new ArrayList<Object>();
        }
        if (valuesList.isEmpty()) {
            eq("666", 666);
        }
        Criteria c = new Criteria(field, Criteria.CRITERIA_IS_NOT, Criteria.BOOL_AND);
        addCriteria(c);
    }

    /**
     * Agrega un criterio de la forma: field IS NOT NULL OR
     *
     * @param field campo de la tabla.
     */
    public void isNotNullOr(String field) {
        if (valuesList == null) {
            valuesList = new ArrayList<Object>();
        }
        if (valuesList.isEmpty()) {
            eq("666", 666);
        }
        Criteria c = new Criteria(field, Criteria.CRITERIA_IS_NOT, Criteria.BOOL_OR);
        addCriteria(c);
    }

    public static void main(String[] args) {
        CriteriaBuilder cb = new CriteriaBuilder();
        cb.eqOr("a", 2);
        cb.gt("b", 3);
        
        cb.groupAsc("c");
        //cb.groupDesc("a");
        //cb.orderAsc("b");
        //cb.orderAsc("z");
        cb.setlimit(10);
        System.out.println(cb.getCriteria());
        System.out.println(cb.getPreparedCriteria());
    }
    
    public void having(String condition){
        addCriteriaHaving(condition);
    }
}
