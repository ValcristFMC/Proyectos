/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.castores.criteriaapi.core;

/**
 *
 * @author andres
 * (c) /201
 */
public class GroupOrder {
    public static final String ASC = "ASC";
    public static final String DESC = "DESC";
    private String field;
    private String order;

    public GroupOrder(String field, String order) {
        this.field = field;
        this.order = order;
    }

    @Override
    public String toString() {
        return " " + field + " " + order;
    }
}
