/**
 *
 * (c) 2011 Transportes Castores de Baja California
 * 
 */
package com.castores.criteriaapi.core;

/**
 * Contenedor para una condicion de ordenación
 */
public class CriteriaOrder {

    public static final String ASC = "ASC";
    public static final String DESC = "DESC";
    private String field;
    private String order;

    public CriteriaOrder(String field, String order) {
        this.field = field;
        this.order = order;
    }

    @Override
    public String toString() {
        return " " + field + " " + order;
    }
}
