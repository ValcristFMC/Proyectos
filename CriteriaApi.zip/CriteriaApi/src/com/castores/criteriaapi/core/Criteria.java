/**
 *
 * (c) 2011 Transportes Castores de Baja California
 * 
 */
package com.castores.criteriaapi.core;

/**
 * Contenedor para un criterio de busqueda en sql
 */
public class Criteria {

    /** Conector boleano AND */
    public static final String BOOL_AND = "AND";
    /** Conector booleano OR */
    public static final String BOOL_OR = "OR";
    /** Igual a =*/
    public static final String CRITERIA_EQ = "=";
    /** Diferente a <>*/
    public static final String CRITERIA_NEQ = "<>";
    /** Mayor a >*/
    public static final String CRITERIA_GT = ">";
    /** Mayor o igual a >=*/
    public static final String CRITERIA_GTE = ">=";
    /** Menor a <*/
    public static final String CRITERIA_LT = "<";
    /** Menor o igual a <=*/
    public static final String CRITERIA_LTE = "<=";
    /** Entre BETWEEN*/
    public static final String CRITERIA_BTW = "BETWEEN";
    /** Dentro de IN*/
    public static final String CRITERIA_IN = "IN";
    /** Dentro de IN*/
    public static final String CRITERIA_NIN = "NOT IN";
    /** Similar a LIKE*/
    public static final String CRITERIA_LIKE = "LIKE";
    /** Similar a NOT LIKE*/
    public static final String CRITERIA_NLIKE = "NOT LIKE";
    /** Similar a IS NULL*/
    public static final String CRITERIA_IS = "IS";
    /** Similar a IS NOT NULL*/
    public static final String CRITERIA_IS_NOT = "IS NOT";
    /** Filtro */
    public static final String CRITERIA_HAVING = "HAVING";
    
    private String field;
    private String condition;
    private String bool;
    private int placeHolders = 1;

    /**
     *
     * @param field campo
     * @param condition condicion ej Criteria.CRITERIA_LIKE
     * @param bool conector ej Criteria.BOOL_AND
     */
    public Criteria(String field, String condition, String bool) {
        this.field = field;
        this.condition = condition;
        this.bool = bool;
    }

    public String getBool() {
        return bool;
    }

    public void setBool(String bool) {
        this.bool = bool;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public int getPlaceHolders() {
        return placeHolders;
    }

    public void setPlaceHolders(int placeHolders) {
        this.placeHolders = placeHolders;
    }

    private String getPlaceHoldersSigns() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < placeHolders; i++) {
            sb.append("?");
        }
        String res = sb.toString().replace("??", "?,?");
        while (res.contains("??")) {
            res = res.replace("??", "?,?");
        }
        return res;
    }
    
    @Override
    public String toString() {
        if (condition.equals(CRITERIA_BTW)) {
            return " " + field + " " + condition + "  ? AND ? ";

        } else if (condition.equals(CRITERIA_IN)) {
            return " " + field + " " + condition + " (" + getPlaceHoldersSigns() + ")";

        } else if (condition.equals(CRITERIA_NIN)) {
            return " " + field + " " + condition + " (" + getPlaceHoldersSigns() + ")";

        } else if (condition.equals(CRITERIA_LIKE)) {
            return " " + field + " " + condition + " ?";

        } else if (condition.equals(CRITERIA_IS) || condition.equals(CRITERIA_IS_NOT)) {
            return " " + field + " " + condition + " NULL";

        } else {
            return " " + field + " " + condition + " ?";
        }
    }
}
