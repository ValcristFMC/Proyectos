package com.castores.citeriaapi.version;

/*
 * Título               : version.java
 * Descripción          : Muestra la versión del sistema
 * Compañía             : Transportes Castores de Baja California S.A. de C.V. – Área de Desarrollo
 * Fecha de creación    : 2019-12-03
 * Autor                : Francisco Bernal
 * Versión              : 1.0.0
 * ID Requerimiento     : NULL
 */
public class version {

    /*
    * Versión           : 1.0.0
    * Último autor      : Francisco Bernal
    * Descripción       : Se le asignó una versión al sistema
    * ID Requerimiento  : NULL
    */
    public String version() {
        return "1.0.0";
    }
}
