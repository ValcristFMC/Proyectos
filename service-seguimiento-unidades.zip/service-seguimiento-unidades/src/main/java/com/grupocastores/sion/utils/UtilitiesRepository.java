package com.grupocastores.sion.utils;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Repository;

@Repository
public class UtilitiesRepository {

	@PersistenceContext
	private EntityManager entityManager;
	
	public static final String DB13 = "PRODUCCION13";
	public static final String DB23 = "PRODUCCION23";
	public static final String queryGetLinkedServerByIdOficina = 
			"SELECT * FROM syn.dbo.v_Oficinas where Oficina = \'%s\'";
	
    public static String getDb23() {
        return DB23;
    }
    
    public static String getDb13() {
        return DB13;
    }
    
    public Boolean executeStoredProcedure(String query) {
        StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("PcrExecSQL");
        storedProcedure.registerStoredProcedureParameter("sql", String.class, ParameterMode.IN);
        storedProcedure.registerStoredProcedureParameter("respuesta", String.class, ParameterMode.OUT);
        storedProcedure.setParameter("sql", query);
        storedProcedure.execute();
        int resp = Integer.parseInt((String) storedProcedure.getOutputParameterValue("respuesta"));
        return resp > 0;
    }
}