package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.dto.OficinasDTO;
import com.grupocastores.sion.service.IOficinasService;
import com.grupocastores.sion.service.domain.UsuarioDivisionSion;
import com.grupocastores.sion.service.repository.OficinasRepository;
import com.grupocastores.sion.service.repository.UsuarioDivisionSionRepository;

@Service
public class OficinasServiceImpl implements IOficinasService {
	Logger logger = LoggerFactory.getLogger(OficinasServiceImpl.class);

	@Autowired
	private OficinasRepository oficinasRepository;
	
	@Autowired
	private UsuarioDivisionSionRepository usuarioDivisionSionRepository;
	
	@Override
	public List<OficinasDTO> getOficinas(String division) {
		List<OficinasDTO> lstOficinas = new ArrayList<OficinasDTO>();
		
		try {
			lstOficinas = oficinasRepository.getOficinasByDivision(division);
			if (lstOficinas == null) {
				throw new Exception("No se pudo obtener el registro del seguimiento: ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return lstOficinas;
	}
	
	@Override
	public List<OficinasDTO> getOficinasByUsuario(Long usuario) {
		List<OficinasDTO> lstOficinas = new ArrayList<OficinasDTO>();
		
		try {
			if (usuario == null || usuario.equals(0L)) {
				lstOficinas = oficinasRepository.getOficinas();
			}else {
				List<UsuarioDivisionSion> lstDivisionesUsuario = usuarioDivisionSionRepository.findByIdUsuario(usuario);
				String divisiones = lstDivisionesUsuario.stream()
		                .map(UsuarioDivisionSion::getIdDivision) 
		                .map(String::valueOf) 
		                .collect(Collectors.joining(","));
				lstOficinas = oficinasRepository.getOficinasByDivision(divisiones);
			}
			if (lstOficinas == null) {
				throw new Exception("No se pudo obtener el registro del seguimiento: ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return lstOficinas;
	}
}
