package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de IncidenciasEtiquetas", description = "Datos de IncidenciasEtiquetas")
public class IncidenciasEtiquetaDTO {
	
	private String folioIncidenciaAlmacen;
	private String talon;
	private String etiqueta;
	private int numero;
	private String nombre;
	
	public IncidenciasEtiquetaDTO (String folioIncidenciaAlmacen
			, String talon
			, String etiqueta
			, int numero
			, String nombre) {
		this.folioIncidenciaAlmacen = folioIncidenciaAlmacen;
		this.talon = talon;
		this.etiqueta = etiqueta;
		this.numero = numero;
		this.nombre = nombre;
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("IncidenciasEtiqueta [folioIncidenciaAlmacen=").append(folioIncidenciaAlmacen)
		.append(", talon=").append(talon)
		.append(", etiqueta=").append(etiqueta)
		.append(", numero=").append(numero)
		.append(", nombre=").append(nombre);
		return strBuilder.toString();
	}
}
