package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.IncidenciasEtiquetaDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "IncidenciasEtiqueta")
@EntityListeners(IncidenciasEtiqueta.class)
public class IncidenciasEtiqueta {
	
	
	private String folioIncidenciaAlmacen;
	private String talon;
	private String etiqueta;
	@Id
	private int numero;
	private String nombre;
	
	/**
	 * Metodo estatico para obtener un IncidenciasEtiqueta a partir de un IncidenciasEtiquetaDTO origen
	 * 
	 * @param incidenciasEtiqueta IncidenciasEtiquetaDTO origen
	 * 
	 * @return IncidenciasEtiqueta
	 */
	public static IncidenciasEtiqueta fromIncidenciasEtiquetaDTO(IncidenciasEtiquetaDTO incidenciasEtiqueta) {
		IncidenciasEtiqueta rest = new IncidenciasEtiqueta();
		rest.setFolioIncidenciaAlmacen(incidenciasEtiqueta.getFolioIncidenciaAlmacen());
		rest.setTalon(incidenciasEtiqueta.getTalon());
		rest.setEtiqueta(incidenciasEtiqueta.getEtiqueta());
		rest.setNumero(incidenciasEtiqueta.getNumero());
		rest.setNombre(incidenciasEtiqueta.getNombre());
		return rest;
	}
	
	/**
	 * Metodo para obtener un IncidenciasDTO a partir de un Incidencias origen
	 * 
	 * @return IncidenciasDTO
	 */
	public IncidenciasEtiquetaDTO toIncidenciasEtiquetaDTO() {
		IncidenciasEtiquetaDTO dto = new  IncidenciasEtiquetaDTO();
		 dto.setFolioIncidenciaAlmacen(this.getFolioIncidenciaAlmacen());
		 dto.setTalon(this.getTalon());
		 dto.setEtiqueta(this.getEtiqueta());
		 dto.setNumero(this.getNumero());
		 dto.setNombre(this.getNombre());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("IncidenciasEtiqueta [folioIncidenciaAlmacen=").append(folioIncidenciaAlmacen)
		.append(",talon=").append(talon)
		.append(",etiqueta=").append(etiqueta)
		.append(",numero=").append(numero)
		.append(",nombre=").append(nombre);
		return strBuilder.toString();
	}
}
