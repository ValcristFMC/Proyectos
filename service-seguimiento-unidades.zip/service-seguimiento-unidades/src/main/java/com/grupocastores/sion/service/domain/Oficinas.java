package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.OficinasDTO;
import com.grupocastores.sion.dto.OficinasDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "oficinas")
@EntityListeners(Oficinas.class)
public class Oficinas {
	
	@Id
	private String idOficina;
	private String nombre;
	private String estatus;
	private String idCiudad;

	public static Oficinas fromDivisionDTO(OficinasDTO division) {
		Oficinas rest = new Oficinas();
		rest.setIdOficina(division.getIdOficina());
		rest.setNombre(division.getNombre());
		rest.setEstatus(division.getEstatus());
		rest.setIdCiudad(division.getIdCiudad());
		return rest;
	}
	
	public OficinasDTO toOficinasDTO() {
		OficinasDTO dto = new  OficinasDTO();
		 dto.setIdOficina(this.getIdOficina());
		 dto.setNombre(this.getNombre());
		 dto.setEstatus(this.getEstatus());
		 dto.setIdCiudad(this.getIdCiudad());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Oficinas [idOficina=").append(idOficina)
		.append(",nombre=").append(nombre)
		.append(",estatus=").append(estatus)
		.append(",idCiudad=").append(idCiudad);
		return strBuilder.toString();
	}
}

