package com.grupocastores.sion.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;
import java.time.LocalTime;

import com.grupocastores.sion.dto.GuiaInfoDTO;
import lombok.Data;

@Data
@Entity
@Table(name = "guia_info")
public class GuiaInfo {

    @Id
    @Column(name = "numero_guia")
    private String numeroGuia;
    private String unidad;
    private String placas;
    private int idOperador;
    private int remolque;
    private int origen;
    private int destino;
    private String despacho;
    private int idPersonal;
    private String idOficina;
    private int moneda;
    private double conversion;
    private LocalDate fecha;
    private LocalTime hora;
    private int status;
    private int idCliente;
    private int idProducto;
    private String cita;
    private int tipoUnidad;

    public static GuiaInfo fromGuiaInfoDTO(GuiaInfoDTO guiaInfoDTO) {
        GuiaInfo guiaInfo = new GuiaInfo();
        guiaInfo.setNumeroGuia(guiaInfoDTO.getNumeroGuia());
        guiaInfo.setUnidad(guiaInfoDTO.getUnidad());
        guiaInfo.setPlacas(guiaInfoDTO.getPlacas());
        guiaInfo.setIdOperador(guiaInfoDTO.getIdOperador());
        guiaInfo.setRemolque(guiaInfoDTO.getRemolque());
        guiaInfo.setOrigen(guiaInfoDTO.getOrigen());
        guiaInfo.setDestino(guiaInfoDTO.getDestino());
        guiaInfo.setDespacho(guiaInfoDTO.getDespacho());
        guiaInfo.setIdPersonal(guiaInfoDTO.getIdPersonal());
        guiaInfo.setIdOficina(guiaInfoDTO.getIdOficina());
        guiaInfo.setMoneda(guiaInfoDTO.getMoneda());
        guiaInfo.setConversion(guiaInfoDTO.getConversion());
        guiaInfo.setFecha(guiaInfoDTO.getFecha());
        guiaInfo.setHora(guiaInfoDTO.getHora());
        guiaInfo.setStatus(guiaInfoDTO.getStatus());
        guiaInfo.setIdCliente(guiaInfoDTO.getIdCliente());
        guiaInfo.setIdProducto(guiaInfoDTO.getIdProducto());
        guiaInfo.setCita(guiaInfoDTO.getCita());
        guiaInfo.setTipoUnidad(guiaInfoDTO.getTipoUnidad());
        return guiaInfo;
    }

    public GuiaInfoDTO toGuiaInfoDTO() {
        GuiaInfoDTO dto = new GuiaInfoDTO();
        dto.setNumeroGuia(this.getNumeroGuia());
        dto.setUnidad(this.getUnidad());
        dto.setPlacas(this.getPlacas());
        dto.setIdOperador(this.getIdOperador());
        dto.setRemolque(this.getRemolque());
        dto.setOrigen(this.getOrigen());
        dto.setDestino(this.getDestino());
        dto.setDespacho(this.getDespacho());
        dto.setIdPersonal(this.getIdPersonal());
        dto.setIdOficina(this.getIdOficina());
        dto.setMoneda(this.getMoneda());
        dto.setConversion(this.getConversion());
        dto.setFecha(this.getFecha());
        dto.setHora(this.getHora());
        dto.setStatus(this.getStatus());
        dto.setIdCliente(this.getIdCliente());
        dto.setIdProducto(this.getIdProducto());
        dto.setCita(this.getCita());
        dto.setTipoUnidad(this.getTipoUnidad());
        return dto;
    }
}
