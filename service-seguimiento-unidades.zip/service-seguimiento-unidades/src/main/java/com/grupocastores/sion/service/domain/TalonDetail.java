package com.grupocastores.sion.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.TalonDetailDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "talon_detail")
public class TalonDetail {

    @Id
    @Column(name = "cla_talon")
    private String claveTalon;
    private String idoficina;
    private String tabla;
    private int status;
    private String remision;
    private String serie;
    private double maniobras;
    private int relacion;
    private String tablarel;
    @Column(name = "dirxml")
    private String direccionxml;
    @Column(name = "enviacorreo")
    private boolean enviaCorreo;
    @Column(name = "seenviocorreo")
    private boolean seEnvioCorreo;
    @Column(name = "noaprobacion")
    private String numeroAprobacion;
    @Column(name = "anioaprobacion")
    private String anioAprobacion;
    @Column(name = "nocertificado")
    private String numeroCertificado;
    @Column(name = "idoficinaorigen")
    private String idOficinaOrigen;

    public static TalonDetail fromTalonDetailDTO(TalonDetailDTO talonDetailDTO) {
        TalonDetail talonDetail = new TalonDetail();
        talonDetail.setClaveTalon(talonDetailDTO.getClaTalon());
        talonDetail.setIdoficina(talonDetailDTO.getIdOficina());
        talonDetail.setTabla(talonDetailDTO.getTabla());
        talonDetail.setStatus(talonDetailDTO.getStatus());
        talonDetail.setRemision(talonDetailDTO.getRemision());
        talonDetail.setSerie(talonDetailDTO.getSerie());
        talonDetail.setManiobras(talonDetailDTO.getManiobras());
        talonDetail.setRelacion(talonDetailDTO.getRelacion());
        talonDetail.setTablarel(talonDetailDTO.getTablarel());
        talonDetail.setDireccionxml(talonDetailDTO.getDirxml());
        talonDetail.setEnviaCorreo(talonDetailDTO.isEnviacorreo());
        talonDetail.setSeEnvioCorreo(talonDetailDTO.isSeenviocorreo());
        talonDetail.setNumeroAprobacion(talonDetailDTO.getNoaprobacion());
        talonDetail.setAnioAprobacion(talonDetailDTO.getAnioaprobacion());
        talonDetail.setNumeroCertificado(talonDetailDTO.getNocertificado());
        talonDetail.setIdOficinaOrigen(talonDetailDTO.getIdOficinaOrigen());
        return talonDetail;
    }

    public TalonDetailDTO toTalonDetailDTO() {
        TalonDetailDTO dto = new TalonDetailDTO();
        dto.setClaTalon(this.getClaveTalon());
        dto.setIdOficina(this.getIdoficina());
        dto.setTabla(this.getTabla());
        dto.setStatus(this.getStatus());
        dto.setRemision(this.getRemision());
        dto.setSerie(this.getSerie());
        dto.setManiobras(this.getManiobras());
        dto.setRelacion(this.getRelacion());
        dto.setTablarel(this.getTablarel());
        dto.setDirxml(this.getDireccionxml());
        dto.setEnviacorreo(this.isEnviaCorreo());
        dto.setSeenviocorreo(this.isSeEnvioCorreo());
        dto.setNoaprobacion(this.getNumeroAprobacion());
        dto.setAnioaprobacion(this.getAnioAprobacion());
        dto.setNocertificado(this.getNumeroCertificado());
        dto.setIdOficinaOrigen(this.getIdOficinaOrigen());
        return dto;
    }
}
