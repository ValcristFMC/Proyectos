package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Incidencias", description = "Datos de Incidencias")
public class IncidenciasDTO {
	
	private String idIncidencia;
	private String folioIncidencia;
	private String bultos;
	private String talon;
	private String bultosTotales;
	private String unidad;
	private String proceso;
	private String almacenista;
	private String coordinador;
	private String oficina;
	private String origen;
	private String destino;
	private String fecha;
	private String status;
	private String observaciones;
	private String incidencia;
	
	public IncidenciasDTO (String idIncidencia
			, String folioIncidencia
			, String bultos
			, String talon
			, String bultosTotales
			, String unidad
			, String proceso
			, String almacenista
			, String coordinador
			, String oficina
			, String origen
			, String destino
			, String fecha
			, String status
			, String observaciones
			, String incidencia) {
		this.idIncidencia = idIncidencia;
		this.folioIncidencia = folioIncidencia;
		this.bultos = bultos;
		this.talon = talon;
		this.bultosTotales = bultosTotales;
		this.unidad = unidad;
		this.proceso = proceso;
		this.almacenista = almacenista;
		this.almacenista = coordinador;
		this.oficina = oficina;
		this.origen = origen;
		this.destino = destino;
		this.fecha = fecha;
		this.status = status;
		this.observaciones = observaciones;
		this.incidencia = incidencia;
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Incidencias [idIncidencia=").append(idIncidencia)
		.append(", folioIncidencia=").append(folioIncidencia)
		.append(", bultos=").append(bultos)
		.append(", talon=").append(talon)
		.append(", bultosTotales=").append(bultosTotales)
		.append(", unidad=").append(unidad)
		.append(", proceso=").append(proceso)
		.append(", almacenista=").append(almacenista)
		.append(", coordinador=").append(coordinador)
		.append(", oficina=").append(oficina)
		.append(", origen=").append(origen)
		.append(", destino=").append(destino)
		.append(", fecha=").append(fecha)
		.append(", status=").append(status)
		.append(", observaciones=").append(observaciones)
		.append(", incidencia=").append(incidencia);
		return strBuilder.toString();
	}
}
