package com.grupocastores.sion.service.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.grupocastores.sion.dto.SeguimientoUnidadesDTO;

/**
 * Clase SeguimientoUnidades del dominio tiene su correspondiente {@link SeguimientoUnidadesDTO}
 *
 * @author Castores - Desarrollo TI
 */
@Data
@Entity
@Table(name = "seguimientoUnidades")
@EntityListeners(SeguimientoUnidades.class)
public class SeguimientoUnidades {
	
	private String numeroGuia;
	private int idViaje;
	private String idOficina;
	private String idOficinaGv;
	private String idRuta;
	@Id
	private String idOficinaOrigen;
	private String idOficinaDestino;
	private String idOficinaDestinoGv;
	private String oficinaOrigen;
	private String oficinaDestino;
	private String oficinaDestinoGv;
	private String idUnidad;
	private String tipoUnidad;
	private String folio;
	private int estatus;
	private int estatusGuiaViaje;
	private String estatusViaje;
	private Date fechaViaje;
	private String horaViaje;
	private String claveVehiculo;
	private String numeroSerie;
	private String numeroEconomico;
	private Date fechaPosicion;
	private String posicionVehiculo;
	
	
	/**
	 * Metodo estatico para obtener un SeguimientoUnidades a partir de un SeguimientoUnidadesDTO origen
	 * 
	 * @param seguimientoUnidades SeguimientoUnidadesDTO origen
	 * 
	 * @return SeguimientoUnidades
	 */
	public static SeguimientoUnidades fromSeguimientoUnidadesDTO(SeguimientoUnidadesDTO seguimientoUnidades) {
		SeguimientoUnidades rest = new SeguimientoUnidades();
		rest.setNumeroGuia(seguimientoUnidades.getNumeroGuia());
		rest.setIdViaje(seguimientoUnidades.getIdViaje());
		rest.setIdOficina(seguimientoUnidades.getIdOficina());
		rest.setIdOficinaGv(seguimientoUnidades.getIdOficinaGv());		
		rest.setIdRuta(seguimientoUnidades.getIdRuta());
		rest.setIdOficinaOrigen(seguimientoUnidades.getIdOficinaOrigen());
		rest.setIdOficinaDestino(seguimientoUnidades.getIdOficinaDestino());
		rest.setIdOficinaDestinoGv(seguimientoUnidades.getIdOficinaDestinoGv());
		rest.setOficinaOrigen(seguimientoUnidades.getOficinaOrigen());
		rest.setOficinaDestino(seguimientoUnidades.getOficinaDestino());
		rest.setOficinaDestinoGv(seguimientoUnidades.getOficinaDestinoGv());
		rest.setIdUnidad(seguimientoUnidades.getIdUnidad());
		rest.setTipoUnidad(seguimientoUnidades.getTipoUnidad());
		rest.setFolio(seguimientoUnidades.getFolio());
		rest.setEstatus(seguimientoUnidades.getEstatus());
		rest.setEstatusGuiaViaje(seguimientoUnidades.getEstatusGuiaViaje());
		rest.setEstatusViaje(seguimientoUnidades.getEstatusViaje());
		rest.setFechaViaje(seguimientoUnidades.getFechaViaje());
		rest.setHoraViaje(seguimientoUnidades.getHoraViaje());
		rest.setClaveVehiculo(seguimientoUnidades.getClaveVehiculo());
		rest.setNumeroSerie(seguimientoUnidades.getNumeroSerie());
		rest.setNumeroEconomico(seguimientoUnidades.getNumeroEconomico());
		rest.setFechaPosicion(seguimientoUnidades.getFechaPosicion());
		rest.setPosicionVehiculo(seguimientoUnidades.getPosicionVehiculo());
		return rest;
	}
	
	/**
	 * Metodo para obtener un SeguimientoUnidadesDTO a partir de un SeguimientoUnidades origen
	 * 
	 * @return SeguimientoUnidadesDTO
	 */
	public SeguimientoUnidadesDTO toSeguimientoUnidadesDTO() {
		 SeguimientoUnidadesDTO dto = new  SeguimientoUnidadesDTO();
		 dto.setNumeroGuia(this.getNumeroGuia());
		 dto.setIdViaje(this.getIdViaje());
		 dto.setIdOficina(this.getIdOficina());
		 dto.setIdOficinaGv(this.getIdOficinaGv());
		 dto.setIdRuta(this.getIdRuta());
		 dto.setIdOficinaOrigen(this.getIdOficinaOrigen());
		 dto.setIdOficinaDestino(this.getIdOficinaDestino());
		 dto.setIdOficinaDestinoGv(this.getIdOficinaDestinoGv());
		 dto.setOficinaOrigen(this.getOficinaOrigen());
		 dto.setOficinaDestino(this.getOficinaDestino());
		 dto.setOficinaDestinoGv(this.getOficinaDestinoGv());
		 dto.setIdUnidad(this.getIdUnidad());
		 dto.setTipoUnidad(this.getTipoUnidad());
		 dto.setFolio(this.getFolio());
		 dto.setEstatus(this.getEstatus());
		 dto.setEstatusGuiaViaje(this.getEstatusGuiaViaje());
		 dto.setEstatusViaje(this.getEstatusViaje());
		 dto.setFechaViaje(this.getFechaViaje());
		 dto.setHoraViaje(this.getHoraViaje());
		 dto.setClaveVehiculo(this.getClaveVehiculo());
		 dto.setNumeroSerie(this.getNumeroSerie());
		 dto.setNumeroEconomico(this.getNumeroEconomico());
		 dto.setFechaPosicion(this.getFechaPosicion());
		 dto.setPosicionVehiculo(this.getPosicionVehiculo());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("SeguimientoUnidades [numeroGuia=").append(numeroGuia)
		.append(",idViaje=").append(idViaje)
		.append(",idOficina=").append(idOficina)
		.append(",idOficinaGv=").append(idOficinaGv)
		.append(",idRuta=").append(idRuta)
		.append(",idOficinaOrigen=").append(idOficinaOrigen)
		.append(",idOficinaDestino=").append(idOficinaDestino)
		.append(",idOficinaDestinoGv=").append(idOficinaDestinoGv)
		.append(",oficinaOrigen=").append(oficinaOrigen)
		.append(",oficinaDestino=").append(oficinaDestino)
		.append(",oficinaDestinoGv=").append(oficinaDestinoGv)
		.append(",idUnidad=").append(idUnidad)
		.append(",tipoUnidad=").append(tipoUnidad)
		.append(",folio=").append(folio)
		.append(",estatus=").append(estatus)
		.append(",estatusGuiaViaje=").append(estatusGuiaViaje)
		.append(",estatusViaje=").append(estatusViaje)
		.append(",fechaViaje=").append(fechaViaje)
		.append(",horaViaje=").append(horaViaje)
		.append(",claveVehiculo=").append(claveVehiculo)
		.append(",numeroSerie=").append(numeroSerie)
		.append(",numeroEconomico=").append(numeroEconomico)
		.append(",fechaPosicion=").append(fechaPosicion)
		.append(",posicionVehiculo=").append(posicionVehiculo);
		return strBuilder.toString();
	}
}
