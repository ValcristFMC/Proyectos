package com.grupocastores.sion.service.repository;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.IncidenciasEtiquetaDTO;
import com.grupocastores.sion.service.domain.IncidenciasEtiqueta;

@Repository
public class IncidenciasEtiquetaRepository {

	Logger log = LoggerFactory.getLogger(IncidenciasEtiquetaRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	static final String QUERY = "SELECT * FROM OPENQUERY (PRODUCCION13,'"
			+ " SELECT "
			+ "	bt.folioincidencia_almacen AS folio_incidencia_almacen "
			+ "	, bt.cla_talon AS talon"
			+ "	, \"Etiqueta: \" AS etiqueta "
			+ "	, bt.etiqueta AS numero "
			+ "	, CONCAT(IF(ti.nombre IS NOT NULL, ti.nombre, \"\"), \", \" , IF(dti.descripcion IS NOT NULL, dti.descripcion, \"\") "
			+ "	, \", \" , IF(cdi.nombre IS NOT NULL, cdi.nombre, \"\"), \", \" "
			+ "	, IF(cti.descripcion IS NOT NULL, cti.descripcion, \"\"), \", \" "
			+ "	, IF(mo.nombre IS NOT NULL, mo.nombre, \"\")) AS nombre "
			+ "	FROM seguromercancias.bultoconincidencia bt "
			+ "	LEFT JOIN seguromercancias.tipo_incidencia ti ON bt.motivo_incidencia = ti.idtipo_incidencia "
			+ "	LEFT JOIN seguromercancias.detalle_tipo_incidencia dti ON ti.idtipo_incidencia = dti.idtipoincidencia "
			+ "	LEFT JOIN seguromercancias.catalogo_detalle_incidencia cdi ON dti.idcatalogoincidencia = cdi.id_detalle "
			+ "	LEFT JOIN seguromercancias.catalogo_tipos_incidencia cti ON bt.tipo_incidencia = cti.id_tipo_incidencia "
			+ "	LEFT JOIN seguromercancias.detalle_extra_incidencia dei ON bt.folioincidencia_almacen = dei.folio_incidencia "
			+ "	LEFT JOIN seguromercancias.motivo_incidencia mo ON bt.motivo_incidencia = mo.idmotivo_incidencia "
			+ "	WHERE bt.folioincidencia_almacen = \"%s\";')";

	public List<IncidenciasEtiquetaDTO> getIncidenciasEtiqueta(String folio) {
		String queryString = String.format(QUERY, folio);
		Query query = entityManager.createNativeQuery(queryString, IncidenciasEtiqueta.class);
		List<IncidenciasEtiqueta> lstIncidenciasEtiqueta = Lists
				.newArrayList(Iterables.filter(query.getResultList(), IncidenciasEtiqueta.class));
		List<IncidenciasEtiquetaDTO> lstIncidenciasEtiquetaDTO = lstIncidenciasEtiqueta.stream()
				.map(IncidenciasEtiqueta::toIncidenciasEtiquetaDTO).collect(Collectors.toList());
		return lstIncidenciasEtiquetaDTO;
	}
}
