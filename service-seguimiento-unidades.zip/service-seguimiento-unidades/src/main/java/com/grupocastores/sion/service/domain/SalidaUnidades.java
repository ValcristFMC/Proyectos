package com.grupocastores.sion.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.SalidaUnidadesDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "SalidaUnidades")
@EntityListeners(SalidaUnidades.class)
public class SalidaUnidades {
	
	@Id
	@Column(name = "id_ruta")
	Integer idRuta;
	Integer consecutivo;
	Integer dia;
	@Column(name = "hora_llegada")
	String horaLlegada;
	@Column(name = "hora_salida")
	String horaSalida;
	@Column(name = "dia_fecha")
	String diaFecha;
	String plaza;
	
	public static SalidaUnidades fromUSalidaUnidadesDTO(SalidaUnidades salidaUnidades) {
		SalidaUnidades rest = new SalidaUnidades();
		rest.setIdRuta(salidaUnidades.getIdRuta());
		rest.setConsecutivo(salidaUnidades.getConsecutivo());
		rest.setDia(salidaUnidades.getDia());
		rest.setHoraLlegada(salidaUnidades.getHoraLlegada());	
		rest.setHoraSalida(salidaUnidades.getHoraSalida());
		rest.setDiaFecha(salidaUnidades.getDiaFecha());
		rest.setPlaza(salidaUnidades.getPlaza());
		return rest;
	}
	
	public SalidaUnidadesDTO toSalidaUnidadesDTO() {
		SalidaUnidadesDTO dto = new  SalidaUnidadesDTO();
		 dto.setIdruta(this.idRuta);
		 dto.setConsecutivo(this.consecutivo);
		 dto.setDia(this.dia);
		 dto.setHorallegada(this.horaLlegada);
		 dto.setHorasalida(this.horaSalida);
		 dto.setDiafecha(this.diaFecha);
		 dto.setPlaza(this.plaza);
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("SalidaUnidades [idruta=").append(idRuta)
		.append(",consecutivo=").append(consecutivo)
		.append(",dia=").append(dia)
		.append(",horallegada=").append(horaLlegada)
		.append(",horasalida=").append(horaSalida)
		.append(",diafecha=").append(diaFecha)
		.append(",plaza=").append(plaza);
		return strBuilder.toString();
	}

}
