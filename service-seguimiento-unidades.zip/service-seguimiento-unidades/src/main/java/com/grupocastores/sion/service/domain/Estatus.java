package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.EstatusDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "estatus")
@EntityListeners(Estatus.class)
public class Estatus {
	
	@Id
	private int idEstatusViajes;
	private String nombre;
	
	
	/**
	 * Metodo estatico para obtener un Estatus a partir de un EstatusDTO estatus
	 * 
	 * @param estatus EstatusDTO estatus
	 * 
	 * @return Estatus
	 */
	public static Estatus fromEstatusDTO(EstatusDTO estatus) {
		Estatus rest = new Estatus();
		rest.setIdEstatusViajes(estatus.getIdEstatusViajes());
		rest.setNombre(estatus.getNombre());
		return rest;
	}
	
	/**
	 * Metodo para obtener un EstatusDTO a partir de un Estatus origen
	 * 
	 * @return EstatusDTO
	 */
	public EstatusDTO toEstatusDTO() {
		EstatusDTO dto = new  EstatusDTO();
		 dto.setIdEstatusViajes(this.getIdEstatusViajes());
		 dto.setNombre(this.getNombre());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Estatus [idEstatusViajes=").append(idEstatusViajes)
		.append(",nombre=").append(nombre);
		return strBuilder.toString();
	}
}
