package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.SemaforoDTO;

public interface ISemaforoService {

	public List<SemaforoDTO> getSemaforoByViajeFecha(String fechaMod, String idViaje, String idOficina);
}
