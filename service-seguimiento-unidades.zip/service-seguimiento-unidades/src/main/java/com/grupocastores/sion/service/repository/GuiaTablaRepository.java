package com.grupocastores.sion.service.repository;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.GuiaTablaDTO;
import com.grupocastores.sion.service.domain.GuiaTabla;

@Repository
public class GuiaTablaRepository {

	Logger log = LoggerFactory.getLogger(GuiasRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	static final String QUERY = "SELECT * FROM OPENQUERY (PRODUCCION23,'"
			+ "SELECT "
			+ "	gv.idviaje AS id_viaje "
			+ "	, gv.idoficina AS id_oficina "
			+ "	, gv.idoficinaguia AS id_oficina_guia "
			+ "	, gv.idoficinadestino AS id_oficina_destino "
			+ "	, (SELECT plaza FROM castores.oficinas o WHERE o.idoficina = gv.idoficina) AS oficina "
			+ "	, (SELECT plaza FROM castores.oficinas o WHERE o.idoficina = gv.idoficinaguia) AS oficina_guia "
			+ "	, (SELECT plaza FROM castores.oficinas o WHERE o.idoficina = gv.idoficinadestino) AS oficina_destino "
			+ "	, g.no_guia AS numero_guia "
			+ "	, gv.estatusguia AS estatus_guia "
			+ "	, gv.estatus AS estatus "
			+ "	, g.status AS status "
			+ "	, (SELECT nombre FROM talones.estatusviajes e WHERE e.idestatusviajes = gv.estatusguia) AS estatus_guia_viaje "
			+ "	, (SELECT nombre FROM talones.estatusviajes e WHERE e.idestatusviajes = gv.estatus) AS estatus_viaje "
			+ "	, (SELECT nombre FROM talones.estatusviajes e WHERE e.idestatusviajes = g.status) AS status_viaje "
			+ "	, g.tabla AS tabla "
			+ "	, g.unidad As unidad "
			+ "	FROM talones.guias g " + "	INNER JOIN talones.guiaviaje gv ON gv.no_guia = g.no_guia "
			+ "	WHERE (gv.fechamod BETWEEN \"%s\" AND \"%s\");')";

	public List<GuiaTablaDTO> getGuiaTabla(String fechaInicial, String fechaFinal) {
		String queryString = String.format(QUERY, fechaInicial, fechaFinal);
		Query query = entityManager.createNativeQuery(queryString, GuiaTabla.class);
		List<GuiaTabla> lstGuiaTabla = Lists.newArrayList(Iterables.filter(query.getResultList(), GuiaTabla.class));
		List<GuiaTablaDTO> lstGuiaTablaDTO = lstGuiaTabla.stream().map(GuiaTabla::toGuiaTablaDTO)
				.collect(Collectors.toList());
		return lstGuiaTablaDTO;
	}
}
