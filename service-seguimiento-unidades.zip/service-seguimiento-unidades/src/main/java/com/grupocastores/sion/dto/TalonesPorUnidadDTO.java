package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Talones por unidad", description = "Datos de las unidades")
public class TalonesPorUnidadDTO {

	private String claveTalon;
	private Integer bultos;
	private String empaque;
	private String contiene;
	private String origen;
	private String destinatario;
	private String tipoPago;
	private Integer incidencias;
	
	public TalonesPorUnidadDTO (String cla_talon,Integer bultos,String empaque,String contiene,String origen, String destinatario, String tipoPago, Integer incidencias) {
		this.claveTalon = cla_talon;
		this.bultos = bultos;
		this.empaque = empaque;
		this.contiene = contiene;
		this.origen=origen;
		this.destinatario = destinatario;
		this.tipoPago =tipoPago;
		this.incidencias=incidencias;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("UnidadesPorOficina [cla_talon=").append(claveTalon)	
		.append(", bultos=").append(bultos)
		.append(", empaque=").append(empaque)
		.append(", contiene=").append(contiene)
		.append(", origen=").append(origen)
		.append(", destinatario=").append(destinatario)
		.append(", tipoPago=").append(tipoPago)
		.append(", incidencias=").append(incidencias);
		return strBuilder.toString();
	}
	
	
}
