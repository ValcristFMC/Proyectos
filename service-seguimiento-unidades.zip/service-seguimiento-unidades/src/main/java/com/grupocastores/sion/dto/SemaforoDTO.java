package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Semaforo", description = "Datos de Semaforo")
public class SemaforoDTO {
	
	private String idViaje;
	private int idEstatusGuiaViaje;
	private int idEstatusGuia;
	private int idEstatusViaje;
	private int idEstatusGeocerca;
	private String estatusGuia;
	private String estatus;
	private String estatusViaje;
	private String estatusViajeGeocerca;
	private String idOficinaOrigen;
	private String idOficinaDestino;
	private String idOficinaDestinoViaje;
	private String oficinaOrigenViaje;
	private String oficinaDestinoGuia;
	private String oficinaDestinoViaje;
	private String numeroLatitudVehiculo;
	private String numeroLongitudVehiculo;
	private String longitud;
	private String latitud;
	private String estatusLlegadaSalida;
	private String fechaHoraSalida;
	private String horaLlegada;
	private String horaSalida;
	private String kilometros;

	public SemaforoDTO (String idViaje
			, int idEstatusGuiaViaje
			, int idEstatusGuia
			, int idEstatusViaje
			, int idEstatusGeocerca
			, String estatusGuia
			, String estatus
			, String estatusViaje
			, String estatusViajeGeocerca
			, String idOficinaOrigen
			, String idOficinaDestino
			, String idOficinaDestinoViaje
			, String oficinaOrigenViaje
			, String oficinaDestinoGuia
			, String oficinaDestinoViaje
			, String numeroLatitudVehiculo
			, String numeroLongitudVehiculo
			, String longitud
			, String latitud
			, String estatusLlegadaSalida
			, String fechaHoraSalida
			, String horaLlegada
			, String horaSalida
			, String kilometros) {
		this.idViaje = idViaje;
		this.idEstatusGuiaViaje = idEstatusGuiaViaje;
		this.idEstatusGuia = idEstatusGuia;
		this.idEstatusViaje = idEstatusViaje;
		this.idEstatusGeocerca = idEstatusGeocerca;
		this.estatusGuia = estatusGuia;
		this.estatus = estatus;
		this.estatusViaje = estatusViaje;
		this.estatusViajeGeocerca = estatusViajeGeocerca;
		this.idOficinaOrigen = idOficinaOrigen;
		this.idOficinaDestino = idOficinaDestino;
		this.idOficinaDestinoViaje = idOficinaDestinoViaje;
		this.oficinaOrigenViaje = oficinaOrigenViaje;
		this.oficinaDestinoGuia = oficinaDestinoGuia;
		this.oficinaDestinoViaje = oficinaDestinoViaje;
		this.numeroLatitudVehiculo = numeroLatitudVehiculo;
		this.numeroLongitudVehiculo = numeroLongitudVehiculo;
		this.longitud = longitud;
		this.latitud = latitud;
		this.estatusLlegadaSalida = estatusLlegadaSalida;
		this.fechaHoraSalida = fechaHoraSalida;
		this.horaLlegada = horaLlegada;
		this.horaSalida = horaSalida;
		this.kilometros = kilometros;
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Semaforo [idViaje=").append(idViaje)
		.append(", idEstatusGuiaViaje=").append(idEstatusGuiaViaje)
		.append(", idEstatusGuia=").append(idEstatusGuia)
		.append(", idEstatusViaje=").append(idEstatusViaje)
		.append(", idEstatusGeocerca=").append(idEstatusGeocerca)
		.append(", estatusGuia=").append(estatusGuia)
		.append(", estatus=").append(estatus)
		.append(", estatusViaje=").append(estatusViaje)
		.append(", estatusViajeGeocerca=").append(estatusViajeGeocerca)
		.append(", idOficinaOrigen=").append(idOficinaOrigen)
		.append(", idOficinaDestino=").append(idOficinaDestino)
		.append(", idOficinaDestinoViaje=").append(idOficinaDestinoViaje)
		.append(", oficinaOrigenViaje=").append(oficinaOrigenViaje)
		.append(", oficinaDestinoGuia=").append(oficinaDestinoGuia)
		.append(", oficinaDestinoViaje=").append(oficinaDestinoViaje)
		.append(", numeroLatitudVehiculo=").append(numeroLatitudVehiculo)
		.append(", numeroLongitudVehiculo=").append(numeroLongitudVehiculo)
		.append(", longitud=").append(longitud)
		.append(", latitud=").append(latitud)
		.append(", estatusLlegadaSalida=").append(estatusLlegadaSalida)
		.append(", fechaHoraSalida=").append(fechaHoraSalida)
		.append(", horaLlegada=").append(horaLlegada)
		.append(", horaSalida=").append(horaSalida)
		.append(", kilometros=").append(kilometros);
		return strBuilder.toString();
	}
}
