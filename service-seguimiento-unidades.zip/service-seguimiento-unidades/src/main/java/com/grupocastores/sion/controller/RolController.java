package com.grupocastores.sion.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.grupocastores.sion.dto.ResponseDTO;
import com.grupocastores.sion.service.IRolService;
import com.grupocastores.sion.service.domain.UsuarioRolSion;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/sion")
@Api(value = "RolController", produces = "application/json")
public class RolController {

    Logger log = LoggerFactory.getLogger(RolController.class);

    @Autowired
    private IRolService rolService;

    static final String HEADERBACK = "/sion/{id}";
    private Map<String, Object> response;

    @ApiOperation(value = "Recupera los roles de un usuario")
    @ApiResponses(value = { 
        @ApiResponse(code = 200, message = "Roles obtenidos correctamente", response = UsuarioRolSion.class),
        @ApiResponse(code = 500, message = "Error al obtener roles", response = ResponseDTO.class),
        @ApiResponse(code = 401, message = "No autorizado", response = ResponseDTO.class),
        @ApiResponse(code = 403, message = "Acceso prohibido", response = ResponseDTO.class),
        @ApiResponse(code = 404, message = "Recurso no encontrado", response = ResponseDTO.class) 
    })
    @HystrixCommand(fallbackMethod = "fallBackMethod")
    @GetMapping(value = "/getRolesByUsuario", produces = "application/json;charset=UTF-8")
    public ResponseEntity<?> getRolesByUsuario(@RequestParam(name = "idUsuario") Long idUsuario) {
        UsuarioRolSion rol;
        try {
        	rol = rolService.getRolesByUsuarioId(idUsuario);
        } catch (Exception e) {
            response = new HashMap<String, Object>();
            response.put("error", "Error al obtener roles del usuario");
            response.put("message", e.getMessage());
            response.put("class", this.getClass());
            return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return ResponseEntity.ok(rol);
    }

    public ResponseEntity<?> fallBackMethod(Long idUsuario, Throwable e) {
        response = new HashMap<String, Object>();
        response.put("error", "Servicio no disponible temporalmente");
        response.put("message", e.getMessage());
        response.put("class", this.getClass());
        return new ResponseEntity<Map<String, Object>>(response, HttpStatus.SERVICE_UNAVAILABLE);
    }
}
