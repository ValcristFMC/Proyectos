package com.grupocastores.sion.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.grupocastores.sion.dto.IncidenciasEtiquetaDTO;
import com.grupocastores.sion.dto.ResponseDTO;
import com.grupocastores.sion.service.IIncidenciasEtiquetaService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/sion")
@Api(value = "IncidenciasEtiquetaController", produces = "application/json")
public class IncidenciasEtiquetaController {

	Logger log = LoggerFactory.getLogger(IncidenciasEtiquetaController.class);

	@Autowired
	private IIncidenciasEtiquetaService incidenciasEtiquetaService;
	static final String HEADERBACK = "/sion/{id}";
	private Map<String, Object> response;

	@ApiOperation(value = "Recupera Etiquetas de Incidencias")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Etiquetas de incidencias obtenidas", response = IncidenciasEtiquetaDTO.class),
			@ApiResponse(code = 500, message = "No encontrados", response = ResponseDTO.class),
			@ApiResponse(code = 401, message = "No esta autorizado para acceder a este recurso.", response = ResponseDTO.class),
			@ApiResponse(code = 403, message = "El cliente tiene autenticación valida, pero no esta autorizda la petición al recurso", response = ResponseDTO.class),
			@ApiResponse(code = 404, message = "El servidor no encuentra la petición al recurso", response = ResponseDTO.class) })
	@HystrixCommand(fallbackMethod = "fallBackMethod")
	@GetMapping(value = "/getIncidenciasEtiqueta", params = { "folio" }, produces = "application/json;charset=UTF-8")
	public ResponseEntity<?> getIncidenciasEtiqueta(@RequestParam(name = "folio") String folio) {
		List<IncidenciasEtiquetaDTO> lstIncidenciasEtiqueta;
		try {

			lstIncidenciasEtiqueta = incidenciasEtiquetaService.getIncidenciasEtiquetaByFolio(folio);

		} catch (Exception e) {
			response = new HashMap<String, Object>();
			response.put("error", "Error en getIncidenciasEtiqueta()");
			response.put("message", e.getMessage());
			response.put("class", this.getClass());
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return ResponseEntity.ok(lstIncidenciasEtiqueta);
	}
}
