package com.grupocastores.sion.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UnidadUbicacionDTO {

    private String claveUnidad;
    private String plaza;
    private Double latitudUnidad;
    private Double longitudUnidad;
    private Double latitudOficina;
    private Double longitudOficina;
    private String mensaje;

    public UnidadUbicacionDTO(String claveUnidad, Double latitudUnidad, Double longitudUnidad, Double latitudOficina, Double longitudOficina, String plaza) {
        this.claveUnidad = claveUnidad;
        this.plaza = plaza;
        this.latitudUnidad = latitudUnidad;
        this.longitudUnidad = longitudUnidad;
        this.latitudOficina = latitudOficina;
        this.longitudOficina = longitudOficina;
        this.mensaje = calcularMensaje();
    }

    private String calcularMensaje() {
        return "Unidad " + claveUnidad + " ubicada en (" + latitudUnidad + ", " + longitudUnidad + ")";
    }

    @Override
    public String toString() {
        return "UnidadUbicacionDTO{" +
                "claveUnidad='" + claveUnidad + '\'' +
                ", plaza='" + plaza + '\'' +
                ", latitudUnidad=" + latitudUnidad +
                ", longitudUnidad=" + longitudUnidad +
                ", latitudOficina=" + latitudOficina +
                ", longitudOficina=" + longitudOficina +
                ", mensaje='" + mensaje + '\'' +
                '}';
    }
}
