package com.grupocastores.sion.service.repository;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.IncidenciasDTO;
import com.grupocastores.sion.service.domain.Incidencias;

@Repository
public class IncidenciasRepository {

	Logger log = LoggerFactory.getLogger(IncidenciasRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	static final String QUERY = "SELECT * FROM OPENQUERY (PRODUCCION13,'"
			+ " SELECT DISTINCT "
			+ "	inci.idincidencia AS id_incidencia "
			+ "	, inci.folio AS folio_incidencia "
			+ "	, (SELECT DISTINCT COUNT(*) FROM seguromercancias.bultoconincidencia sb "
			+ "	WHERE sb.folioincidencia_almacen = inci.folio) AS bultos "
			+ "	, inci.cla_talon AS talon "
			+ "	, bultos_totales AS bultos_totales "
			+ "	, unidad AS unidad "
			+ "	, tp.nombre AS proceso "
			+ "	, CONCAT(p.nombre,\" \",p.apepaterno,\" \",p.apematerno) AS almacenista "
			+ "	, (	SELECT CONCAT_WS(\" \", pp.nombre, pp.apepaterno, pp.apematerno) "
			+ "	FROM seguromercancias.incidencia_seguimiento isg  "
			+ "	INNER JOIN personal.personal pp ON pp.idpersonal = isg.personal "
			+ "	WHERE isg.folio	= inci.folio LIMIT 1 ) AS coordinador "
			+ "	, of.plaza AS oficina "
			+ "	, ci.nombre AS origen "
			+ "	, c.nombre AS destino "
			+ "	, inci.fechahora AS fecha "
			+ "	, inci.estatus AS STATUS "
			+ "	, dei.observaciones AS observaciones "
			+ "	, cti.descripcion AS incidencia "
			+ "	FROM seguromercancias.incidencia_almacen inci "
			+ "	LEFT JOIN seguromercancias.bultoconincidencia binci ON inci.folio = binci.folioincidencia_almacen "
			+ "	LEFT JOIN seguromercancias.catalogo_tipos_incidencia cti ON inci.idtipoincidencia = cti.id_tipo_incidencia "
			+ "	LEFT JOIN personal.personal p ON inci.idalmacenista = p.idpersonal "
			+ "	LEFT JOIN seguromercancias.tipo_incidencia mot ON inci.idtipoincidencia = mot.idtipo_incidencia "
			+ "	LEFT JOIN castores.oficinas of ON of.idoficina = inci.idsucursal "
			+ "	LEFT JOIN camiones.ciudades ci ON inci.idorigen = ci.idciudad "
			+ "	LEFT JOIN camiones.ciudades c ON inci.iddestino = c.idciudad "
			+ "	LEFT JOIN seguromercancias.detalle_extra_incidencia dei ON inci.folio = dei.folio_incidencia "
			+ "	LEFT JOIN seguromercancias.detalle_tipo_incidencia dti ON mot.idtipo_incidencia = dti.idtipoincidencia "
			+ "	LEFT JOIN seguromercancias.catalogo_detalle_incidencia cdi ON dti.idcatalogoincidencia = cdi.id_detalle "
			+ "	LEFT JOIN seguromercancias.tipo_proceso tp ON tp.idtipo_proceso = inci.proceso AND tp.estatus = 1 "
			+ "	WHERE inci.estatus IN (1, 2) AND inci.cla_talon = \"%s\";')";

	public List<IncidenciasDTO> getIncidencias(String talon) {
		String queryString = String.format(QUERY, talon);
		Query query = entityManager.createNativeQuery(queryString, Incidencias.class);
		List<Incidencias> lstIncidencias = Lists
				.newArrayList(Iterables.filter(query.getResultList(), Incidencias.class));
		List<IncidenciasDTO> lstIncidenciasDTO = lstIncidencias.stream().map(Incidencias::toIncidenciasDTO)
				.collect(Collectors.toList());
		return lstIncidenciasDTO;
	}
}
