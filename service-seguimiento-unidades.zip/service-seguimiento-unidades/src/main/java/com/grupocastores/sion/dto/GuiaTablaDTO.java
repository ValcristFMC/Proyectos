package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de GuiasTabla", description = "Datos de GuiasTabla")
public class GuiaTablaDTO {
	
	private String idViaje;
	private String idOficina;
	private String idOficinaGuia;
	private String idOficinaDestino;
	private String oficina;
	private String oficinaGuia;
	private String oficinaDestino;
	private String numeroGuia;
	private int estatusGuia;
	private int estatus;
	private int status;
	private String estatusGuiaViaje;
	private String estatusViaje;
	private String statusViaje;
	private String tabla;
	private String unidad;
	
	public GuiaTablaDTO (String idViaje
			, String idOficina
			, String idOficinaGuia
			, String idOficinaDestino
			, String oficina
			, String oficinaGuia
			, String oficinaDestino
			, String numeroGuia
			, int estatusGuia
			, int estatus
			, int status
			, String estatusGuiaViaje
			, String estatusViaje
			, String statusViaje) {
		this.idViaje = idViaje;
		this.idOficina = idOficina;
		this.idOficinaGuia = idOficinaGuia;
		this.idOficinaDestino = idOficinaDestino;
		this.oficina = oficina;
		this.oficinaGuia = oficinaGuia;
		this.oficinaDestino = oficinaDestino;
		this.numeroGuia = numeroGuia;
		this.estatusGuia = estatusGuia;
		this.estatus = estatus;
		this.status = status;
		this.estatusGuiaViaje = estatusGuiaViaje;
		this.estatusViaje = estatusViaje;
		this.statusViaje = statusViaje;
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("GuiaTabla [idViaje=").append(idViaje)
		.append(", idOficina=").append(idOficina)	
		.append(", idOficinaGuia=").append(idOficinaGuia)
		.append(", idOficinaDestino=").append(idOficinaDestino)
		.append(", oficina=").append(oficina)
		.append(", oficinaGuia=").append(oficinaGuia)
		.append(", oficinaDestino=").append(oficinaDestino)
		.append(", numeroGuia=").append(numeroGuia)
		.append(", estatusGuia=").append(estatusGuia)	
		.append(", estatus=").append(estatus)
		.append(", status=").append(status)
		.append(", estatusGuiaViaje=").append(estatusGuiaViaje)
		.append(", estatusViaje=").append(estatusViaje)
		.append(", statusViaje=").append(statusViaje);
		return strBuilder.toString();
	}
}
