package com.grupocastores.sion.service.repository;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.GuiaDTO;
import com.grupocastores.sion.dto.GuiaInfoDTO;
import com.grupocastores.sion.dto.GuiaStatusDTO;
import com.grupocastores.sion.dto.TalonDetailDTO;
import com.grupocastores.sion.dto.TalonGuiaDTO;
import com.grupocastores.sion.service.domain.Guia;
import com.grupocastores.sion.service.domain.GuiaInfo;
import com.grupocastores.sion.service.domain.GuiaStatus;
import com.grupocastores.sion.service.domain.SalidaUnidades;
import com.grupocastores.sion.service.domain.TalonDetail;
import com.grupocastores.sion.service.domain.TalonGuia;
import com.grupocastores.sion.service.domain.TalonesPorUnidad;
import com.grupocastores.sion.service.domain.UnidadesPorOficina;
import com.grupocastores.sion.utils.UtilitiesRepository;

@Repository
public class TalonesUnidadRepositorya {
    Logger log = LoggerFactory.getLogger(TalonesUnidadRepositorya.class);
    
    @PersistenceContext
    private EntityManager entityManager;

            static final String QUERY_GETGUIAS = "SELECT * FROM OPENQUERY (%s, 'SELECT "
            + "g.idviaje AS id_viaje, "
            + "g.idoficina AS id_oficina, "
            + "g.no_guia AS no_guia, "
            + "g.idoficinaguia AS id_oficina_guia, "
            + "g.estatusguia AS estatus_guia, "
            + "g.consecutivo AS consecutivo, "
            + "g.impresionpreguia AS impresion_pre_guia, "
            + "g.impresionguia AS impresion_guia, "
            + "g.estatus AS estatus, "
            + "g.idpersonal AS id_personal, "
            + "g.fechamod AS fecha_mod, "
            + "g.horamod AS hora_mod, "
            + "g.totalguia AS total_guia, "
            + "g.idoficinadeposito AS id_oficina_deposito, "
            + "g.totaldeposito AS total_deposito, "
            + "g.operacionguia AS operacion_guia, "
            + "g.idoficinadestino AS id_oficina_destino, "
            + "g.visitada AS visitada "
            + "FROM talones.guiaviaje g "
            + "INNER JOIN talones.viajes v ON v.idviaje = g.idviaje "
            + "INNER JOIN camiones.unidades u ON u.unidad = v.idunidad "
            + "WHERE g.fechamod > CURDATE() - 7   AND u.noeconomico = \"%s\" AND g.idoficinadestino IN (%s)');";
    
    static final String QUERY_GETGUIASBYNOGUIA = "SELECT * FROM OPENQUERY (%s, 'SELECT "
            + "g.no_guia AS numero_guia, "
            + "g.tabla AS tabla, "
            + "g.unidad AS unidad, "
            + "g.status AS status, "
            + "g.idliquidacion AS id_liquidacion, "
            + "g.anioliq AS anio_liquidacion "
            + "FROM talones.guias g "
            + "WHERE no_guia IN (%s) "
            + "ORDER BY no_guia;');";

    static final String QUERY_GETINFOGUIAS = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.gu%s WHERE no_guia IN (%s);');";

    static final String QUERY_GETINFOTALONES = "SELECT * FROM OPENQUERY (%s, 'SELECT "
        + "t.cla_talon AS cla_talon, "
        + "t.no_guia AS numero_guia, "
        + "t.norenglon AS numero_renglon "
        + "FROM talones.tg%s t "
        + "WHERE t.no_guia IN (%s);');";

    static final String QUERY_GETINFOTALON = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.talones WHERE cla_talon IN(%s);');";

    static final String QUERY_GETTALONESOCURRE = "SELECT * FROM OPENQUERY (%s, 'SELECT tr.cla_talon, SUM(bultos) AS bultos, co.empaque, co.que_contiene AS contiene, o.`plaza` AS origen, tr.`nomdestino` AS destinatario,tp.tipopago AS tipo_pago, 0 AS Incidencias "
    	+ "FROM talones.tr%s AS tr\r\n"
    	+ "INNER JOIN talones.co%s AS co ON tr.cla_talon = co.cla_talon "
    	+ "INNER JOIN talones.tipodepago tp ON tp.idtipopago = tr.tipopago "
    	+ "INNER JOIN personal.`oficinas` o ON o.`idoficina` = tr.`idoficina`"
        + "WHERE tr.ocurre = 1 AND tr.cla_talon IN(%s) GROUP BY tr.cla_talon, o.`plaza`, tr.`nomdestino`, tp.tipopago;');";

    static final String QUERY_GETUNIDADES = "SELECT * FROM OPENQUERY (%s, 'SELECT DISTINCT c.noeconomico AS unidad, es.nombre AS estatus, "
    		+" v.idviaje as id_viaje, v.idoficina as id_oficina, v.idruta AS id_ruta "
    		+ "FROM talones.viajes v "
    		+ "INNER JOIN camiones.camiones c ON c.unidad = v.idunidad "
    		+ "INNER JOIN talones.estatusviajes es ON es.idestatusviajes= v.estatus "
    		+ "INNER JOIN talones.guiaviaje gv ON v.idviaje = gv.idviaje "
    		+ "INNER JOIN talones.guias t ON t.no_guia = gv.no_guia "
    		+ "INNER JOIN talones.guiaviaje tg ON tg.no_guia= t.no_guia AND t.unidad = c.unidad "
    		+ "INNER JOIN talones.destinosviaje dv ON dv.idviaje = v.idviaje AND dv.idoficina = v.idoficina"
    		+" WHERE  v.fechamod > CURDATE() - 7 AND  v.estatus IN (2,4,5) AND gv.operacionguia=1  AND (v.idoficinadestino IN (%s) OR v.idoficinaorigen IN (%s) OR dv.destino IN (%s))');";
    

	static final String QUERY_GETINCIDENCIAS = "SELECT * FROM OPENQUERY (%s, 'SELECT count(*) FROM seguromercancias.incidencia_almacen WHERE cla_talon IN (\"%s\") AND estatus IN (1, 2);');";

    static final String QUERY_GETGUIASBYVIAJE  = "SELECT * FROM OPENQUERY (%s, 'SELECT "
                + "g.idviaje AS id_viaje, "
                + "g.idoficina AS id_oficina, "
                + "g.no_guia AS no_guia, "
                + "g.idoficinaguia AS id_oficina_guia, "
                + "g.estatusguia AS estatus_guia, "
                + "g.consecutivo AS consecutivo, "
                + "g.impresionpreguia AS impresion_pre_guia, "
                + "g.impresionguia AS impresion_guia, "
                + "g.estatus AS estatus, "
                + "g.idpersonal AS id_personal, "
                + "g.fechamod AS fecha_mod, "
                + "g.horamod AS hora_mod, "
                + "g.totalguia AS total_guia, "
                + "g.idoficinadeposito AS id_oficina_deposito, "
                + "g.totaldeposito AS total_deposito, "
                + "g.operacionguia AS operacion_guia, "
                + "g.idoficinadestino AS id_oficina_destino, "
                + "g.visitada AS visitada "
                + "FROM talones.guiaviaje g  WHERE g.idviaje = \"%s\" AND g.idoficina = \"%s\" AND g.idoficinadestino = \"%s\"');";

    static final String QUERY_GETTABLAS = "SELECT * FROM OPENQUERY (%s, 'SELECT DISTINCT tabla FROM talones.guias WHERE no_guia IN (%s);');";
    static final String QUERY_GETMONEDA = "SELECT * FROM OPENQUERY (%s, 'SELECT moneda FROM talones.gu%s WHERE no_guia IN (%s) and moneda = 1;');";

	static final String QUERY_GETSALIDAUNIDADES = "SELECT * FROM OPENQUERY (%s, 'SELECT cr.idruta AS id_ruta, cr.consecutivo, cr.dia, cr.horallegada AS hora_llegada, cr.horasalida AS hora_salida, cr.diafecha AS dia_fecha , dv.destino AS plaza "
			    + "FROM talones.cuerpo_ruta_circuito cr "
			    + "LEFT JOIN talones.destinosviaje dv ON dv.consecutivo = cr.consecutivo "
			    + "LEFT JOIN personal.oficinas o ON o.idoficina IN (%s) "
			    + "WHERE cr.idruta = \"%s\"  AND dv.idviaje = \"%s\" AND dv.idoficina = \"%s\" AND (dv.destino IN (%s) OR o.idciudad = dv.destino) LIMIT 1;')";
	
	
    public List<GuiaDTO> getGuias(String noeconomico, String idOficinaDestino) {
        String queryString = String.format(QUERY_GETGUIAS, UtilitiesRepository.getDb23(), noeconomico, idOficinaDestino);
        Query query = entityManager.createNativeQuery(queryString, Guia.class);
        List<Guia> lstGuias = Lists.newArrayList(Iterables.filter(query.getResultList(), Guia.class));
        List<GuiaDTO> lstGuiasDTO = lstGuias.stream().map(Guia::toGuiaDTO).collect(Collectors.toList());
        return lstGuiasDTO;
    }

    public List<GuiaDTO> getGuiasByViaje(String idViaje, String idOficina, String idOficinaDestino) {
        String queryString = String.format(QUERY_GETGUIASBYVIAJE, UtilitiesRepository.getDb23(), idViaje, idOficina,idOficinaDestino);
        Query query = entityManager.createNativeQuery(queryString, Guia.class);
        List<Guia> lstGuias = Lists.newArrayList(Iterables.filter(query.getResultList(), Guia.class));
        List<GuiaDTO> lstGuiasDTO = lstGuias.stream().map(Guia::toGuiaDTO).collect(Collectors.toList());
        return lstGuiasDTO;
    }

    public List<String> getTablas(String noGuia) {
        String queryString = String.format(QUERY_GETTABLAS, UtilitiesRepository.getDb23(), noGuia);
        Query query = entityManager.createNativeQuery(queryString);
        List<String> lstTablas = Lists.newArrayList(Iterables.filter(query.getResultList(), String.class));
        return lstTablas;
    }

    public int getMoneda(String noGuia, String tabla) {
        String queryString = String.format(QUERY_GETMONEDA, UtilitiesRepository.getDb23(), tabla, noGuia);
        Query query = entityManager.createNativeQuery(queryString);
        List<Integer> lstMonedas = Lists.newArrayList(Iterables.filter(query.getResultList(), Integer.class));
        return lstMonedas.isEmpty() ? 0 : lstMonedas.get(0);
    }

    
    public List<GuiaStatusDTO> getGuiasByNoGuia(String noGuia) {
        String queryString = String.format(QUERY_GETGUIASBYNOGUIA, UtilitiesRepository.getDb23(), noGuia);
        Query query = entityManager.createNativeQuery(queryString, GuiaStatus.class);
        List<GuiaStatus> lstGuias = Lists.newArrayList(Iterables.filter(query.getResultList(), GuiaStatus.class));
        List<GuiaStatusDTO> lstGuiasDTO = lstGuias.stream().map(GuiaStatus::toGuiaStatusDTO).collect(Collectors.toList());
        return lstGuiasDTO;
    }

    public List<GuiaInfoDTO> getInfoGuias(String noGuia, String numeroTabla) {
        String queryString = String.format(QUERY_GETINFOGUIAS, UtilitiesRepository.getDb23(), numeroTabla, noGuia);
        Query query = entityManager.createNativeQuery(queryString, GuiaInfo.class);
        List<GuiaInfo> lstGuias = Lists.newArrayList(Iterables.filter(query.getResultList(), GuiaInfo.class));
        List<GuiaInfoDTO> lstGuiasDTO = lstGuias.stream().map(GuiaInfo::toGuiaInfoDTO).collect(Collectors.toList());
        return lstGuiasDTO;
    }

    public List<TalonGuiaDTO> getInfoTalones(String noGuia, String numeroTabla) {
        String queryString = String.format(QUERY_GETINFOTALONES, UtilitiesRepository.getDb23(), numeroTabla, noGuia);
        Query query = entityManager.createNativeQuery(queryString, TalonGuia.class);
        List<TalonGuia> lstTalones = Lists.newArrayList(Iterables.filter(query.getResultList(), TalonGuia.class));
        List<TalonGuiaDTO> lstTalonesDTO = lstTalones.stream().map(TalonGuia::toTalonInfoDTO).collect(Collectors.toList());
        return lstTalonesDTO;
    }

    public List<TalonDetailDTO> getInfoTalon(String claTalon) {
        String queryString = String.format(QUERY_GETINFOTALON, UtilitiesRepository.getDb23(), claTalon);
        Query query = entityManager.createNativeQuery(queryString, TalonDetail.class);
        List<TalonDetail> lstTalones = Lists.newArrayList(Iterables.filter(query.getResultList(), TalonDetail.class));
        List<TalonDetailDTO> lstTalonesDTO = lstTalones.stream().map(TalonDetail::toTalonDetailDTO).collect(Collectors.toList());
        return lstTalonesDTO;
    }

    public List<TalonesPorUnidad> getTalonesTr(String claTalon, String numeroTabla) {
        Query queryTalonesPorUnidad = entityManager.createNativeQuery(String.format(QUERY_GETTALONESOCURRE, UtilitiesRepository.getDb23(),numeroTabla, numeroTabla, claTalon), TalonesPorUnidad.class);
		List<TalonesPorUnidad> lstTalonesUnidad = queryTalonesPorUnidad.getResultList();
        lstTalonesUnidad.forEach(talon -> {
            Integer incidencias = RegistrarIncidenciasPorTalon(talon.getClaveTalon());
            talon.setIncidencias(incidencias);  
        });
        return lstTalonesUnidad.isEmpty() ? new ArrayList<>() : lstTalonesUnidad;
    }
    
    public Integer RegistrarIncidenciasPorTalon(String talon) {
        Query queryTalonesIncidencia = entityManager.createNativeQuery(
                String.format(QUERY_GETINCIDENCIAS, UtilitiesRepository.getDb13(), talon));
        List<Object> lstIncidencias = queryTalonesIncidencia.getResultList();
    
        if (!lstIncidencias.isEmpty()) {
            Object incidencia = lstIncidencias.get(0); 
    
            if (incidencia instanceof BigInteger) {
                return ((BigInteger) incidencia).intValue();  
            }
            else if (incidencia instanceof Integer) {
                return (Integer) incidencia;
            }
        }
    
        return 0;
    }
     
    public List<SalidaUnidades> getSalidaUnidad(Integer idruta, Integer dia, String idviaje, String idoficina, String destino) {
 		Query querySalidaUnidad = entityManager.createNativeQuery(String.format(QUERY_GETSALIDAUNIDADES,UtilitiesRepository.getDb23(),destino,idruta,idviaje,idoficina,destino), SalidaUnidades.class);
 		List<SalidaUnidades> lstsalidas = querySalidaUnidad.getResultList();
 		return lstsalidas.isEmpty() ? null : lstsalidas;
 	}
     
    public List<UnidadesPorOficina> getUnidades(String idOficinaDestino) {
    	 Query queryTalonesPorUnidad = entityManager.createNativeQuery(String.format(QUERY_GETUNIDADES, UtilitiesRepository.getDb23(), idOficinaDestino,idOficinaDestino,idOficinaDestino),UnidadesPorOficina.class);
 		List<UnidadesPorOficina> lstTalonesUnidad = queryTalonesPorUnidad.getResultList();
 		return lstTalonesUnidad.isEmpty() ? null : lstTalonesUnidad;
     }
}
