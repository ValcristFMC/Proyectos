package com.grupocastores.sion.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.TalonesPorUnidadDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "talonesPorUnidad")
@EntityListeners(TalonesPorUnidad.class)
public class TalonesPorUnidad {
	
	@Id
	@Column(name = "cla_talon")
	private String claveTalon;
	private Integer bultos;
	private String empaque;
	private String contiene;
	private String origen;
	private String destinatario;
	@Column(name = "tipo_pago")
	private String tipoPago;
	private Integer incidencias;
	
	public static TalonesPorUnidad fromTalonesPorUnidadDTO(TalonesPorUnidad talonesPorUnidad) {
		TalonesPorUnidad rest = new TalonesPorUnidad();
		rest.setClaveTalon(talonesPorUnidad.getClaveTalon());
		rest.setBultos(talonesPorUnidad.getBultos());
		rest.setEmpaque(talonesPorUnidad.getEmpaque());
		rest.setContiene(talonesPorUnidad.getContiene());		
		rest.setOrigen(talonesPorUnidad.getOrigen());
		rest.setDestinatario(talonesPorUnidad.getDestinatario());
		rest.setTipoPago(talonesPorUnidad.getTipoPago());
		rest.setIncidencias(talonesPorUnidad.getIncidencias());
		return rest;
	}
	
	public TalonesPorUnidadDTO toTalonesPorUnidadDTO() {
		TalonesPorUnidadDTO dto = new  TalonesPorUnidadDTO();
		 dto.setClaveTalon(this.getClaveTalon());
		 dto.setBultos(this.getBultos());
		 dto.setEmpaque(this.getEmpaque());
		 dto.setContiene(this.getContiene());
		 dto.setOrigen(this.getOrigen());
		 dto.setDestinatario(this.getOrigen());
		 dto.setTipoPago(this.getTipoPago());
		 dto.setIncidencias(this.getIncidencias());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("UnidadesPorOficina [cla_talon=").append(claveTalon)
		.append(",bultos=").append(bultos)
		.append(",empaque=").append(empaque)
		.append(",contiene=").append(contiene)
		.append(",origen=").append(origen)
		.append(",destinatario=").append(destinatario)
		.append(",tipo_pago=").append(tipoPago)
		.append(",inicidencias=").append(incidencias);
		return strBuilder.toString();
	}

}
