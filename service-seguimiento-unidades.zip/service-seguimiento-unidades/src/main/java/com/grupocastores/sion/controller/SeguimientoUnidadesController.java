package com.grupocastores.sion.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.grupocastores.sion.service.ISeguimientoUnidadesService;
import com.grupocastores.sion.dto.SeguimientoUnidadesDTO;
import com.grupocastores.sion.dto.ResponseDTO;

@RestController
@RequestMapping(value = "/sion")
@Api(value = "SeguimientoUnidadesController", produces = "application/json")
public class SeguimientoUnidadesController {

	Logger log = LoggerFactory.getLogger(SeguimientoUnidadesController.class);

	@Autowired
	private ISeguimientoUnidadesService seguimientoUnidadesService;
	static final String HEADERBACK = "/sion/{id}";
	private Map<String, Object> response;

	@ApiOperation(value = "Recupera tabla seguimiento unidades")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Tabla de seguimiento de unidades obtenidos", response = SeguimientoUnidadesDTO.class),
			@ApiResponse(code = 500, message = "No encontrados", response = ResponseDTO.class),
			@ApiResponse(code = 401, message = "No esta autorizado para acceder a este recurso.", response = ResponseDTO.class),
			@ApiResponse(code = 403, message = "El cliente tiene autenticación valida, pero no esta autorizda la petición al recurso", response = ResponseDTO.class),
			@ApiResponse(code = 404, message = "El servidor no encuentra la petición al recurso", response = ResponseDTO.class) })
	@HystrixCommand(fallbackMethod = "fallBackMethod")
	@GetMapping(value = "/getSeguimientoUnidades", params = { "oficinaDestino", "fechaInicial",
			"fechaFinal" }, produces = "application/json;charset=UTF-8")
	public ResponseEntity<?> getSeguimientoUnidades(@RequestParam(name = "fechaInicial") String fechaInicial,
			@RequestParam(name = "fechaFinal") String fechaFinal,
			@RequestParam(name = "oficinaDestino") Integer oficinaDestino) {
		List<SeguimientoUnidadesDTO> lstSeguimientoUnidades;
		try {

			lstSeguimientoUnidades = seguimientoUnidadesService.getSeguimientoUnidadesByFechas(fechaInicial, fechaFinal,
					oficinaDestino);

		} catch (Exception e) {
			response = new HashMap<String, Object>();
			response.put("error", "Error en getSeguimientoUnidades()");
			response.put("message", e.getMessage());
			response.put("class", this.getClass());
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return ResponseEntity.ok(lstSeguimientoUnidades);
	}
}
