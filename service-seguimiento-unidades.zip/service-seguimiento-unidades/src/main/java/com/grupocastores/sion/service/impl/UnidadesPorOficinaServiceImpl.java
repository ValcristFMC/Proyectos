package com.grupocastores.sion.service.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.clients.SemaforoFeingClient;
import com.grupocastores.sion.dto.SemaforoFeingDTO;
import com.grupocastores.sion.dto.SemaforoStatusDTO;
import com.grupocastores.sion.dto.UnidadUbicacionDTO;

import com.grupocastores.sion.service.IUnidadesPorOficinaService;
import com.grupocastores.sion.service.domain.SalidaUnidades;
import com.grupocastores.sion.service.domain.UnidadesPorOficina;
import com.grupocastores.sion.service.repository.SemaforoRepository;
import com.grupocastores.sion.service.repository.TalonesUnidadRepositorya;

@Service
public class UnidadesPorOficinaServiceImpl implements IUnidadesPorOficinaService{

	@PersistenceContext
	private EntityManager entityManager;
	Logger logger = LoggerFactory.getLogger(UnidadesPorOficinaServiceImpl.class);
	@Autowired
	TalonesUnidadRepositorya talonesUnidadRepositorya;
	@Autowired
	private SemaforoRepository semaforoRepository;
	@Autowired
	private SemaforoFeingClient semaforoFeingClient;

	@Override
	public List<UnidadesPorOficina> getUnidadesPorOficina(String OficinaDestino) {
		  try { List<UnidadesPorOficina> lstUnidades =
		  talonesUnidadRepositorya.getUnidades(OficinaDestino); return lstUnidades; }
		  catch (Exception e) {
		  logger.error("Error al obtener unidades por oficina: {}", OficinaDestino, e);
		  return Collections.emptyList(); }
		 
	}
	
	@Override
	public List<SalidaUnidades> getSalidaUnidad(Integer idruta, Integer dia, String idviaje, String idoficina, String destino) {
		try {
		List<SalidaUnidades> lstSalidas = talonesUnidadRepositorya.getSalidaUnidad(idruta, dia,idviaje,idoficina,destino);
		return lstSalidas.isEmpty() ? null : lstSalidas;
		}catch(Exception e) {
			 logger.error("Error al obtener salida de unidades: {}", idruta, e);
		        return  Collections.emptyList();
		}
		
	}

	@Override
	public List<SemaforoStatusDTO> getSemaforoStatus(String idViaje, String idOficina) {
		List<SemaforoStatusDTO> lstSemaforo = semaforoRepository.getSemaforo(idViaje, idOficina);
	    return lstSemaforo.stream()
	            .collect(Collectors.groupingBy(SemaforoStatusDTO::getIdOficina)) 
	            .values().stream() 
	            .map(group -> group.get(0)) 
	            .sorted(Comparator.comparing(SemaforoStatusDTO::getOrdenLlegada)) 
	            .collect(Collectors.toList()); 
	}
		
	@Override
	public UnidadUbicacionDTO getUnidadUbicacion(String idOficina, String idUnidad,String geometries, String overview, String tipo) {
		UnidadUbicacionDTO unidadUbicacionDTO = semaforoRepository.getCoordenadas(idOficina, idUnidad, tipo);
		String coordinates =  unidadUbicacionDTO.getLongitudUnidad() + "," + unidadUbicacionDTO.getLatitudUnidad() + ";" + unidadUbicacionDTO.getLongitudOficina() + "," + unidadUbicacionDTO.getLatitudOficina();
		SemaforoFeingDTO semaforoFeingDTO = semaforoFeingClient.getDistancia(coordinates, geometries, overview);

		unidadUbicacionDTO.setMensaje("A "  + semaforoFeingDTO.getRoutes().get(0).getDistance() / 1000 + " km de " + unidadUbicacionDTO.getPlaza());
		
		if(semaforoFeingDTO.getWaypoints().get(0).getName() != null) {
			unidadUbicacionDTO.setMensaje(unidadUbicacionDTO.getMensaje() + " por " + semaforoFeingDTO.getWaypoints().get(0).getName());
		}

		return unidadUbicacionDTO;
	}
}