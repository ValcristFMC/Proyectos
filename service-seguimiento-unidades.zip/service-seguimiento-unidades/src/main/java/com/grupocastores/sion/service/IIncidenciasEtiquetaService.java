package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.IncidenciasEtiquetaDTO;

public interface IIncidenciasEtiquetaService {

	public List<IncidenciasEtiquetaDTO> getIncidenciasEtiquetaByFolio(String folio);
}
