package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.OficinasDTO;
import com.grupocastores.sion.service.domain.Division;

public interface IDivisionService {

	public List<Division> getDivisiones(Long usuario);

}
