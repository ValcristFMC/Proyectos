package com.grupocastores.sion.service.repository;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.GuiasDTO;
import com.grupocastores.sion.service.domain.Guias;

@Repository
public class GuiasRepository {

	Logger log = LoggerFactory.getLogger(GuiasRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	static final String QUERY = "SELECT * FROM OPENQUERY (PRODUCCION23,'"
			+ "SELECT "
			+ "	gu.status AS estatus_guia "
			+ "	, IF(gu.no_guia IS NOT NULL, gu.no_guia, '''') AS numero_guia "
			+ "	, IF(gu.tipounidad IS NOT NULL, gu.tipounidad, 0) AS tipo_unidad "
			+ "	, IF(gu.unidad IS NOT NULL, gu.unidad, '''') AS unidad "
			+ "	, IF(gu.idoficina IS NOT NULL, gu.idoficina, 0) AS id_oficina "
			+ "	, IF(gu.idoperador IS NOT NULL, gu.idoperador, 0) AS id_operador "
			+ "	, IF(gu.moneda IS NOT NULL, gu.moneda, 0) AS tipo_guia "
			+ "	, IF(gu.origen IS NOT NULL, gu.origen, 0) AS origen "
			+ "	, IF(gu.destino IS NOT NULL, gu.destino, 0) AS destino "
			+ "	, IF(v.folio IS NOT NULL, v.folio, '''') AS folio_viaje "
			+ "	, IF(ig.totaltotal IS NOT NULL, ig.totaltotal, 0) AS total_guia "
			+ "	, IF(gu.remolque IS NOT NULL, gu.remolque, 0) AS remolque "
			+ "	FROM talones.gu%s AS gu "
			+ "	LEFT JOIN talones.guias g ON g.no_guia = gu.no_guia "
			+ "	LEFT JOIN talones.importeguias ig ON gu.no_guia = ig.no_guia "
			+ "	LEFT JOIN talones.guiaviaje gv ON gu.no_guia = gv.no_guia "
			+ "	LEFT JOIN talones.viajes v ON gv.idviaje = v.idviaje AND gv.idoficina = v.idoficina "
			+ "	LEFT JOIN camiones.relacion_unidad ru ON v.idunidad = ru.idunidad AND v.tipounidad = ru.idtipounidad "
			+ "	LEFT JOIN camiones.relacion_unidad reu ON v.idremolque = reu.idunidad AND reu.idtipounidad = 4 "
			+ "	WHERE gu.moneda IN (\"1\") "
			+ "	AND (gv.operacionguia = 1) "
			+ "	ORDER BY gu.no_guia, gu.fecha ASC, gu.no_guia ASC;')";

	public List<GuiasDTO> getGuias(String tabla) {
		String queryString = String.format(QUERY, tabla);
		Query query = entityManager.createNativeQuery(queryString, Guias.class);
		List<Guias> lstGuias = Lists.newArrayList(Iterables.filter(query.getResultList(), Guias.class));
		List<GuiasDTO> lstGuiasDTO = lstGuias.stream().map(Guias::toGuiasDTO).collect(Collectors.toList());
		return lstGuiasDTO;
	}
}
