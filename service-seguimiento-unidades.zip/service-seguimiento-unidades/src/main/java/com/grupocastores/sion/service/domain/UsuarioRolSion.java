package com.grupocastores.sion.service.domain;

import javax.persistence.*;

import com.grupocastores.sion.dto.RoleDTO;

import java.util.Date;

import lombok.Data;

@Data
@Entity
@Table(name = "usuario_rol_sion")
public class UsuarioRolSion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario_rol")
    private Long idUsuarioRol;

    @Column(name = "id_rol")
    private Long idRol;

    @Column(name = "id_usuario")
    private Long idUsuario;

    @Column(name = "estatus")
    private String estatus;

    @Column(name = "id_personal")
    private Long idPersonal;

    @Column(name = "fecha_registro")
    private Date fechaRegistro; 

    @Column(name = "fecha_modificacion")
    private Date fechaModificacion; 

    @ManyToOne
    @JoinColumn(name = "id_rol", insertable = false, updatable = false)
    private RolSion rolSion;

    public static RoleDTO toRoleDTO(UsuarioRolSion entity) {
        return new RoleDTO(
            entity.getIdUsuarioRol(),
            entity.getIdUsuario(),
            entity.getIdRol(),
            entity.getRolSion().getNombre(), 
            entity.getRolSion().getDescripcion(), 
            entity.getEstatus()
        );
    }
}
