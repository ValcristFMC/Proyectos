package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.dto.EstatusDTO;
import com.grupocastores.sion.service.IEstatusService;
import com.grupocastores.sion.service.repository.EstatusRepository;

@Service
public class EstatusServiceImpl implements IEstatusService {
	Logger logger = LoggerFactory.getLogger(EstatusServiceImpl.class);

	@Autowired
	private EstatusRepository estatusRepository;

	@Override
	public List<EstatusDTO> getEstatus() {
		List<EstatusDTO> lstEstatus = new ArrayList<EstatusDTO>();

		try {
			lstEstatus = estatusRepository.getEstatus();
			if (lstEstatus == null) {
				throw new Exception("No se pudo obtener el registro del seguimiento: ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return lstEstatus;
	}
}
