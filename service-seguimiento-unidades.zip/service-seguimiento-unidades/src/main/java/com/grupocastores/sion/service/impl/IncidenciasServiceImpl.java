package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.dto.IncidenciasDTO;
import com.grupocastores.sion.service.IIncidenciasService;
import com.grupocastores.sion.service.repository.IncidenciasRepository;

@Service
public class IncidenciasServiceImpl implements IIncidenciasService {
	Logger logger = LoggerFactory.getLogger(IncidenciasServiceImpl.class);

	@Autowired
	private IncidenciasRepository incidenciasRepository;

	@Override
	public List<IncidenciasDTO> getIncidenciasByFolio(String talon) {
		List<IncidenciasDTO> lstIncidencias = new ArrayList<IncidenciasDTO>();

		try {
			lstIncidencias = incidenciasRepository.getIncidencias(talon);
			if (lstIncidencias == null) {
				throw new Exception("No se pudo obtener el registro del seguimiento: ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return lstIncidencias;
	}
}
