package com.grupocastores.sion.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.grupocastores.sion.dto.SemaforoFeingDTO;

@FeignClient(name = "semaforoService", url = "http://192.168.0.65:5000/route/v1/driving")
public interface SemaforoFeingClient {
    @GetMapping("/{coordinates}")
    SemaforoFeingDTO getDistancia(
        @PathVariable("coordinates") String coordinates, 
        @RequestParam("geometries") String geometries, 
        @RequestParam("overview") String overview
    );
}