package com.grupocastores.sion.dto;

import java.util.Date;

import io.swagger.annotations.ApiModel;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un SeguimientoUnidades", description = "Datos del SeguimientoUnidades")
public class SeguimientoUnidadesDTO {
	
	private String numeroGuia;
	private int idViaje;
	private String idOficina;
	private String idOficinaGv;
	private String idRuta;
	private String idOficinaOrigen;
	private String idOficinaDestino;
	private String idOficinaDestinoGv;
	private String oficinaOrigen;
	private String oficinaDestino;
	private String oficinaDestinoGv;
	private String idUnidad;
	private String tipoUnidad;
	private String folio;
	private int estatus;
	private int estatusGuiaViaje;
	private String estatusViaje;
	private Date fechaViaje;
	private String horaViaje;
	private String claveVehiculo;
	private String numeroSerie;
	private String numeroEconomico;
	private Date fechaPosicion;
	private String posicionVehiculo;
	
	public SeguimientoUnidadesDTO (String numeroGuia
			, int idViaje
			, String idOficina
			, String idOficinaGv
			, String idRuta
			, String idOficinaOrigen
			, String idOficinaDestino
			, String idOficinaDestinoGv
			, String oficinaOrigen
			, String oficinaDestino
			, String oficinaDestinoGv
			, String idUnidad
			, String tipoUnidad
			, String folio
			, int estatus
			, int estatusGuiaViaje
			, String estatusViaje
			, Date fechaViaje
			, String horaViaje
			, String claveVehiculo
			, String numeroSerie
			, String numeroEconomico
			, Date fechaPosicion
			, String posicionVehiculo) {
		this.numeroGuia = numeroGuia;
		this.idViaje = idViaje;
		this.idOficina = idOficina;
		this.idOficinaGv = idOficinaGv;
		this.idRuta = idRuta;
		this.idOficinaOrigen = idOficinaOrigen;
		this.idOficinaDestino = idOficinaDestino;
		this.idOficinaDestinoGv = idOficinaDestinoGv;
		this.oficinaOrigen = oficinaOrigen;
		this.oficinaDestino = oficinaDestino;
		this.oficinaDestinoGv = oficinaDestinoGv;
		this.idUnidad = idUnidad;
		this.tipoUnidad = tipoUnidad;
		this.folio = folio;
		this.estatus = estatus;
		this.estatusGuiaViaje = estatusGuiaViaje;
		this.estatusViaje = estatusViaje;
		this.fechaViaje = fechaViaje;
		this.horaViaje = horaViaje;
		this.claveVehiculo = claveVehiculo;
		this.numeroSerie = numeroSerie;
		this.numeroEconomico = numeroEconomico;
		this.fechaPosicion = fechaPosicion;
		this.posicionVehiculo = posicionVehiculo;
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("SeguimientoUnidades [numeroGuia=").append(numeroGuia)
		.append(", idViaje=").append(idViaje)	
		.append(", idOficina=").append(idOficina)
		.append(", idOficinaGv=").append(idOficinaGv)
		.append(", idRuta=").append(idRuta)
		.append(", idOficinaOrigen=").append(idOficinaOrigen)
		.append(", idOficinaDestino=").append(idOficinaDestino)
		.append(", idOficinaDestinoGv=").append(idOficinaDestinoGv)
		.append(", oficinaOrigen=").append(oficinaOrigen)	
		.append(", oficinaDestino=").append(oficinaDestino)
		.append(", oficinaDestinoGv=").append(oficinaDestinoGv)
		.append(", idUnidad=").append(idUnidad)
		.append(", tipoUnidad=").append(tipoUnidad)
		.append(", folio=").append(folio)
		.append(", estatus=").append(estatus)	
		.append(", estatusGuiaViaje=").append(estatusGuiaViaje)
		.append(", estatusViaje=").append(estatusViaje)
		.append(", fechaViaje=").append(fechaViaje)
		.append(", horaViaje=").append(horaViaje)
		.append(", claveVehiculo=").append(claveVehiculo)
		.append(", numeroSerie=").append(numeroSerie)
		.append(", numeroEconomico=").append(numeroEconomico)
		.append(", fechaPosicion=").append(fechaPosicion)
		.append(", posicionVehiculo=").append(posicionVehiculo);
		return strBuilder.toString();
	}
}
