package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.UnidadUbicacionDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "unidad_ubicacion")
public class UnidadUbicacion {

    @Id
    private String claveUnidad;
    private String plaza;
    private Double latitudUnidad;
    private Double longitudUnidad;
    private Double latitudOficina;
    private Double longitudOficina;

    // Método para convertir de DTO a entidad
    public static UnidadUbicacion fromUnidadUbicacionDTO(UnidadUbicacionDTO dto) {
        UnidadUbicacion entity = new UnidadUbicacion();
        entity.setClaveUnidad(dto.getClaveUnidad());
        entity.setPlaza(dto.getPlaza());
        entity.setLatitudUnidad(dto.getLatitudUnidad());
        entity.setLongitudUnidad(dto.getLongitudUnidad());
        entity.setLatitudOficina(dto.getLatitudOficina());
        entity.setLongitudOficina(dto.getLongitudOficina());
        return entity;
    }

    // Método para convertir de entidad a DTO
    public UnidadUbicacionDTO toUnidadUbicacionDTO() {
        return new UnidadUbicacionDTO(
            this.getClaveUnidad(),
            this.getLatitudUnidad(),
            this.getLongitudUnidad(),
            this.getLatitudOficina(),
            this.getLongitudOficina(),
            this.getPlaza()
        );
    }
}
