package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Guia Status", description = "Datos del estado de las guias")
public class GuiaStatusDTO {

    private String numeroGuia;
    private String tabla;
    private String unidad;
    private int status;
    private Integer idLiquidacion;
    private Integer anioLiq;

    public GuiaStatusDTO(String noGuia,  String tabla, String unidad, int status, Integer idLiquidacion, Integer anioLiq) {
        this.numeroGuia = noGuia;
        this.tabla = tabla;
        this.unidad = unidad;
        this.status = status;
        this.idLiquidacion = idLiquidacion;
        this.anioLiq = anioLiq;
    }

    @Override
    public String toString() {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append("GuiaStatusDTO [noGuia=").append(numeroGuia)
                  .append(", tabla=").append(tabla)
                  .append(", unidad=").append(unidad)
                  .append(", status=").append(status)
                  .append(", idLiquidacion=").append(idLiquidacion)
                  .append(", anioLiq=").append(anioLiq)
                  .append("]");
        return strBuilder.toString();
    }
}
