package com.grupocastores.sion.service.domain;

import java.io.Serializable;
import lombok.Data;

@Data
public class TalonesPorGuia implements Serializable {

    private String claveTalon;
    private String numeroGuia;

    public TalonesPorGuia() {}

    public TalonesPorGuia(String claTalon, String noGuia) {
        this.claveTalon = claTalon;
        this.numeroGuia = noGuia;
    }
}
