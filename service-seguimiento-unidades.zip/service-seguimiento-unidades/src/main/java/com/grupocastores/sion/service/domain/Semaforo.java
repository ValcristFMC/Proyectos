package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.GuiasDTO;
import com.grupocastores.sion.dto.SemaforoDTO;
import lombok.Data;

@Data
@Entity
@Table(name = "semaforo")
@EntityListeners(Semaforo.class)
public class Semaforo {
	
	@Id
	private String idViaje;
	private int idEstatusGuiaViaje;
	private int idEstatusGuia;
	private int idEstatusViaje;
	private int idEstatusGeocerca;
	private String estatusGuia;
	private String estatus;
	private String estatusViaje;
	private String estatusViajeGeocerca;
	private String idOficinaOrigen;
	private String idOficinaDestino;
	private String idOficinaDestinoViaje;
	private String oficinaOrigenViaje;
	private String oficinaDestinoGuia;
	private String oficinaDestinoViaje;
	private String numeroLatitudVehiculo;
	private String numeroLongitudVehiculo;
	private String longitud;
	private String latitud;
	private String estatusLlegadaSalida;
	private String fechaHoraSalida;
	private String horaLlegada;
	private String horaSalida;
	
	/**
	 * Metodo estatico para obtener un Semaforo a partir de un SemaforoDTO origen
	 * 
	 * @param semaforo SemaforoDTO origen
	 * 
	 * @return Semaforo
	 */
	public static Semaforo fromSemaforoDTO(SemaforoDTO semaforo) {
		Semaforo rest = new Semaforo();
		rest.setIdViaje(semaforo.getIdViaje());
		rest.setIdEstatusGuiaViaje(semaforo.getIdEstatusGuiaViaje());
		rest.setIdEstatusGuia(semaforo.getIdEstatusGuia());
		rest.setIdEstatusViaje(semaforo.getIdEstatusViaje());
		rest.setIdEstatusGeocerca(semaforo.getIdEstatusGeocerca());
		rest.setEstatus(semaforo.getEstatus());
		rest.setEstatusViaje(semaforo.getEstatusViaje());
		rest.setEstatusGuia(semaforo.getEstatusGuia());
		rest.setEstatusViajeGeocerca(semaforo.getEstatusViajeGeocerca());
		rest.setIdOficinaOrigen(semaforo.getIdOficinaOrigen());
		rest.setIdOficinaDestino(semaforo.getIdOficinaDestino());
		rest.setIdOficinaDestinoViaje(semaforo.getIdOficinaDestinoViaje());
		rest.setOficinaOrigenViaje(semaforo.getOficinaOrigenViaje());
		rest.setOficinaDestinoGuia(semaforo.getOficinaDestinoGuia());
		rest.setOficinaDestinoViaje(semaforo.getOficinaDestinoViaje());
		rest.setNumeroLatitudVehiculo(semaforo.getNumeroLatitudVehiculo());
		rest.setNumeroLongitudVehiculo(semaforo.getNumeroLongitudVehiculo());
		rest.setLongitud(semaforo.getLongitud());
		rest.setLatitud(semaforo.getLatitud());
		rest.setEstatusLlegadaSalida(semaforo.getEstatusLlegadaSalida());
		rest.setFechaHoraSalida(semaforo.getFechaHoraSalida());
		rest.setHoraLlegada(semaforo.getHoraLlegada());
		rest.setHoraSalida(semaforo.getHoraSalida());
		return rest;
	}
	
	/**
	 * Metodo para obtener un SemaforoDTO a partir de un Semaforo origen
	 * 
	 * @return SemaforoDTO
	 */
	public SemaforoDTO toSemaforoDTO() {
		 SemaforoDTO dto = new  SemaforoDTO();
		 dto.setIdViaje(this.getIdViaje());
		 dto.setIdEstatusGuiaViaje(this.getIdEstatusGuiaViaje());
		 dto.setIdEstatusGuia(this.getIdEstatusGuia());
		 dto.setIdEstatusViaje(this.getIdEstatusViaje());
		 dto.setIdEstatusGeocerca(this.getIdEstatusGeocerca());
		 dto.setEstatus(this.getEstatus());
		 dto.setEstatusViaje(this.getEstatusViaje());
		 dto.setEstatusGuia(this.getEstatusGuia());
		 dto.setEstatusViajeGeocerca(this.getEstatusViajeGeocerca());
		 dto.setIdOficinaOrigen(this.getIdOficinaOrigen());
		 dto.setIdOficinaDestino(this.getIdOficinaDestino());
		 dto.setIdOficinaDestinoViaje(this.getIdOficinaDestinoViaje());
		 dto.setOficinaOrigenViaje(this.getOficinaOrigenViaje());
		 dto.setOficinaDestinoGuia(this.getOficinaDestinoGuia());
		 dto.setOficinaDestinoViaje(this.getOficinaDestinoViaje());
		 dto.setNumeroLatitudVehiculo(this.getNumeroLatitudVehiculo());
		 dto.setNumeroLongitudVehiculo(this.getNumeroLongitudVehiculo());
		 dto.setLongitud(this.getLongitud());
		 dto.setLatitud(this.getLatitud());
		 dto.setEstatusLlegadaSalida(this.getEstatusLlegadaSalida());
		 dto.setFechaHoraSalida(this.getFechaHoraSalida());
		 dto.setHoraLlegada(this.getHoraLlegada());
		 dto.setHoraSalida(this.getHoraSalida());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Semaforo [idViaje=").append(idViaje)
		.append(",idEstatusGuiaViaje=").append(idEstatusGuiaViaje)
		.append(",idEstatusGuia=").append(idEstatusGuia)
		.append(",idEstatusViaje=").append(idEstatusViaje)
		.append(",idEstatusGeocerca=").append(idEstatusGeocerca)
		.append(",estatus=").append(estatus)
		.append(",estatusViaje=").append(estatusViaje)
		.append(",estatusViajeGeocerca=").append(estatusViajeGeocerca)
		.append(",idOficinaOrigen=").append(idOficinaOrigen)
		.append(",idOficinaDestino=").append(idOficinaDestino)
		.append(",idOficinaDestinoViaje=").append(idOficinaDestinoViaje)
		.append(",oficinaOrigenViaje=").append(oficinaOrigenViaje)
		.append(",oficinaDestinoGuia=").append(oficinaDestinoGuia)
		.append(",oficinaDestinoViaje=").append(oficinaDestinoViaje)
		.append(",numeroLatitudVehiculo=").append(numeroLatitudVehiculo)
		.append(",numeroLongitudVehiculo=").append(numeroLongitudVehiculo)
		.append(",longitud=").append(longitud)
		.append(",latitud=").append(latitud)
		.append(",estatusLlegadaSalida=").append(estatusLlegadaSalida)
		.append(",fechaHoraSalida=").append(fechaHoraSalida)
		.append(",horaLlegada=").append(horaLlegada)
		.append(",horaSalida=").append(horaSalida);
		return strBuilder.toString();
	}

}
