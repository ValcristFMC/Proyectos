package com.grupocastores.sion.service.impl;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.service.IRolService;
import com.grupocastores.sion.service.domain.UsuarioRolSion;
import com.grupocastores.sion.service.repository.UsuarioRolSionRepository;

@Service
public class RolServiceImpl implements IRolService {
    
    private static final Logger logger = LoggerFactory.getLogger(RolServiceImpl.class);

    @Autowired
    private UsuarioRolSionRepository usuarioRolSionRepository;

    @Override
    public UsuarioRolSion getRolesByUsuarioId(Long idUsuario) {
        UsuarioRolSion rol = new UsuarioRolSion();

        try {
        	rol = usuarioRolSionRepository.findRolesByUsuarioId(idUsuario);
         
        } catch (Exception e) {
            logger.error("Error al obtener roles para el usuario con ID {}: {}", idUsuario, e.getMessage());
        }

        return rol;
    }
}
