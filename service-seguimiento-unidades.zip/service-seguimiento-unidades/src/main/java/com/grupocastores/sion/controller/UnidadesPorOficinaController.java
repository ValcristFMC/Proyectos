package com.grupocastores.sion.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.grupocastores.sion.dto.ResponseDTO;
import com.grupocastores.sion.dto.SalidaUnidadesDTO;
import com.grupocastores.sion.dto.SemaforoStatusDTO;
import com.grupocastores.sion.dto.UnidadesPorOficinaDTO;
import com.grupocastores.sion.service.IUnidadesPorOficinaService;
import com.grupocastores.sion.service.domain.SalidaUnidades;
import com.grupocastores.sion.service.domain.UnidadesPorOficina;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/sion")
@Api(value = "UnidadesPorOficinaController", produces = "application/json")
public class UnidadesPorOficinaController {

Logger log = LoggerFactory.getLogger(TalonesPorUnidadController.class);
	
	@Autowired
	private IUnidadesPorOficinaService seguimientoUnidadesService;
	static final String HEADERBACK = "/sion/{id}";
	private Map<String, Object> response;
	
	@ApiOperation(value = "Recupera unidades que llegarán a la oficina")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Unidades obtenidas", response = UnidadesPorOficinaDTO.class),
			@ApiResponse(code = 500, message = "Error interno del servidor", response = ResponseDTO.class),
			@ApiResponse(code = 401, message = "No esta autorizado para acceder a este recurso.", response = ResponseDTO.class),
			@ApiResponse(code = 403, message = "El cliente tiene autenticación valida, pero no esta autorizda la petición al recurso", response = ResponseDTO.class),
			@ApiResponse(code = 404, message = "El servidor no encuentra la petición al recurso", response = ResponseDTO.class) })
	@HystrixCommand(fallbackMethod = "fallBackMethod")
	@GetMapping(value = "/findConsultaUnidades", params={"OficinaDestino"}, produces = "application/json;charset=UTF-8")
	public ResponseEntity<?> ConsultaUnidades(@RequestParam(name = "OficinaDestino") String OficinaDestino) {
		List<UnidadesPorOficina> lstUnidadesPorOficina;
		try {
			lstUnidadesPorOficina = seguimientoUnidadesService.getUnidadesPorOficina(OficinaDestino);
		} catch (Exception e) {
		    response = new HashMap<String, Object>();
			response.put("error", "Error en findViaje()"); 	
			response.put("message", e.getMessage());
			response.put("class", this.getClass());
			return new ResponseEntity<Map<String,Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return ResponseEntity.ok(lstUnidadesPorOficina); 
	}
	
	@ApiOperation(value = "Recupera las salidas de las unidades")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Salida de unidades", response = SalidaUnidadesDTO.class),
			@ApiResponse(code = 500, message = "Error interno del servidor", response = ResponseDTO.class),
			@ApiResponse(code = 401, message = "No esta autorizado para acceder a este recurso.", response = ResponseDTO.class),
			@ApiResponse(code = 403, message = "El cliente tiene autenticación valida, pero no esta autorizda la petición al recurso", response = ResponseDTO.class),
			@ApiResponse(code = 404, message = "El servidor no encuentra la petición al recurso", response = ResponseDTO.class) })
	@HystrixCommand(fallbackMethod = "fallBackMethod")
	@GetMapping(value = "/findSalidaUnidades", params={"idruta","dia","idviaje","idoficina","destino"}, produces = "application/json;charset=UTF-8")
	public ResponseEntity<?> findSalidaUnidades(@RequestParam(name = "idruta") Integer idruta, @RequestParam(name = "dia") Integer dia,
			 @RequestParam(name = "idviaje") String idviaje, @RequestParam(name = "idoficina") String idoficina, @RequestParam(name = "destino") String destino) {
		List<SalidaUnidades> lstSalidaUnidades;
		try {
			lstSalidaUnidades = seguimientoUnidadesService.getSalidaUnidad(idruta, dia, idviaje,idoficina,destino);
		} catch (Exception e) {
		    response = new HashMap<String, Object>();
			response.put("error", "Error en findViaje()"); 	
			response.put("message", e.getMessage());
			response.put("class", this.getClass());
			return new ResponseEntity<Map<String,Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return ResponseEntity.ok(lstSalidaUnidades); 
	}
	
	@HystrixCommand(fallbackMethod = "fallBackMethod")
	@GetMapping(value = "/getSemaforoStatus", params={"idViaje","idOficina"}, produces = "application/json;charset=UTF-8")
	public ResponseEntity<?> findSemaforoStatus(@RequestParam(name = "idViaje") String idViaje, @RequestParam(name = "idOficina") String idOficina) {
		List<SemaforoStatusDTO> lstSemaforoStatus;
		try {
			lstSemaforoStatus = seguimientoUnidadesService.getSemaforoStatus(idViaje, idOficina);
		} catch (Exception e) {
		    response = new HashMap<String, Object>();
			response.put("error", "Error en findViaje()"); 	
			response.put("message", e.getMessage());
			response.put("class", this.getClass());
			return new ResponseEntity<Map<String,Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return ResponseEntity.ok(lstSemaforoStatus); 
	}

	@HystrixCommand(fallbackMethod = "fallBackMethod")
	@GetMapping(value = "/getUnidadUbicacion", params={"idOficina","idUnidad","geometries","overview"}, produces = "application/json;charset=UTF-8")
	public ResponseEntity<?> findUnidadUbicacion(@RequestParam(name = "idOficina") String idOficina, @RequestParam(name = "idUnidad") String idUnidad, @RequestParam(name = "geometries") String geometries, @RequestParam(name = "overview") String overview, @RequestParam(name = "tipo") String tipo) {
		try {
			return ResponseEntity.ok(seguimientoUnidadesService.getUnidadUbicacion(idOficina, idUnidad, geometries, overview, tipo));
		} catch (Exception e) {
		    response = new HashMap<String, Object>();
			response.put("error", "Error en findViaje()"); 	
			response.put("message", e.getMessage());
			response.put("class", this.getClass());
			return new ResponseEntity<Map<String,Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
