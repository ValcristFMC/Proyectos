package com.grupocastores.sion.service.repository;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.EstatusDTO;
import com.grupocastores.sion.service.domain.Estatus;

@Repository
public class EstatusRepository {

	Logger log = LoggerFactory.getLogger(EstatusRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	static final String QUERY = "SELECT * FROM OPENQUERY (PRODUCCION23,'"
			+ " SELECT "
			+ " idestatusviajes	AS id_estatus_viajes"
			+ " , nombre "
			+ "	FROM talones.estatusviajes"
			+ " WHERE idestatusviajes IN (2,4);')";

	public List<EstatusDTO> getEstatus() {
		String queryString = String.format(QUERY);
		Query query = entityManager.createNativeQuery(queryString, Estatus.class);
		List<Estatus> lstEstatus = Lists.newArrayList(Iterables.filter(query.getResultList(), Estatus.class));
		List<EstatusDTO> lstEstatusDTO = lstEstatus.stream().map(Estatus::toEstatusDTO).collect(Collectors.toList());
		return lstEstatusDTO;
	}
}
