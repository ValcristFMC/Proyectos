package com.grupocastores.sion.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RoleDTO {

    private Long idUsuarioRol;
    private Long idUsuario;
    private Long idRol;
    private String nombreRol;
    private String descripcionRol;
    private String estatus;

    public RoleDTO(Long idUsuarioRol, Long idUsuario, Long idRol, String nombreRol, String descripcionRol, String estatus) {
        this.idUsuarioRol = idUsuarioRol;
        this.idUsuario = idUsuario;
        this.idRol = idRol;
        this.nombreRol = nombreRol;
        this.descripcionRol = descripcionRol;
        this.estatus = estatus;
    }

    @Override
    public String toString() {
        return "RoleDTO [idUsuarioRol=" + idUsuarioRol + ", idUsuario=" + idUsuario + ", idRol=" + idRol + ", nombreRol="
                + nombreRol + ", descripcionRol=" + descripcionRol + ", estatus=" + estatus + "]";
    }
}
