package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.GuiaDTO;

import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Entity
@Table(name = "guias")
@EntityListeners(Guia.class)
public class Guia {
    @Id
    private String noGuia;
    private Long idViaje;
    private String idOficina;
    private String idOficinaGuia;
    private int estatusGuia;
    private int consecutivo;
    private boolean impresionPreGuia;
    private boolean impresionGuia;
    private int estatus;
    private int idPersonal;
    private LocalDate fechaMod;
    private LocalTime horaMod;
    private double totalGuia;
    private String idOficinaDeposito;
    private double totalDeposito;
    private int operacionGuia;
    private String idOficinaDestino;
    private boolean visitada;

    // Conversion methods between entity and DTO (GuiaDTO) could be added here as
    // static methods if desired
    public static Guia fromGuiaDTO(GuiaDTO guiaDTO) {
        Guia guia = new Guia();
        guia.setIdViaje(guiaDTO.getIdViaje());
        guia.setIdOficina(guiaDTO.getIdOficina());
        guia.setNoGuia(guiaDTO.getNoGuia());
        guia.setIdOficinaGuia(guiaDTO.getIdOficinaGuia());
        guia.setEstatusGuia(guiaDTO.getEstatusGuia());
        guia.setConsecutivo(guiaDTO.getConsecutivo());
        guia.setImpresionPreGuia(guiaDTO.isImpresionPreGuia());
        guia.setImpresionGuia(guiaDTO.isImpresionGuia());
        guia.setEstatus(guiaDTO.getEstatus());
        guia.setIdPersonal(guiaDTO.getIdPersonal());
        guia.setFechaMod(guiaDTO.getFechaMod());
        guia.setHoraMod(guiaDTO.getHoraMod());
        guia.setTotalGuia(guiaDTO.getTotalGuia());
        guia.setIdOficinaDeposito(guiaDTO.getIdOficinaDeposito());
        guia.setTotalDeposito(guiaDTO.getTotalDeposito());
        guia.setOperacionGuia(guiaDTO.getOperacionGuia());
        guia.setIdOficinaDestino(guiaDTO.getIdOficinaDestino());
        guia.setVisitada(guiaDTO.isVisitada());
        return guia;
    }

    public GuiaDTO toGuiaDTO() {
        GuiaDTO dto = new GuiaDTO();
        dto.setIdViaje(this.getIdViaje());
        dto.setIdOficina(this.getIdOficina());
        dto.setNoGuia(this.getNoGuia());
        dto.setIdOficinaGuia(this.getIdOficinaGuia());
        dto.setEstatusGuia(this.getEstatusGuia());
        dto.setConsecutivo(this.getConsecutivo());
        dto.setImpresionPreGuia(this.isImpresionPreGuia());
        dto.setImpresionGuia(this.isImpresionGuia());
        dto.setEstatus(this.getEstatus());
        dto.setIdPersonal(this.getIdPersonal());
        dto.setFechaMod(this.getFechaMod());
        dto.setHoraMod(this.getHoraMod());
        dto.setTotalGuia(this.getTotalGuia());
        dto.setIdOficinaDeposito(this.getIdOficinaDeposito());
        dto.setTotalDeposito(this.getTotalDeposito());
        dto.setOperacionGuia(this.getOperacionGuia());
        dto.setIdOficinaDestino(this.getIdOficinaDestino());
        dto.setVisitada(this.isVisitada());
        return dto;
    }

}
