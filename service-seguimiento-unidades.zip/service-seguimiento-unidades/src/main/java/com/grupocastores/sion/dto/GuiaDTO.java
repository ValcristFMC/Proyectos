package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Guia", description = "Datos de la guia")
public class GuiaDTO {

    private Long idViaje;
    private String idOficina;
    private String noGuia;
    private String idOficinaGuia;
    private int estatusGuia;
    private int consecutivo;
    private boolean impresionPreGuia;
    private boolean impresionGuia;
    private int estatus;
    private int idPersonal;
    private LocalDate fechaMod;
    private LocalTime horaMod;
    private double totalGuia;
    private String idOficinaDeposito;
    private double totalDeposito;
    private int operacionGuia;
    private String idOficinaDestino;
    private boolean visitada;

    public GuiaDTO(Long idViaje, String idOficina, String noGuia, String idOficinaGuia, int estatusGuia, int consecutivo,
                   boolean impresionPreGuia, boolean impresionGuia, int estatus, int idPersonal, LocalDate fechaMod,
                   LocalTime horaMod, double totalGuia, String idOficinaDeposito, double totalDeposito,
                   int operacionGuia, String idOficinaDestino, boolean visitada) {
        this.idViaje = idViaje;
        this.idOficina = idOficina;
        this.noGuia = noGuia;
        this.idOficinaGuia = idOficinaGuia;
        this.estatusGuia = estatusGuia;
        this.consecutivo = consecutivo;
        this.impresionPreGuia = impresionPreGuia;
        this.impresionGuia = impresionGuia;
        this.estatus = estatus;
        this.idPersonal = idPersonal;
        this.fechaMod = fechaMod;
        this.horaMod = horaMod;
        this.totalGuia = totalGuia;
        this.idOficinaDeposito = idOficinaDeposito;
        this.totalDeposito = totalDeposito;
        this.operacionGuia = operacionGuia;
        this.idOficinaDestino = idOficinaDestino;
        this.visitada = visitada;
    }

    @Override
    public String toString() {
        StringBuilder strBuilder = new StringBuilder();
        strBuilder.append("GuiaDTO [idViaje=").append(idViaje)
                  .append(", idOficina=").append(idOficina)
                  .append(", noGuia=").append(noGuia)
                  .append(", idOficinaGuia=").append(idOficinaGuia)
                  .append(", estatusGuia=").append(estatusGuia)
                  .append(", consecutivo=").append(consecutivo)
                  .append(", impresionPreGuia=").append(impresionPreGuia)
                  .append(", impresionGuia=").append(impresionGuia)
                  .append(", estatus=").append(estatus)
                  .append(", idPersonal=").append(idPersonal)
                  .append(", fechaMod=").append(fechaMod)
                  .append(", horaMod=").append(horaMod)
                  .append(", totalGuia=").append(totalGuia)
                  .append(", idOficinaDeposito=").append(idOficinaDeposito)
                  .append(", totalDeposito=").append(totalDeposito)
                  .append(", operacionGuia=").append(operacionGuia)
                  .append(", idOficinaDestino=").append(idOficinaDestino)
                  .append(", visitada=").append(visitada)
                  .append("]");
        return strBuilder.toString();
    }
}
