package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.IncidenciasDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "incidencias")
@EntityListeners(Incidencias.class)
public class Incidencias {
	
	@Id
	private String idIncidencia;
	private String folioIncidencia;
	private String bultos;
	private String talon;
	private String bultosTotales;
	private String unidad;
	private String proceso;
	private String almacenista;
	private String coordinador;
	private String oficina;
	private String origen;
	private String destino;
	private String fecha;
	private String status;
	private String observaciones;
	private String incidencia;
	
	/**
	 * Metodo estatico para obtener un Incidencias a partir de un IncidenciasDTO origen
	 * 
	 * @param incidencias IncidenciasDTO origen
	 * 
	 * @return Incidencias
	 */
	public static Incidencias fromIncidenciasDTO(IncidenciasDTO incidencias) {
		Incidencias rest = new Incidencias();
		rest.setIdIncidencia(incidencias.getIdIncidencia());
		rest.setFolioIncidencia(incidencias.getFolioIncidencia());
		rest.setBultos(incidencias.getBultos());
		rest.setTalon(incidencias.getTalon());
		rest.setBultosTotales(incidencias.getBultosTotales());
		rest.setUnidad(incidencias.getUnidad());
		rest.setProceso(incidencias.getProceso());
		rest.setAlmacenista(incidencias.getAlmacenista());
		rest.setCoordinador(incidencias.getCoordinador());
		rest.setOficina(incidencias.getOficina());
		rest.setOrigen(incidencias.getOrigen());
		rest.setDestino(incidencias.getDestino());
		rest.setFecha(incidencias.getFecha());
		rest.setStatus(incidencias.getStatus());
		rest.setObservaciones(incidencias.getObservaciones());
		rest.setIncidencia(incidencias.getIncidencia());
		return rest;
	}
	
	/**
	 * Metodo para obtener un IncidenciasDTO a partir de un Incidencias origen
	 * 
	 * @return IncidenciasDTO
	 */
	public IncidenciasDTO toIncidenciasDTO() {
		IncidenciasDTO dto = new  IncidenciasDTO();
		 dto.setIdIncidencia(this.getIdIncidencia());
		 dto.setFolioIncidencia(this.getFolioIncidencia());
		 dto.setBultos(this.getBultos());
		 dto.setTalon(this.getTalon());
		 dto.setBultosTotales(this.getBultosTotales());
		 dto.setUnidad(this.getUnidad());
		 dto.setProceso(this.getProceso());
		 dto.setAlmacenista(this.getAlmacenista());
		 dto.setCoordinador(this.getCoordinador());
		 dto.setOficina(this.getOficina());
		 dto.setOrigen(this.getOrigen());
		 dto.setDestino(this.getDestino());
		 dto.setFecha(this.getFecha());
		 dto.setStatus(this.getStatus());
		 dto.setObservaciones(this.getObservaciones());
		 dto.setIncidencia(this.getIncidencia());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Incidencias [idIncidencia=").append(idIncidencia)
		.append(",folioIncidencia=").append(folioIncidencia)
		.append(",bultos=").append(bultos)
		.append(",talon=").append(talon)
		.append(",bultosTotales=").append(bultosTotales)
		.append(",unidad=").append(unidad)
		.append(",proceso=").append(proceso)
		.append(",almacenista=").append(almacenista)
		.append(",coordinador=").append(coordinador)
		.append(",oficina=").append(oficina)
		.append(",origen=").append(origen)
		.append(",destino=").append(destino)
		.append(",fecha=").append(fecha)
		.append(",status=").append(status)
		.append(",observaciones=").append(observaciones)
		.append(",incidencia=").append(incidencia);
		return strBuilder.toString();
	}
}
