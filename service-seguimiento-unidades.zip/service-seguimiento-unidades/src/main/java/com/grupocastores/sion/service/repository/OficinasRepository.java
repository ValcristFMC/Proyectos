package com.grupocastores.sion.service.repository;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.OficinasDTO;
import com.grupocastores.sion.service.domain.Oficinas;
import com.grupocastores.sion.utils.UtilitiesRepository;

@Repository
public class OficinasRepository {

	Logger log = LoggerFactory.getLogger(OficinasRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	static final String QUERY_GETOFICINASBYDIVISION = "SELECT o.clave as id_oficina, " +
            "(SELECT STRING_AGG(UPPER(LEFT(value, 1)) + LOWER(SUBSTRING(value, 2, LEN(value))), ' ')  FROM STRING_SPLIT(o.plaza, ' ')) AS nombre, " +
            "o.id_estatus_oficina as estatus, " +
            "om.id_ciudad " +
            "FROM oficina o " +
            "INNER JOIN oficina_division od ON o.clave = od.clave_oficina " +
            "LEFT JOIN OPENQUERY(%s, 'SELECT o.idoficina AS id_oficina, o.idciudad AS id_ciudad FROM personal.oficinas o') om " +
            "ON o.clave = om.id_oficina " +
            "WHERE od.clave_division IN (%s)";
	
	static final String QUERY_GETOFICINAS = "SELECT o.clave as id_oficina, " +
            "(SELECT STRING_AGG(UPPER(LEFT(value, 1)) + LOWER(SUBSTRING(value, 2, LEN(value))), ' ')  FROM STRING_SPLIT(o.plaza, ' ')) AS nombre, " +
            "o.id_estatus_oficina as estatus, " +
            "om.id_ciudad " +
            "FROM oficina o " +
            "INNER JOIN oficina_division od ON o.clave = od.clave_oficina " +
            "LEFT JOIN OPENQUERY(%s, 'SELECT o.idoficina AS id_oficina, o.idciudad AS id_ciudad FROM personal.oficinas o') om " +
            "ON o.clave = om.id_oficina";


	public List<OficinasDTO> getOficinasByDivision(String division) {
		
		String formattedDivision = Arrays.stream(division.split(","))
                .map(val -> "'" + val.trim() + "'")
                .collect(Collectors.joining(","));
		
		String queryString = String.format(QUERY_GETOFICINASBYDIVISION, UtilitiesRepository.getDb23(), formattedDivision);
		Query query = entityManager.createNativeQuery(queryString, Oficinas.class);
		List<Oficinas> lstOficinas = Lists.newArrayList(Iterables.filter(query.getResultList(), Oficinas.class));
		List<OficinasDTO> lstOficinasDTO = lstOficinas.stream().map(Oficinas::toOficinasDTO)
				.collect(Collectors.toList());
		return lstOficinasDTO;
	}
	
public List<OficinasDTO> getOficinas() {
		String queryString = String.format(QUERY_GETOFICINAS, UtilitiesRepository.getDb23());
		Query query = entityManager.createNativeQuery(queryString, Oficinas.class);
		List<Oficinas> lstOficinas = Lists.newArrayList(Iterables.filter(query.getResultList(), Oficinas.class));
		List<OficinasDTO> lstOficinasDTO = lstOficinas.stream().map(Oficinas::toOficinasDTO)
				.collect(Collectors.toList());
		return lstOficinasDTO;
	}
}
