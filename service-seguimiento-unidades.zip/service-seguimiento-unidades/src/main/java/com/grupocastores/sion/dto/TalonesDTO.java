package com.grupocastores.sion.dto;

import java.util.Date;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Talones", description = "Datos de Talones")
public class TalonesDTO {
	
	private String claTalon;
	private int numeroRenglon;
	private String numeroGuia;
	private String idOficina;
	private int idCliente;
	private int idProducto;
	private String unidad;
	private String placas;
	private int origen;
	private int destino;
	private String despacho;
	private int moneda;
	private Date fecha;
	private int status;
	private int tipoUnidad;
	
	public TalonesDTO (String claTalon
			, int numeroRenglon
			, String numeroGuia
			, String idOficina
			, int idCliente
			, int idProducto
			, String unidad
			, String placas
			, int origen
			, int destino
			, String despacho
			, int moneda
			, Date fecha
			, int status
			, int tipoUnidad) {
		this.claTalon = claTalon;
		this.numeroRenglon = numeroRenglon;
		this.numeroGuia = numeroGuia;
		this.idOficina = idOficina;
		this.idCliente = idCliente;
		this.idProducto = idProducto;
		this.unidad = unidad;
		this.placas = placas;
		this.origen = origen;
		this.origen = destino;
		this.despacho = despacho;
		this.moneda = moneda;
		this.fecha = fecha;
		this.status = status;
		this.tipoUnidad = tipoUnidad;
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Guias [claTalon=").append(claTalon)
		.append(", numeroRenglon=").append(numeroRenglon)
		.append(", numeroGuia=").append(numeroGuia)
		.append(", idOficina=").append(idOficina)
		.append(", idCliente=").append(idCliente)
		.append(", idProducto=").append(idProducto)
		.append(", unidad=").append(unidad)
		.append(", placas=").append(placas)
		.append(", origen=").append(origen)
		.append(", destino=").append(destino)
		.append(", despacho=").append(despacho)
		.append(", moneda=").append(moneda)
		.append(", fecha=").append(fecha)
		.append(", status=").append(status)
		.append(", tipoUnidad=").append(tipoUnidad);
		return strBuilder.toString();
	}
}