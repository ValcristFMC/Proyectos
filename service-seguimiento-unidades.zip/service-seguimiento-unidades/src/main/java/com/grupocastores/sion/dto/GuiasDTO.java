package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Guias", description = "Datos de Guias")
public class GuiasDTO {
	
	private int estatusGuia;
	private String numeroGuia;
	private int tipoUnidad;
	private int unidad;
	private String idOficina;
	private String idOperador;
	private int tipoGuia;
	private int origen;
	private int destino;
	private String folioViaje;
	private String totalGuia;
	private int remolque;
	
	public GuiasDTO (int estatusGuia
			, String numeroGuia
			, int tipoUnidad
			, int unidad
			, String idOficina
			, String idOperador
			, int tipoGuia
			, int origen
			, int destino
			, String folioViaje
			, String totalGuia
			, int remolque) {
		this.estatusGuia = estatusGuia;
		this.numeroGuia = numeroGuia;
		this.tipoUnidad = tipoUnidad;
		this.unidad = unidad;
		this.idOficina = idOficina;
		this.idOperador = idOperador;
		this.tipoGuia = tipoGuia;
		this.origen = origen;
		this.destino = destino;
		this.folioViaje = folioViaje;
		this.totalGuia = totalGuia;
		this.remolque = remolque;
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Guias [estatusGuia=").append(estatusGuia)
		.append(", numeroGuia=").append(numeroGuia)	
		.append(", tipoUnidad=").append(tipoUnidad)
		.append(", unidad=").append(unidad)
		.append(", idOficina=").append(idOficina)
		.append(", idOperador=").append(idOperador)
		.append(", tipoGuia=").append(tipoGuia)
		.append(", origen=").append(origen)
		.append(", destino=").append(destino)	
		.append(", folioViaje=").append(folioViaje)
		.append(", totalGuia=").append(totalGuia)
		.append(", remolque=").append(remolque);
		return strBuilder.toString();
	}
}
