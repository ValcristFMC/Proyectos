package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.dto.GuiaDTO;
import com.grupocastores.sion.dto.GuiaStatusDTO;
import com.grupocastores.sion.dto.TalonDetailDTO;
import com.grupocastores.sion.dto.TalonGuiaDTO;
import com.grupocastores.sion.service.ITalonesPorUnidadService;
import com.grupocastores.sion.service.domain.TalonesPorUnidad;
import com.grupocastores.sion.service.repository.TalonesUnidadRepositorya;

@Service
public class TalonesPorUnidadServiceImpl implements ITalonesPorUnidadService{

	@PersistenceContext
	private EntityManager entityManager;
	Logger logger = LoggerFactory.getLogger(ITalonesPorUnidadService.class);
	
	@Autowired
	private TalonesUnidadRepositorya talonesUnidadRepository;

	@Override
	public List<TalonesPorUnidad> getTalonesPorUnidadDTO(String noeconomico, String idOficinaDestino) {
	    List<TalonesPorUnidad> lstTalonesOcurre = new ArrayList<>();

	    List<GuiaDTO> lstGuias = talonesUnidadRepository.getGuias(noeconomico, idOficinaDestino);
	    if (lstGuias.isEmpty()) {
	        return lstTalonesOcurre;
	    }

	    Set<String> noGuiasSet = lstGuias.stream()
	            .map(GuiaDTO::getNoGuia)
	            .collect(Collectors.toSet());

	    List<String> noGuiasList = noGuiasSet.stream()
	            .map(noGuia -> "\"" + noGuia + "\"") 
	            .collect(Collectors.toList());

	    String noGuiasStr = String.join(",", noGuiasList);
	    List<GuiaStatusDTO> lstGuiaStatusDTO = talonesUnidadRepository.getGuiasByNoGuia(noGuiasStr);

	    if (lstGuiaStatusDTO.isEmpty()) {
	        return lstTalonesOcurre;
	    }

	    Map<String, Set<String>> guiasPorTabla = lstGuiaStatusDTO.stream()
	        .collect(Collectors.groupingBy(
	            GuiaStatusDTO::getTabla,
	            Collectors.mapping(GuiaStatusDTO::getNumeroGuia, Collectors.toSet())
	        ));

	    guiasPorTabla.forEach((tabla, noGuiasTabla) -> {
	    	List<TalonGuiaDTO> lstTalonInfoDTO = talonesUnidadRepository.getInfoTalones(noGuiasStr, tabla);

	        if (!lstTalonInfoDTO.isEmpty()) {
	            Set<String> noTalonesSet = lstTalonInfoDTO.stream()
	                .map(TalonGuiaDTO::getClaveTalon)
	                .collect(Collectors.toSet());

	            List<String> noTalonesList = new ArrayList<>();
	            for (String talon : noTalonesSet) {
	                noTalonesList.add("\"" + talon + "\""); 
	            }

	            String noTalonesStr = String.join(",", noTalonesList);
	            List<TalonDetailDTO> lstTalonDetailDTO = talonesUnidadRepository.getInfoTalon(noTalonesStr);

	            if (!lstTalonDetailDTO.isEmpty()) {
	                Map<String, Set<String>> talonesPorTabla = lstTalonDetailDTO.stream()
	                    .collect(Collectors.groupingBy(
	                        TalonDetailDTO::getTabla,
	                        Collectors.mapping(TalonDetailDTO::getClaTalon, Collectors.toSet())
	                    ));

	                talonesPorTabla.forEach((tablaTalon, noTalonesTabla) -> {
	                	lstTalonesOcurre.addAll(talonesUnidadRepository.getTalonesTr(noTalonesStr, tablaTalon));
	                });
	                
	                
	            }
	        }
	    });
	    return lstTalonesOcurre;
	}

}
