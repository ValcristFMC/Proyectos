package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.service.repository.GuiasRepository;
import com.grupocastores.sion.dto.GuiasDTO;
import com.grupocastores.sion.service.IGuiasService;

@Service
public class GuiasServiceImpl implements IGuiasService {
	Logger logger = LoggerFactory.getLogger(GuiasServiceImpl.class);

	@Autowired
	private GuiasRepository guiasRepository;

	@Override
	public List<GuiasDTO> getGuiasByFechas(String tabla) {
		List<GuiasDTO> lstGuias = new ArrayList<GuiasDTO>();

		try {
			lstGuias = guiasRepository.getGuias(tabla);
			if (lstGuias == null) {
				throw new Exception("No se pudo obtener el registro del seguimiento: ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return lstGuias;
	}
}
