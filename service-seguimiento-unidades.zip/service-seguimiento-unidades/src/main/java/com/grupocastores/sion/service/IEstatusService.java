package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.EstatusDTO;

public interface IEstatusService {

	public List<EstatusDTO> getEstatus();
}
