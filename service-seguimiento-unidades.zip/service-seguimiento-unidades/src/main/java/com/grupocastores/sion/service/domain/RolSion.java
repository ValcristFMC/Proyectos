package com.grupocastores.sion.service.domain;

import javax.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "rol_sion")
public class RolSion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_rol")
    private Long idRol;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "rol_maestro")
    private String rolMaestro;

    @Column(name = "estatus")
    private String estatus;

    @Column(name = "id_personal")
    private Long idPersonal;

    @Column(name = "fecha_registro")
    private String fechaRegistro;

    @Column(name = "fecha_modificacion")
    private String fechaModificacion;

}
