package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "usuario_division_sion")
public class UsuarioDivisionSion {

    @Id
    private Long idUsuarioDivision;

    private Long idUsuario;
    private Long idDivision;
    private String estatus;
    private Long idPersonal;
    private Date fechaRegistro;
    private Date fechaModificacion;

    // Getters y Setters
    public Long getIdUsuarioDivision() {
        return idUsuarioDivision;
    }

    public void setIdUsuarioDivision(Long idUsuarioDivision) {
        this.idUsuarioDivision = idUsuarioDivision;
    }

    public Long getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Long getIdDivision() {
        return idDivision;
    }

    public void setIdDivision(Long idDivision) {
        this.idDivision = idDivision;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }

    public Long getIdPersonal() {
        return idPersonal;
    }

    public void setIdPersonal(Long idPersonal) {
        this.idPersonal = idPersonal;
    }

    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Date fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Date getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(Date fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }
}
