package com.grupocastores.sion.service.repository;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.TalonesDTO;
import com.grupocastores.sion.service.domain.Talones;

@Repository
public class TalonesRepository {

	Logger log = LoggerFactory.getLogger(TalonesRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	static final String QUERY = "SELECT * FROM OPENQUERY (PRODUCCION23,'"
			+ " SELECT "
			+ "	tg.cla_talon AS cla_talon"
			+ "	, tg.norenglon AS numero_renglon "
			+ "	, gu.no_guia AS numero_guia"
			+ "	, gu.idoficina AS id_oficina "
			+ "	, gu.idcliente AS id_cliente"
			+ "	, gu.idproducto AS id_producto "
			+ "	, gu.unidad AS unidad"
			+ "	, gu.placas AS placas"
			+ "	, gu.origen AS origen "
			+ "	, gu.destino AS destino"
			+ "	, gu.despacho AS despacho "
			+ "	, gu.moneda AS moneda"
			+ "	, gu.fecha AS fecha"
			+ "	, gu.status AS status "
			+ "	, gu.tipounidad AS tipo_unidad"
			+ " FROM talones.gu%s gu"
			+ " INNER JOIN talones.tg%s	tg	ON tg.no_guia AND gu.no_guia"
			+ " WHERE gu.moneda = 1 "
			+ "	AND gu.no_guia = \"%s\";')";

	public List<TalonesDTO> getTalones(String tabla, String numeroGuia) {
		String queryString = String.format(QUERY, tabla, tabla, numeroGuia);
		Query query = entityManager.createNativeQuery(queryString, Talones.class);
		List<Talones> lstTalones = Lists.newArrayList(Iterables.filter(query.getResultList(), Talones.class));
		List<TalonesDTO> lstTalonesDTO = lstTalones.stream().map(Talones::toTalonesDTO).collect(Collectors.toList());
		return lstTalonesDTO;
	}

}
