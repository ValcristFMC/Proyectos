package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.SemaforoStatusDTO;
import lombok.Data;

@Data
@Entity
@Table(name = "semaforo_status")
public class SemaforoStatus {

    private String idViaje;
    private String idOficina;
    @Id
    private int ordenLlegada;
    private Integer idCiudad;
    private String nombreDestino;
    private String llegadaGeocerca;
    private String salidaGeocerca;
    private String horaLlegadaFicha;
    private String horaSalidaFicha;
    private int estatusLlegada;
    private int estatusSalida;
    private boolean idProximaOficina;
    private String tipo;

    // Método para convertir de DTO a entidad
    public static SemaforoStatus fromSemaforoStatusDTO(SemaforoStatusDTO semaforoStatusDTO) {
        SemaforoStatus semaforoStatus = new SemaforoStatus();
        semaforoStatus.setIdViaje(semaforoStatusDTO.getIdViaje());
        semaforoStatus.setIdOficina(semaforoStatusDTO.getIdOficina());
        semaforoStatus.setOrdenLlegada(semaforoStatusDTO.getOrdenLlegada());
        semaforoStatus.setIdCiudad(semaforoStatusDTO.getIdCiudad());
        semaforoStatus.setNombreDestino(semaforoStatusDTO.getNombreDestino());
        semaforoStatus.setLlegadaGeocerca(semaforoStatusDTO.getLlegadaGeocerca());
        semaforoStatus.setSalidaGeocerca(semaforoStatusDTO.getSalidaGeocerca());
        semaforoStatus.setHoraLlegadaFicha(semaforoStatusDTO.getHoraLlegadaFicha());
        semaforoStatus.setHoraSalidaFicha(semaforoStatusDTO.getHoraSalidaFicha());
        semaforoStatus.setEstatusLlegada(semaforoStatusDTO.getEstatusLlegada());
        semaforoStatus.setEstatusSalida(semaforoStatusDTO.getEstatusSalida());
        semaforoStatus.setIdProximaOficina(semaforoStatusDTO.isIdProximaOficina());
        semaforoStatus.setTipo(semaforoStatusDTO.getTipo());
        return semaforoStatus;
    }

    // Método para convertir de entidad a DTO
    public SemaforoStatusDTO toSemaforoStatusDTO() {
        SemaforoStatusDTO dto = new SemaforoStatusDTO(
                this.getIdViaje(),
                this.getIdOficina(),
                this.getOrdenLlegada(),
                this.getIdCiudad(),
                this.getNombreDestino(),
                this.getLlegadaGeocerca(),
                this.getSalidaGeocerca(),
                this.getHoraLlegadaFicha(),
                this.getHoraSalidaFicha(),
                this.getEstatusLlegada(),
                this.getEstatusSalida(),
                this.isIdProximaOficina(),
                this.getTipo()
        );
        return dto;
    }
}
