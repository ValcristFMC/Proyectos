package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Talon", description = "Detalles del talon relacionado a la guia")
public class TalonGuiaDTO {

    private String claveTalon;
    private String numeroGuia;
    private int numeroRenglon;

    public TalonGuiaDTO(String claveTalon, String numeroGuia, int noRenglon) {
        this.claveTalon = claveTalon;
        this.numeroGuia = numeroGuia;
        this.numeroRenglon = noRenglon;
    }

    @Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("TalonInfoDTO [claveTalon=").append(claveTalon)	
		.append(", numeroGuia=").append(numeroGuia)
		.append(", numeroRenglon=").append(numeroRenglon);

		return strBuilder.toString();
	}
}
