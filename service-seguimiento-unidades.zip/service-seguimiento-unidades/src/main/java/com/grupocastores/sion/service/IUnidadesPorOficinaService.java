package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.SemaforoStatusDTO;
import com.grupocastores.sion.dto.UnidadUbicacionDTO;
import com.grupocastores.sion.service.domain.SalidaUnidades;
import com.grupocastores.sion.service.domain.UnidadesPorOficina;

public interface IUnidadesPorOficinaService {

	public List<UnidadesPorOficina> getUnidadesPorOficina(String OficinaDestino);
	public UnidadUbicacionDTO getUnidadUbicacion(String idOficina, String idUnidad,String geometries, String overview,String tipo);
	public List<SemaforoStatusDTO> getSemaforoStatus(String idViaje, String idOficina);
	public List<SalidaUnidades> getSalidaUnidad (Integer idruta,Integer dia, String idviaje, String idoficina, String destino);
}
