package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.service.repository.SeguimientoUnidadesRepository;
import com.grupocastores.sion.dto.SeguimientoUnidadesDTO;
import com.grupocastores.sion.service.ISeguimientoUnidadesService;

@Service
public class SeguimientoUnidadesServiceImpl implements ISeguimientoUnidadesService {
	Logger logger = LoggerFactory.getLogger(SeguimientoUnidadesServiceImpl.class);

	@Autowired
	private SeguimientoUnidadesRepository seguimientoUnidadesRepository;

	@Override
	public List<SeguimientoUnidadesDTO> getSeguimientoUnidadesByFechas(String fechaInicial, String fechaFinal,
			int OficinaDestino) {
		List<SeguimientoUnidadesDTO> lstSeguimientoUnidades = new ArrayList<SeguimientoUnidadesDTO>();

		try {
			lstSeguimientoUnidades = seguimientoUnidadesRepository.getSeguimientoUnidades(fechaInicial, fechaFinal,
					OficinaDestino);
			if (lstSeguimientoUnidades == null) {
				throw new Exception("No se pudo obtener el registro del seguimiento: ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return lstSeguimientoUnidades;
	}
}
