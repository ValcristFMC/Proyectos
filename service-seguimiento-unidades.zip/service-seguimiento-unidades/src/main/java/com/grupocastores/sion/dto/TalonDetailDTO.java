package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Detalle de Talon", description = "Detalles del talon en la base de datos")
public class TalonDetailDTO {

    private String claTalon;
    private String idOficina;
    private String tabla;
    private int status;
    private String remision;
    private String serie;
    private double maniobras;
    private int relacion;
    private String tablarel;
    private String dirxml;
    private boolean enviacorreo;
    private boolean seenviocorreo;
    private String noaprobacion;
    private String anioaprobacion;
    private String nocertificado;
    private String idOficinaOrigen;

    @Override
    public String toString() {
        return "TalonDetailDTO [claTalon=" + claTalon + ", idOficina=" + idOficina + ", tabla=" + tabla + ", status=" + status
                + ", remision=" + remision + ", serie=" + serie + ", maniobras=" + maniobras + ", relacion=" + relacion
                + ", tablarel=" + tablarel + ", dirxml=" + dirxml + ", enviacorreo=" + enviacorreo
                + ", seenviocorreo=" + seenviocorreo + ", noaprobacion=" + noaprobacion + ", anioaprobacion="
                + anioaprobacion + ", nocertificado=" + nocertificado + ", idOficinaOrigen=" + idOficinaOrigen + "]";
    }
}
