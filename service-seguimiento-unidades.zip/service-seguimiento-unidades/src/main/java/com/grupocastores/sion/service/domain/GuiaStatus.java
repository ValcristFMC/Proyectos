package com.grupocastores.sion.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.GuiaStatusDTO;
import lombok.Data;

@Data
@Entity
@Table(name = "guia_status")
public class GuiaStatus {

    @Id
    @Column(name = "numero_guia")
    private String numeroGuia;
    private String tabla;
    private String unidad;
    private int status;
    private Integer idLiquidacion; 
    private Integer anioLiquidacion; 

    public static GuiaStatus fromGuiaStatusDTO(GuiaStatusDTO guiaStatusDTO) {
        GuiaStatus guiaStatus = new GuiaStatus();
        guiaStatus.setNumeroGuia(guiaStatusDTO.getNumeroGuia());
        guiaStatus.setTabla(guiaStatusDTO.getTabla());
        guiaStatus.setUnidad(guiaStatusDTO.getUnidad());
        guiaStatus.setStatus(guiaStatusDTO.getStatus());
        guiaStatus.setIdLiquidacion(guiaStatusDTO.getIdLiquidacion());
        guiaStatus.setAnioLiquidacion(guiaStatusDTO.getAnioLiq());
        return guiaStatus;
    }

    public GuiaStatusDTO toGuiaStatusDTO() {
        GuiaStatusDTO dto = new GuiaStatusDTO();
        dto.setNumeroGuia(this.getNumeroGuia());
        dto.setTabla(this.getTabla());
        dto.setUnidad(this.getUnidad());
        dto.setStatus(this.getStatus());
        dto.setIdLiquidacion(this.getIdLiquidacion());
        dto.setAnioLiq(this.getAnioLiquidacion());
        return dto;
    }
}
