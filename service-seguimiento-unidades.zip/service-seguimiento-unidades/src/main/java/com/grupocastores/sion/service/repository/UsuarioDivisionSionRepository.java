package com.grupocastores.sion.service.repository;

import com.grupocastores.sion.service.domain.UsuarioDivisionSion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsuarioDivisionSionRepository extends JpaRepository<UsuarioDivisionSion, Long> {
    List<UsuarioDivisionSion> findByIdUsuario(Long idUsuario); 
}
