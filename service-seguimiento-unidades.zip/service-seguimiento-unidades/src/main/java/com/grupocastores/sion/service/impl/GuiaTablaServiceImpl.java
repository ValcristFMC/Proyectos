package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.service.repository.GuiaTablaRepository;
import com.grupocastores.sion.dto.GuiaTablaDTO;
import com.grupocastores.sion.service.IGuiaTablaService;

@Service
public class GuiaTablaServiceImpl implements IGuiaTablaService {
	Logger logger = LoggerFactory.getLogger(GuiaTablaServiceImpl.class);

	@Autowired
	private GuiaTablaRepository guiaTablaRepository;

	@Override
	public List<GuiaTablaDTO> getGuiaTablaByFechas(String fechaInicial, String fechaFinal) {
		List<GuiaTablaDTO> lstGuiaTabla = new ArrayList<GuiaTablaDTO>();

		try {
			lstGuiaTabla = guiaTablaRepository.getGuiaTabla(fechaInicial, fechaFinal);
			if (lstGuiaTabla == null) {
				throw new Exception("No se pudo obtener el registro del seguimiento: ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return lstGuiaTabla;
	}
}
