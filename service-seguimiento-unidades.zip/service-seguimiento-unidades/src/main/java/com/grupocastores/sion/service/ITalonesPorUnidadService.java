package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.service.domain.TalonesPorUnidad;

public interface ITalonesPorUnidadService {

	public List<TalonesPorUnidad> getTalonesPorUnidadDTO(String noeconomico, String idOficinaDestino);
}
