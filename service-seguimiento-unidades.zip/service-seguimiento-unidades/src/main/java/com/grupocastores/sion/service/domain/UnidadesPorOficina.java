package com.grupocastores.sion.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;
import com.grupocastores.sion.dto.UnidadesPorOficinaDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "unidadesPorOficina")
@EntityListeners(UnidadesPorOficina.class)
public class UnidadesPorOficina {
	
	@Id
	private String unidad;
	private String estatus;
	@Column(name = "id_viaje")
	private String idViaje;
	@Column(name = "id_oficina")
	private String idOficina;
	@Column(name = "id_ruta")
	private String idRuta;
	
	public static UnidadesPorOficina fromUnidadesPorOficinaDTO(UnidadesPorOficina unidadesPorOficina) {
		UnidadesPorOficina rest = new UnidadesPorOficina();
		rest.setUnidad(unidadesPorOficina.getUnidad());
		rest.setEstatus(unidadesPorOficina.getEstatus());
		rest.setIdViaje(unidadesPorOficina.getIdViaje());
		rest.setIdOficina(unidadesPorOficina.getIdOficina());
		rest.setIdRuta(unidadesPorOficina.getIdRuta());
		return rest;
	}
	
	public UnidadesPorOficinaDTO toUnidadesPorOficinaDTO() {
		UnidadesPorOficinaDTO dto = new  UnidadesPorOficinaDTO();
		 dto.setUnidad(this.getUnidad());
		 dto.setEstatus(this.getEstatus());
		 dto.setIdViaje(this.getIdViaje());
		 dto.setIdOficina(this.getIdOficina());
		 dto.setIdRuta(this.getIdRuta());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("UnidadesPorOficina [unidad=").append(unidad)
		.append(",estatus=").append(estatus)
		.append(",idviaje=").append(idViaje)
		.append(",idoficina=").append(idOficina)
		.append(",idRuta=").append(idRuta);
		return strBuilder.toString();
	}
}
