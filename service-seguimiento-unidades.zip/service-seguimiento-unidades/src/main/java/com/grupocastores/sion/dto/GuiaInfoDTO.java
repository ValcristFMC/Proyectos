package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Guia", description = "Detalles de la guia")
public class GuiaInfoDTO {

    private String numeroGuia;
    private String unidad;
    private String placas;
    private int idOperador;
    private int remolque;
    private int origen;
    private int destino;
    private String despacho;
    private int idPersonal;
    private String idOficina;
    private int moneda;
    private double conversion;
    private LocalDate fecha;
    private LocalTime hora;
    private int status;
    private int idCliente;
    private int idProducto;
    private String cita;
    private int tipoUnidad;

    public GuiaInfoDTO(String noGuia, String unidad, String placas, int idOperador, int remolque, int origen, int destino, 
                       String despacho, int idPersonal, String idOficina, int moneda, double conversion, 
                       LocalDate fecha, LocalTime hora, int status, int idCliente, int idProducto, 
                       String cita, int tipoUnidad) {
        this.numeroGuia = noGuia;
        this.unidad = unidad;
        this.placas = placas;
        this.idOperador = idOperador;
        this.remolque = remolque;
        this.origen = origen;
        this.destino = destino;
        this.despacho = despacho;
        this.idPersonal = idPersonal;
        this.idOficina = idOficina;
        this.moneda = moneda;
        this.conversion = conversion;
        this.fecha = fecha;
        this.hora = hora;
        this.status = status;
        this.idCliente = idCliente;
        this.idProducto = idProducto;
        this.cita = cita;
        this.tipoUnidad = tipoUnidad;
    }

    @Override
    public String toString() {
        return "GuiaInfoDTO [noGuia=" + numeroGuia + ", unidad=" + unidad + ", placas=" + placas +
                ", idOperador=" + idOperador + ", remolque=" + remolque + ", origen=" + origen +
                ", destino=" + destino + ", despacho=" + despacho + ", idPersonal=" + idPersonal +
                ", idOficina=" + idOficina + ", moneda=" + moneda + ", conversion=" + conversion +
                ", fecha=" + fecha + ", hora=" + hora + ", status=" + status +
                ", idCliente=" + idCliente + ", idProducto=" + idProducto +
                ", cita=" + cita + ", tipoUnidad=" + tipoUnidad + "]";
    }
}
