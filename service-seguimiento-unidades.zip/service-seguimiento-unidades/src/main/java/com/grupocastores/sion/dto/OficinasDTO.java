package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Division", description = "Datos de Division")
public class OficinasDTO {
	
	private String idOficina;
	private String nombre;
	private String estatus;
	private String idCiudad;
	
	public OficinasDTO (String idOficina, String nombre, String estatus, String idCiudad) {
		this.idOficina = idOficina;
		this.nombre = nombre;
		this.estatus = estatus;
		this.idCiudad = idCiudad;
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Division [idOficina=").append(idOficina)
		.append(", nombre=").append(nombre)
		.append(", estatus=").append(estatus)
		.append(", idCiudad=").append(idCiudad);
		return strBuilder.toString();
	}
}
