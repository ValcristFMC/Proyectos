package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion del Semáforo de Viaje", description = "Datos del estado de la llegada y salida en el semáforo de viajes")
public class SemaforoStatusDTO {

    private String idViaje;
    private String idOficina;
    private int ordenLlegada;
    private Integer idCiudad;
    private String nombreDestino;
    private String llegadaGeocerca;
    private String salidaGeocerca;
    private String horaLlegadaFicha;
    private String horaSalidaFicha;
    private int estatusLlegada;
    private int estatusSalida;
    private boolean idProximaOficina;
    private String tipo;

    public SemaforoStatusDTO(String idViaje, String idOficina, int ordenLlegada, Integer idCiudad, String nombreDestino,
                             String llegadaGeocerca, String salidaGeocerca, String horaLlegadaFicha, String horaSalidaFicha,
                             int estatusLlegada, int estatusSalida, boolean idProximaOficina, String tipo) {
        this.idViaje = idViaje;
        this.idOficina = idOficina;
        this.ordenLlegada = ordenLlegada;
        this.idCiudad = idCiudad;
        this.nombreDestino = nombreDestino;
        this.llegadaGeocerca = llegadaGeocerca;
        this.salidaGeocerca = salidaGeocerca;
        this.horaLlegadaFicha = horaLlegadaFicha;
        this.horaSalidaFicha = horaSalidaFicha;
        this.estatusLlegada = estatusLlegada;
        this.estatusSalida = estatusSalida;
        this.idProximaOficina = idProximaOficina;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "SemaforoStatusDTO{" +
                "idViaje='" + idViaje + '\'' +
                ", idOficina='" + idOficina + '\'' +
                ", ordenLlegada=" + ordenLlegada +
                ", idCiudad=" + idCiudad +
                ", nombreDestino='" + nombreDestino + '\'' +
                ", llegadaGeocerca='" + llegadaGeocerca + '\'' +
                ", salidaGeocerca='" + salidaGeocerca + '\'' +
                ", horaLlegadaFicha='" + horaLlegadaFicha + '\'' +
                ", horaSalidaFicha='" + horaSalidaFicha + '\'' +
                ", estatusLlegada=" + estatusLlegada +
                ", estatusSalida=" + estatusSalida +
                ", idProximaOficina=" + idProximaOficina +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}
