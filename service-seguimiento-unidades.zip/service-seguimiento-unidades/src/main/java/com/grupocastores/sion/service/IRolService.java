package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.service.domain.UsuarioRolSion;

public interface IRolService {

    public UsuarioRolSion getRolesByUsuarioId(Long idUsuario);
}
