package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.GuiasDTO;
import lombok.Data;

@Data
@Entity
@Table(name = "seguimientoUnidades")
@EntityListeners(SeguimientoUnidades.class)
public class Guias {
	
	private int estatusGuia;
	private String numeroGuia;
	private int tipoUnidad;
	private int unidad;
	@Id
	private String idOficina;
	private String idOperador;
	private int tipoGuia;
	private int origen;
	private int destino;
	private String folioViaje;
	private String totalGuia;
	private int remolque;
	
	/**
	 * Metodo estatico para obtener un Guias a partir de un GuiasDTO origen
	 * 
	 * @param guias GuiasDTO origen
	 * 
	 * @return Guias
	 */
	public static Guias fromGuiasDTO(GuiasDTO guias) {
		Guias rest = new Guias();
		rest.setEstatusGuia(guias.getEstatusGuia());
		rest.setNumeroGuia(guias.getNumeroGuia());
		rest.setTipoUnidad(guias.getTipoUnidad());
		rest.setUnidad(guias.getUnidad());		
		rest.setIdOficina(guias.getIdOficina());
		rest.setIdOperador(guias.getIdOperador());
		rest.setTipoGuia(guias.getTipoGuia());
		rest.setOrigen(guias.getOrigen());
		rest.setDestino(guias.getDestino());
		rest.setFolioViaje(guias.getFolioViaje());
		rest.setTotalGuia(guias.getTotalGuia());
		rest.setRemolque(guias.getRemolque());
		return rest;
	}
	
	/**
	 * Metodo para obtener un GuiasDTO a partir de un Guias origen
	 * 
	 * @return GuiasDTO
	 */
	public GuiasDTO toGuiasDTO() {
		 GuiasDTO dto = new  GuiasDTO();
		 dto.setEstatusGuia(this.getEstatusGuia());
		 dto.setNumeroGuia(this.getNumeroGuia());
		 dto.setTipoUnidad(this.getTipoUnidad());
		 dto.setUnidad(this.getUnidad());
		 dto.setIdOficina(this.getIdOficina());
		 dto.setIdOperador(this.getIdOperador());
		 dto.setTipoGuia(this.getTipoGuia());
		 dto.setOrigen(this.getOrigen());
		 dto.setDestino(this.getDestino());
		 dto.setFolioViaje(this.getFolioViaje());
		 dto.setTotalGuia(this.getTotalGuia());
		 dto.setRemolque(this.getRemolque());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Guias [estatusGuia=").append(estatusGuia)
		.append(",numeroGuia=").append(numeroGuia)
		.append(",idOficina=").append(idOficina)
		.append(",unidad=").append(unidad)
		.append(",idOficina=").append(idOficina)
		.append(",idOperador=").append(idOperador)
		.append(",tipoGuia=").append(tipoGuia)
		.append(",origen=").append(origen)
		.append(",destino=").append(destino)
		.append(",folioViaje=").append(folioViaje)
		.append(",totalGuia=").append(totalGuia)
		.append(",remolque=").append(remolque);
		return strBuilder.toString();
	}
}



