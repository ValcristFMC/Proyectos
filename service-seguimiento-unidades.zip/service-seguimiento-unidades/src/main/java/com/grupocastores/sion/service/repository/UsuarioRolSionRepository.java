package com.grupocastores.sion.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.grupocastores.sion.service.domain.UsuarioRolSion;

public interface UsuarioRolSionRepository extends JpaRepository<UsuarioRolSion, Long> {

    static final String QUERY_FIND_ROLES_BY_USUARIO_ID = "SELECT ur FROM UsuarioRolSion ur " +
                                                         "JOIN ur.rolSion r " +
                                                         "WHERE ur.idUsuario = :idUsuario";

    @Query(QUERY_FIND_ROLES_BY_USUARIO_ID)
    UsuarioRolSion findRolesByUsuarioId(@Param("idUsuario") Long idUsuario);
}
