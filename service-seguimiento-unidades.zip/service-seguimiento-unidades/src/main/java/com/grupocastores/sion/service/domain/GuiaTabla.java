package com.grupocastores.sion.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.GuiaTablaDTO;

import lombok.Data;


@Data
@Entity
@Table(name = "guiaTabla")
@EntityListeners(GuiaTabla.class)
public class GuiaTabla {
	
	private String idViaje;
	@Id
	private String idOficina;
	private String idOficinaGuia;
	private String idOficinaDestino;
	private String oficina;
	private String oficinaGuia;
	private String oficinaDestino;
	private String numeroGuia;
	private int estatusGuia;
	private int estatus;
	private int status;
	private String estatusGuiaViaje;
	private String estatusViaje;
	private String statusViaje;
	private String tabla;
	private String unidad;
	
	public static GuiaTabla fromGuiaTablaDTO(GuiaTablaDTO guiaTabla) {
		GuiaTabla rest = new GuiaTabla();
		rest.setIdViaje(guiaTabla.getIdViaje());
		rest.setIdOficinaGuia(guiaTabla.getIdOficinaGuia());
		rest.setIdOficinaDestino(guiaTabla.getIdOficinaDestino());
		rest.setOficina(guiaTabla.getOficina());		
		rest.setOficinaGuia(guiaTabla.getOficinaGuia());
		rest.setOficinaDestino(guiaTabla.getOficinaDestino());
		rest.setNumeroGuia(guiaTabla.getNumeroGuia());
		rest.setEstatusGuia(guiaTabla.getEstatusGuia());
		rest.setEstatus(guiaTabla.getEstatus());
		rest.setStatus(guiaTabla.getStatus());
		rest.setEstatusGuiaViaje(guiaTabla.getEstatusGuiaViaje());
		rest.setEstatusViaje(guiaTabla.getEstatusViaje());
		rest.setStatusViaje(guiaTabla.getStatusViaje());
		rest.setTabla(guiaTabla.getTabla());
		rest.setUnidad(guiaTabla.getUnidad());
		return rest;
	}
	
	/**
	 * Metodo para obtener un GuiasDTO a partir de un Guias origen
	 * 
	 * @return GuiaTablaDTO
	 */
	public GuiaTablaDTO toGuiaTablaDTO() {
		 GuiaTablaDTO dto = new  GuiaTablaDTO();
		 dto.setIdViaje(this.getIdViaje());
		 dto.setIdOficinaGuia(this.getIdOficinaGuia());
		 dto.setIdOficinaDestino(this.getIdOficinaDestino());
		 dto.setOficina(this.getOficina());
		 dto.setOficinaGuia(this.getOficinaGuia());
		 dto.setOficinaDestino(this.getOficinaDestino());
		 dto.setNumeroGuia(this.getNumeroGuia());
		 dto.setEstatusGuia(this.getEstatusGuia());
		 dto.setEstatus(this.getEstatus());
		 dto.setStatus(this.getStatus());
		 dto.setEstatusGuiaViaje(this.getEstatusGuiaViaje());
		 dto.setEstatusViaje(this.getEstatusViaje());
		 dto.setStatusViaje(this.getStatusViaje());
		 dto.setTabla(this.getTabla());
		 dto.setUnidad(this.getUnidad());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("GuiaTabla [idViaje=").append(idViaje)
		.append(",idOficinaGuia=").append(idOficinaGuia)
		.append(",idOficinaDestino=").append(idOficinaDestino)
		.append(",oficina=").append(oficina)
		.append(",oficinaGuia=").append(oficinaGuia)
		.append(",oficinaDestino=").append(oficinaDestino)
		.append(",numeroGuia=").append(numeroGuia)
		.append(",estatusGuia=").append(estatusGuia)
		.append(",estatus=").append(estatus)
		.append(",status=").append(status)
		.append(",estatusGuiaViaje=").append(estatusGuiaViaje)
		.append(",estatusViaje=").append(estatusViaje)
		.append(",statusViaje=").append(statusViaje)
		.append(",tabla=").append(tabla)
		.append(",unidad=").append(unidad);
		return strBuilder.toString();
	}

}
