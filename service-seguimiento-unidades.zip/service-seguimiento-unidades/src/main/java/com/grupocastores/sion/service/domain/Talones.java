package com.grupocastores.sion.service.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.sion.dto.TalonesDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "talones")
public class Talones {
	
	private String claTalon;
	private int numeroRenglon;
	private String numeroGuia;
	@Id
	private String idOficina;
	private int idCliente;
	private int idProducto;
	private String unidad;
	private String placas;
	private int origen;
	private int destino;
	private String despacho;
	private int moneda;
	private Date fecha;
	private int status;
	private int tipoUnidad;
	
	/**
	 * Metodo estatico para obtener un Talones a partir de un TalonesDTO origen
	 * 
	 * @param talones TalonesDTO origen
	 * 
	 * @return Talones
	 */
	public static Talones fromTalonesDTO(TalonesDTO talones) {
		Talones rest = new Talones();
		rest.setClaTalon(talones.getClaTalon());
		rest.setNumeroRenglon(talones.getNumeroRenglon());
		rest.setNumeroGuia(talones.getNumeroGuia());
		rest.setIdOficina(talones.getIdOficina());
		rest.setIdCliente(talones.getIdCliente());
		rest.setIdProducto(talones.getIdProducto());
		rest.setUnidad(talones.getUnidad());
		rest.setPlacas(talones.getPlacas());
		rest.setOrigen(talones.getOrigen());
		rest.setDestino(talones.getDestino());
		rest.setDespacho(talones.getDespacho());
		rest.setMoneda(talones.getMoneda());
		rest.setFecha(talones.getFecha());
		rest.setStatus(talones.getStatus());
		rest.setTipoUnidad(talones.getTipoUnidad());
		return rest;
	}
	
	/**
	 * Metodo para obtener un TalonesDTO a partir de un Talones origen
	 * 
	 * @return TalonesDTO
	 */
	public TalonesDTO toTalonesDTO() {
		 TalonesDTO dto = new  TalonesDTO();
		 dto.setClaTalon(this.getClaTalon());
		 dto.setNumeroRenglon(this.getNumeroRenglon());
		 dto.setNumeroGuia(this.getNumeroGuia());
		 dto.setIdOficina(this.getIdOficina());
		 dto.setIdCliente(this.getIdCliente());
		 dto.setIdProducto(this.getIdProducto());
		 dto.setUnidad(this.getUnidad());
		 dto.setPlacas(this.getPlacas());
		 dto.setOrigen(this.getOrigen());
		 dto.setDestino(this.getDestino());
		 dto.setDespacho(this.getDespacho());
		 dto.setMoneda(this.getMoneda());
		 dto.setFecha(this.getFecha());
		 dto.setStatus(this.getStatus());
		 dto.setTipoUnidad(this.getTipoUnidad());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Talones [claTalon=").append(claTalon)
		.append(",numeroRenglon=").append(numeroRenglon)
		.append(",numeroGuia=").append(numeroGuia)
		.append(",idOficina=").append(idOficina)
		.append(",idCliente=").append(idCliente)
		.append(",idProducto=").append(idProducto)
		.append(",unidad=").append(unidad)
		.append(",placas=").append(placas)
		.append(",origen=").append(origen)
		.append(",destino=").append(destino)
		.append(",despacho=").append(despacho)
		.append(",moneda=").append(moneda)
		.append(",fecha=").append(fecha)
		.append(",status=").append(status)
		.append(",tipoUnidad=").append(tipoUnidad);
		return strBuilder.toString();
	}
}
