package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Unidades por oficina", description = "Datos de las unidades")
public class UnidadesPorOficinaDTO {
	String unidad;
	String estatus;
	String idViaje;
	String idOficina;
	String idRuta;
	
	public UnidadesPorOficinaDTO (String unidad,String estatus,String idviaje, String idoficina, String IdRuta) {
		this.unidad= unidad;
		this.estatus = estatus;
		this.idViaje=idviaje;
		this.idOficina=idoficina;
		this.idRuta=IdRuta;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("UnidadesPorOficina [unidad=").append(unidad)
		.append(",estatus").append(estatus)
		.append(", idviaje").append(idViaje)
		.append(", idoficina").append(idOficina)
		.append(",idRuta").append(idRuta);
		return strBuilder.toString();
	}
}
