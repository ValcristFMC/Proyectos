package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.SeguimientoUnidadesDTO;

public interface ISeguimientoUnidadesService {

	public List<SeguimientoUnidadesDTO> getSeguimientoUnidadesByFechas(String fechaInicial, String fechaFinal,
			int oficinaDestino);
}
