package com.grupocastores.sion.service.repository;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.SeguimientoUnidadesDTO;
import com.grupocastores.sion.service.domain.SeguimientoUnidades;

@Repository
public class SeguimientoUnidadesRepository {

	Logger log = LoggerFactory.getLogger(OficinasRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	static final String QUERY = "SELECT * FROM OPENQUERY (PRODUCCION23,'"
			+ " SELECT "
			+ "	gv.no_guia AS numero_guia "
			+ "	, v.idviaje AS id_viaje "
			+ "	, v.idoficina AS id_oficina "
			+ "	, gv.idoficina AS id_oficina_gv "
			+ "	, v.idruta AS id_ruta "
			+ "	, v.idoficinaorigen AS id_oficina_origen "
			+ "	, v.idoficinadestino AS id_oficina_destino "
			+ "	, gv.idoficinadestino AS id_oficina_destino_gv "
			+ "	, (SELECT plaza FROM castores.oficinas o WHERE o.idoficina = v.idoficinaorigen) AS oficina_origen "
			+ "	, (SELECT plaza FROM castores.oficinas o WHERE o.idoficina = v.idoficinadestino) AS oficina_destino "
			+ "	, (SELECT plaza FROM castores.oficinas o WHERE o.idoficina = gv.idoficinadestino) AS oficina_destino_gv "
			+ "	, v.idunidad AS id_unidad "
			+ "	, v.tipounidad AS tipo_unidad "
			+ "	, v.folio AS folio "
			+ "	, v.estatus AS estatus "
			+ "	, gv.estatus AS estatus_guia_viaje "
			+ "	, (SELECT nombre FROM talones.estatusviajes e WHERE e.idestatusviajes = v.estatus) AS estatus_viaje "
			+ "	, v.fechaviaje AS fecha_viaje "
			+ "	, v.horaviaje AS hora_viaje "
			+ "	, tv.pk_clave_veh AS clave_vehiculo "
			+ "	, tv.num_serie_veh AS numero_serie "
			+ "	, tv.txt_economico_veh AS numero_economico "
			+ "	, tv.fec_posicion_veh AS fecha_posicion "
			+ "	, tv.txt_posicion_veh AS posicion_vehiculo "
			+ "	FROM talones.viajes v "
			+ "	INNER JOIN talones.guiaviaje gv	 ON gv.idviaje = v.idviaje AND gv.idoficina = v.idoficina AND gv.operacionguia	= \"1\" "
			+ "	INNER JOIN camiones.camiones c ON c.unidad = v.idunidad AND v.tipounidad = c.idtipounidad "
			+ "	INNER JOIN monitoreo.tb_vehiculos tv ON c.noeconomico = tv.txt_economico_veh "
			+ "	WHERE (v.fechamod BETWEEN \"%s\""
			+ " AND \"%s\")"
			+ " AND v.estatus IN(\"2\",\"4\",\"5\")  "
			+ "	AND gv.idoficinadestino = \"%s\" GROUP BY v.idviaje, v.idoficina;')";

	public List<SeguimientoUnidadesDTO> getSeguimientoUnidades(String fechaInicial, String fechaFinal,
			int oficinaDestino) {
		String queryString = String.format(QUERY, fechaInicial, fechaFinal, oficinaDestino);
		Query query = entityManager.createNativeQuery(queryString, SeguimientoUnidades.class);
		List<SeguimientoUnidades> lstSeguimientoUnidades = Lists
				.newArrayList(Iterables.filter(query.getResultList(), SeguimientoUnidades.class));
		List<SeguimientoUnidadesDTO> lstSeguimientoUnidadesDTO = lstSeguimientoUnidades.stream()
				.map(SeguimientoUnidades::toSeguimientoUnidadesDTO).collect(Collectors.toList());
		return lstSeguimientoUnidadesDTO;
	}
}
