package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Estatus", description = "Datos de Estatus")
public class EstatusDTO {
	
	private int idEstatusViajes;
	private String nombre;
	
	public EstatusDTO (int idEstatusViajes
			, String nombre) {
		this.idEstatusViajes = idEstatusViajes;
		this.nombre = nombre;
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Estatus [idEstatusViajes=").append(idEstatusViajes)
		.append(", nombre=").append(nombre);
		return strBuilder.toString();
	}
}
