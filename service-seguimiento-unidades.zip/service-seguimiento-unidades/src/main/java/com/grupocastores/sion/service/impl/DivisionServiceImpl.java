package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.dto.OficinasDTO;
import com.grupocastores.sion.service.IDivisionService;
import com.grupocastores.sion.service.domain.Division;
import com.grupocastores.sion.service.domain.UsuarioDivisionSion;
import com.grupocastores.sion.service.repository.DivisionRepository;
import com.grupocastores.sion.service.repository.UsuarioDivisionSionRepository;

@Service
public class DivisionServiceImpl implements IDivisionService {
	Logger logger = LoggerFactory.getLogger(DivisionServiceImpl.class);

	@Autowired
	private DivisionRepository divisionRepository;
	
	@Autowired
	private UsuarioDivisionSionRepository usuarioDivisionSionRepository;
	
	@Override
	public List<Division> getDivisiones(Long usuario) {
		List<Division> lstDivision;
	
		try {
			lstDivision = divisionRepository.findByEstatusTrue();
			if (lstDivision == null || lstDivision.isEmpty()) {
				throw new Exception("No se pudieron obtener las divisiones.");
			}
	
			if (usuario != null && ! usuario.equals(0L)) {
				List<UsuarioDivisionSion> lstDivisionesUsuario = usuarioDivisionSionRepository.findByIdUsuario(usuario);
	
				Set<Long> divisionIdsUsuario = lstDivisionesUsuario.stream()
					.map(UsuarioDivisionSion::getIdDivision)
					.collect(Collectors.toSet());
	
				lstDivision.removeIf(division -> 
					!divisionIdsUsuario.contains(Long.parseLong(division.getClave())) 
				);
			}
	
		} catch (Exception e) {
			e.printStackTrace();
			return Collections.emptyList(); 
		}
	
		return lstDivision;
	}
	
}
