package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.GuiasDTO;

public interface IGuiasService {

	public List<GuiasDTO> getGuiasByFechas(String tabla);
}