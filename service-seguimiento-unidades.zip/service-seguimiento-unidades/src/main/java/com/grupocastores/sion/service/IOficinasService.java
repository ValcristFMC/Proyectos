package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.OficinasDTO;

public interface IOficinasService {

	public List<OficinasDTO> getOficinas(String division);
	public List<OficinasDTO> getOficinasByUsuario(Long usuario);
}