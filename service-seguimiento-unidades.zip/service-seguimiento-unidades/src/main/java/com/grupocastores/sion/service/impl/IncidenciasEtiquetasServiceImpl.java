package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.dto.IncidenciasEtiquetaDTO;
import com.grupocastores.sion.service.IIncidenciasEtiquetaService;
import com.grupocastores.sion.service.repository.IncidenciasEtiquetaRepository;

@Service
public class IncidenciasEtiquetasServiceImpl implements IIncidenciasEtiquetaService {
	Logger logger = LoggerFactory.getLogger(IncidenciasEtiquetasServiceImpl.class);

	@Autowired
	private IncidenciasEtiquetaRepository incidenciasEtiquetaRepository;

	@Override
	public List<IncidenciasEtiquetaDTO> getIncidenciasEtiquetaByFolio(String folio) {
		List<IncidenciasEtiquetaDTO> lstIncidenciasEtiqueta = new ArrayList<IncidenciasEtiquetaDTO>();

		try {
			lstIncidenciasEtiqueta = incidenciasEtiquetaRepository.getIncidenciasEtiqueta(folio);
			if (lstIncidenciasEtiqueta == null) {
				throw new Exception("No se pudo obtener el registro del seguimiento: ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return lstIncidenciasEtiqueta;
	}
}
