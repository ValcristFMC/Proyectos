package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.GuiaTablaDTO;

public interface IGuiaTablaService {

	public List<GuiaTablaDTO> getGuiaTablaByFechas(String fechaInicial, String fechaFinal);
}