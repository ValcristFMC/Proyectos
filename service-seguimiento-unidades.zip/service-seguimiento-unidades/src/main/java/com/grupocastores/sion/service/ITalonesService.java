package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.dto.TalonesDTO;

public interface ITalonesService {

	public List<TalonesDTO> getTalonesByNumeroGuia(String tabla, String numeroGuia);
}
