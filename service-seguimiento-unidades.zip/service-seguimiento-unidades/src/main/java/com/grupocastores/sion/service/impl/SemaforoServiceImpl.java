package com.grupocastores.sion.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.dto.SemaforoDTO;
import com.grupocastores.sion.service.ISemaforoService;
import com.grupocastores.sion.service.repository.SemaforoRepository;

@Service
public class SemaforoServiceImpl implements ISemaforoService {
	Logger logger = LoggerFactory.getLogger(SemaforoServiceImpl.class);

	@Autowired
	private SemaforoRepository semaforoRepository;

	@Override
	public List<SemaforoDTO> getSemaforoByViajeFecha(String fechaMod, String idViaje, String idOficina) {
		List<SemaforoDTO> lstSemaforo = new ArrayList<SemaforoDTO>();

		try {
			lstSemaforo = semaforoRepository.getSemaforo(fechaMod, idViaje, idOficina);
			if (lstSemaforo == null) {
				throw new Exception("No se pudo obtener el registro del seguimiento: ");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return lstSemaforo;
	}
}
