package com.grupocastores.sion.service.repository;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.grupocastores.sion.dto.SemaforoDTO;
import com.grupocastores.sion.dto.SemaforoStatusDTO;
import com.grupocastores.sion.dto.UnidadUbicacionDTO;
import com.grupocastores.sion.service.domain.Semaforo;
import com.grupocastores.sion.service.domain.SemaforoStatus;
import com.grupocastores.sion.service.domain.UnidadUbicacion;
import com.grupocastores.sion.utils.UtilitiesRepository;

@Repository
public class SemaforoRepository {

	Logger log = LoggerFactory.getLogger(SemaforoRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	static final String QUERY = "SELECT * FROM OPENQUERY (PRODUCCION23,'"
			+ " SELECT DISTINCT "
			+ "	v.idviaje AS id_viaje "
			+ "	, gv.estatusguia AS id_estatus_guia_viaje "
			+ "	, gv.estatus AS id_estatus_guia "
			+ "	, v.estatus AS id_estatus_viaje "
			+ "	, g.estatus AS id_estatus_geocerca "
			+ "	, (SELECT nombre FROM talones.estatusviajes e WHERE e.idestatusviajes = gv.estatusguia) AS estatus_guia "
			+ "	, (SELECT nombre FROM talones.estatusviajes e WHERE e.idestatusviajes = gv.estatus) AS estatus "
			+ "	, (SELECT nombre FROM talones.estatusviajes e WHERE e.idestatusviajes = v.estatus) AS estatus_viaje "
			+ "	, (SELECT nombre FROM talones.estatusviajes e WHERE e.idestatusviajes = g.estatus) AS estatus_viaje_geocerca "
			+ "	, v.idoficinaorigen AS id_oficina_origen "
			+ "	, gv.idoficinadestino AS id_oficina_destino "
			+ "	, v.idoficinadestino AS id_oficina_destino_viaje "
			+ "	, (SELECT plaza FROM castores.oficinas o WHERE o.idoficina = v.idoficinaorigen) AS oficina_origen_viaje "
			+ "	, (SELECT plaza FROM castores.oficinas o WHERE o.idoficina = gv.idoficinadestino) AS oficina_destino_guia "
			+ "	, (SELECT plaza FROM castores.oficinas o WHERE o.idoficina = v.idoficinadestino) AS oficina_destino_viaje "
			+ "	, tv.num_latitud_veh AS numero_latitud_vehiculo "
			+ "	, tv.num_longitud_veh AS numero_longitud_vehiculo "
			+ "	, g.latitud AS longitud "
			+ "	, g.longitud AS latitud "
			+ "	, ELT(sg.estatus, \"LLEGADA\", \"SALIDA\") AS estatus_llegada_salida "
			+ "	, sg.fecha_hora AS fecha_hora_salida "
			+ "	, rc.horallegada AS hora_llegada "
			+ "	, rc.horasalida AS hora_salida "
			+ "	FROM talones.viajes v "
			+ "	INNER JOIN talones.guiaviaje gv ON gv.idviaje = v.idviaje "
			+ "	INNER JOIN talones.salidas_llegadas_geocerca sg ON sg.id_viaje = gv.idviaje AND sg.oficina_geocerca	= gv.idoficinadestino "
			+ "	INNER JOIN camiones.camiones c ON c.unidad = v.idunidad AND v.tipounidad = c.idtipounidad "
			+ "	INNER JOIN monitoreo.tb_vehiculos tv ON c.noeconomico = tv.txt_economico_veh "
			+ "	INNER JOIN georeferencias.geocerca g ON g.idoficina = gv.idoficinadestino AND g.estatus = 1 AND g.idtipogeocerca = \"0\" "
			+ "	INNER JOIN talones.cuerpo_ruta_circuito rc ON rc.idruta = v.idruta AND rc.diafecha = 2 "
			+ "	WHERE gv.fechamod = \"%s\" "
			+ "	AND v.idviaje = \"%s\" "
			+ "	AND v.idoficina = \"%s\" "
			+ "	AND v.estatus IN(\"1\",\"2\",\"3\") "
			+ "	AND ((sg.estatus = 1 AND rc.horallegada != \"\") OR (sg.estatus = 2 AND rc.horasalida != \"\")) "
			+ "	;')";

	static final String QUERY_GET_SEMAFORO = "SELECT * FROM OPENQUERY (%s, 'SELECT "
	        + "dkv.idviaje AS id_viaje, "
	        + "COALESCE(CAST(o.idoficina AS CHAR), CAST(c.idciudad AS CHAR), CAST(cc.idciudad AS CHAR)) AS id_oficina, "
	        + "dkv.consecutivo AS orden_llegada, "
	        + "dkv.idciudad AS id_ciudad, "
	        + "COALESCE(o.plaza, c.nombre, cc.nombre) AS nombre_destino, "
	        + "slge.fecha_hora AS llegada_geocerca, "
	        + "slgs.fecha_hora AS salida_geocerca, "
	        + "crc.horallegada AS hora_llegada_ficha, "
	        + "crc.horasalida AS hora_salida_ficha, "
	        + "CASE WHEN dv.tipo = 1 THEN 0 ELSE 1 END AS tipo, "
	        + "CASE "
	        + "   WHEN slge.fecha_hora IS NULL THEN 3 "
	        + "   WHEN crc.horallegada IS NULL THEN 1 "
	        + "   WHEN TIME(slge.fecha_hora) <= crc.horallegada THEN 1 "
	        + "   WHEN TIME(slge.fecha_hora) > crc.horallegada THEN 2 "
	        + "END AS estatus_llegada, "
	        + "CASE "
	        + "   WHEN slgs.fecha_hora IS NULL THEN 3 "
	        + "   WHEN crc.horasalida IS NULL THEN 1 "
	        + "   WHEN TIME(slgs.fecha_hora) <= crc.horasalida THEN 1 "
	        + "   WHEN TIME(slgs.fecha_hora) > crc.horasalida THEN 2 "
	        + "END AS estatus_salida, "
	        + "CASE "
	        + "   WHEN slge.fecha_hora IS NULL AND dkv.consecutivo != -1 "
	        + "        AND NOT EXISTS ( "
	        + "            SELECT 1 "
	        + "            FROM ( "
	        + "                SELECT * "
	        + "                FROM talones.det_kilometros_viajes "
	        + "                WHERE idviaje = \"%s\" AND idoficina = \"%s\" "
	        + "                UNION ALL "
	        + "                SELECT * "
	        + "                FROM talones.det_kilometros_viajes_gastosmin "
	        + "                WHERE idviaje = \"%s\" AND idoficina = \"%s\" "
	        + "            ) AS dkv_sub "
	        + "            LEFT JOIN talones.destinosviaje dv_sub "
	        + "                ON dkv_sub.consecutivo = dv_sub.consecutivo "
	        + "                AND dkv_sub.idviaje = dv_sub.idviaje "
	        + "                AND dkv_sub.idoficina = dv_sub.idoficina "
	        + "            LEFT JOIN talones.salidas_llegadas_geocerca slge_sub "
	        + "                ON dv_sub.idviaje = slge_sub.id_viaje "
	        + "                AND dv_sub.idoficina = slge_sub.id_oficina_viaje "
	        + "                AND dv_sub.destino = slge_sub.oficina_geocerca "
	        + "                AND slge_sub.estatus = 1 "
	        + "            WHERE dkv_sub.idviaje = dkv.idviaje "
	        + "                AND dkv_sub.consecutivo > dkv.consecutivo "
	        + "                AND slge_sub.fecha_hora IS NOT NULL "
	        + "        ) THEN TRUE "
	        + "   ELSE FALSE "
	        + "END AS id_proxima_oficina "
	        + "FROM ( "
	        + "    SELECT * "
	        + "    FROM talones.det_kilometros_viajes "
	        + "    WHERE idviaje = \"%s\" AND idoficina = \"%s\" "
	        + "    UNION ALL "
	        + "    SELECT * "
	        + "    FROM talones.det_kilometros_viajes_gastosmin "
	        + "    WHERE idviaje = \"%s\" AND idoficina = \"%s\" "
	        + ") dkv "
	        + "LEFT JOIN talones.destinosviaje dv ON dkv.consecutivo = dv.consecutivo AND dkv.idviaje = dv.idviaje AND dkv.idoficina = dv.idoficina "
	        + "LEFT JOIN talones.viajes v ON dv.idviaje = v.idviaje AND dv.idoficina = v.idoficina "
	        + "LEFT JOIN personal.oficinas o ON dv.destino = o.idoficina AND dv.tipo = 1 "
	        + "LEFT JOIN camiones.ciudades c ON dv.destino = c.idciudad AND dv.tipo = 2 "
	        + "LEFT JOIN camiones.ciudades cc ON dkv.idciudad = cc.idciudad AND dv.tipo IS NULL "
	        + "LEFT JOIN talones.salidas_llegadas_geocerca slge ON dkv.idviaje = slge.id_viaje AND dkv.idoficina = slge.id_oficina_viaje AND dv.destino = slge.oficina_geocerca AND slge.estatus = 1 "
	        + "LEFT JOIN talones.salidas_llegadas_geocerca slgs ON dkv.idviaje = slgs.id_viaje AND dkv.idoficina = slgs.id_oficina_viaje AND dv.destino = slgs.oficina_geocerca AND slgs.estatus = 2 "
	        + "LEFT JOIN talones.cuerpo_ruta_circuito crc ON v.idruta = crc.idruta AND crc.dia = DAYOFWEEK(slge.fecha_hora) - 1 AND crc.consecutivo = dv.consecutivo "
	        + "GROUP BY dkv.consecutivo, dv.destino');";

    static final String QUERY_GET_COORDENADAS = "SELECT * FROM OPENQUERY (%s, 'SELECT "
            + "tb.`pk_clave_veh` AS clave_unidad, "
            + "COALESCE( o.`plaza`, c.`nombre`) AS plaza,"
            + "tb.`num_latitud_veh` AS latitud_unidad, "
            + "tb.`num_longitud_veh` AS longitud_unidad, "
            + "g.`latitud` AS latitud_oficina, "
            + "g.`longitud` AS longitud_oficina "
            + "FROM monitoreo.`tb_vehiculos` tb "
            + "LEFT JOIN georeferencias.geocerca g ON g.idoficina = \"%s\" AND g.`idtipogeocerca` = \"%s\" OR g.`idciudadcliente` = \"%s\" AND g.`idtipogeocerca` = \"%s\" "
            + "LEFT JOIN personal.`oficinas` o ON o.`idoficina` = g.`idoficina` "
            + "LEFT JOIN camiones.`ciudades` c ON c.`idciudad` = g.`idciudadcliente` "
            + "WHERE tb.`txt_economico_veh` = \"%s\"');";

	public List<SemaforoDTO> getSemaforo(String fechaMod, String idViaje, String idOficina) {
		String queryString = String.format(QUERY, fechaMod, idViaje, idOficina);
		Query query = entityManager.createNativeQuery(queryString, Semaforo.class);
		List<Semaforo> lstSemaforo = Lists.newArrayList(Iterables.filter(query.getResultList(), Semaforo.class));
		List<SemaforoDTO> lstSemaforoDTO = lstSemaforo.stream().map(Semaforo::toSemaforoDTO)
				.collect(Collectors.toList());
		return lstSemaforoDTO;
	}

	    public List<SemaforoStatusDTO> getSemaforo(String idViaje, String idOficina) {
        String queryString = String.format(QUERY_GET_SEMAFORO, UtilitiesRepository.getDb23(), idViaje, idOficina, idViaje, idOficina, idViaje, idOficina, idViaje, idOficina);
        Query query = entityManager.createNativeQuery(queryString, SemaforoStatus.class);
        List<SemaforoStatus> lstSemaforo = Lists.newArrayList(Iterables.filter(query.getResultList(), SemaforoStatus.class));
        List<SemaforoStatusDTO> lstSemaforoDTO = lstSemaforo.stream().map(SemaforoStatus::toSemaforoStatusDTO).collect(Collectors.toList());
        return lstSemaforoDTO;
    }

    public UnidadUbicacionDTO getCoordenadas(String idOficina, String idUnidad,String tipo) {
        String queryString = String.format(QUERY_GET_COORDENADAS, UtilitiesRepository.getDb23(), idOficina, tipo, idOficina, tipo, idUnidad);
        Query query = entityManager.createNativeQuery(queryString, UnidadUbicacion.class);
        List<UnidadUbicacion> lstUnidadUbicacion = Lists.newArrayList(Iterables.filter(query.getResultList(), UnidadUbicacion.class));
        return lstUnidadUbicacion.stream().map(UnidadUbicacion::toUnidadUbicacionDTO).findFirst().orElse(null);
    }

}
