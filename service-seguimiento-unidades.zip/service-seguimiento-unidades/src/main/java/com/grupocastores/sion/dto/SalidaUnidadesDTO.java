package com.grupocastores.sion.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Salida de unidades", description = "Datos de las salidas")
public class SalidaUnidadesDTO {

	Integer idruta;
	Integer consecutivo;
	Integer dia;
	String horallegada;
	String horasalida;
	String diafecha;
	String plaza;
	
	public SalidaUnidadesDTO (Integer idruta,Integer consecutivo,Integer dia,String horallegada, String horasalida, String plaza) {
		this.idruta = idruta;
		this.consecutivo = consecutivo;
		this.dia = dia;
		this.horallegada=horallegada;
		this.horasalida=horasalida;
		this.plaza=plaza;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("SalidaUnidades [idruta=").append(idruta)
		.append(", consecutivo=").append(consecutivo)
		.append(", dia=").append(dia)
		.append(", horallegada=").append(horallegada)
		.append(", horasalida").append(horasalida)
		.append(", plaza").append(plaza);
		return strBuilder.toString();
	}
}
