package com.grupocastores.sion.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.grupocastores.sion.dto.TalonGuiaDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "talon_info")
@IdClass(TalonesPorGuia.class)
public class TalonGuia {

    @Id
    @Column(name = "cla_talon")
    private String claveTalon;
    @Id
    @Column(name = "numero_guia")
    private String numeroGuia;
    @Column(name = "numero_renglon")
    private int numeroRenglon;

    public static TalonGuia fromTalonInfoDTO(TalonGuiaDTO talonInfoDTO) {
        TalonGuia talonInfo = new TalonGuia();
        talonInfo.setClaveTalon(talonInfoDTO.getClaveTalon());
        talonInfo.setNumeroGuia(talonInfoDTO.getNumeroGuia());
        talonInfo.setNumeroRenglon(talonInfoDTO.getNumeroRenglon());
        return talonInfo;
    }

    public TalonGuiaDTO toTalonInfoDTO() {
        TalonGuiaDTO dto = new TalonGuiaDTO();
        dto.setClaveTalon(this.getClaveTalon());
        dto.setNumeroGuia(this.getNumeroGuia());
        dto.setNumeroRenglon(this.getNumeroRenglon());
        return dto;
    }
}
