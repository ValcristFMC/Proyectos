# castores-service-sion-seguimiento-unidades

## Versión: 1.0.0.1
- __Ticket/Proyecto:__ SION
- __Author:__ Jose de Jesús Sustaita Neri
- __Fecha:__ 19-11-2024
- __Descripción:__ 
	- Se crea servicio base para proyecto SION de Seguimiento de Unidades.
--------

## Configuración técnica
- __IDE:__ Spring Tools Suite 4
- __Lenguaje:__ Java 8 Sping Boot


## Librerías
### Internas
-

### Externas
-
-------------
## Documentación
- Generar peticiones en swagger
