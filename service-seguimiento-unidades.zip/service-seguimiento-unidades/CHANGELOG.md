# castores-service-sion-seguimiento-unidades

## Versión: 1.0.0.3
- __Ticket/Proyecto:__ SION
- __Author:__ Flavio Urdiales
- __Fecha:__ 28-11-2024
- __Descripción:__ 
	- Se hace metodo para obtener semaforo
	- Se hace metodo para obtener distancia de la proxima oficina

## Versión: 1.0.0.2
- __Ticket/Proyecto:__ SION
- __Author:__ Fernando Morales Castillo
- __Fecha:__ 08/11/2024

## Versión: 1.0.0.1
- __Ticket/Proyecto:__ SION
- __Author:__ Jose de jesus sustaita Neri
- __Fecha:__ 19/11/2024
- __Descripción:__ 
	- Se crea servicio base para proyecto SION de Seguimiento de Unidades.
