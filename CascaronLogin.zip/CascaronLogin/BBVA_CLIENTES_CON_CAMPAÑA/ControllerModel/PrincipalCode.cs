﻿using CascaronLogin.Models;
using CascaronLogin.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CascaronLogin.ControllerModel
{
    public class PrincipalCode
    {

    }
}