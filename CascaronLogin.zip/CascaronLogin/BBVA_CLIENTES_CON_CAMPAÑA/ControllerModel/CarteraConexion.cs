﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CascaronLogin.ControllerModel
{
    public class CarteraConexion
    {
        public string Conexion(string id_Cartera)
        {
            if (id_Cartera == "1")
                return "Data Source=172.29.41.62; Initial Catalog=BBVA_VideoVisita; User id=SSIS; Password=1N736R4710NS3RV1C3S;";
            else
                return "0";
        }
    }
}