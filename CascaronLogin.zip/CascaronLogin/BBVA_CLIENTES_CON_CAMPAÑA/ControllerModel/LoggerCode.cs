﻿using CascaronLogin.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Windows.Forms;

namespace CascaronLogin.ControllerModel
{
    public class LoggerCode
    {
        public bool saveLog(string strLog, string id_Usuario)
        {
            try
            {
                InformacionViewModel info = new InformacionViewModel();
                //SaveLogDB(strLog, id_Usuario);

                return saveLogFile("CascaronLogin", String.Format("{0} => {1} => {2}", info.MyHostName, id_Usuario, strLog), "CascaronLogin", info.MyIp);
            }
            catch (Exception ex)
            {
                try
                {
                    InformacionViewModel info = new InformacionViewModel();
                    return saveLogFile("CascaronLogin", String.Format("{0} => {1}", info.MyHostName, strLog), "CascaronLogin", info.MyIp);
                }
                catch (Exception exII)
                {
                    return false;
                }
                throw ex;
            }
        }

        ////Metodo que guarda log en Base de Datos
        //private void SaveLogDB(string contenido, string id_Usuario)
        //{
        //    try
        //    {
        //        using (var db = new Models.GOBIERNO_ESTADO_CITAS_VEHICULARESEntities())
        //        {
        //            InformacionViewModel info = new InformacionViewModel();
                   
        //            db.Database.ExecuteSqlCommand("EXEC SP_SaveLogDB @ip, @hostname, @id_Usuario, @contenido", new SqlParameter("@ip", info.MyIp), new SqlParameter("@hostname", info.MyHostName), new SqlParameter("@id_Usuario", id_Usuario), new SqlParameter("@contenido", contenido));
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //Metodo que guarda Log en txt
        private bool saveLogFile(string strArchivo, string strLog, string strAplicacion, string strIp)
        {
            StreamWriter logFile;

            string strRutaArchivo = "C:\\Logs\\" + strAplicacion;
            string strNombreLog = strRutaArchivo + "\\" + strArchivo + "_" + DateTime.Now.ToString("ddMMyyyy");

            try
            {
                if (!Directory.Exists(strRutaArchivo))
                    Directory.CreateDirectory(strRutaArchivo);

                if (DateTime.Now.ToString("HH") == "06" || DateTime.Now.ToString("HH") == "07" || DateTime.Now.ToString("HH") == "08" || DateTime.Now.ToString("HH") == "09")
                {
                    logFile = new StreamWriter(strNombreLog + "_1" + ".txt", true, System.Text.Encoding.Default);
                }
                else if (DateTime.Now.ToString("HH") == "10" || DateTime.Now.ToString("HH") == "11" || DateTime.Now.ToString("HH") == "12" || DateTime.Now.ToString("HH") == "13")
                {
                    logFile = new StreamWriter(strNombreLog + "_2" + ".txt", true, System.Text.Encoding.Default);
                }
                else if (DateTime.Now.ToString("HH") == "14" || DateTime.Now.ToString("HH") == "15" || DateTime.Now.ToString("HH") == "16" || DateTime.Now.ToString("HH") == "17")
                {
                    logFile = new StreamWriter(strNombreLog + "_3" + ".txt", true, System.Text.Encoding.Default);
                }
                else if (DateTime.Now.ToString("HH") == "18" || DateTime.Now.ToString("HH") == "19" || DateTime.Now.ToString("HH") == "20" || DateTime.Now.ToString("HH") == "21")
                {
                    logFile = new StreamWriter(strNombreLog + "_4" + ".txt", true, System.Text.Encoding.Default);
                }
                else if (DateTime.Now.ToString("HH") == "22" || DateTime.Now.ToString("HH") == "23")
                {
                    logFile = new StreamWriter(strNombreLog + "_5" + ".txt", true, System.Text.Encoding.Default);
                }
                else
                {
                    logFile = new StreamWriter(strNombreLog + "_6" + ".txt", true, System.Text.Encoding.Default);
                }

                logFile.WriteLine(DateTime.Now.ToString("HH:mm:ss.fff") + " => [" + strIp + "] => " + strLog);

                logFile.Flush();

                logFile.Close();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}