﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace CascaronLogin.ControllerModel
{
    public class LoginCode
    {

        public string Conexion (string id_Cartera)
        {
            if (id_Cartera == "1")
                return "Data Source=172.29.41.62; Initial Catalog=BBVA_VideoVisita; User id=SSIS; Password=1N736R4710NS3RV1C3S;";
            else
                return "0";
        } 

        ////Cierra Sesion
        //public bool eliminaSesion(string id_Usuario)
        //{
        //    try
        //    {
        //        using (var db = new Models.GOBIERNO_ESTADO_CITAS_VEHICULARESEntities())
        //        {            
        //            //Esta forma de correr querys solo devuelve un solo campo        
        //            var sesion = db.Database.SqlQuery<string>("EXEC SP_EliminaSesiones @id_Usuario", new SqlParameter("@id_Usuario", id_Usuario)).ToList();

        //            if (sesion.Count > 0)
        //                return false;
        //            else
        //                return true;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //Encripta Password
        public string passwordEncryptSHA(string password)
        {
            var sha = new System.Security.Cryptography.SHA1CryptoServiceProvider();
            byte[] bytesToHash;

            bytesToHash = System.Text.Encoding.ASCII.GetBytes(password);
            bytesToHash = sha.ComputeHash(bytesToHash);

            string encPassword = "";

            foreach (byte b in bytesToHash)
            {
                encPassword += b.ToString("x2");
            }

            return encPassword;
        }

        //Genera llave unica
        public string RandomString(int size)
        {
            Random rand = new Random();
            int randValue;
            string str = "";
            char letter;

            for (int i = 0; i < size; i++)
            {
                randValue = rand.Next(0, 26);
                letter = Convert.ToChar(randValue + 65);
                str = str + letter;
            }

            return str;
        }
    }
}