﻿using CascaronLogin.ControllerModel;
using CascaronLogin.Models.ViewModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.Mvc;

namespace CascaronLogin.Controllers
{
    public class PrincipalController : Controller
    {
        private PrincipalCode objPrincipal = new PrincipalCode();
        private LoggerCode objLogger = new LoggerCode();
        private InformacionViewModel info = new InformacionViewModel();
        private CarteraConexion Conect = new CarteraConexion();

        [HttpGet]
        public ActionResult PrincipalView()
        {                        
            ViewBag.IpUsuario = info.MyIp;

            return View();
        }        
    }
}