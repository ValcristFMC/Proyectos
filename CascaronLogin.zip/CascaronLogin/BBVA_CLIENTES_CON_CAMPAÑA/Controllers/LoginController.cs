﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CascaronLogin.ControllerModel;
using CascaronLogin.Models.ViewModel;
using CascaronLogin.Models;
using System.Data.SqlClient;

namespace CascaronLogin.Controllers
{
    public class LoginController : Controller
    {
        //Variables privadas
        private LoginCode objUsuario = new LoginCode();
        private LoggerCode objLogger = new LoggerCode();
        private CarteraConexion Conect = new CarteraConexion();

        //Variables publicas
        public static string strUsuario = string.Empty;
        public static int intentosLogin = 0;
        
        [HttpGet]
        public ActionResult LoginView()
        {
            System.Reflection.Assembly ensamblado;
            System.Reflection.AssemblyName an;
            ensamblado = System.Reflection.Assembly.GetExecutingAssembly();
            an = ensamblado.GetName();

            ViewBag.Version = an.Version.Major + "." + an.Version.Minor + "." + an.Version.Build;

            return View();
        }

        [HttpGet]
        public ActionResult CambioPasswordView()
        {
            return View();
        }

        [HttpPost]
        public ActionResult EntrarLogin(string id_Usuario, string password)
        {
            try
            {
                string key = new Random(DateTime.Now.Millisecond + DateTime.Now.Second * 1000 + DateTime.Now.Minute * 60000 + DateTime.Now.Minute * 3600000).Next() + objUsuario.RandomString(60);
                List<usuario> usuario = new List<usuario>();

                //Validacion usuario bloqueado
                using (SqlConnection cnn = new SqlConnection(Conect.Conexion("1")))
                {
                    using (SqlCommand cmd = new SqlCommand("Exec SP_BLOQUEARUSUARIOLOGIN @ID_USUARIO = '" + id_Usuario + "', @OPCION = '2'"))
                    {
                        cmd.Connection = cnn;
                        bool usuarioBloqueado = false;
                        cnn.Open();

                        using (SqlDataReader sdr = cmd.ExecuteReader())
                        {
                            while (sdr.Read())
                            {
                                usuarioBloqueado = true;
                            }

                            if (usuarioBloqueado == true)
                                return Content("El usuario esta bloqueado, favor de reportarlo a la mesa de ayuda.");
                        }
                    }
                }

                //Buscar Usuario
                using (SqlConnection cnn = new SqlConnection(Conect.Conexion("1")))
                {
                    using (SqlCommand cmd = new SqlCommand("Exec SP_OBTENERUSUARIOLOGIN @id_Usuario = '" + id_Usuario + "', @password = '" + objUsuario.passwordEncryptSHA(password) + "'"))
                    {
                        cmd.Connection = cnn;                    
                        cnn.Open();

                        using (SqlDataReader sdr = cmd.ExecuteReader())
                        {
                            while (sdr.Read())
                            {
                                usuario.Add(new usuario(  
                                    sdr["id_Usuario"].ToString(),
                                    sdr["id_TipoUsuario"].ToString(),
                                    sdr["id_Centro"].ToString(),
                                    sdr["id_Cartera"].ToString(),
                                    sdr["id_Coordinador"].ToString(),
                                    sdr["id_Depto"].ToString(),
                                    sdr["Nombre"].ToString(),
                                    sdr["ApPaterno"].ToString(),
                                    sdr["ApMaterno"].ToString(),
                                    sdr["NombreCompleto"].ToString(),
                                    sdr["Password"].ToString(),
                                    sdr["Sexo"].ToString(),
                                    sdr["Tipo"].ToString(),
                                    sdr["Status"].ToString(),
                                    sdr["Marcacion"].ToString(),
                                    sdr["LastLogin"].ToString(),
                                    sdr["CambioPws"].ToString(),
                                    sdr["EsBaja"].ToString(),
                                    sdr["MotivoBaja"].ToString(),
                                    sdr["FechaEsBaja"].ToString(),
                                    sdr["EsBecario"].ToString(),
                                    sdr["EsRenuncia"].ToString(),
                                    sdr["MotivoRenuncia"].ToString(),
                                    sdr["Bloqueado"].ToString(),
                                    sdr["Intentos"].ToString(),
                                    sdr["Version"].ToString(),
                                    sdr["Inactivo"].ToString(),
                                    sdr["FechaInactivo"].ToString(),
                                    sdr["UltimaGestion"].ToString(),
                                    sdr["Manual"].ToString(),
                                    sdr["Compuesto"].ToString(),
                                    sdr["perDummy"].ToString(),
                                    sdr["RenegociarPromesas"].ToString(),
                                    sdr["perConsulta"].ToString(),
                                    sdr["perConsultaGestion"].ToString(),
                                    sdr["perBuscar"].ToString(),
                                    sdr["PerReenvioConvenio"].ToString(),
                                    sdr["perEnvioSMS"].ToString()
                                ));
                            }                        
                        }
                    }
                }

                if (usuario.Count > 0)
                {
                    //Revisa Sesion
                    using (SqlConnection cnn = new SqlConnection(Conect.Conexion("1")))
                    {
                        using (SqlCommand cmd = new SqlCommand("Exec SP_SESIONESLOGIN @ID_USUARIO = '" + id_Usuario + "', @ID_SESION = '" + key + "', @SISTEMA = 'BBVA_VideoVisita'"))
                        {
                            cmd.Connection = cnn;
                            string idSesion = "";
                            cnn.Open();

                            using (SqlDataReader sdr = cmd.ExecuteReader())
                            {
                                while (sdr.Read())
                                {
                                    idSesion = sdr["SESION"].ToString();
                                }
                            }

                            if (idSesion != key)
                                return Content("Ya tienes una sesion iniciada, cierra la sesion anterior y vuelve a intentarlo.");
                        }
                    }

                    //Actualiza ultimo Login
                    using (SqlConnection cnn = new SqlConnection(Conect.Conexion("1")))
                    {
                        using (SqlCommand cmd = new SqlCommand("Exec SP_ACTUALIZALASTLOGIN @ID_USUARIO = '" + id_Usuario + "', @PASSWORD = '" + objUsuario.passwordEncryptSHA(password) + "'"))
                        {
                            cmd.Connection = cnn;
                            cnn.Open();
                            cmd.ExecuteNonQuery();
                        }
                    }

                    bool cambioPws = false;

                    foreach (usuario tmpUsuario in usuario)
                    {
                        //Crear variables de Session
                        Session["IDUSUARIO"] = tmpUsuario.id_Usuario;
                        Session["TIPO"] = tmpUsuario.id_TipoUsuario;
                        Session["CARTERA"] = tmpUsuario.id_Cartera;
                        Session["NOMBRE"] = tmpUsuario.NombreCompleto;
                        Session["PASSUSUARIO"] = tmpUsuario.Password;
                        Session["IPUSUARIO"] = Request.ServerVariables["REMOTE_ADDR"];
                        Session["MANUAL"] = tmpUsuario.Manual;
                        Session["PERDUMMY"] = tmpUsuario.perDummy;
                        Session["PERCONSULTA"] = tmpUsuario.perConsulta;
                        Session["PERCONSULTAGESTION"] = tmpUsuario.perConsultaGestion;
                        Session["PERBUSCAR"] = tmpUsuario.perBuscar;
                        Session["PERREENVIO"] = tmpUsuario.perEnvioSMS;
                        cambioPws = Convert.ToBoolean(tmpUsuario.CambioPws);
                    }

                    //Guardar log con la siguiente estructura ("MOVIMIENTO","Id_Usuario")
                    objLogger.saveLog("Inicio Sesion", id_Usuario);

                    strUsuario = id_Usuario;

                    //Checo si cambio password
                    if (cambioPws == false)
                    {   //Cambio contraseña
                        return Content("2");
                    }
                    else
                    {   //Principal
                        objLogger.saveLog("LOGIN OK", id_Usuario);
                        return Content("1");
                    }

                }
                else
                {
                    //Validacion de intentos
                    if (strUsuario != "")
                    {
                        if (id_Usuario == strUsuario)
                        {
                            intentosLogin = intentosLogin + 1;
                        }
                        else
                        {
                            strUsuario = id_Usuario;
                            intentosLogin = 1;
                        }
                    }
                    else
                    {
                        strUsuario = id_Usuario;
                        intentosLogin = 1;
                    }

                    //Si consigue 3 intentos lo bloquea
                    if (intentosLogin >= 3)
                    {
                        using (SqlConnection cnn = new SqlConnection(Conect.Conexion("1")))
                        {
                            using (SqlCommand cmd = new SqlCommand("Exec SP_BLOQUEARUSUARIOLOGIN @ID_USUARIO = '" + id_Usuario + "', @OPCION = '1'"))
                            {
                                cmd.Connection = cnn;
                                cnn.Open();
                                cmd.ExecuteNonQuery();

                                return Content("El usuario esta bloqueado, favor de reportarlo a la mesa de ayuda.");
                            }
                        }
                    }

                    return Content("Contraseña y/o usuario incorrectos.");
                }
            }
            catch (Exception ex)
            {
                return Content("Error: " + ex);
            }
        }       

        [HttpPost]
        public ActionResult CambiarPassword(string nuevoPassword, string confirmaPassword)
        {
            try
            {
                using (SqlConnection cnn = new SqlConnection(Conect.Conexion("1")))
                {
                    using (SqlCommand cmd = new SqlCommand("Exec SP_ACTUALIZACONTRASEÑALOGIN @ID_USUARIO = '" + Session["IDUSUARIO"].ToString() + "', @NEWPASSWORD = '" + objUsuario.passwordEncryptSHA(nuevoPassword) + "'"))
                    {
                        cmd.Connection = cnn;
                        cnn.Open();
                        cmd.ExecuteNonQuery();

                        objLogger.saveLog("CAMBIO PASSWORD OK", Session["IDUSUARIO"].ToString());
                        return Content("1");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content("Error: " + ex);
            }            
        }
        
        [HttpPost]
        public ActionResult CerrarSesion()
        {
            try
            {
                using (SqlConnection cnn = new SqlConnection(Conect.Conexion("1")))
                {
                    using (SqlCommand cmd = new SqlCommand("Exec SP_EliminaSesionesAlltool @ID_USUARIO = '" + Session["IDUSUARIO"].ToString() + "' "))
                    {
                        cmd.Connection = cnn;
                        cnn.Open();
                        cmd.ExecuteNonQuery();

                        objLogger.saveLog("CERRO SESION OK", Session["IDUSUARIO"].ToString());

                        Session.Remove("IDUSUARIO");
                        Session.Remove("TIPO");
                        Session.Remove("CARTERA");
                        Session.Remove("NOMBRE");
                        Session.Remove("PASSUSUARIO");
                        Session.Remove("IPUSUARIO");
                        Session.Remove("MANUAL");
                        Session.Remove("PERDUMMY");
                        Session.Remove("PERCONSULTA");
                        Session.Remove("PERCONSULTAGESTION");
                        Session.Remove("PERBUSCAR");
                        Session.Remove("PERREENVIO");

                        return Content("1");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content("Error: " + ex);
            }
        }        
    }
}