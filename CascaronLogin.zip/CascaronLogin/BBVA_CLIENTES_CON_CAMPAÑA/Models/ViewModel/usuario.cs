﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CascaronLogin.Models.ViewModel
{
    public class usuario
    {

        public usuario (string id_Usuario,
                        string id_TipoUsuario,
                        string id_Centro,
                        string id_Cartera,
                        string id_Coordinador,
                        string id_Depto,
                        string Nombre,
                        string ApPaterno,
                        string ApMaterno,
                        string NombreCompleto,
                        string Password,
                        string Sexo,
                        string Tipo,
                        string Status,
                        string Marcacion,
                        string LastLogin,
                        string CambioPws,
                        string EsBaja,
                        string MotivoBaja,
                        string FechaEsBaja,
                        string EsBecario,
                        string EsRenuncia,
                        string MotivoRenuncia,
                        string Bloqueado,
                        string Intentos,
                        string Version,
                        string Inactivo,
                        string FechaInactivo,
                        string UltimaGestion,
                        string Manual,
                        string Compuesto,
                        string perDummy,
                        string RenegociarPromesas,
                        string perConsulta,
                        string perConsultaGestion,
                        string perBuscar,
                        string PerReenvioConvenio,
                        string perEnvioSMS)
        {            
            this.id_Usuario = id_Usuario;
            this.id_TipoUsuario = id_TipoUsuario;
            this.id_Centro = id_Centro;
            this.id_Cartera = id_Cartera;
            this.id_Coordinador = id_Coordinador;
            this.id_Depto = id_Depto;
            this.Nombre = Nombre;
            this.ApPaterno = ApPaterno;
            this.ApMaterno = ApMaterno;
            this.NombreCompleto = NombreCompleto;
            this.Password = Password;
            this.Sexo = Sexo;
            this.Tipo = Tipo;
            this.Status = Status;
            this.Marcacion = Marcacion;
            this.LastLogin = LastLogin;
            this.CambioPws = CambioPws;
            this.EsBaja = EsBaja;
            this.MotivoBaja = MotivoBaja;
            this.FechaEsBaja = FechaEsBaja;
            this.EsBecario = EsBecario;
            this.EsRenuncia = EsRenuncia;
            this.MotivoRenuncia = MotivoRenuncia;
            this.Bloqueado = Bloqueado;
            this.Intentos = Intentos;
            this.Version = Version;
            this.Inactivo = Inactivo;
            this.FechaInactivo = FechaInactivo;
            this.UltimaGestion = UltimaGestion;
            this.Manual = Manual;
            this.Compuesto = Compuesto;
            this.perDummy = perDummy;
            this.RenegociarPromesas = RenegociarPromesas;
            this.perConsulta = perConsulta;
            this.perConsultaGestion = perConsultaGestion;
            this.perBuscar = perBuscar;
            this.PerReenvioConvenio = PerReenvioConvenio;
            this.perEnvioSMS = perEnvioSMS;            
        }

        public string id_Usuario { get; set; }
        public string id_TipoUsuario { get; set; }
        public string id_Centro { get; set; }
        public string id_Cartera { get; set; }
        public string id_Coordinador { get; set; }
        public string id_Depto { get; set; }
        public string Nombre { get; set; }
        public string ApPaterno { get; set; }
        public string ApMaterno { get; set; }
        public string NombreCompleto { get; set; }
        public string Password { get; set; }
        public string Sexo { get; set; }
        public string Tipo { get; set; }
        public string Status { get; set; }
        public string Marcacion { get; set; }
        public string LastLogin { get; set; }
        public string CambioPws { get; set; }
        public string EsBaja { get; set; }
        public string MotivoBaja { get; set; }
        public string FechaEsBaja { get; set; }
        public string EsBecario { get; set; }
        public string EsRenuncia { get; set; }
        public string MotivoRenuncia { get; set; }
        public string Bloqueado { get; set; }
        public string Intentos { get; set; }
        public string Version { get; set; }
        public string Inactivo { get; set; }
        public string FechaInactivo { get; set; }
        public string UltimaGestion { get; set; }
        public string Manual { get; set; }
        public string Compuesto { get; set; }
        public string perDummy { get; set; }
        public string RenegociarPromesas { get; set; }
        public string perConsulta { get; set; }
        public string perConsultaGestion { get; set; }
        public string perBuscar { get; set; }
        public string PerReenvioConvenio { get; set; }
        public string perEnvioSMS { get; set; }
    }
}