﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;

namespace CascaronLogin.Models.ViewModel
{
    public class InformacionViewModel
    {
        private string myIp;
        private string myHostName;
        private string myVersion;
        
        public string MyIp
        {
            get { return myIp; }
            set { myIp = value; }
        }

        public string MyHostName
        {
            get { return myHostName; }
            set { myHostName = value; }
        }

        public string MyVersion
        {
            get { return myVersion; }
            set { myVersion = value; }
        }

        public InformacionViewModel()
        {
            try
            {
                myIp = Dns.GetHostEntry(Dns.GetHostName()).AddressList.GetValue(Dns.GetHostEntry(Dns.GetHostName()).AddressList.Length - 1).ToString();
                myHostName = Dns.GetHostName();
                myVersion = System.Windows.Forms.Application.ProductVersion;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}