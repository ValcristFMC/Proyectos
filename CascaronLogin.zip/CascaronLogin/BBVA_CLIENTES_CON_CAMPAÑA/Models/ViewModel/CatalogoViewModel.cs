﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CascaronLogin.Models.ViewModel
{
    public class CatalogoViewModel
    {

        public CatalogoViewModel (string Id, string Nombre)
        {
            this.Id = Id;
            this.Nombre = Nombre;
        }

        public string Id { get; set; }
        public string Nombre { get; set; }
    }
}