﻿namespace DataAccess
{
    public class ClsAcceso
    {
        public static string Servidor = ""; 
        public static int Puerto = 1433;
        public static string DB = "";
        public static string Usuario = "";
        public static string Contraseña = "";
    }
}
