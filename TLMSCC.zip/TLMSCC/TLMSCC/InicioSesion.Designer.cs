﻿namespace TLMSCC
{
    partial class InicioSesion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InicioSesion));
            this.scInicioSesion = new System.Windows.Forms.SplitContainer();
            this.btnCerrar = new TLMSCC.Controles.Boton();
            this.btnEntrar = new TLMSCC.Controles.Boton();
            this.txbContraseña = new System.Windows.Forms.TextBox();
            this.txbUsuario = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.scInicioSesion)).BeginInit();
            this.scInicioSesion.Panel2.SuspendLayout();
            this.scInicioSesion.SuspendLayout();
            this.SuspendLayout();
            // 
            // scInicioSesion
            // 
            this.scInicioSesion.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scInicioSesion.IsSplitterFixed = true;
            this.scInicioSesion.Location = new System.Drawing.Point(0, 0);
            this.scInicioSesion.Margin = new System.Windows.Forms.Padding(0);
            this.scInicioSesion.Name = "scInicioSesion";
            // 
            // scInicioSesion.Panel1
            // 
            this.scInicioSesion.Panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("scInicioSesion.Panel1.BackgroundImage")));
            this.scInicioSesion.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            // 
            // scInicioSesion.Panel2
            // 
            this.scInicioSesion.Panel2.Controls.Add(this.btnCerrar);
            this.scInicioSesion.Panel2.Controls.Add(this.btnEntrar);
            this.scInicioSesion.Panel2.Controls.Add(this.txbContraseña);
            this.scInicioSesion.Panel2.Controls.Add(this.txbUsuario);
            this.scInicioSesion.Panel2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.scInicioSesion.Panel2.ForeColor = System.Drawing.Color.Black;
            this.scInicioSesion.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.scInicioSesion.Size = new System.Drawing.Size(435, 120);
            this.scInicioSesion.SplitterDistance = 130;
            this.scInicioSesion.TabIndex = 0;
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnCerrar.BorderColor = System.Drawing.Color.Transparent;
            this.btnCerrar.BorderRadius = 10;
            this.btnCerrar.BorderSize = 0;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnCerrar.Location = new System.Drawing.Point(226, 60);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(63, 23);
            this.btnCerrar.TabIndex = 7;
            this.btnCerrar.Text = "Cerrar";
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // btnEntrar
            // 
            this.btnEntrar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnEntrar.BorderColor = System.Drawing.Color.Transparent;
            this.btnEntrar.BorderRadius = 10;
            this.btnEntrar.BorderSize = 0;
            this.btnEntrar.FlatAppearance.BorderSize = 0;
            this.btnEntrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEntrar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnEntrar.Location = new System.Drawing.Point(226, 31);
            this.btnEntrar.Name = "btnEntrar";
            this.btnEntrar.Size = new System.Drawing.Size(63, 23);
            this.btnEntrar.TabIndex = 6;
            this.btnEntrar.Text = "Entrar";
            this.btnEntrar.UseVisualStyleBackColor = false;
            this.btnEntrar.Click += new System.EventHandler(this.btnEntrar_Click);
            // 
            // txbContraseña
            // 
            this.txbContraseña.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txbContraseña.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbContraseña.Location = new System.Drawing.Point(84, 64);
            this.txbContraseña.Name = "txbContraseña";
            this.txbContraseña.PasswordChar = '*';
            this.txbContraseña.Size = new System.Drawing.Size(134, 16);
            this.txbContraseña.TabIndex = 1;
            // 
            // txbUsuario
            // 
            this.txbUsuario.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txbUsuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbUsuario.Location = new System.Drawing.Point(84, 35);
            this.txbUsuario.Name = "txbUsuario";
            this.txbUsuario.Size = new System.Drawing.Size(134, 16);
            this.txbUsuario.TabIndex = 0;
            // 
            // InicioSesion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(435, 120);
            this.ControlBox = false;
            this.Controls.Add(this.scInicioSesion);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "InicioSesion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Iniciar sesión";
            this.scInicioSesion.Panel2.ResumeLayout(false);
            this.scInicioSesion.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.scInicioSesion)).EndInit();
            this.scInicioSesion.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer scInicioSesion;
        private System.Windows.Forms.TextBox txbContraseña;
        private System.Windows.Forms.TextBox txbUsuario;
        private Controles.Boton btnEntrar;
        private Controles.Boton btnCerrar;
    }
}