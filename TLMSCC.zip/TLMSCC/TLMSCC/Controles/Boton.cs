﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace TLMSCC.Controles
{
    public class Boton : Button
    {
        private int borderSize = 0;
        private int borderRadius = 10;
        private Color borderColor = Color.Transparent;

        public int BorderSize
        {
            get { return borderSize; }
            set { borderSize = value; this.Invalidate(); }
        }

        public int BorderRadius
        {
            get { return borderRadius; }
            set { borderRadius = value; this.Invalidate(); }
        }

        public Color BorderColor
        {
            get { return borderColor; }
            set { borderColor = value; this.Invalidate(); }
        }

        public Boton()
        {
            this.FlatStyle = FlatStyle.Flat;
            this.FlatAppearance.BorderSize = 0;
            this.Size = new Size(63, 23);
            this.BackColor = Color.DodgerBlue;
            this.ForeColor = Color.AliceBlue;
        }

        private GraphicsPath GetFigurePath(RectangleF Rectangulo, float Radio)
        {
            GraphicsPath path = new GraphicsPath();
            path.StartFigure();
            path.AddArc(Rectangulo.X, Rectangulo.Y, Radio, Radio, 180, 90);
            path.AddArc(Rectangulo.Width - Radio, Rectangulo.Y, Radio, Radio, 270, 90);
            path.AddArc(Rectangulo.Width - Radio, Rectangulo.Height - Radio, Radio, Radio, 0, 90);
            path.AddArc(Rectangulo.X, Rectangulo.Height - Radio, Radio, Radio, 90, 90);
            path.CloseFigure();

            return path;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            RectangleF rectSupercficie = new RectangleF(0, 0, this.Width, this.Height);
            RectangleF rectBorde = new RectangleF(1, 1, this.Width - 0.8F, this.Height - 1);

            if(borderRadius > 2)
            {
                using (GraphicsPath pathSuperficie = GetFigurePath(rectSupercficie, borderRadius))
                using (GraphicsPath pathBorde = GetFigurePath(rectBorde, borderRadius - 1F))
                using (Pen penSuperficie = new Pen(this.Parent.BackColor, 2))
                using (Pen penBorde = new Pen(borderColor, borderSize))
                {
                    penBorde.Alignment = PenAlignment.Inset;
                    this.Region = new Region(pathSuperficie);
                    e.Graphics.DrawPath(penSuperficie, pathSuperficie);

                    if (borderSize >= 1)
                    {
                        e.Graphics.DrawPath(penBorde, pathBorde);
                    }
                }
            }
            else
            {
                this.Region = new Region(rectSupercficie);

                if(borderSize >=1 )
                {
                    using(Pen penBorde = new Pen(borderColor, borderSize))
                    {
                        penBorde.Alignment = PenAlignment.Inset;
                        e.Graphics.DrawRectangle(penBorde, 0, 0, this.Width - 1, this.Height - 1);
                    }
                }
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            this.Parent.BackColorChanged += new EventHandler(Container_BackcolorChanged);
        }

        private void Container_BackcolorChanged(object sender, EventArgs e)
        {
            if(this.DesignMode)
            {
                this.Invalidate();
            }
        }
    }
}
