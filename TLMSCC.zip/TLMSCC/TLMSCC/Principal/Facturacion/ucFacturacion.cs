﻿using BusinessEntities;
using BusinessEntities.Archivos;
using BusinessEntities.RH;
using DataAccess.Archivos;
using Microsoft.ReportingServices.ReportProcessing.ReportObjectModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TLMSCC.Principal.Facturacion
{
    public partial class ucFacturacion : UserControl
    {
        private ClsArchivosDA ArchivosDA = new ClsArchivosDA();
        private List<ClsArchivosCharly> ListaArchivosCharly = new List<ClsArchivosCharly>();
        private List<ClsArchivosCharly> ListaCharly = new List<ClsArchivosCharly>();
        private ClsArchivosCharly ArchivosCharly = new ClsArchivosCharly();
        private ClsUsuario Usuario = new ClsUsuario();
        private DataTable TablaCSV = new DataTable();
        private DataTable TablaArchivo = new DataTable();
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private int PaginaInicio = 1;
        private int NumeroFilas = 20;
        private int PaginaFinal = 0;

        public ucFacturacion(ClsUsuario Usr)
        {
            Usuario = Usr;
            InitializeComponent();
            CargaInicial();
        }

        private void CargaInicial()
        {
            try
            {
                ListaArchivosCharly = ArchivosDA.ConsultarListaArchivos(Usuario.Usuario);
                cbxListaArchivos.Items.Clear();
                cbxListaArchivos.DataSource = ListaArchivosCharly;
                cbxListaArchivos.ValueMember = "NumeroArchivo";
                cbxListaArchivos.DisplayMember = "Nombre";
                cbxListaArchivos.SelectedIndex = 0;

                ListaCharly = ArchivosDA.ConsultarTablaArchivo(Usuario.Usuario, int.Parse(cbxListaArchivos.SelectedValue.ToString()), dtpFechaArchivo.Value);
                TablaCSV = Funciones.ConvertToDataTable(ListaCharly);
                TablaArchivo = Funciones.CreateDataTable(ArchivosCharly.GetType());
                CargarGridArchivo();
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void CargarGridArchivo()
        {
            try
            {
                int FilasMostradas = NumeroFilas;
                int Paginas = TablaCSV.Rows.Count / FilasMostradas;

                if (TablaCSV.Rows.Count < FilasMostradas)
                {
                    Paginas = 1;
                }

                txbPagina.Text = Paginas.ToString();
                TablaArchivo.Rows.Clear();

                if (cbxPagina.Items.Count == 0)
                {
                    for (int Contador = 1; Contador <= Paginas; Contador++)
                    {
                        cbxPagina.Items.Add(Contador.ToString());
                    }

                    cbxPagina.SelectedIndex = 0;
                }

                for (int Contador = 0; Contador < NumeroFilas; Contador++)
                {
                    int Fila = (int.Parse(cbxPagina.Text) * NumeroFilas) + Contador;
                    TablaArchivo.Rows.Add(TablaCSV.Rows[Fila].ItemArray);
                }

                dgvArchivo.DataSource = TablaArchivo;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void cbxPagina_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                int Pagina = int.Parse(txbPagina.Text);
                PaginaInicio = (Pagina - 1) * NumeroFilas + 1;
                PaginaFinal = Pagina * NumeroFilas;
                CargarGridArchivo();
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }
    }
}
