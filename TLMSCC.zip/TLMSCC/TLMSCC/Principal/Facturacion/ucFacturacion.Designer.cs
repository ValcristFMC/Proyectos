﻿namespace TLMSCC.Principal.Facturacion
{
    partial class ucFacturacion
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.cbxPagina = new System.Windows.Forms.ComboBox();
            this.txbPagina = new System.Windows.Forms.TextBox();
            this.lblPaginas = new System.Windows.Forms.Label();
            this.lblPagina = new System.Windows.Forms.Label();
            this.cbxListaArchivos = new System.Windows.Forms.ComboBox();
            this.dtpFechaArchivo = new System.Windows.Forms.DateTimePicker();
            this.lblSeleccion = new System.Windows.Forms.Label();
            this.dgvArchivo = new System.Windows.Forms.DataGridView();
            this.btnImprimir = new TLMSCC.Controles.Boton();
            this.btnBuscar = new TLMSCC.Controles.Boton();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvArchivo)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.White;
            this.splitContainer1.Panel1.Controls.Add(this.cbxPagina);
            this.splitContainer1.Panel1.Controls.Add(this.txbPagina);
            this.splitContainer1.Panel1.Controls.Add(this.lblPaginas);
            this.splitContainer1.Panel1.Controls.Add(this.lblPagina);
            this.splitContainer1.Panel1.Controls.Add(this.cbxListaArchivos);
            this.splitContainer1.Panel1.Controls.Add(this.btnImprimir);
            this.splitContainer1.Panel1.Controls.Add(this.dtpFechaArchivo);
            this.splitContainer1.Panel1.Controls.Add(this.lblSeleccion);
            this.splitContainer1.Panel1.Controls.Add(this.btnBuscar);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dgvArchivo);
            this.splitContainer1.Size = new System.Drawing.Size(800, 600);
            this.splitContainer1.SplitterDistance = 214;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 0;
            // 
            // cbxPagina
            // 
            this.cbxPagina.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cbxPagina.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbxPagina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxPagina.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbxPagina.FormattingEnabled = true;
            this.cbxPagina.Location = new System.Drawing.Point(72, 147);
            this.cbxPagina.MaxDropDownItems = 10;
            this.cbxPagina.Name = "cbxPagina";
            this.cbxPagina.Size = new System.Drawing.Size(49, 23);
            this.cbxPagina.TabIndex = 20;
            this.cbxPagina.SelectionChangeCommitted += new System.EventHandler(this.cbxPagina_SelectionChangeCommitted);
            // 
            // txbPagina
            // 
            this.txbPagina.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txbPagina.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbPagina.Enabled = false;
            this.txbPagina.Location = new System.Drawing.Point(72, 182);
            this.txbPagina.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txbPagina.Name = "txbPagina";
            this.txbPagina.Size = new System.Drawing.Size(44, 16);
            this.txbPagina.TabIndex = 19;
            // 
            // lblPaginas
            // 
            this.lblPaginas.AutoSize = true;
            this.lblPaginas.Location = new System.Drawing.Point(3, 182);
            this.lblPaginas.Name = "lblPaginas";
            this.lblPaginas.Size = new System.Drawing.Size(65, 15);
            this.lblPaginas.TabIndex = 18;
            this.lblPaginas.Text = "N° Páginas";
            // 
            // lblPagina
            // 
            this.lblPagina.AutoSize = true;
            this.lblPagina.Location = new System.Drawing.Point(3, 150);
            this.lblPagina.Name = "lblPagina";
            this.lblPagina.Size = new System.Drawing.Size(43, 15);
            this.lblPagina.TabIndex = 17;
            this.lblPagina.Text = "Página";
            // 
            // cbxListaArchivos
            // 
            this.cbxListaArchivos.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.cbxListaArchivos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxListaArchivos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbxListaArchivos.FormattingEnabled = true;
            this.cbxListaArchivos.Location = new System.Drawing.Point(3, 86);
            this.cbxListaArchivos.Name = "cbxListaArchivos";
            this.cbxListaArchivos.Size = new System.Drawing.Size(208, 23);
            this.cbxListaArchivos.TabIndex = 11;
            // 
            // dtpFechaArchivo
            // 
            this.dtpFechaArchivo.Location = new System.Drawing.Point(3, 24);
            this.dtpFechaArchivo.Name = "dtpFechaArchivo";
            this.dtpFechaArchivo.Size = new System.Drawing.Size(208, 23);
            this.dtpFechaArchivo.TabIndex = 9;
            // 
            // lblSeleccion
            // 
            this.lblSeleccion.AutoSize = true;
            this.lblSeleccion.Location = new System.Drawing.Point(3, 59);
            this.lblSeleccion.Name = "lblSeleccion";
            this.lblSeleccion.Size = new System.Drawing.Size(112, 15);
            this.lblSeleccion.TabIndex = 1;
            this.lblSeleccion.Text = "Selecciona Archivo";
            // 
            // dgvArchivo
            // 
            this.dgvArchivo.AllowUserToAddRows = false;
            this.dgvArchivo.AllowUserToDeleteRows = false;
            this.dgvArchivo.AllowUserToResizeColumns = false;
            this.dgvArchivo.AllowUserToResizeRows = false;
            this.dgvArchivo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvArchivo.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvArchivo.BackgroundColor = System.Drawing.SystemColors.HotTrack;
            this.dgvArchivo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvArchivo.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgvArchivo.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvArchivo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvArchivo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvArchivo.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvArchivo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvArchivo.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvArchivo.EnableHeadersVisualStyles = false;
            this.dgvArchivo.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvArchivo.Location = new System.Drawing.Point(0, 0);
            this.dgvArchivo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dgvArchivo.MultiSelect = false;
            this.dgvArchivo.Name = "dgvArchivo";
            this.dgvArchivo.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvArchivo.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvArchivo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.SkyBlue;
            this.dgvArchivo.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvArchivo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvArchivo.Size = new System.Drawing.Size(581, 600);
            this.dgvArchivo.TabIndex = 1;
            // 
            // btnImprimir
            // 
            this.btnImprimir.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnImprimir.BorderColor = System.Drawing.Color.Transparent;
            this.btnImprimir.BorderRadius = 10;
            this.btnImprimir.BorderSize = 0;
            this.btnImprimir.FlatAppearance.BorderSize = 0;
            this.btnImprimir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnImprimir.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnImprimir.Location = new System.Drawing.Point(72, 115);
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(63, 23);
            this.btnImprimir.TabIndex = 10;
            this.btnImprimir.Text = "Imprime";
            this.btnImprimir.UseVisualStyleBackColor = false;
            this.btnImprimir.Click += new System.EventHandler(this.btnImprimir_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnBuscar.BorderColor = System.Drawing.Color.Transparent;
            this.btnBuscar.BorderRadius = 10;
            this.btnBuscar.BorderSize = 0;
            this.btnBuscar.FlatAppearance.BorderSize = 0;
            this.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnBuscar.Location = new System.Drawing.Point(3, 115);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(63, 23);
            this.btnBuscar.TabIndex = 0;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // ucFacturacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "ucFacturacion";
            this.Size = new System.Drawing.Size(800, 600);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvArchivo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label lblSeleccion;
        private Controles.Boton btnBuscar;
        private System.Windows.Forms.DateTimePicker dtpFechaArchivo;
        private Controles.Boton btnImprimir;
        private System.Windows.Forms.DataGridView dgvArchivo;
        private System.Windows.Forms.ComboBox cbxListaArchivos;
        private System.Windows.Forms.ComboBox cbxPagina;
        private System.Windows.Forms.TextBox txbPagina;
        private System.Windows.Forms.Label lblPaginas;
        private System.Windows.Forms.Label lblPagina;
    }
}
