﻿using BusinessEntities;
using BusinessEntities.Archivos;
using BusinessEntities.RH;
using DataAccess.Archivos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace TLMSCC.Principal.CargaArchivos
{
    public partial class ucCargaArchivos : UserControl
    {
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private string ContenidoArchivo = string.Empty;
        private string RutaArchivo = string.Empty;
        private DataTable TablaCSV = new DataTable();
        private DataTable TablaCSVR = new DataTable();
        private DataTable TablaArchivo = new DataTable();
        private DataTable TablaArchivoR = new DataTable();
        private List<ClsCharlyCSV> ListaCSV = new List<ClsCharlyCSV>();
        private ClsCharlyCSV CharlyCSV = new ClsCharlyCSV();
        private ClsArchivosDA ArchivosDA = new ClsArchivosDA();
        private ClsUsuario Usuario = new ClsUsuario();
        private int PaginaInicio = 1;
        private int NumeroFilas = 20;
        private int PaginaFinal = 0;

        public ucCargaArchivos(ClsUsuario Usr)
        {
            InitializeComponent();
            CargaInicial();
            Usuario = Usr;
        }

        private void CargarGridArchivo()
        {
            try
            {
                int FilasMostradas = NumeroFilas;
                int Paginas = TablaCSV.Rows.Count / FilasMostradas;

                if (TablaCSV.Rows.Count < FilasMostradas)
                {
                    Paginas = 1;
                }

                txbPagina.Text = Paginas.ToString();
                TablaArchivo.Rows.Clear();

                if (cbxPagina.Items.Count == 0)
                {
                    for (int Contador = 1; Contador <= Paginas; Contador++)
                    {
                        cbxPagina.Items.Add(Contador.ToString());
                    }

                    cbxPagina.SelectedIndex = 0;
                }
                
                for (int Contador = 0; Contador < NumeroFilas; Contador++)
                {
                    int Fila = (int.Parse(cbxPagina.Text) * NumeroFilas) + Contador;
                    TablaArchivo.Rows.Add(TablaCSV.Rows[Fila].ItemArray);
                }

                dgvArchivo.DataSource = TablaArchivo;
            }
            catch(Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void CargarGridResultado()
        {
            try
            {
                int FilasMostradasR = NumeroFilas;
                int PaginasR = TablaCSVR.Rows.Count / FilasMostradasR;

                if (TablaCSVR.Rows.Count < FilasMostradasR)
                {
                    PaginasR = 1;
                }

                txbPaginaR.Text = PaginasR.ToString();
                TablaArchivoR.Rows.Clear();

                if (cbxPaginaR.Items.Count == 0)
                {
                    for (int Contador = 1; Contador <= PaginasR; Contador++)
                    {
                        cbxPaginaR.Items.Add(Contador.ToString());
                    }

                    cbxPaginaR.SelectedIndex = 0;
                }

                for (int Contador = 0; Contador < NumeroFilas; Contador++)
                {
                    int Fila = (int.Parse(cbxPaginaR.Text) * NumeroFilas) + Contador;
                    TablaArchivoR.Rows.Add(TablaCSVR.Rows[Fila].ItemArray);
                }

                dgvValidar.DataSource = TablaArchivoR;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void CargaInicial()
        {
            try
            {
                ListaCSV.Clear();
                TablaCSV.Dispose();
                TablaArchivo.Dispose();
                TablaArchivoR.Dispose();
                dgvArchivo.DataSource = null;
                dgvValidar.DataSource = null;
                btnBanderaLimpiar.BackColor = Color.Red;
                btnBanderaValidar.BackColor = Color.Red;
                btnBanderaCargar.BackColor = Color.Red;
                cbxPagina.Items.Clear();
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void BuscarArchivo()
        {
            try
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.InitialDirectory = "c:\\";
                    openFileDialog.Filter = "csv files (*.csv)|*.csv";
                    openFileDialog.FilterIndex = 2;
                    openFileDialog.RestoreDirectory = true;
                    CargaInicial();

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        RutaArchivo = openFileDialog.FileName;
                        var fileStream = openFileDialog.OpenFile();

                        using (StreamReader reader = new StreamReader(fileStream))
                        {
                            ContenidoArchivo = reader.ReadToEnd();
                            txbRuta.Text = RutaArchivo;
                            TablaCSV = Funciones.ConvertCSVtoDataTableSinHeaders(RutaArchivo, CharlyCSV.GetType());
                            TablaArchivo = Funciones.CreateDataTable(CharlyCSV.GetType());
                            CargarGridArchivo();
                        }
                    }

                    btnBanderaLimpiar.BackColor = Color.Yellow;
                    btnBanderaValidar.BackColor = Color.Yellow;
                    btnBanderaCargar.BackColor = Color.Yellow;
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void LimpiarArchivo()
        {
            int Columna = 0;
            int Fila = 0;
            try
            {
                if (TablaCSV.Rows.Count == 0)
                {
                    throw new Exception("Debe haber cargado un archivo primero");
                }
                else
                {
                    foreach (DataRow r in TablaCSV.Rows)
                    {
                        foreach (var x in r.ItemArray)
                        {
                            TablaCSV.Rows[Fila][Columna] = Regex.Replace(x.ToString().Replace("  ", " "), @"[^\w\s.!@$%^&*()\-\/]+", "");
                            Columna++;
                        }
                        Columna = 0;
                        Fila++;
                    }
                    btnBanderaLimpiar.BackColor = Color.Green;
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void ValidarArchivo()
        {
            try
            {
                if (btnBanderaLimpiar.BackColor == Color.Yellow || btnBanderaLimpiar.BackColor == Color.Red)
                {
                    throw new Exception("El documento no está listo para validar");
                }
                else
                {
                    if (btnBanderaValidar.BackColor == Color.Green)
                    {
                        throw new Exception("El documento ya está validado");
                    }
                    else
                    {
                        ListaCSV = ArchivosDA.ValidarTablaArchivo(Usuario.Usuario, TablaCSV);
                        TablaCSVR = Funciones.ConvertToDataTable(ListaCSV);
                    }

                    TablaArchivoR = Funciones.CreateDataTable(CharlyCSV.GetType());
                    CargarGridResultado();

                    if (ListaCSV.Count < TablaCSV.Rows.Count)
                    {
                        MessageBox.Show("Los talones mostrados ya fueron cargados previamente");
                    }
                    else
                    {
                        btnBanderaValidar.BackColor = Color.Green;
                    }
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void CargarArchivo()
        {
            try
            {
                if (btnBanderaLimpiar.BackColor == Color.Yellow || btnBanderaLimpiar.BackColor == Color.Red || btnBanderaValidar.BackColor == Color.Yellow || btnBanderaValidar.BackColor == Color.Red)
                {
                    throw new Exception("El documento no está listo para guardar");
                }
                else
                {
                    if (btnBanderaCargar.BackColor == Color.Green)
                    {
                        throw new Exception("El documento ya está cargado");
                    }
                    else
                    {
                        ArchivosDA.CargarTablaArchivo(Usuario.Usuario, TablaCSV);
                        btnBanderaCargar.BackColor = Color.Green;
                    }
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                BuscarArchivo();
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            try
            {
                LimpiarArchivo();
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            try
            {
                ValidarArchivo();
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void btnCargar_Click(object sender, EventArgs e)
        {
            try
            {
                CargarArchivo();
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void cbxPagina_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                int Pagina = int.Parse(txbPagina.Text);
                PaginaInicio = (Pagina - 1) * NumeroFilas + 1;
                PaginaFinal = Pagina * NumeroFilas;
                CargarGridArchivo();
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void cbxPaginaR_SelectionChangeCommitted(object sender, EventArgs e)
        {
            try
            {
                int Pagina = int.Parse(txbPagina.Text);
                PaginaInicio = (Pagina - 1) * NumeroFilas + 1;
                PaginaFinal = Pagina * NumeroFilas;
                CargarGridResultado();
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }
    }
} 
