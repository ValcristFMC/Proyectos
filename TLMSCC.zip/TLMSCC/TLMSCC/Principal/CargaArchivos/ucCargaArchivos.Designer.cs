﻿namespace TLMSCC.Principal.CargaArchivos
{
    partial class ucCargaArchivos
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.ucBusquedaArchivo = new System.Windows.Forms.SplitContainer();
            this.ucValidadorArchivo = new System.Windows.Forms.SplitContainer();
            this.cbxPagina = new System.Windows.Forms.ComboBox();
            this.txbPagina = new System.Windows.Forms.TextBox();
            this.lblPaginas = new System.Windows.Forms.Label();
            this.lblPagina = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBuscar = new TLMSCC.Controles.Boton();
            this.txbRuta = new System.Windows.Forms.TextBox();
            this.dgvArchivo = new System.Windows.Forms.DataGridView();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.txbPaginaR = new System.Windows.Forms.TextBox();
            this.btnBanderaLimpiar = new TLMSCC.Controles.Boton();
            this.lblPaginasR = new System.Windows.Forms.Label();
            this.btnBanderaCargar = new TLMSCC.Controles.Boton();
            this.cbxPaginaR = new System.Windows.Forms.ComboBox();
            this.btnBanderaValidar = new TLMSCC.Controles.Boton();
            this.lblPaginaR = new System.Windows.Forms.Label();
            this.lblLimpiar = new System.Windows.Forms.Label();
            this.lblCargar = new System.Windows.Forms.Label();
            this.lblValidar = new System.Windows.Forms.Label();
            this.btnValidar = new TLMSCC.Controles.Boton();
            this.btnCargar = new TLMSCC.Controles.Boton();
            this.btnLimpiar = new TLMSCC.Controles.Boton();
            this.dgvValidar = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.ucBusquedaArchivo)).BeginInit();
            this.ucBusquedaArchivo.Panel1.SuspendLayout();
            this.ucBusquedaArchivo.Panel2.SuspendLayout();
            this.ucBusquedaArchivo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ucValidadorArchivo)).BeginInit();
            this.ucValidadorArchivo.Panel1.SuspendLayout();
            this.ucValidadorArchivo.Panel2.SuspendLayout();
            this.ucValidadorArchivo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvArchivo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvValidar)).BeginInit();
            this.SuspendLayout();
            // 
            // ucBusquedaArchivo
            // 
            this.ucBusquedaArchivo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucBusquedaArchivo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.ucBusquedaArchivo.IsSplitterFixed = true;
            this.ucBusquedaArchivo.Location = new System.Drawing.Point(0, 0);
            this.ucBusquedaArchivo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ucBusquedaArchivo.Name = "ucBusquedaArchivo";
            // 
            // ucBusquedaArchivo.Panel1
            // 
            this.ucBusquedaArchivo.Panel1.Controls.Add(this.ucValidadorArchivo);
            // 
            // ucBusquedaArchivo.Panel2
            // 
            this.ucBusquedaArchivo.Panel2.Controls.Add(this.splitContainer3);
            this.ucBusquedaArchivo.Size = new System.Drawing.Size(800, 600);
            this.ucBusquedaArchivo.SplitterDistance = 400;
            this.ucBusquedaArchivo.SplitterWidth = 5;
            this.ucBusquedaArchivo.TabIndex = 0;
            // 
            // ucValidadorArchivo
            // 
            this.ucValidadorArchivo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucValidadorArchivo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.ucValidadorArchivo.IsSplitterFixed = true;
            this.ucValidadorArchivo.Location = new System.Drawing.Point(0, 0);
            this.ucValidadorArchivo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ucValidadorArchivo.Name = "ucValidadorArchivo";
            this.ucValidadorArchivo.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // ucValidadorArchivo.Panel1
            // 
            this.ucValidadorArchivo.Panel1.BackColor = System.Drawing.Color.White;
            this.ucValidadorArchivo.Panel1.Controls.Add(this.cbxPagina);
            this.ucValidadorArchivo.Panel1.Controls.Add(this.txbPagina);
            this.ucValidadorArchivo.Panel1.Controls.Add(this.lblPaginas);
            this.ucValidadorArchivo.Panel1.Controls.Add(this.lblPagina);
            this.ucValidadorArchivo.Panel1.Controls.Add(this.label1);
            this.ucValidadorArchivo.Panel1.Controls.Add(this.btnBuscar);
            this.ucValidadorArchivo.Panel1.Controls.Add(this.txbRuta);
            // 
            // ucValidadorArchivo.Panel2
            // 
            this.ucValidadorArchivo.Panel2.Controls.Add(this.dgvArchivo);
            this.ucValidadorArchivo.Size = new System.Drawing.Size(400, 600);
            this.ucValidadorArchivo.SplitterDistance = 133;
            this.ucValidadorArchivo.SplitterWidth = 5;
            this.ucValidadorArchivo.TabIndex = 0;
            // 
            // cbxPagina
            // 
            this.cbxPagina.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cbxPagina.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbxPagina.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxPagina.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbxPagina.FormattingEnabled = true;
            this.cbxPagina.Location = new System.Drawing.Point(225, 110);
            this.cbxPagina.MaxDropDownItems = 10;
            this.cbxPagina.Name = "cbxPagina";
            this.cbxPagina.Size = new System.Drawing.Size(49, 23);
            this.cbxPagina.TabIndex = 16;
            this.cbxPagina.SelectionChangeCommitted += new System.EventHandler(this.cbxPagina_SelectionChangeCommitted);
            // 
            // txbPagina
            // 
            this.txbPagina.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txbPagina.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbPagina.Enabled = false;
            this.txbPagina.Location = new System.Drawing.Point(352, 113);
            this.txbPagina.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txbPagina.Name = "txbPagina";
            this.txbPagina.Size = new System.Drawing.Size(44, 16);
            this.txbPagina.TabIndex = 13;
            // 
            // lblPaginas
            // 
            this.lblPaginas.AutoSize = true;
            this.lblPaginas.Location = new System.Drawing.Point(280, 113);
            this.lblPaginas.Name = "lblPaginas";
            this.lblPaginas.Size = new System.Drawing.Size(65, 15);
            this.lblPaginas.TabIndex = 12;
            this.lblPaginas.Text = "N° Páginas";
            // 
            // lblPagina
            // 
            this.lblPagina.AutoSize = true;
            this.lblPagina.Location = new System.Drawing.Point(176, 113);
            this.lblPagina.Name = "lblPagina";
            this.lblPagina.Size = new System.Drawing.Size(43, 15);
            this.lblPagina.TabIndex = 10;
            this.lblPagina.Text = "Página";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Seleccione el archivo CSV a cargar:";
            // 
            // btnBuscar
            // 
            this.btnBuscar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnBuscar.BorderColor = System.Drawing.Color.Transparent;
            this.btnBuscar.BorderRadius = 10;
            this.btnBuscar.BorderSize = 0;
            this.btnBuscar.FlatAppearance.BorderSize = 0;
            this.btnBuscar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBuscar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnBuscar.Location = new System.Drawing.Point(18, 93);
            this.btnBuscar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(74, 27);
            this.btnBuscar.TabIndex = 8;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = false;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // txbRuta
            // 
            this.txbRuta.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txbRuta.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbRuta.Enabled = false;
            this.txbRuta.Location = new System.Drawing.Point(18, 70);
            this.txbRuta.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txbRuta.Name = "txbRuta";
            this.txbRuta.Size = new System.Drawing.Size(378, 16);
            this.txbRuta.TabIndex = 7;
            // 
            // dgvArchivo
            // 
            this.dgvArchivo.AllowUserToAddRows = false;
            this.dgvArchivo.AllowUserToDeleteRows = false;
            this.dgvArchivo.AllowUserToResizeColumns = false;
            this.dgvArchivo.AllowUserToResizeRows = false;
            this.dgvArchivo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvArchivo.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvArchivo.BackgroundColor = System.Drawing.SystemColors.HotTrack;
            this.dgvArchivo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvArchivo.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgvArchivo.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvArchivo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvArchivo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvArchivo.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvArchivo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvArchivo.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvArchivo.EnableHeadersVisualStyles = false;
            this.dgvArchivo.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvArchivo.Location = new System.Drawing.Point(0, 0);
            this.dgvArchivo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dgvArchivo.MultiSelect = false;
            this.dgvArchivo.Name = "dgvArchivo";
            this.dgvArchivo.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvArchivo.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvArchivo.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.SkyBlue;
            this.dgvArchivo.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvArchivo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvArchivo.Size = new System.Drawing.Size(400, 462);
            this.dgvArchivo.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.BackColor = System.Drawing.Color.White;
            this.splitContainer3.Panel1.Controls.Add(this.txbPaginaR);
            this.splitContainer3.Panel1.Controls.Add(this.btnBanderaLimpiar);
            this.splitContainer3.Panel1.Controls.Add(this.lblPaginasR);
            this.splitContainer3.Panel1.Controls.Add(this.btnBanderaCargar);
            this.splitContainer3.Panel1.Controls.Add(this.cbxPaginaR);
            this.splitContainer3.Panel1.Controls.Add(this.btnBanderaValidar);
            this.splitContainer3.Panel1.Controls.Add(this.lblPaginaR);
            this.splitContainer3.Panel1.Controls.Add(this.lblLimpiar);
            this.splitContainer3.Panel1.Controls.Add(this.lblCargar);
            this.splitContainer3.Panel1.Controls.Add(this.lblValidar);
            this.splitContainer3.Panel1.Controls.Add(this.btnValidar);
            this.splitContainer3.Panel1.Controls.Add(this.btnCargar);
            this.splitContainer3.Panel1.Controls.Add(this.btnLimpiar);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.dgvValidar);
            this.splitContainer3.Size = new System.Drawing.Size(395, 600);
            this.splitContainer3.SplitterDistance = 133;
            this.splitContainer3.SplitterWidth = 5;
            this.splitContainer3.TabIndex = 0;
            // 
            // txbPaginaR
            // 
            this.txbPaginaR.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txbPaginaR.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txbPaginaR.Enabled = false;
            this.txbPaginaR.Location = new System.Drawing.Point(347, 114);
            this.txbPaginaR.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txbPaginaR.Name = "txbPaginaR";
            this.txbPaginaR.Size = new System.Drawing.Size(44, 16);
            this.txbPaginaR.TabIndex = 17;
            // 
            // btnBanderaLimpiar
            // 
            this.btnBanderaLimpiar.BackColor = System.Drawing.Color.Red;
            this.btnBanderaLimpiar.BorderColor = System.Drawing.Color.Transparent;
            this.btnBanderaLimpiar.BorderRadius = 10;
            this.btnBanderaLimpiar.BorderSize = 0;
            this.btnBanderaLimpiar.Enabled = false;
            this.btnBanderaLimpiar.FlatAppearance.BorderSize = 0;
            this.btnBanderaLimpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBanderaLimpiar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnBanderaLimpiar.Location = new System.Drawing.Point(325, 3);
            this.btnBanderaLimpiar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBanderaLimpiar.Name = "btnBanderaLimpiar";
            this.btnBanderaLimpiar.Size = new System.Drawing.Size(27, 27);
            this.btnBanderaLimpiar.TabIndex = 17;
            this.btnBanderaLimpiar.UseVisualStyleBackColor = false;
            // 
            // lblPaginasR
            // 
            this.lblPaginasR.AutoSize = true;
            this.lblPaginasR.Location = new System.Drawing.Point(275, 114);
            this.lblPaginasR.Name = "lblPaginasR";
            this.lblPaginasR.Size = new System.Drawing.Size(65, 15);
            this.lblPaginasR.TabIndex = 16;
            this.lblPaginasR.Text = "N° Páginas";
            // 
            // btnBanderaCargar
            // 
            this.btnBanderaCargar.BackColor = System.Drawing.Color.Red;
            this.btnBanderaCargar.BorderColor = System.Drawing.Color.Transparent;
            this.btnBanderaCargar.BorderRadius = 10;
            this.btnBanderaCargar.BorderSize = 0;
            this.btnBanderaCargar.Enabled = false;
            this.btnBanderaCargar.FlatAppearance.BorderSize = 0;
            this.btnBanderaCargar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBanderaCargar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnBanderaCargar.Location = new System.Drawing.Point(325, 70);
            this.btnBanderaCargar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBanderaCargar.Name = "btnBanderaCargar";
            this.btnBanderaCargar.Size = new System.Drawing.Size(27, 27);
            this.btnBanderaCargar.TabIndex = 16;
            this.btnBanderaCargar.UseVisualStyleBackColor = false;
            // 
            // cbxPaginaR
            // 
            this.cbxPaginaR.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cbxPaginaR.Cursor = System.Windows.Forms.Cursors.Default;
            this.cbxPaginaR.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxPaginaR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbxPaginaR.FormattingEnabled = true;
            this.cbxPaginaR.Location = new System.Drawing.Point(220, 111);
            this.cbxPaginaR.MaxDropDownItems = 10;
            this.cbxPaginaR.Name = "cbxPaginaR";
            this.cbxPaginaR.Size = new System.Drawing.Size(49, 23);
            this.cbxPaginaR.TabIndex = 15;
            this.cbxPaginaR.SelectionChangeCommitted += new System.EventHandler(this.cbxPaginaR_SelectionChangeCommitted);
            // 
            // btnBanderaValidar
            // 
            this.btnBanderaValidar.BackColor = System.Drawing.Color.Red;
            this.btnBanderaValidar.BorderColor = System.Drawing.Color.Transparent;
            this.btnBanderaValidar.BorderRadius = 10;
            this.btnBanderaValidar.BorderSize = 0;
            this.btnBanderaValidar.Enabled = false;
            this.btnBanderaValidar.FlatAppearance.BorderSize = 0;
            this.btnBanderaValidar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBanderaValidar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnBanderaValidar.Location = new System.Drawing.Point(325, 36);
            this.btnBanderaValidar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBanderaValidar.Name = "btnBanderaValidar";
            this.btnBanderaValidar.Size = new System.Drawing.Size(27, 27);
            this.btnBanderaValidar.TabIndex = 15;
            this.btnBanderaValidar.UseVisualStyleBackColor = false;
            // 
            // lblPaginaR
            // 
            this.lblPaginaR.AutoSize = true;
            this.lblPaginaR.Location = new System.Drawing.Point(171, 114);
            this.lblPaginaR.Name = "lblPaginaR";
            this.lblPaginaR.Size = new System.Drawing.Size(43, 15);
            this.lblPaginaR.TabIndex = 14;
            this.lblPaginaR.Text = "Página";
            // 
            // lblLimpiar
            // 
            this.lblLimpiar.AutoSize = true;
            this.lblLimpiar.Location = new System.Drawing.Point(93, 75);
            this.lblLimpiar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLimpiar.Name = "lblLimpiar";
            this.lblLimpiar.Size = new System.Drawing.Size(163, 15);
            this.lblLimpiar.TabIndex = 14;
            this.lblLimpiar.Text = "Limpia parametros de carga.";
            // 
            // lblCargar
            // 
            this.lblCargar.AutoSize = true;
            this.lblCargar.Location = new System.Drawing.Point(93, 41);
            this.lblCargar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCargar.Name = "lblCargar";
            this.lblCargar.Size = new System.Drawing.Size(192, 15);
            this.lblCargar.TabIndex = 13;
            this.lblCargar.Text = "Primero se valida antes de cargar.";
            // 
            // lblValidar
            // 
            this.lblValidar.AutoSize = true;
            this.lblValidar.Location = new System.Drawing.Point(93, 10);
            this.lblValidar.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValidar.Name = "lblValidar";
            this.lblValidar.Size = new System.Drawing.Size(189, 15);
            this.lblValidar.TabIndex = 12;
            this.lblValidar.Text = "No se ha cargado ningun archivo.";
            // 
            // btnValidar
            // 
            this.btnValidar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnValidar.BorderColor = System.Drawing.Color.Transparent;
            this.btnValidar.BorderRadius = 10;
            this.btnValidar.BorderSize = 0;
            this.btnValidar.FlatAppearance.BorderSize = 0;
            this.btnValidar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnValidar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnValidar.Location = new System.Drawing.Point(13, 36);
            this.btnValidar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnValidar.Name = "btnValidar";
            this.btnValidar.Size = new System.Drawing.Size(74, 27);
            this.btnValidar.TabIndex = 11;
            this.btnValidar.Text = "Validar";
            this.btnValidar.UseVisualStyleBackColor = false;
            this.btnValidar.Click += new System.EventHandler(this.btnValidar_Click);
            // 
            // btnCargar
            // 
            this.btnCargar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnCargar.BorderColor = System.Drawing.Color.Transparent;
            this.btnCargar.BorderRadius = 10;
            this.btnCargar.BorderSize = 0;
            this.btnCargar.FlatAppearance.BorderSize = 0;
            this.btnCargar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCargar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnCargar.Location = new System.Drawing.Point(13, 70);
            this.btnCargar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCargar.Name = "btnCargar";
            this.btnCargar.Size = new System.Drawing.Size(74, 27);
            this.btnCargar.TabIndex = 10;
            this.btnCargar.Text = "Cargar";
            this.btnCargar.UseVisualStyleBackColor = false;
            this.btnCargar.Click += new System.EventHandler(this.btnCargar_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnLimpiar.BorderColor = System.Drawing.Color.Transparent;
            this.btnLimpiar.BorderRadius = 10;
            this.btnLimpiar.BorderSize = 0;
            this.btnLimpiar.FlatAppearance.BorderSize = 0;
            this.btnLimpiar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLimpiar.ForeColor = System.Drawing.Color.AliceBlue;
            this.btnLimpiar.Location = new System.Drawing.Point(13, 3);
            this.btnLimpiar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(74, 27);
            this.btnLimpiar.TabIndex = 9;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = false;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // dgvValidar
            // 
            this.dgvValidar.AllowUserToAddRows = false;
            this.dgvValidar.AllowUserToDeleteRows = false;
            this.dgvValidar.AllowUserToResizeColumns = false;
            this.dgvValidar.AllowUserToResizeRows = false;
            this.dgvValidar.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvValidar.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvValidar.BackgroundColor = System.Drawing.SystemColors.HotTrack;
            this.dgvValidar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvValidar.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dgvValidar.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvValidar.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvValidar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.InactiveCaption;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvValidar.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvValidar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvValidar.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvValidar.EnableHeadersVisualStyles = false;
            this.dgvValidar.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvValidar.Location = new System.Drawing.Point(0, 0);
            this.dgvValidar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dgvValidar.MultiSelect = false;
            this.dgvValidar.Name = "dgvValidar";
            this.dgvValidar.ReadOnly = true;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvValidar.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvValidar.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.SkyBlue;
            this.dgvValidar.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvValidar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvValidar.Size = new System.Drawing.Size(395, 462);
            this.dgvValidar.TabIndex = 1;
            // 
            // ucCargaArchivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Controls.Add(this.ucBusquedaArchivo);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "ucCargaArchivos";
            this.Size = new System.Drawing.Size(800, 600);
            this.ucBusquedaArchivo.Panel1.ResumeLayout(false);
            this.ucBusquedaArchivo.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ucBusquedaArchivo)).EndInit();
            this.ucBusquedaArchivo.ResumeLayout(false);
            this.ucValidadorArchivo.Panel1.ResumeLayout(false);
            this.ucValidadorArchivo.Panel1.PerformLayout();
            this.ucValidadorArchivo.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ucValidadorArchivo)).EndInit();
            this.ucValidadorArchivo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvArchivo)).EndInit();
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvValidar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer ucBusquedaArchivo;
        private System.Windows.Forms.SplitContainer ucValidadorArchivo;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private Controles.Boton btnBuscar;
        private System.Windows.Forms.TextBox txbRuta;
        private System.Windows.Forms.DataGridView dgvArchivo;
        private Controles.Boton btnValidar;
        private Controles.Boton btnCargar;
        private Controles.Boton btnLimpiar;
        private System.Windows.Forms.Label label1;
        private Controles.Boton btnBanderaValidar;
        private System.Windows.Forms.Label lblLimpiar;
        private System.Windows.Forms.Label lblCargar;
        private System.Windows.Forms.Label lblValidar;
        private Controles.Boton btnBanderaLimpiar;
        private Controles.Boton btnBanderaCargar;
        private System.Windows.Forms.DataGridView dgvValidar;
        private System.Windows.Forms.Label lblPagina;
        private System.Windows.Forms.Label lblPaginas;
        private System.Windows.Forms.TextBox txbPagina;
        private System.Windows.Forms.TextBox txbPaginaR;
        private System.Windows.Forms.Label lblPaginasR;
        private System.Windows.Forms.ComboBox cbxPaginaR;
        private System.Windows.Forms.Label lblPaginaR;
        private System.Windows.Forms.ComboBox cbxPagina;
    }
}
