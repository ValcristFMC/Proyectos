﻿namespace TLMSCC
{
    partial class SCC
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SCC));
            this.mnuPrincipal = new System.Windows.Forms.MenuStrip();
            this.mnuCargaArchivos = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuGuias = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFacturacion = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCerrarSesion = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlPrincipal = new System.Windows.Forms.Panel();
            this.mnuPrincipal.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuPrincipal
            // 
            this.mnuPrincipal.BackColor = System.Drawing.Color.White;
            this.mnuPrincipal.Dock = System.Windows.Forms.DockStyle.Left;
            this.mnuPrincipal.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.mnuPrincipal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCargaArchivos,
            this.mnuGuias,
            this.mnuFacturacion,
            this.mnuCerrarSesion});
            this.mnuPrincipal.Location = new System.Drawing.Point(0, 0);
            this.mnuPrincipal.Name = "mnuPrincipal";
            this.mnuPrincipal.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.mnuPrincipal.Size = new System.Drawing.Size(141, 692);
            this.mnuPrincipal.TabIndex = 0;
            this.mnuPrincipal.Text = "MenuPrincipal";
            // 
            // mnuCargaArchivos
            // 
            this.mnuCargaArchivos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.mnuCargaArchivos.Image = ((System.Drawing.Image)(resources.GetObject("mnuCargaArchivos.Image")));
            this.mnuCargaArchivos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnuCargaArchivos.Name = "mnuCargaArchivos";
            this.mnuCargaArchivos.Size = new System.Drawing.Size(126, 20);
            this.mnuCargaArchivos.Text = "Carga de Archivos";
            this.mnuCargaArchivos.Click += new System.EventHandler(this.mnuCargaArchivos_Click);
            // 
            // mnuGuias
            // 
            this.mnuGuias.Image = ((System.Drawing.Image)(resources.GetObject("mnuGuias.Image")));
            this.mnuGuias.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnuGuias.Name = "mnuGuias";
            this.mnuGuias.Size = new System.Drawing.Size(126, 20);
            this.mnuGuias.Text = "Guias";
            this.mnuGuias.Click += new System.EventHandler(this.mnuGuias_Click);
            // 
            // mnuFacturacion
            // 
            this.mnuFacturacion.Image = ((System.Drawing.Image)(resources.GetObject("mnuFacturacion.Image")));
            this.mnuFacturacion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnuFacturacion.Name = "mnuFacturacion";
            this.mnuFacturacion.Size = new System.Drawing.Size(126, 20);
            this.mnuFacturacion.Text = "Facturación";
            this.mnuFacturacion.Click += new System.EventHandler(this.mnuFacturacion_Click);
            // 
            // mnuCerrarSesion
            // 
            this.mnuCerrarSesion.Image = ((System.Drawing.Image)(resources.GetObject("mnuCerrarSesion.Image")));
            this.mnuCerrarSesion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.mnuCerrarSesion.Name = "mnuCerrarSesion";
            this.mnuCerrarSesion.Size = new System.Drawing.Size(126, 20);
            this.mnuCerrarSesion.Text = "Cerrar Sesión";
            this.mnuCerrarSesion.Click += new System.EventHandler(this.mnuCerrarSesion_Click);
            // 
            // pnlPrincipal
            // 
            this.pnlPrincipal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPrincipal.BackgroundImage")));
            this.pnlPrincipal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnlPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrincipal.Location = new System.Drawing.Point(141, 0);
            this.pnlPrincipal.Name = "pnlPrincipal";
            this.pnlPrincipal.Size = new System.Drawing.Size(792, 692);
            this.pnlPrincipal.TabIndex = 1;
            // 
            // SCC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 692);
            this.ControlBox = false;
            this.Controls.Add(this.pnlPrincipal);
            this.Controls.Add(this.mnuPrincipal);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.mnuPrincipal;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "SCC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema Control de Clientes";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SCC_FormClosing);
            this.mnuPrincipal.ResumeLayout(false);
            this.mnuPrincipal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuPrincipal;
        private System.Windows.Forms.ToolStripMenuItem mnuCargaArchivos;
        private System.Windows.Forms.ToolStripMenuItem mnuGuias;
        private System.Windows.Forms.ToolStripMenuItem mnuFacturacion;
        private System.Windows.Forms.ToolStripMenuItem mnuCerrarSesion;
        private System.Windows.Forms.Panel pnlPrincipal;
    }
}

