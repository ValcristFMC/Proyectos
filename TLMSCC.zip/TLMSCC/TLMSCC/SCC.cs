﻿using BusinessEntities.RH;
using DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using TLMSCC.Principal.CargaArchivos;
using TLMSCC.Principal.Facturacion;
using TLMSCC.Principal.Guias;
using static System.Collections.Specialized.BitVector32;

namespace TLMSCC
{
    public partial class SCC : Form
    {
        private bool Sesion = false;
        private ClsUsuario Usuario = new ClsUsuario();
        private ClsLogin Login = new ClsLogin();
        private string Menu = string.Empty;
        private string MenuAnterior = string.Empty;
        private string MenuTemp = string.Empty;
        private bool Bandera = false;

        public SCC(ClsUsuario Usu)
        {
            InitializeComponent();
            Usuario = Usu;
        }

        public void MostrarError(string strErr)
        {
            MessageBox.Show(strErr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void VerificaSesion(bool Estatus)
        {
            try
            {
                Usuario = Login.VerificaSesion(Usuario.Usuario, Usuario.Contraseña)[0];
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.OpenForms[0].Show();
            this.Close();
        }

        private void mnuCargaArchivos_Click(object sender, EventArgs e)
        {
            try
            {
                MenuTemp = MenuAnterior;
                MenuAnterior = Menu;
                Menu = "ucCargaArchivos";
                RevisarCambioUserControl();

                if (Bandera)
                {
                    if ((MenuAnterior == "ucFacturacion" || MenuAnterior == "ucCargaArchivos") && (Menu == string.Empty || Menu == "ucFacturacion" || Menu == "ucCargaArchivos"))
                    {
                        DialogResult dialogResult = MessageBox.Show("Este proceso sera cancelado y perdera la información.", "Advertencia", MessageBoxButtons.YesNo);

                        if (dialogResult == DialogResult.Yes)
                        {
                            pnlPrincipal.Controls.Clear();
                            ucCargaArchivos CargaArchivos = new ucCargaArchivos(Usuario);
                            pnlPrincipal.Controls.Add(CargaArchivos);
                            CargaArchivos.AutoSize = true;
                            CargaArchivos.Dock = DockStyle.Fill;
                        }
                        if (dialogResult == DialogResult.No)
                        {
                            Menu = MenuAnterior;
                            MenuAnterior = MenuTemp;
                        }
                    }
                    else
                    {
                        if ((MenuAnterior == string.Empty || MenuAnterior != "ucCargaArchivos" || MenuAnterior != "ucFacturacion") && Menu == "ucCargaArchivos")
                        {
                            pnlPrincipal.Controls.Clear();
                            ucCargaArchivos CargaArchivos = new ucCargaArchivos(Usuario);
                            pnlPrincipal.Controls.Add(CargaArchivos);
                            CargaArchivos.AutoSize = true;
                            CargaArchivos.Dock = DockStyle.Fill;
                        }
                    }
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void mnuFacturacion_Click(object sender, EventArgs e)
        {
            try
            {
                MenuTemp = MenuAnterior;
                MenuAnterior = Menu;
                Menu = "ucFacturacion";
                RevisarCambioUserControl();

                if (Bandera)
                {
                    if ((MenuAnterior == "ucFacturacion" || MenuAnterior == "ucCargaArchivos") && (Menu == string.Empty || Menu == "ucFacturacion" || Menu == "ucCargaArchivos"))
                    {
                        DialogResult dialogResult = MessageBox.Show("Este proceso sera cancelado y perdera la información.", "Advertencia", MessageBoxButtons.YesNo);

                        if (dialogResult == DialogResult.Yes)
                        {
                            pnlPrincipal.Controls.Clear();
                            ucFacturacion Facturacion = new ucFacturacion(Usuario);
                            pnlPrincipal.Controls.Add(Facturacion);
                            Facturacion.AutoSize = true;
                            Facturacion.Dock = DockStyle.Fill;
                        }
                        if (dialogResult == DialogResult.No)
                        {
                            Menu = MenuAnterior;
                            MenuAnterior = MenuTemp;
                        }
                    }
                    else
                    {
                        if ((MenuAnterior == string.Empty || MenuAnterior != "ucCargaArchivos" || MenuAnterior != "ucFacturacion") && Menu == "ucFacturacion")
                        {
                            pnlPrincipal.Controls.Clear();
                            ucFacturacion Facturacion = new ucFacturacion(Usuario);
                            pnlPrincipal.Controls.Add(Facturacion);
                            Facturacion.AutoSize = true;
                            Facturacion.Dock = DockStyle.Fill;
                        }
                    }
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void mnuGuias_Click(object sender, EventArgs e)
        {
            try
            {
                MenuTemp = MenuAnterior;
                MenuAnterior = Menu;
                Menu = "ucGuias";
                RevisarCambioUserControl();

                if (!Bandera)
                {
                    if (MenuAnterior == "ucFacturacion" || MenuAnterior == "ucCargaArchivos")
                    {
                        DialogResult dialogResult = MessageBox.Show("Este proceso sera cancelado y perdera la información.", "Advertencia", MessageBoxButtons.YesNo);

                        if (dialogResult == DialogResult.Yes)
                        {
                            pnlPrincipal.Controls.Clear();
                            ucGuias Guias = new ucGuias();
                            pnlPrincipal.Controls.Add(Guias);
                            Guias.AutoSize = true;
                            Guias.Dock = DockStyle.Fill;
                        }
                        if (dialogResult == DialogResult.No)
                        {
                            Menu = MenuAnterior;
                            MenuAnterior = MenuTemp;
                        }
                    }
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void RevisarCambioUserControl()
        {
            try
            {
                switch (Menu)
                {
                    case "ucCargaArchivos":
                        Bandera = true;
                        break;
                    case "ucFacturacion":
                        Bandera = true;
                        break;
                    default:
                        Bandera = false;
                        break;
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void mnuCerrarSesion_Click(object sender, EventArgs e)
        {
            Application.OpenForms[0].Show();
            this.Close();
        }

        private void SCC_FormClosing(object sender, FormClosingEventArgs e)
        {
            VerificaSesion(!Sesion);
            Application.Exit();
        }
    }
}
