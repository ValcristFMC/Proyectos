﻿using BusinessEntities.RH;
using DataAccess;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace TLMSCC
{
    public partial class InicioSesion : Form
    {
        private bool SesionIniciada = false;
        private ClsLogin Login = new ClsLogin();
        private List<ClsUsuario> ListaUsuario = new List<ClsUsuario>();

        public InicioSesion()
        {
            InitializeComponent();
        }

        protected bool formaCargada(string pstrNombre)
        {
            for (int X = 0; X < this.MdiChildren.Length; X++)
            {
                if (this.MdiChildren[X].Name == pstrNombre)
                {
                    this.MdiChildren[X].Activate();

                    return (true);
                }
            }

            return (false);
        }

        public void MostrarError(string strErr)
        {
            MessageBox.Show(strErr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            try
            {
                ListaUsuario = Login.VerificaSesion(txbUsuario.Text, txbContraseña.Text);

                if (ListaUsuario.Count > 0)
                {
                    SesionIniciada = true;
                }
                else
                {
                    SesionIniciada = false;
                }

                bool Cancela = true;

                if (SesionIniciada)
                {
                    foreach (Form frm in Application.OpenForms)
                    {
                        if (frm.GetType() == typeof(SCC))
                        {
                            Cancela = false;
                            break;
                        }
                    }

                    if (Cancela)
                    {
                        if (!formaCargada("Jiricuicho"))
                        {
                            SCC MonitoreoProcesos = new SCC(ListaUsuario[0]);
                            MonitoreoProcesos.Show();
                            Application.OpenForms[0].Hide();
                        }
                    }

                    txbUsuario.Text = string.Empty;
                    txbContraseña.Text = string.Empty;
                }
                else
                {
                    throw new Exception("Nombre de usuario y contraseña erroneos, intentarlo nuevamente");
                }
            }
            catch (Exception Error)
            {
                txbUsuario.Text = string.Empty;
                txbContraseña.Text = string.Empty;
                MessageBox.Show(Error.Message);
            }
        }
    }
}
