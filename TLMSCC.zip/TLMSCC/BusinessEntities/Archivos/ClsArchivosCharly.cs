﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.Archivos
{
    public class ClsArchivosCharly
    {
        public int idArchivos { get; set; }
        public string NumeroGuia { get; set; }
        public string NumeroConsignatario { get; set; }
        public int NumeroCajas { get; set; }
        public int Pares { get; set; }
        public string Ciudad { get; set; }
        public int NumeroArchivo { get; set; }
        public bool Estatus { get; set; }
        public DateTime Fecha { get; set; }
        public string Nombre { get; set; }
    }
}
