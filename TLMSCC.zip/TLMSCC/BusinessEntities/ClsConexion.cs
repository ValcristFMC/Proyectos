﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities
{
    public class ClsConexion
    {
        #region Atributos

        public SqlConnection sqlCon = null;
        private SqlTransaction sqlTrn = null;
        private string _Servidor;
        private int _Puerto;
        private string _BaseDeDatos;
        private string _Usuario;
        private string _Clave;
        private string _CadCon;

        public string Servidor
        {
            set
            {
                _Servidor = value;
                _CadCon = string.Empty;
            }
            get { return _Servidor; }
        }
        public int Puerto
        {
            set { _Puerto = value; }
            get { return _Puerto; }
        }
        public string BaseDeDatos
        {
            set { _BaseDeDatos = value; }
            get { return _BaseDeDatos; }
        }
        public string Usuario
        {
            set { _Usuario = value; }
            get { return _Usuario; }
        }
        public string Clave
        {
            set { _Clave = value; }
            get { return _Clave; }
        }
        public string CadCon
        {
            set
            {
                _CadCon = value;
                _Servidor = string.Empty;
            }
            get { return _CadCon; }
        }

        #endregion

        #region Funciones de la Clase

        /// <Inicializa la Clase>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        public ClsConexion()
        {
            _Servidor = string.Empty;
        }

        /// <Inicializa Atributos de la Clase>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <param name="Servidor"></param>
        /// <param name="Puerto"></param>
        /// <param name="BaseDeDatos"></param>
        /// <param name="Usuario"></param>
        /// <param name="Clave"></param>
        public ClsConexion(string Servidor, int Puerto, string BaseDeDatos, string Usuario, string Clave)
        {
            _Servidor = Servidor;
            _Puerto = Puerto;
            this._BaseDeDatos = BaseDeDatos;
            _Usuario = Usuario;
            _Clave = Clave;
        }

        /// <Inicializa la cadena de conexión>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <param name="CadCon"></param>
        public ClsConexion(string CadCon)
        {
            _Servidor = string.Empty;
            _CadCon = CadCon;
        }

        /// <Cierra Conexión de la Base de Datos>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        public void Dispose()
        {
            CerrarConexion();
        }

        /// <Abre conexión a la Base de Datos con string de comando>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <param name="strCadCon"></param>
        public void AbrirConexion(string strCadCon)
        {
            if (ExisteConexion())
            {
                CerrarConexion();
            }

            try
            {
                sqlCon = new SqlConnection(strCadCon);
                sqlCon.Open();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        /// <Abre conexión a la Base de Datos sin string de comando>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        public void AbrirConexion()
        {
            if (ExisteConexion())
            {
                CerrarConexion();
            }

            try
            {
                sqlCon = new SqlConnection(ObtenerCadenaDeConexion());
                sqlCon.Open();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        /// <Obtiene Cadena de conexión para acceder a la Base de Datos>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <returns></returns>
        private string ObtenerCadenaDeConexion()
        {
            if (_Servidor != string.Empty)
            {
                if (_Servidor == string.Empty || _Puerto == 0 || _BaseDeDatos == string.Empty)
                {
                    throw new Exception("No es posible obtener la cadena de conexión, asegurese de proporcionar los datos requeridos");
                }

                //return "Server=" + _Servidor + "," + _Puerto.ToString() + ";Database=" + _BaseDeDatos + ";User ID=" + _Usuario + ";Password=" + _Clave + ";Trusted_Connection=True";
                return "Server=" + _Servidor + ";Database=" + _BaseDeDatos + ";User ID=" + _Usuario + ";Password=" + _Clave + ";Trusted_Connection=True";
            }

            return _CadCon;
        }

        /// <Cierra la conexión abierta a la Base de Datos>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        public void CerrarConexion()
        {
            try
            {
                if (ExisteTransaccion())
                {
                    CancelarTransaccion();
                    sqlTrn.Dispose();
                }

                if (ExisteConexion())
                {
                    sqlCon.Close();
                    sqlCon.Dispose();
                }

                sqlCon = null;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        /// <Ejecuta el comando de la transacción en la Base de Datos>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <param name="strQuery"></param>
        /// <returns></returns>
        public object ObtenerEscalar(string strQuery)
        {
            if (!ExisteConexion())
            {
                throw new Exception("No existe ninguna conexión abierta.");
            }

            SqlCommand sqlCmd;

            if (ExisteTransaccion())
            {
                sqlCmd = new SqlCommand(strQuery, sqlCon, sqlTrn);
            }
            else
            {
                sqlCmd = new SqlCommand(strQuery, sqlCon);
            }

            return sqlCmd.ExecuteScalar();
        }

        /// <Ejecuta proceso almacenado>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <param name="strQuery"></param>
        /// <returns></returns>
        public int EjecutarComando(string strQuery)
        {
            if (!ExisteConexion())
            {
                throw new Exception("No existe ninguna conexión abierta.");
            }

            SqlCommand sqlCmd;

            if (ExisteTransaccion())
            {
                sqlCmd = new SqlCommand(strQuery, sqlCon, sqlTrn);
            }
            else
            {
                sqlCmd = new SqlCommand(strQuery, sqlCon);
            }

            return sqlCmd.ExecuteNonQuery();
        }

        /// <Ejecuta comando para obtener una tabla a traves de un Query>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <param name="strQuery"></param>
        /// <returns></returns>
        public DataTable ObtenerTabla(string strQuery)
        {
            if (!ExisteConexion())
            {
                throw new Exception("No existe ninguna conexión abierta.");
            }

            try
            {
                SqlCommand sqlCmd;

                if (ExisteTransaccion())
                {
                    sqlCmd = new SqlCommand(strQuery, sqlCon, sqlTrn);
                }
                else
                {
                    sqlCmd = new SqlCommand(strQuery, sqlCon);
                }

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                DataSet oDs = new DataSet("Tabla");
                sqlDa.Fill(oDs);

                return oDs.Tables[0];
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        /// <Ejecuta comando para obtener un DataSet a traves de un Query>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <param name="strQuery"></param>
        /// <returns></returns>
        public DataSet ObtenerDataSet(string strQuery)
        {
            if (!ExisteConexion())
            {
                throw new Exception("No existe ninguna conexión abierta.");
            }

            try
            {
                SqlCommand sqlCmd;

                if (ExisteTransaccion())
                {
                    sqlCmd = new SqlCommand(strQuery, sqlCon, sqlTrn);
                }
                else
                {
                    sqlCmd = new SqlCommand(strQuery, sqlCon);
                }

                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                DataSet oDs = new DataSet("Tabla");
                sqlDa.Fill(oDs);

                return oDs;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        /// <Ejecuta comando para iniciar la transacción>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        public void IniciarTransaccion()
        {
            if (ExisteTransaccion())
            {
                throw new Exception("Ya se ha iniciado la transacción.");
            }

            try
            {
                sqlTrn = sqlCon.BeginTransaction();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        /// <Ejectutar confirmar Transacción>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        public void CometerTransaccion()
        {
            if (!ExisteTransaccion())
            {
                throw new Exception("Aun no se ha iniciado ninguna transacción.");
            }

            try
            {
                sqlTrn.Commit();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        /// <Ejecuta la regresión de la Transacción>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        public void CancelarTransaccion()
        {
            if (!ExisteTransaccion())
            {
                throw new Exception("Aun no se ha iniciado ninguna transacción.");
            }

            try
            {
                sqlTrn.Rollback();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }

        /// <Verifica si hay transacción en ejecución>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <returns></returns>
        public bool ExisteTransaccion()
        {
            return sqlTrn != null && sqlTrn.Connection != null;
        }

        /// <Verifica si Existe conexión abierta>
        /// Modificación: FMC 02/11/2022
        /// </summary>
        /// <returns></returns>
        public bool ExisteConexion()
        {
            return sqlCon != null && sqlCon.State != ConnectionState.Closed;
        }

        #endregion
    }
}
