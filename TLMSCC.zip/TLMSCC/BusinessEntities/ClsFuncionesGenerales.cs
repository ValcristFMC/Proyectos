﻿using BusinessEntities.Clientes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BusinessEntities
{
    public class ClsFuncionesGenerales
    {
        /// <Convierte archivo csv a tabla>
        /// Creación: 03/12/2024
        /// </summary>
        /// <param name="strFilePath"></param>
        /// <returns></returns>
        public DataTable ConvertCSVtoDataTable(string strFilePath)
        {
            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(strFilePath))
            {
                string[] headers = sr.ReadLine().Split(',');
                foreach (string header in headers)
                {
                    dt.Columns.Add(header);
                }
                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine().Split(',');
                    DataRow dr = dt.NewRow();
                    for (int i = 0; i < headers.Length; i++)
                    {
                        dr[i] = rows[i];
                    }
                    dt.Rows.Add(dr);
                }
            }
            return dt;
        }

        /// <Convierte archivo csv a tabla>
        /// Creación: 03/12/2024
        /// </summary>
        /// <param name="strFilePath"></param>
        /// <returns></returns>
        public DataTable ConvertCSVtoDataTableSinHeaders(string strFilePath, Type Tipo)
        {
            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(strFilePath))
            {
                dt = CreateDataTable(Tipo);
                string[] headers = sr.ReadLine().Split(',');
                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine().Split(',');
                    DataRow dr = dt.NewRow();
                    for (int i = 0; i < headers.Length; i++)
                    {
                        dr[i] = rows[i];
                    }
                    dt.Rows.Add(dr);
                }
            }
            return dt;
        }

        /// <Verifica los datos del RFC>
        /// Creación: FMC 02/10/2022 
        /// </summary>
        /// <param name="RFC"></param>
        /// <param name="FisicaMoral"></param>
        /// <returns></returns>
        public ClsRFC RFCFisicaMoral(string RFC, bool FisicaMoral)
        {
            int PersonaMoral = 3;
            int PersonaFisica = 4;
            int contador = 1;
            char[] Letras = RFC.ToCharArray(0, RFC.Length);
            string resultado = string.Empty;
            string digitos = string.Empty;
            string caracteres = string.Empty;
            Regex ValN = new Regex(@"[0-9]");
            ClsRFC RFCFM = new ClsRFC();

            try
            {
                foreach (char letra in Letras)
                {
                    if (contador <= PersonaMoral && FisicaMoral)
                    {
                        resultado = resultado + letra;
                        contador++;

                        if (resultado.Length == 3)
                        {
                            if (!ValN.IsMatch(resultado))
                            {
                                continue;
                            }
                            else
                            {
                                throw new Exception("RFC Persona Moral Error: El formato no Coincide en las primeras 3 letas");
                            }
                        }

                        continue;
                    }
                    else
                    {
                        if (contador <= PersonaFisica && !FisicaMoral)
                        {
                            resultado = resultado + letra;
                            contador++;

                            if (resultado.Length == 4)
                            {
                                if (!ValN.IsMatch(resultado))
                                {
                                    continue;
                                }
                                else
                                {
                                    throw new Exception("RFC Persona Física Error: El formato no Coincide en las primeras 4 letas");
                                }
                            }

                            continue;
                        }
                    }

                    if (contador > PersonaMoral && contador <= Letras.Length - 3)
                    {
                        digitos = digitos + letra;
                        contador++;

                        if (digitos.Length == 6)
                        {
                            int result;

                            if (int.TryParse(digitos, out result))
                            {
                                continue;
                            }
                            else
                            {
                                throw new Exception("RFC Persona " + (FisicaMoral ? "Moral " : "Física ") + "Error: El formato no Coincide en los 6 valores númericos");
                            }
                        }

                        continue;
                    }

                    if (contador > Letras.Length - 3)
                    {
                        caracteres = caracteres + letra;
                        contador++;

                        if (caracteres.Length == 3)
                        {
                            foreach (char carcater in caracteres)
                            {
                                if (Char.IsLetterOrDigit(carcater))
                                {
                                    continue;
                                }
                                else
                                {
                                    throw new Exception("RFC Persona " + (FisicaMoral ? "Moral " : "Física ") + "Error: el formato no Coincide en los 3 últimos valores");
                                }
                            }
                        }

                        continue;
                    }
                }

                RFCFM.letras = resultado;
                RFCFM.digitos = Int32.Parse(digitos);
                RFCFM.alfanumericos = caracteres;
                RFCFM.tipo = ((resultado + digitos + caracteres).Length == 12 ? "Moral" : (resultado + digitos + caracteres).Length == 13 ? "Física" : "Incorrecto");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return RFCFM;
        }

        /// <Obtiene la descripcion del enum>
        /// Creación: FMC 02/10/2022
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public string GetEnumDescription(Enum value)
        {
            try
            {
                FieldInfo fi = value.GetType().GetField(value.ToString());

                DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attributes != null && attributes.Length > 0)
                {
                    return attributes[0].Description;
                }
                else
                {
                    return value.ToString();
                }
            }
            catch (Exception x)
            {
                throw new Exception(x.Message);
            }
        }

        /// <Obtiene el valor de un Enum por su descripción>
        /// Creación: FMC 02/10/2022
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="description"></param>
        /// <returns></returns>
        public T GetEnumValueFromEnumDescription<T>(string description)
        {
            var type = typeof(T);

            if (!type.IsEnum)
            {
                throw new ArgumentException();
            }

            FieldInfo[] fields = type.GetFields();

            var field = fields.SelectMany(f => f.GetCustomAttributes(typeof(DescriptionAttribute), false), (f, a) => new { Field = f, Att = a }).Where(a => ((DescriptionAttribute)a.Att).Description == description).SingleOrDefault();

            return field == null ? default(T) : (T)field.Field.GetRawConstantValue();
        }

        /// <Convertir Tabla a Lista>
        /// Creación: FMC 02/10/2022
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public List<T> ConvertToList<T>(DataTable dt)
        {
            List<T> data = new List<T>();

            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }

            return data;
        }

        /// <Convierte el Elemento de una tabla en Tipo de dato>
        /// Creación: FMC 02/10/2022
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dr"></param>
        /// <returns></returns>
        public T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            try
            {
                foreach (DataColumn column in dr.Table.Columns)
                {
                    foreach (PropertyInfo pro in temp.GetProperties())
                    {
                        if (pro.Name == column.ColumnName)
                        {
                            if (dr[column.ColumnName] == System.DBNull.Value)
                            {
                                continue;
                            }
                            else
                            {
                                if (pro.PropertyType.Name == "Char")
                                {
                                    char C = new char();
                                    C = char.Parse(dr[column.ColumnName].ToString());
                                    pro.SetValue(obj, C, null);
                                    break;
                                }
                                if (pro.PropertyType.Name == "Single")
                                {
                                    Single S = new Single();
                                    S = Convert.ToSingle(dr[column.ColumnName].ToString());
                                    pro.SetValue(obj, S, null);
                                    break;
                                }
                                else
                                {
                                    pro.SetValue(obj, dr[column.ColumnName], null);
                                    break;
                                }
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                }

                return obj;
            }
            catch (Exception x)
            {
                throw new Exception("Fallo la conversion a lista: " + x.Message);
            }
        }

        /// <Convertir Lista a Tabla>
        /// Creacion: FMC 02/10/2022
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        public DataTable ConvertToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();

            foreach (PropertyDescriptor prop in properties)
            {
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }

            foreach (T item in data)
            {
                DataRow row = table.NewRow();

                foreach (PropertyDescriptor prop in properties)
                {
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                }

                table.Rows.Add(row);
            }

            return table;
        }

        /// <Convierte un objeto simple a una tabla>
        /// Creación: FMC 02/10/2022
        /// </summary>
        /// <param name="Tipo"></param>
        /// <returns></returns>
        public DataTable CreateDataTable(Type Tipo)
        {
            DataTable return_Datatable = new DataTable();

            foreach (PropertyInfo info in Tipo.GetProperties())
            {
                return_Datatable.Columns.Add(new DataColumn(info.Name, info.PropertyType));
            }

            return return_Datatable;
        }

        /// <Controla un evento cuando oprime una tecla si el valor es numerico>
        /// Creación: FMC 02/10/2022
        /// </summary>
        /// <param name="evento"></param>
        /// <returns></returns>
        public KeyPressEventArgs SoloNumeros(KeyPressEventArgs evento)
        {
            if (Char.IsDigit(evento.KeyChar))
            {
                evento.Handled = false;
            }
            else if (Char.IsControl(evento.KeyChar))
            {
                evento.Handled = false;
            }
            else if (Char.IsSeparator(evento.KeyChar))
            {
                evento.Handled = false;
            }
            else
            {
                evento.Handled = true;
            }

            return evento;
        }

        /// <Controla un evento cuando oprime una tecla si el valor es letra>
        /// Creación: FMC 02/10/2022
        /// </summary>
        /// <param name="evento"></param>
        /// <returns></returns>
        public KeyPressEventArgs SoloLetras(KeyPressEventArgs evento)
        {
            if (Char.IsDigit(evento.KeyChar))
            {
                evento.Handled = true;
            }
            else if (Char.IsControl(evento.KeyChar))
            {
                evento.Handled = false;
            }
            else if (Char.IsSeparator(evento.KeyChar))
            {
                evento.Handled = false;
            }
            else if (Char.IsLetter(evento.KeyChar))
            {
                evento.Handled = false;
            }

            return evento;
        }

        /// <Valida un correo electronico y vera si es valido o no>
        /// Creación: FMC 02/10/2022
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public bool ValidarCorreoElectrónico(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                /* NormalizationForm el Dominio */
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));

                /* Examina la parte del dominio del correo y lo normaliza */
                string DomainMapper(Match match)
                {
                    /* Usa la clase IdnMapping para convertirlo en un nombre de dominio Unicode */
                    var idn = new IdnMapping();

                    /* Extrae y procesa el nombre de dominio (arroja ArgumentException en no válido) */
                    string domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                var i = e;
                return false;
            }
            catch (ArgumentException e)
            {
                var i = e;
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }
    }
}
