﻿using BusinessEntities;
using BusinessEntities.Clientes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Directorio;
using BusinessEntities.Directorio;

namespace DataAccess.Clientes
{
    public class ClsClientesDA
    {
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsConexion clsSql = new ClsConexion(ClsAcceso.Servidor, ClsAcceso.Puerto, ClsAcceso.DB, ClsAcceso.Usuario, ClsAcceso.Contraseña);
        private string Error = string.Empty;

        public List<ClsClientes> GuardarCliente(ClsClientes Cliente, ClsDirecciones Direccion)
        {
            try
            {
                List<ClsClientes> ListaDatos = new List<ClsClientes>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_GuardarCliente", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Nombre", Cliente.Nombre);
                cmd.Parameters.AddWithValue("@ApellidoPaterno", Cliente.ApellidoPaterno);
                cmd.Parameters.AddWithValue("@ApellidoMaterno", Cliente.ApellidoMaterno);
                cmd.Parameters.AddWithValue("@RFC", Cliente.RFC);
                cmd.Parameters.AddWithValue("@CP", Direccion.CP);
                cmd.Parameters.AddWithValue("@Estado", Direccion.Estado);
                cmd.Parameters.AddWithValue("@Localidad", Direccion.Localidad);
                cmd.Parameters.AddWithValue("@Municipio", Direccion.Municipio);
                cmd.Parameters.AddWithValue("@Colonia", Direccion.Colonia);
                cmd.Parameters.AddWithValue("@Calle", Direccion.Calle);
                cmd.Parameters.AddWithValue("@NumeroInterior", Direccion.NoInterior);
                cmd.Parameters.AddWithValue("@NumeroExterior", Direccion.NoExterior);
                cmd.Parameters.AddWithValue("@Telefono", Cliente.Telefono);
                cmd.Parameters.AddWithValue("@CorreoElectronico", Cliente.CorreoElectronico);
                cmd.Parameters.AddWithValue("@Usuario", Cliente.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsClientes>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }

        public List<ClsClientes> ConsultaListaCliente(ClsClientes Cliente, bool Todos)
        {
            try
            {
                List<ClsClientes> ListaDatos = new List<ClsClientes>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ConsultarCliente", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idCliente", Cliente.idCliente);
                cmd.Parameters.AddWithValue("@Nombre", Cliente.Nombre);
                cmd.Parameters.AddWithValue("@RFC", Cliente.RFC);
                cmd.Parameters.AddWithValue("@Todos", @Todos);
                cmd.Parameters.AddWithValue("@Usuario", Cliente.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsClientes>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }

        public List<ClsClientes> ActualizarCliente(ClsClientes Cliente, bool Datos, ClsDirecciones Direccion)
        {
            try
            {
                List<ClsClientes> ListaDatos = new List<ClsClientes>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ActualizarCliente", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idCliente", Cliente.idCliente);
                cmd.Parameters.AddWithValue("@Estatus", Cliente.Estatus);
                cmd.Parameters.AddWithValue("@Nombre", Cliente.Nombre);
                cmd.Parameters.AddWithValue("@ApellidoPaterno", Cliente.ApellidoPaterno);
                cmd.Parameters.AddWithValue("@ApellidoMaterno", Cliente.ApellidoMaterno);
                cmd.Parameters.AddWithValue("@RFC", Cliente.RFC);
                cmd.Parameters.AddWithValue("@CP", Direccion.CP);
                cmd.Parameters.AddWithValue("@Estado", Direccion.Estado);
                cmd.Parameters.AddWithValue("@Localidad", Direccion.Localidad);
                cmd.Parameters.AddWithValue("@Municipio", Direccion.Municipio);
                cmd.Parameters.AddWithValue("@Colonia", Direccion.Colonia);
                cmd.Parameters.AddWithValue("@Calle", Direccion.Calle);
                cmd.Parameters.AddWithValue("@NumeroInterior", Direccion.NoInterior);
                cmd.Parameters.AddWithValue("@NumeroExterior", Direccion.NoExterior);
                cmd.Parameters.AddWithValue("@Telefono", Cliente.Telefono);
                cmd.Parameters.AddWithValue("@Datos", true);
                cmd.Parameters.AddWithValue("@CorreoElectronico", Cliente.CorreoElectronico);
                cmd.Parameters.AddWithValue("@Usuario", Cliente.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsClientes>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }

        public List<ClsClientes> ConsultaListaClienteDetalles(ClsClientes Cliente)
        {
            try
            {
                List<ClsClientes> ListaDatos = new List<ClsClientes>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ConsultarClienteDetalles", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Estatus", Cliente.Estatus);
                cmd.Parameters.AddWithValue("@Usuario", Cliente.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsClientes>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }
    }
}
