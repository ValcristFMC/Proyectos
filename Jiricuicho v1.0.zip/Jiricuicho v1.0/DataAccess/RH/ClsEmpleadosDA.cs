﻿using BusinessEntities;
using BusinessEntities.Inventario;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntities.RH;
using BusinessEntities.Directorio;

namespace DataAccess.RH
{
    public class ClsEmpleadosDA
    {
        #region Variables

        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsConexion clsSql = new ClsConexion(ClsAcceso.Servidor, ClsAcceso.Puerto, ClsAcceso.DB, ClsAcceso.Usuario, ClsAcceso.Contraseña);
        private string Error = string.Empty;

        #endregion

        #region Métodos

        public DataTable GuardarEmpleado(ClsEmpleado Empleado, ClsUsuario Usuario, List<ClsPermiso> ListaPermiso, ClsDirecciones Direccion)
        {
            try
            {
                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_GuardarEmpleado", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                cmd.Parameters.AddWithValue("@Clave", Empleado.Clave);
                cmd.Parameters.AddWithValue("@idPuesto", Empleado.idPuesto);
                cmd.Parameters.AddWithValue("@Estatus", Empleado.Estatus);
                cmd.Parameters.AddWithValue("@Nombre", Empleado.Nombre);
                cmd.Parameters.AddWithValue("@ApellidoPaterno", Empleado.ApellidoPaterno);
                cmd.Parameters.AddWithValue("@ApellidoMaterno", Empleado.ApellidoMaterno);
                cmd.Parameters.AddWithValue("@Telefono", Empleado.Telefono);
                cmd.Parameters.AddWithValue("@CorreoElectronico", Empleado.CorreoElectronico);
                cmd.Parameters.AddWithValue("@FechaIngreso", Empleado.FechaIngreso);
                cmd.Parameters.AddWithValue("@NSS", Empleado.NSS);
                cmd.Parameters.AddWithValue("@RFC", Empleado.RFC);
                cmd.Parameters.AddWithValue("@Nomina", Empleado.Nomina);
                cmd.Parameters.AddWithValue("@ClaveBancaria", Empleado.ClaveBancaria);
                cmd.Parameters.AddWithValue("@Banco", Empleado.Banco);
                cmd.Parameters.AddWithValue("@Usuario", Empleado.Usuario);
                cmd.Parameters.AddWithValue("@Fiscal", Direccion.Fiscal);
                cmd.Parameters.AddWithValue("@CP", Direccion.CP);
                cmd.Parameters.AddWithValue("@Estado", Direccion.Estado);
                cmd.Parameters.AddWithValue("@Municipio", Direccion.Municipio);
                cmd.Parameters.AddWithValue("@Calle", Direccion.Calle);
                cmd.Parameters.AddWithValue("@NumeroInt", Direccion.NoInterior);
                cmd.Parameters.AddWithValue("@NumeroExt", Direccion.NoExterior);
                cmd.Parameters.AddWithValue("@Colonia", Direccion.Colonia);
                cmd.Parameters.AddWithValue("@Ciudad", Direccion.Ciudad);
                cmd.Parameters.AddWithValue("@Pais", Direccion.Pais);
                cmd.Parameters.AddWithValue("@EstatusUsuario", Usuario.Estatus);
                cmd.Parameters.AddWithValue("@Contraseña", Usuario.Contraseña);
                cmd.Parameters.AddWithValue("@NombreUsuario", Usuario.Usuario);
                
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    Usuario.idUsuario = int.Parse(dtTabla.Rows[0]["idUsuario"].ToString());
                    clsSql.CerrarConexion();
                }

                foreach (ClsPermiso Permiso in ListaPermiso)
                {
                    dtTabla = new DataTable();
                    clsSql.AbrirConexion();
                    cmd = new SqlCommand("dbo.usp_GuardarPermisoUsuario", clsSql.sqlCon);
                    cmd.CommandType = CommandType.StoredProcedure;
                    sqlDa = new SqlDataAdapter(cmd);
                    cmd.Parameters.AddWithValue("@idPermiso", Permiso.idPermiso);
                    cmd.Parameters.AddWithValue("@idUsuario", Usuario.idUsuario);
                    sqlDa.Fill(dtTabla);

                    if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                    {
                        Error =
                        dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                        dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                        dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                        dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                        dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                        dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                        dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                        dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                        dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                        clsSql.CerrarConexion();
                        throw new Exception(Error);
                    }
                    else
                    {
                        clsSql.CerrarConexion();
                    }
                }

                return dtTabla;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }

        #endregion
    }
}
