﻿using BusinessEntities;
using BusinessEntities.Entidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess.Directorio
{
    public class ClsDirectorio
    {
        #region Variables

        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsConexion clsSql = new ClsConexion(ClsAcceso.Servidor, ClsAcceso.Puerto, ClsAcceso.DB, ClsAcceso.Usuario, ClsAcceso.Contraseña);
        private string Error = string.Empty;

        #endregion

        #region Métodos

        public List<ClsCodigosPostales> ConsultaCodigoPostal(string CodigoPostal, string Usuario)
        {
            try
            {
                List<ClsCodigosPostales> ListaDatos = new List<ClsCodigosPostales>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_Consulta_Codigo_Postal", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CodigoPostal", CodigoPostal);
                cmd.Parameters.AddWithValue("@Usuario", Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsCodigosPostales>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }

        public List<ClsColonias> ConsultaListaColonias(string CodigoPostal, string Usuario)
        {
            try
            {
                List<ClsColonias> ListaDatos = new List<ClsColonias>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ConsultaColonias", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CodigoPostal", CodigoPostal);
                cmd.Parameters.AddWithValue("@Usuario", Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsColonias>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }

        public List<ClsEstados> ConsultaListaEstados(string Estado, string Usuario)
        {
            try
            {
                List<ClsEstados> ListaDatos = new List<ClsEstados>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ConsultaEstados", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Estado", Estado);
                cmd.Parameters.AddWithValue("@Usuario", Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsEstados>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }

        public List<ClsLocalidades> ConsultaListaLocalidades(string Estado, string Localidad, string Usuario)
        {
            try
            {
                List<ClsLocalidades> ListaDatos = new List<ClsLocalidades>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ConsultaLocalidades", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Estado", Estado);
                cmd.Parameters.AddWithValue("@Localidad", Localidad);
                cmd.Parameters.AddWithValue("@Usuario", Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsLocalidades>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }

        public List<ClsMunicipios> ConsultaListaMunicipios(string Estado, string Descripcion, string Usuario)
        {
            try
            {
                List<ClsMunicipios> ListaDatos = new List<ClsMunicipios>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ConsultaMunicipios", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Estado", Estado);
                cmd.Parameters.AddWithValue("@Descripcion", Descripcion);
                cmd.Parameters.AddWithValue("@Usuario", Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsMunicipios>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception ErrorDB)
            {
                throw new Exception(ErrorDB.Message);
            }
        }

        #endregion
    }
}