﻿using BusinessEntities;
using BusinessEntities.Clientes;
using BusinessEntities.Inventario;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Inventario
{
    public class ClsMateriaPrimaDA
    {
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsConexion clsSql = new ClsConexion(ClsAcceso.Servidor, ClsAcceso.Puerto, ClsAcceso.DB, ClsAcceso.Usuario, ClsAcceso.Contraseña);
        private string Error = string.Empty;

        public List<ClsMateriaPrimaBE> ConsultarMateriaPrima(ClsMateriaPrimaBE MateriaPrima)
        {
            try
            {
                List<ClsMateriaPrimaBE> ListaDatos = new List<ClsMateriaPrimaBE>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ConsultarMateriaPrima", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Nombre", MateriaPrima.Nombre);
                cmd.Parameters.AddWithValue("@Estatus", MateriaPrima.Estatus);
                cmd.Parameters.AddWithValue("@Usuario", MateriaPrima.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsMateriaPrimaBE>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception Error)
            {
                throw new Exception(Error.Message);
            }
        }

        public List<ClsMateriaPrimaBE> GuardarMateriaPrima(ClsMateriaPrimaBE MateriaPrima)
        {
            try
            {
                List<ClsMateriaPrimaBE> ListaDatos = new List<ClsMateriaPrimaBE>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_GuardarMateriaPrima", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Estatus", MateriaPrima.Estatus);
                cmd.Parameters.AddWithValue("@Nombre", MateriaPrima.Nombre);
                cmd.Parameters.AddWithValue("@Descripcion", MateriaPrima.Descripcion);
                cmd.Parameters.AddWithValue("@Clave", MateriaPrima.Clave);
                cmd.Parameters.AddWithValue("@FechaAlta", MateriaPrima.FechaAlta);
                cmd.Parameters.AddWithValue("@idTipo", MateriaPrima.idTipo);
                cmd.Parameters.AddWithValue("@Cantidad", MateriaPrima.Cantidad);
                cmd.Parameters.AddWithValue("@Caducidad", MateriaPrima.Caducidad);
                cmd.Parameters.AddWithValue("@Precio", MateriaPrima.Precio);
                if (MateriaPrima.Caducidad)
                {
                    cmd.Parameters.AddWithValue("@FechaCaducidad", MateriaPrima.FechaCaducidad);
                }
                cmd.Parameters.AddWithValue("@Usuario", MateriaPrima.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsMateriaPrimaBE>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception Error)
            {
                throw new Exception(Error.Message);
            }
        }

        public List<ClsMateriaPrimaBE> ModificarMateriaPrima(ClsMateriaPrimaBE MateriaPrima)
        {
            try
            {
                List<ClsMateriaPrimaBE> ListaDatos = new List<ClsMateriaPrimaBE>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ModificarMateriaPrima", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idMateriaPrima", MateriaPrima.idMateriaPrima);
                cmd.Parameters.AddWithValue("@Estatus", MateriaPrima.Estatus);
                cmd.Parameters.AddWithValue("@Nombre", MateriaPrima.Nombre);
                cmd.Parameters.AddWithValue("@Descripcion", MateriaPrima.Descripcion);
                cmd.Parameters.AddWithValue("@Clave", MateriaPrima.Clave);
                cmd.Parameters.AddWithValue("@idTipo", MateriaPrima.idTipo);
                cmd.Parameters.AddWithValue("@Cantidad", MateriaPrima.Cantidad);
                cmd.Parameters.AddWithValue("@Caducidad", MateriaPrima.Caducidad);
                cmd.Parameters.AddWithValue("@Precio", MateriaPrima.Precio);
                if (MateriaPrima.Caducidad)
                {
                    cmd.Parameters.AddWithValue("@FechaCaducidad", MateriaPrima.FechaCaducidad);
                }
                cmd.Parameters.AddWithValue("@Usuario", MateriaPrima.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsMateriaPrimaBE>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception Error)
            {
                throw new Exception(Error.Message);
            }
        }
    }
}
