﻿using BusinessEntities.Inventario;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntities;

namespace DataAccess.Inventario
{
    public class ClsConsumiblesDA
    {
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsConexion clsSql = new ClsConexion(ClsAcceso.Servidor, ClsAcceso.Puerto, ClsAcceso.DB, ClsAcceso.Usuario, ClsAcceso.Contraseña);
        private string Error = string.Empty;

        public List<ClsConsumiblesBE> ConsultarConsumible(ClsConsumiblesBE Consumibles)
        {
            try
            {
                List<ClsConsumiblesBE> ListaDatos = new List<ClsConsumiblesBE>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ConsultarConsumible", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Descripcion", Consumibles.Descripcion);
                cmd.Parameters.AddWithValue("@Estatus", Consumibles.Estatus);
                cmd.Parameters.AddWithValue("@Usuario", Consumibles.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsConsumiblesBE>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception Error)
            {
                throw new Exception(Error.Message);
            }
        }

        public List<ClsConsumiblesBE> GuardarConsumible(ClsConsumiblesBE Consumibles)
        {
            try
            {
                List<ClsConsumiblesBE> ListaDatos = new List<ClsConsumiblesBE>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_GuardarConsumible", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Estatus", Consumibles.Estatus);
                cmd.Parameters.AddWithValue("@Cantidad", Consumibles.Cantidad);
                cmd.Parameters.AddWithValue("@Clave", Consumibles.Clave);
                cmd.Parameters.AddWithValue("@Descripcion", Consumibles.Descripcion);
                cmd.Parameters.AddWithValue("@FechaAlta", Consumibles.FechaAlta);
                cmd.Parameters.AddWithValue("@idTipo", Consumibles.idTipo);
                cmd.Parameters.AddWithValue("@Usuario", Consumibles.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsConsumiblesBE>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception Error)
            {
                throw new Exception(Error.Message);
            }
        }

        public List<ClsConsumiblesBE> ModificarConsumible(ClsConsumiblesBE Consumibles)
        {
            try
            {
                List<ClsConsumiblesBE> ListaDatos = new List<ClsConsumiblesBE>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ModificarConsumible", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idConsumible", Consumibles.idConsumibles);
                cmd.Parameters.AddWithValue("@Estatus", Consumibles.Estatus);
                cmd.Parameters.AddWithValue("@Cantidad", Consumibles.Cantidad);
                cmd.Parameters.AddWithValue("@Clave", Consumibles.Clave);
                cmd.Parameters.AddWithValue("@Descripcion", Consumibles.Descripcion);
                cmd.Parameters.AddWithValue("@FechaModificacion", Consumibles.FechaModificacion);
                cmd.Parameters.AddWithValue("@idTipo", Consumibles.idTipo);
                cmd.Parameters.AddWithValue("@Usuario", Consumibles.Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsConsumiblesBE>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception Error)
            {
                throw new Exception(Error.Message);
            }
        }
    }
}
