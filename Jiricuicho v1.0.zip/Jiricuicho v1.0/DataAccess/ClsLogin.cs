﻿using BusinessEntities.Inventario;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntities;
using BusinessEntities.RH;

namespace DataAccess
{
    public class ClsLogin
    {
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsConexion clsSql = new ClsConexion(ClsAcceso.Servidor, ClsAcceso.Puerto, ClsAcceso.DB, ClsAcceso.Usuario, ClsAcceso.Contraseña);
        private string Error = string.Empty;

        public List<ClsUsuario> ConsultarUsuario(string Usuario, bool Estatus)
        {
            try
            {
                List<ClsUsuario> ListaDatos = new List<ClsUsuario>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_ConsultarUsuario", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Estatus", Estatus);
                cmd.Parameters.AddWithValue("@Usuario", Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsUsuario>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception Error)
            {
                throw new Exception(Error.Message);
            }
        }

        public List<ClsUsuario> VerificaSesion(string Usuario, string Contraseña)
        {
            try
            {
                List<ClsUsuario> ListaDatos = new List<ClsUsuario>();

                DataTable dtTabla = new DataTable();
                clsSql.AbrirConexion();
                SqlCommand cmd = new SqlCommand("dbo.usp_VerificaSesion", clsSql.sqlCon);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Contraseña", Contraseña);
                cmd.Parameters.AddWithValue("@Usuario", Usuario);
                SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                sqlDa.Fill(dtTabla);

                if (dtTabla.Columns[0].ColumnName == "ErrorNumber")
                {
                    Error =
                    dtTabla.Columns[0].ColumnName + " " + dtTabla.Rows[0][0].ToString() + " " +
                    dtTabla.Columns[1].ColumnName + " " + dtTabla.Rows[0][1].ToString() + " " +
                    dtTabla.Columns[2].ColumnName + " " + dtTabla.Rows[0][2].ToString() + " " +
                    dtTabla.Columns[3].ColumnName + " " + dtTabla.Rows[0][3].ToString() + " " +
                    dtTabla.Columns[4].ColumnName + " " + dtTabla.Rows[0][4].ToString() + " " +
                    dtTabla.Columns[5].ColumnName + " " + dtTabla.Rows[0][5].ToString() + " " +
                    dtTabla.Columns[6].ColumnName + " " + dtTabla.Rows[0][6].ToString() + " " +
                    dtTabla.Columns[7].ColumnName + " " + dtTabla.Rows[0][7].ToString() + " " +
                    dtTabla.Columns[8].ColumnName + " " + dtTabla.Rows[0][8].ToString();
                    clsSql.CerrarConexion();
                    throw new Exception(Error);
                }
                else
                {
                    ListaDatos = Funciones.ConvertToList<ClsUsuario>(dtTabla);
                    clsSql.CerrarConexion();
                }

                return ListaDatos;
            }
            catch (Exception Error)
            {
                throw new Exception(Error.Message);
            }
        }
    }
}
