using BusinessEntities.RH;
using DataAccess;
using Jiricuicho.Clientes;
using Jiricuicho.Inventario;
using Jiricuicho.RH;

namespace Jiricuicho
{
    public partial class Jiricuicho : Form
    {
        #region Variables y Constantes

        private bool Sesion = false;
        ClsUsuario Usuario = new ClsUsuario();
        private ClsLogin Login = new ClsLogin();

        #endregion

        #region Funciones del Formulario

        public Jiricuicho(ClsUsuario Usu)
        {
            Usuario = Usu;
            InitializeComponent();
            Sesion = true;
        }

        private void VerificaSesion(bool Estatus)
        {
            try
            {
                Usuario = Login.VerificaSesion(Usuario.Usuario, Usuario.Contrase�a)[0];
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void MostrarError(string strErr)
        {
            MessageBox.Show(strErr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        #endregion

        #region Eventos

        private void tsmBodegaAltas_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Bodega";
                lblNombreAccion.ForeColor = Color.Green;
                lblNombreAccion.Text = "Alta";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusBodega Alta = new cusBodega('A', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Alta);
                Alta.AutoSize = true;
                Alta.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmBodegaExistencias_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Bodega";
                lblNombreAccion.ForeColor = Color.Blue;
                lblNombreAccion.Text = "Consulta";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusBodega Consulta = new cusBodega('C', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Consulta);
                Consulta.AutoSize = true;
                Consulta.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmBodegaBajas_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Bodega";
                lblNombreAccion.ForeColor = Color.Red;
                lblNombreAccion.Text = "Baja";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusBodega Baja = new cusBodega('B', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Baja);
                Baja.AutoSize = true;
                Baja.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmMateriaPrimaAltas_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Materia Prima";
                lblNombreAccion.ForeColor = Color.Green;
                lblNombreAccion.Text = "Alta";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusMateriaPrima Alta = new cusMateriaPrima('A', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Alta);
                Alta.AutoSize = true;
                Alta.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmMateriaPrimaConsumo_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Materia Prima";
                lblNombreAccion.ForeColor = Color.Red;
                lblNombreAccion.Text = "Modificar";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusMateriaPrima Baja = new cusMateriaPrima('B', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Baja);
                Baja.AutoSize = true;
                Baja.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmMateriaPrimaCostos_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Materia Prima";
                lblNombreAccion.ForeColor = Color.Blue;
                lblNombreAccion.Text = "Consulta";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusMateriaPrima Consulta = new cusMateriaPrima('C', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Consulta);
                Consulta.AutoSize = true;
                Consulta.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmConsumiblesAlta_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Consumibles";
                lblNombreAccion.ForeColor = Color.Green;
                lblNombreAccion.Text = "Alta";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusConsumibles Alta = new cusConsumibles('A', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Alta);
                Alta.AutoSize = true;
                Alta.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmConsumiblesExistencias_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Consumibles";
                lblNombreAccion.ForeColor = Color.Green;
                lblNombreAccion.Text = "Existencias";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusConsumibles Consulta = new cusConsumibles('B', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Consulta);
                Consulta.AutoSize = true;
                Consulta.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmInmueblesPropios_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Inmuebles Altas";
                lblNombreAccion.ForeColor = Color.Green;
                lblNombreAccion.Text = "Administraci�n";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusInmuebles Propios = new cusInmuebles('A', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Propios);
                Propios.AutoSize = true;
                Propios.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmInmueblesRentados_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Inmuebles Cambios";
                lblNombreAccion.ForeColor = Color.Green;
                lblNombreAccion.Text = "Administraci�n";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusInmuebles Rentados = new cusInmuebles('B', Usuario);
                spcJiricuicho.Panel2.Controls.Add(Rentados);
                Rentados.AutoSize = true;
                Rentados.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmInventarioServicios_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Servicios";
                lblNombreAccion.ForeColor = Color.Green;
                lblNombreAccion.Text = "Administraci�n";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusServicios Administacion = new cusServicios(Usuario);
                spcJiricuicho.Panel2.Controls.Add(Administacion);
                Administacion.AutoSize = true;
                Administacion.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Clientes";
                lblNombreAccion.ForeColor = Color.Green;
                lblNombreAccion.Text = "Administraci�n";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusClientes Clientes = new cusClientes(Usuario);
                spcJiricuicho.Panel2.Controls.Add(Clientes);
                Clientes.AutoSize = true;
                Clientes.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void tsmEmpleados_Click(object sender, EventArgs e)
        {
            try
            {
                lblNombreMenu.Text = "Empleados";
                lblNombreAccion.ForeColor = Color.Green;
                lblNombreAccion.Text = "Alta";
                lblNombreUsuario.Text = Usuario.Usuario;
                spcJiricuicho.Panel2.Controls.Clear();
                cusEmpleados Empleados = new cusEmpleados(Usuario);
                spcJiricuicho.Panel2.Controls.Add(Empleados);
                Empleados.AutoSize = true;
                Empleados.Dock = DockStyle.Fill;
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void Jiricuicho_FormClosing(object sender, FormClosingEventArgs e)
        {
            VerificaSesion(!Sesion);
            Application.Exit();
        }

        #endregion
    }
}