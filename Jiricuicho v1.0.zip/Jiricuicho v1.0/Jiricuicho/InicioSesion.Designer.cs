﻿namespace Jiricuicho
{
    partial class InicioSesion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnEntrar = new Button();
            btnCancelar = new Button();
            lblUsuario = new Label();
            lblContraseña = new Label();
            txbUsuario = new TextBox();
            txbContraseña = new TextBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnEntrar
            // 
            btnEntrar.Location = new Point(269, 70);
            btnEntrar.Name = "btnEntrar";
            btnEntrar.Size = new Size(69, 44);
            btnEntrar.TabIndex = 0;
            btnEntrar.Text = "Entrar";
            btnEntrar.UseVisualStyleBackColor = true;
            btnEntrar.Click += btnEntrar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(350, 70);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(69, 44);
            btnCancelar.TabIndex = 1;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Location = new Point(192, 15);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(47, 15);
            lblUsuario.TabIndex = 2;
            lblUsuario.Text = "Usuario";
            // 
            // lblContraseña
            // 
            lblContraseña.AutoSize = true;
            lblContraseña.Location = new Point(192, 49);
            lblContraseña.Name = "lblContraseña";
            lblContraseña.Size = new Size(67, 15);
            lblContraseña.TabIndex = 3;
            lblContraseña.Text = "Contraseña";
            // 
            // txbUsuario
            // 
            txbUsuario.Location = new Point(269, 12);
            txbUsuario.Name = "txbUsuario";
            txbUsuario.Size = new Size(150, 23);
            txbUsuario.TabIndex = 4;
            // 
            // txbContraseña
            // 
            txbContraseña.Location = new Point(269, 41);
            txbContraseña.MaxLength = 8;
            txbContraseña.Name = "txbContraseña";
            txbContraseña.PasswordChar = '*';
            txbContraseña.Size = new Size(150, 23);
            txbContraseña.TabIndex = 5;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.logo_cerveza;
            pictureBox1.Location = new Point(2, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(185, 110);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // InicioSesion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(435, 120);
            Controls.Add(pictureBox1);
            Controls.Add(txbContraseña);
            Controls.Add(txbUsuario);
            Controls.Add(lblContraseña);
            Controls.Add(lblUsuario);
            Controls.Add(btnCancelar);
            Controls.Add(btnEntrar);
            Name = "InicioSesion";
            Text = "Iniciar Sesión";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnEntrar;
        private Button btnCancelar;
        private Label lblUsuario;
        private Label lblContraseña;
        private TextBox txbUsuario;
        private TextBox txbContraseña;
        private PictureBox pictureBox1;
    }
}