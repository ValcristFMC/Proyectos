﻿namespace Jiricuicho.Inventario
{
    partial class cusBodega
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            ddlMateriaPrima = new ComboBox();
            ddlConsumible = new ComboBox();
            lblMateriaPrima = new Label();
            lblConsumible = new Label();
            lblInmueble = new Label();
            txbNumBodega = new TextBox();
            cbxEstatus = new CheckBox();
            txbDescripcion = new TextBox();
            txbClave = new TextBox();
            lblNoBodega = new Label();
            lblDescripcion = new Label();
            lblClave = new Label();
            ddlInmueble = new ComboBox();
            spcBodega = new SplitContainer();
            btnCancelar = new Button();
            btnGuardar = new Button();
            dgvBodegaAlta = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)spcBodega).BeginInit();
            spcBodega.Panel1.SuspendLayout();
            spcBodega.Panel2.SuspendLayout();
            spcBodega.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvBodegaAlta).BeginInit();
            SuspendLayout();
            // 
            // ddlMateriaPrima
            // 
            ddlMateriaPrima.FormattingEnabled = true;
            ddlMateriaPrima.Location = new Point(110, 6);
            ddlMateriaPrima.Name = "ddlMateriaPrima";
            ddlMateriaPrima.Size = new Size(165, 23);
            ddlMateriaPrima.TabIndex = 1;
            // 
            // ddlConsumible
            // 
            ddlConsumible.FormattingEnabled = true;
            ddlConsumible.Location = new Point(110, 44);
            ddlConsumible.Name = "ddlConsumible";
            ddlConsumible.Size = new Size(165, 23);
            ddlConsumible.TabIndex = 2;
            // 
            // lblMateriaPrima
            // 
            lblMateriaPrima.AutoSize = true;
            lblMateriaPrima.Location = new Point(12, 9);
            lblMateriaPrima.Name = "lblMateriaPrima";
            lblMateriaPrima.Size = new Size(81, 15);
            lblMateriaPrima.TabIndex = 3;
            lblMateriaPrima.Text = "Materia Prima";
            // 
            // lblConsumible
            // 
            lblConsumible.AutoSize = true;
            lblConsumible.Location = new Point(12, 47);
            lblConsumible.Name = "lblConsumible";
            lblConsumible.Size = new Size(71, 15);
            lblConsumible.TabIndex = 4;
            lblConsumible.Text = "Consumible";
            // 
            // lblInmueble
            // 
            lblInmueble.AutoSize = true;
            lblInmueble.Location = new Point(12, 85);
            lblInmueble.Name = "lblInmueble";
            lblInmueble.Size = new Size(57, 15);
            lblInmueble.TabIndex = 5;
            lblInmueble.Text = "Inmueble";
            // 
            // txbNumBodega
            // 
            txbNumBodega.Location = new Point(110, 120);
            txbNumBodega.Name = "txbNumBodega";
            txbNumBodega.Size = new Size(32, 23);
            txbNumBodega.TabIndex = 6;
            // 
            // cbxEstatus
            // 
            cbxEstatus.AutoSize = true;
            cbxEstatus.Location = new Point(423, 10);
            cbxEstatus.Name = "cbxEstatus";
            cbxEstatus.Size = new Size(72, 19);
            cbxEstatus.TabIndex = 7;
            cbxEstatus.Text = "Agotado";
            cbxEstatus.UseVisualStyleBackColor = true;
            // 
            // txbDescripcion
            // 
            txbDescripcion.Location = new Point(356, 44);
            txbDescripcion.Multiline = true;
            txbDescripcion.Name = "txbDescripcion";
            txbDescripcion.Size = new Size(229, 61);
            txbDescripcion.TabIndex = 8;
            // 
            // txbClave
            // 
            txbClave.Location = new Point(356, 120);
            txbClave.Name = "txbClave";
            txbClave.Size = new Size(67, 23);
            txbClave.TabIndex = 9;
            // 
            // lblNoBodega
            // 
            lblNoBodega.AutoSize = true;
            lblNoBodega.Location = new Point(12, 123);
            lblNoBodega.Name = "lblNoBodega";
            lblNoBodega.Size = new Size(80, 15);
            lblNoBodega.TabIndex = 10;
            lblNoBodega.Text = "Nª de Bodega";
            // 
            // lblDescripcion
            // 
            lblDescripcion.AutoSize = true;
            lblDescripcion.Location = new Point(281, 47);
            lblDescripcion.Name = "lblDescripcion";
            lblDescripcion.Size = new Size(69, 15);
            lblDescripcion.TabIndex = 11;
            lblDescripcion.Text = "Descripciòn";
            // 
            // lblClave
            // 
            lblClave.AutoSize = true;
            lblClave.Location = new Point(281, 123);
            lblClave.Name = "lblClave";
            lblClave.Size = new Size(36, 15);
            lblClave.TabIndex = 12;
            lblClave.Text = "Clave";
            // 
            // ddlInmueble
            // 
            ddlInmueble.FormattingEnabled = true;
            ddlInmueble.Location = new Point(110, 82);
            ddlInmueble.Name = "ddlInmueble";
            ddlInmueble.Size = new Size(165, 23);
            ddlInmueble.TabIndex = 13;
            // 
            // spcBodega
            // 
            spcBodega.Dock = DockStyle.Fill;
            spcBodega.Location = new Point(0, 0);
            spcBodega.Name = "spcBodega";
            spcBodega.Orientation = Orientation.Horizontal;
            // 
            // spcBodega.Panel1
            // 
            spcBodega.Panel1.Controls.Add(btnCancelar);
            spcBodega.Panel1.Controls.Add(btnGuardar);
            spcBodega.Panel1.Controls.Add(lblMateriaPrima);
            spcBodega.Panel1.Controls.Add(ddlInmueble);
            spcBodega.Panel1.Controls.Add(ddlMateriaPrima);
            spcBodega.Panel1.Controls.Add(lblClave);
            spcBodega.Panel1.Controls.Add(ddlConsumible);
            spcBodega.Panel1.Controls.Add(lblDescripcion);
            spcBodega.Panel1.Controls.Add(lblConsumible);
            spcBodega.Panel1.Controls.Add(lblNoBodega);
            spcBodega.Panel1.Controls.Add(lblInmueble);
            spcBodega.Panel1.Controls.Add(txbClave);
            spcBodega.Panel1.Controls.Add(txbNumBodega);
            spcBodega.Panel1.Controls.Add(txbDescripcion);
            spcBodega.Panel1.Controls.Add(cbxEstatus);
            // 
            // spcBodega.Panel2
            // 
            spcBodega.Panel2.Controls.Add(dgvBodegaAlta);
            spcBodega.Size = new Size(600, 400);
            spcBodega.SplitterDistance = 156;
            spcBodega.TabIndex = 14;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(510, 119);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(75, 23);
            btnCancelar.TabIndex = 15;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(429, 119);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 14;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            // 
            // dgvBodegaAlta
            // 
            dgvBodegaAlta.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvBodegaAlta.Dock = DockStyle.Fill;
            dgvBodegaAlta.Location = new Point(0, 0);
            dgvBodegaAlta.Name = "dgvBodegaAlta";
            dgvBodegaAlta.RowTemplate.Height = 25;
            dgvBodegaAlta.Size = new Size(600, 240);
            dgvBodegaAlta.TabIndex = 0;
            // 
            // Bodega
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(spcBodega);
            Name = "Bodega";
            Size = new Size(600, 400);
            spcBodega.Panel1.ResumeLayout(false);
            spcBodega.Panel1.PerformLayout();
            spcBodega.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)spcBodega).EndInit();
            spcBodega.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvBodegaAlta).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private ComboBox ddlMateriaPrima;
        private ComboBox ddlConsumible;
        private Label lblMateriaPrima;
        private Label lblConsumible;
        private Label lblInmueble;
        private TextBox txbNumBodega;
        private CheckBox cbxEstatus;
        private TextBox txbDescripcion;
        private TextBox txbClave;
        private Label lblNoBodega;
        private Label lblDescripcion;
        private Label lblClave;
        private ComboBox ddlInmueble;
        private SplitContainer spcBodega;
        private DataGridView dgvBodegaAlta;
        private Button btnCancelar;
        private Button btnGuardar;
    }
}
