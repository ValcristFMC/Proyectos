﻿using BusinessEntities.Inventario;
using BusinessEntities;
using BusinessEntities.RH;
using DataAccess.Inventario;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jiricuicho.Inventario
{
    public partial class cusServicios : UserControl
    {
        #region Variables y Constantes

        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsUsuario Usuario = new ClsUsuario();
        private string Error = string.Empty;
        private int IndexDGV = 0;

        #endregion

        #region Funciones del Control
        public cusServicios(ClsUsuario usuario)
        {
            Usuario = usuario;
            InitializeComponent();
        }

        #endregion

        #region Eventos

        #endregion
    }
}
