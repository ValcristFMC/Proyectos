﻿namespace Jiricuicho.Inventario
{
    partial class cusServicios
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            spcServicios = new SplitContainer();
            cbxEstatus = new CheckBox();
            txbRFC = new TextBox();
            lblNombre = new Label();
            lblRFC = new Label();
            label3 = new Label();
            ddlRazonSocial = new ComboBox();
            lblCuentaBanco = new Label();
            lblBanco = new Label();
            txbCuentaBanco = new TextBox();
            ddlBanco = new ComboBox();
            btnGuardar = new Button();
            btnCancelar = new Button();
            dgvServicios = new DataGridView();
            cbxNombre = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)spcServicios).BeginInit();
            spcServicios.Panel1.SuspendLayout();
            spcServicios.Panel2.SuspendLayout();
            spcServicios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvServicios).BeginInit();
            SuspendLayout();
            // 
            // spcServicios
            // 
            spcServicios.Dock = DockStyle.Fill;
            spcServicios.Location = new Point(0, 0);
            spcServicios.Name = "spcServicios";
            spcServicios.Orientation = Orientation.Horizontal;
            // 
            // spcServicios.Panel1
            // 
            spcServicios.Panel1.Controls.Add(cbxNombre);
            spcServicios.Panel1.Controls.Add(btnCancelar);
            spcServicios.Panel1.Controls.Add(btnGuardar);
            spcServicios.Panel1.Controls.Add(ddlBanco);
            spcServicios.Panel1.Controls.Add(lblCuentaBanco);
            spcServicios.Panel1.Controls.Add(lblBanco);
            spcServicios.Panel1.Controls.Add(txbCuentaBanco);
            spcServicios.Panel1.Controls.Add(ddlRazonSocial);
            spcServicios.Panel1.Controls.Add(label3);
            spcServicios.Panel1.Controls.Add(lblRFC);
            spcServicios.Panel1.Controls.Add(lblNombre);
            spcServicios.Panel1.Controls.Add(txbRFC);
            spcServicios.Panel1.Controls.Add(cbxEstatus);
            // 
            // spcServicios.Panel2
            // 
            spcServicios.Panel2.Controls.Add(dgvServicios);
            spcServicios.Size = new Size(600, 400);
            spcServicios.SplitterDistance = 200;
            spcServicios.TabIndex = 0;
            // 
            // cbxEstatus
            // 
            cbxEstatus.AutoSize = true;
            cbxEstatus.Location = new Point(398, 46);
            cbxEstatus.Name = "cbxEstatus";
            cbxEstatus.Size = new Size(60, 19);
            cbxEstatus.TabIndex = 0;
            cbxEstatus.Text = "Activo";
            cbxEstatus.UseVisualStyleBackColor = true;
            // 
            // txbRFC
            // 
            txbRFC.Location = new Point(130, 44);
            txbRFC.Name = "txbRFC";
            txbRFC.Size = new Size(262, 23);
            txbRFC.TabIndex = 2;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(12, 9);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(51, 15);
            lblNombre.TabIndex = 4;
            lblNombre.Text = "Nombre";
            // 
            // lblRFC
            // 
            lblRFC.AutoSize = true;
            lblRFC.Location = new Point(12, 47);
            lblRFC.Name = "lblRFC";
            lblRFC.Size = new Size(28, 15);
            lblRFC.TabIndex = 5;
            lblRFC.Text = "RFC";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 85);
            label3.Name = "label3";
            label3.Size = new Size(73, 15);
            label3.TabIndex = 6;
            label3.Text = "Razón Social";
            // 
            // ddlRazonSocial
            // 
            ddlRazonSocial.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlRazonSocial.FormattingEnabled = true;
            ddlRazonSocial.Location = new Point(130, 82);
            ddlRazonSocial.Name = "ddlRazonSocial";
            ddlRazonSocial.Size = new Size(262, 23);
            ddlRazonSocial.TabIndex = 7;
            // 
            // lblCuentaBanco
            // 
            lblCuentaBanco.AutoSize = true;
            lblCuentaBanco.Location = new Point(12, 161);
            lblCuentaBanco.Name = "lblCuentaBanco";
            lblCuentaBanco.Size = new Size(81, 15);
            lblCuentaBanco.TabIndex = 11;
            lblCuentaBanco.Text = "Cuenta Banco";
            // 
            // lblBanco
            // 
            lblBanco.AutoSize = true;
            lblBanco.Location = new Point(12, 123);
            lblBanco.Name = "lblBanco";
            lblBanco.Size = new Size(40, 15);
            lblBanco.TabIndex = 10;
            lblBanco.Text = "Banco";
            // 
            // txbCuentaBanco
            // 
            txbCuentaBanco.Location = new Point(130, 158);
            txbCuentaBanco.Name = "txbCuentaBanco";
            txbCuentaBanco.Size = new Size(262, 23);
            txbCuentaBanco.TabIndex = 9;
            // 
            // ddlBanco
            // 
            ddlBanco.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlBanco.FormattingEnabled = true;
            ddlBanco.Location = new Point(130, 120);
            ddlBanco.Name = "ddlBanco";
            ddlBanco.Size = new Size(262, 23);
            ddlBanco.TabIndex = 12;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(398, 81);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 62);
            btnGuardar.TabIndex = 13;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(479, 81);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(75, 62);
            btnCancelar.TabIndex = 14;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            // 
            // dgvServicios
            // 
            dgvServicios.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvServicios.Dock = DockStyle.Fill;
            dgvServicios.Location = new Point(0, 0);
            dgvServicios.Name = "dgvServicios";
            dgvServicios.RowTemplate.Height = 25;
            dgvServicios.Size = new Size(600, 196);
            dgvServicios.TabIndex = 0;
            // 
            // cbxNombre
            // 
            cbxNombre.FormattingEnabled = true;
            cbxNombre.Location = new Point(130, 6);
            cbxNombre.Name = "cbxNombre";
            cbxNombre.Size = new Size(262, 23);
            cbxNombre.TabIndex = 15;
            // 
            // Servicios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(spcServicios);
            Name = "Servicios";
            Size = new Size(600, 400);
            spcServicios.Panel1.ResumeLayout(false);
            spcServicios.Panel1.PerformLayout();
            spcServicios.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)spcServicios).EndInit();
            spcServicios.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvServicios).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer spcServicios;
        private ComboBox ddlBanco;
        private Label lblCuentaBanco;
        private Label lblBanco;
        private TextBox txbCuentaBanco;
        private ComboBox ddlRazonSocial;
        private Label label3;
        private Label lblRFC;
        private Label lblNombre;
        private TextBox txbRFC;
        private CheckBox cbxEstatus;
        private Button btnCancelar;
        private Button btnGuardar;
        private DataGridView dgvServicios;
        private ComboBox cbxNombre;
    }
}
