﻿using BusinessEntities.Inventario;
using BusinessEntities;
using DataAccess.Inventario;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessEntities.RH;

namespace Jiricuicho.Inventario
{
    public partial class cusConsumibles : UserControl
    {
        #region Variables y Constantes

        private char Tipo;
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsConsumiblesBE Consumible = new ClsConsumiblesBE();
        private List<ClsConsumiblesBE> ListaConsumibles = new List<ClsConsumiblesBE>();
        private ClsConsumiblesDA ConsumiblesDA = new ClsConsumiblesDA();
        private ClsTipos Tipos = new ClsTipos();
        private ClsUsuario Usuario = new ClsUsuario();
        private ClsTiposDA TiposDA = new ClsTiposDA();
        private List<ClsTipos> ListaTipos = new List<ClsTipos>();
        private string Error = string.Empty;
        private int IndexDGV = 0;

        #endregion

        #region Funciones del Control

        public cusConsumibles(char tipo, BusinessEntities.RH.ClsUsuario usuario)
        {
            Usuario = usuario;
            Tipo = tipo;
            InitializeComponent();
            CargaInicial();
        }

        protected void CargaInicial()
        {
            try
            {
                ListaTipos = TiposDA.ConsultaListaTipos(Usuario.Usuario);
                ddlTipo.DataSource = ListaTipos;
                ddlTipo.DisplayMember = "Descripcion";
                ddlTipo.ValueMember = "idTipo";

                switch (Tipo)
                {
                    case 'A':
                        Consumible.Estatus = ckbEstatus.Checked;
                        LimpiarCampos();
                        break;

                    case 'B':
                        Consumible.Descripcion = txbDescripcion.Text;
                        Consumible.Estatus = ckbEstatus.Checked;
                        ListaConsumibles = ConsumiblesDA.ConsultarConsumible(Consumible);
                        dgvConsumibles.DataSource = ListaConsumibles;
                        btnGuardar.Text = "Modificar";
                        LimpiarCampos();
                        break;

                    case 'C':
                        Consumible.Descripcion = txbDescripcion.Text;
                        Consumible.Estatus = ckbEstatus.Checked;
                        btnGuardar.Text = "Consultar";
                        ckbEstatus.Enabled = false;
                        ddlTipo.Enabled = false;
                        txbCantidad.Enabled = false;
                        LimpiarCampos();
                        break;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void LimpiarCampos()
        {
            try
            {
                txbDescripcion.Text = string.Empty;
                txbClave.Text = string.Empty;
                txbCantidad.Text = string.Empty;
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void ValidaCampos()
        {
            try
            {
                if (txbCantidad.Text == string.Empty)
                {
                    throw new Exception("La cantidad no puede ir vacia");
                }

                if (double.Parse(txbCantidad.Text) == 0)
                {
                    throw new Exception("La cantidad no puede ser cero");
                }

                if (txbClave.Text == string.Empty)
                {
                    throw new Exception("La Clave no puede ir vacia");
                }

                if (txbDescripcion.Text == string.Empty)
                {
                    throw new Exception("La Descripción no puede ir vacia");
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void MostrarError(string strErr)
        {
            MessageBox.Show(strErr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        #endregion

        #region Eventos

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                Consumible.Usuario = Usuario.Usuario;

                switch (Tipo)
                {
                    case 'A':
                        ValidaCampos();
                        Consumible.Descripcion = txbDescripcion.Text;
                        Consumible.Clave = txbClave.Text;
                        Consumible.Cantidad = int.Parse(txbCantidad.Text);
                        Consumible.Estatus = ckbEstatus.Checked;
                        Consumible.idTipo = Convert.ToInt32(ddlTipo.SelectedValue.ToString());
                        Consumible.FechaAlta = DateTime.Now;
                        ListaConsumibles = ConsumiblesDA.GuardarConsumible(Consumible);
                        dgvConsumibles.DataSource = ListaConsumibles;
                        this.dgvConsumibles.Columns["idConsumibles"].Visible = false;
                        this.dgvConsumibles.Columns["FechaAlta"].Visible = false;
                        this.dgvConsumibles.Columns["FechaBaja"].Visible = false;
                        this.dgvConsumibles.Columns["FechaModificacion"].Visible = false;
                        this.dgvConsumibles.Columns["Usuario"].Visible = false;
                        this.dgvConsumibles.Columns["idTipo"].Visible = false;
                        LimpiarCampos();
                        break;
                    case 'B':
                        ValidaCampos();
                        Consumible.Descripcion = txbDescripcion.Text;
                        Consumible.Clave = txbClave.Text;
                        Consumible.Cantidad = int.Parse(txbCantidad.Text);
                        Consumible.Estatus = ckbEstatus.Checked;
                        Consumible.idTipo = Convert.ToInt32(ddlTipo.SelectedValue.ToString());
                        Consumible.FechaModificacion = DateTime.Now;
                        ListaConsumibles = ConsumiblesDA.ModificarConsumible(Consumible);
                        dgvConsumibles.DataSource = ListaConsumibles;
                        LimpiarCampos();
                        break;
                    case 'C':
                        Consumible.Descripcion = txbDescripcion.Text;
                        Consumible.Estatus = ckbEstatus.Checked;
                        ListaConsumibles = ConsumiblesDA.ConsultarConsumible(Consumible);
                        dgvConsumibles.DataSource = ListaConsumibles;
                        this.dgvConsumibles.Columns["idConsumibles"].Visible = false;
                        this.dgvConsumibles.Columns["FechaAlta"].Visible = false;
                        this.dgvConsumibles.Columns["FechaBaja"].Visible = false;
                        this.dgvConsumibles.Columns["FechaModificacion"].Visible = false;
                        this.dgvConsumibles.Columns["Usuario"].Visible = false;
                        this.dgvConsumibles.Columns["idTipo"].Visible = false;
                        break;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void ckbEstatus_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (ckbEstatus.Checked)
                {
                    ckbEstatus.Text = "Existencia";
                }
                else
                {
                    ckbEstatus.Text = "Agotado";
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloNumeros(e);

                if (e.KeyChar == '.')
                {
                    if (!txbCantidad.Text.Contains("."))
                    {
                        txbCantidad.Text = txbCantidad.Text + '.';
                        txbCantidad.Select(txbCantidad.Text.Length, 0);
                    }
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void dgvConsumibles_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                switch (Tipo)
                {
                    case 'B':
                        Consumible = (ClsConsumiblesBE)dgvConsumibles.Rows[e.RowIndex].DataBoundItem;
                        txbDescripcion.Text = Consumible.Descripcion;
                        txbClave.Text = Consumible.Clave;
                        txbCantidad.Text = Consumible.Cantidad.ToString();
                        ckbEstatus.Checked = Consumible.Estatus;
                        ddlTipo.SelectedValue = Consumible.idTipo;
                        break;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        #endregion
    }
}
