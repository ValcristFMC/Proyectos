﻿using BusinessEntities.RH;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jiricuicho.Inventario
{
    public partial class cusBodega : UserControl
    {
        #region Variables y Constantes 

        private char Tipo;
        private ClsUsuario Usuario = new ClsUsuario();

        #endregion

        #region Funciones del Control

        public cusBodega(char tipo, BusinessEntities.RH.ClsUsuario usuario)
        {
            Tipo = tipo;
            Usuario = usuario;
            InitializeComponent();
            Controles();
        }

        public void Controles()
        {
            try
            {
                //switch (Tipo)
                //{
                //    case : 'A';
                //}
            }
            catch(Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        #endregion

        #region Eventos

        #endregion
    }
}
