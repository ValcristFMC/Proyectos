﻿using BusinessEntities.Inventario;
using BusinessEntities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataAccess.Inventario;
using BusinessEntities.RH;

namespace Jiricuicho.Inventario
{
    public partial class cusMateriaPrima : UserControl
    {
        #region Variables y Constantes

        private char Tipo;
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsMateriaPrimaBE MateriaPrima = new ClsMateriaPrimaBE();
        private List<ClsMateriaPrimaBE> ListaMateriaPrima = new List<ClsMateriaPrimaBE>();
        private ClsMateriaPrimaDA MateriaPrimaDA = new ClsMateriaPrimaDA();
        private ClsTipos Tipos = new ClsTipos();
        private ClsTiposDA TiposDA = new ClsTiposDA();
        private List<ClsTipos> ListaTipos = new List<ClsTipos>();
        private ClsUsuario Usuario = new ClsUsuario();
        private string Error = string.Empty;
        private int IndexDGV = 0;

        #endregion

        #region Funciones del Control

        public cusMateriaPrima(char tipo, ClsUsuario usuario)
        {
            Usuario = usuario;
            Tipo = tipo;
            InitializeComponent();
            CargaInicial();
        }

        protected void CargaInicial()
        {
            try
            {
                ListaTipos = TiposDA.ConsultaListaTipos(Usuario.Usuario);
                ddlTipo.DataSource = ListaTipos;
                ddlTipo.DisplayMember = "Descripcion";
                ddlTipo.ValueMember = "idTipo";
                MateriaPrima.Usuario = Usuario.Usuario;

                switch (Tipo)
                {
                    case 'A':
                        MateriaPrima.Nombre = txbNombre.Text;
                        MateriaPrima.Estatus = ckbEstatus.Checked;
                        LimpiarCampos();
                        break;

                    case 'B':
                        MateriaPrima.Nombre = txbNombre.Text;
                        MateriaPrima.Estatus = ckbEstatus.Checked;
                        ListaMateriaPrima = MateriaPrimaDA.ConsultarMateriaPrima(MateriaPrima);
                        dgvMateriaPrima.DataSource = ListaMateriaPrima;
                        btnGuardar.Text = "Modificar";
                        LimpiarCampos();
                        break;

                    case 'C':
                        MateriaPrima.Nombre = txbNombre.Text;
                        MateriaPrima.Estatus = ckbEstatus.Checked;
                        btnGuardar.Text = "Consultar";
                        txbDescripcion.Enabled = false;
                        txbClave.Enabled = false;
                        txbCantidad.Enabled = false;
                        ddlTipo.Enabled = false;
                        txbPrecioPorUMD.Enabled = false;
                        ckbCaducidad.Enabled = false;
                        dtpFechaCaducidad.Enabled = false;
                        LimpiarCampos();
                        break;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void LimpiarCampos()
        {
            try
            {
                txbNombre.Text = string.Empty;
                txbDescripcion.Text = string.Empty;
                txbClave.Text = string.Empty;
                txbCantidad.Text = string.Empty;
                ddlTipo.SelectedIndex = 0;
                txbPrecioPorUMD.Text = string.Empty;
                dtpFechaCaducidad.Value = DateTime.Now;
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void ValidaCampos()
        {
            try
            {
                Error = string.Empty;

                if (txbNombre.Text == string.Empty)
                {
                    Error = Error + "El nombre no puede ir vacio /n";
                }

                if (txbDescripcion.Text == string.Empty)
                {
                    Error = Error + "La descripción es obligatoria /n";
                }

                if (txbClave.Text == string.Empty)
                {
                    Error = Error + "Incluya una Clave acorde al catálogo /n";
                }

                if (txbCantidad.Text == string.Empty)
                {
                    Error = Error + "Debe existir una cantidad con un tipo válido /n";
                }

                if (Error != string.Empty)
                {
                    throw new Exception(Error);
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void MostrarError(string strErr)
        {
            MessageBox.Show(strErr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        #endregion

        #region Eventos

        private void txbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloLetras(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbClave_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {

            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloNumeros(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void ckbCaducidad_CheckStateChanged(object sender, EventArgs e)
        {
            try
            {
                if (ckbCaducidad.Checked)
                {
                    dtpFechaCaducidad.Enabled = true;
                    dtpFechaCaducidad.Visible = true;
                }

                if (!ckbCaducidad.Checked)
                {
                    dtpFechaCaducidad.Enabled = false;
                    dtpFechaCaducidad.Visible = false;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void ddlTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                lblEquivalencia.Text = ListaTipos[ddlTipo.SelectedIndex].Equivalencia;
                lblSimbolo.Text = ListaTipos[ddlTipo.SelectedIndex].Simbolo;
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                MateriaPrima.Usuario = Usuario.Usuario;

                switch (Tipo)
                {
                    case 'A':
                        ValidaCampos();
                        MateriaPrima.Nombre = txbNombre.Text;
                        MateriaPrima.Descripcion = txbDescripcion.Text;
                        MateriaPrima.Clave = txbClave.Text;
                        MateriaPrima.Caducidad = ckbCaducidad.Checked;
                        MateriaPrima.Cantidad = int.Parse(txbCantidad.Text);
                        MateriaPrima.Estatus = ckbEstatus.Checked;
                        MateriaPrima.idTipo = Convert.ToInt32(ddlTipo.SelectedValue.ToString());
                        MateriaPrima.FechaAlta = DateTime.Now;
                        MateriaPrima.FechaCaducidad = dtpFechaCaducidad.Value;
                        MateriaPrima.Precio = double.Parse(txbPrecioPorUMD.Text);
                        ListaMateriaPrima = MateriaPrimaDA.GuardarMateriaPrima(MateriaPrima);
                        dgvMateriaPrima.DataSource = ListaMateriaPrima;
                        this.dgvMateriaPrima.Columns["idMateriaPrima"].Visible = false;
                        this.dgvMateriaPrima.Columns["FechaAlta"].Visible = false;
                        this.dgvMateriaPrima.Columns["FechaBaja"].Visible = false;
                        this.dgvMateriaPrima.Columns["FechaModificacion"].Visible = false;
                        this.dgvMateriaPrima.Columns["Usuario"].Visible = false;
                        this.dgvMateriaPrima.Columns["idTipo"].Visible = false;
                        LimpiarCampos();
                        break;
                    case 'B':
                        ValidaCampos();
                        MateriaPrima.Nombre = txbNombre.Text;
                        MateriaPrima.Descripcion = txbDescripcion.Text;
                        MateriaPrima.Clave = txbClave.Text;
                        MateriaPrima.Caducidad = ckbCaducidad.Checked;
                        MateriaPrima.Cantidad = int.Parse(txbCantidad.Text);
                        MateriaPrima.Estatus = ckbEstatus.Checked;
                        MateriaPrima.idTipo = Convert.ToInt32(ddlTipo.SelectedValue.ToString());
                        MateriaPrima.FechaAlta = MateriaPrima.FechaAlta;
                        MateriaPrima.FechaCaducidad = dtpFechaCaducidad.Value;
                        MateriaPrima.Precio = double.Parse(txbPrecioPorUMD.Text);
                        ListaMateriaPrima = MateriaPrimaDA.ModificarMateriaPrima(MateriaPrima);
                        dgvMateriaPrima.DataSource = ListaMateriaPrima;
                        LimpiarCampos();
                        break;
                    case 'C':
                        MateriaPrima.Nombre = txbNombre.Text;
                        MateriaPrima.Estatus = ckbEstatus.Checked;
                        ListaMateriaPrima = MateriaPrimaDA.ConsultarMateriaPrima(MateriaPrima);
                        dgvMateriaPrima.DataSource = ListaMateriaPrima;
                        this.dgvMateriaPrima.Columns["idMateriaPrima"].Visible = false;
                        this.dgvMateriaPrima.Columns["FechaAlta"].Visible = false;
                        this.dgvMateriaPrima.Columns["FechaBaja"].Visible = false;
                        this.dgvMateriaPrima.Columns["FechaModificacion"].Visible = false;
                        this.dgvMateriaPrima.Columns["Usuario"].Visible = false;
                        this.dgvMateriaPrima.Columns["idTipo"].Visible = false;
                        break;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void ckbEstatus_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (ckbEstatus.Checked)
                {
                    ckbEstatus.Text = "Existencia";
                }
                else
                {
                    ckbEstatus.Text = "Agotado";
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloLetras(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbCostoPorTipo_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloNumeros(e);

                if (e.KeyChar == '.')
                {
                    if (!txbPrecioPorUMD.Text.Contains("."))
                    {
                        txbPrecioPorUMD.Text = txbPrecioPorUMD.Text + '.';
                        txbPrecioPorUMD.Select(txbPrecioPorUMD.Text.Length, 0);
                    }
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void dgvMateriaPrima_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                switch (Tipo)
                {
                    case 'B':
                        MateriaPrima = (ClsMateriaPrimaBE)dgvMateriaPrima.Rows[e.RowIndex].DataBoundItem;
                        txbNombre.Text = MateriaPrima.Nombre;
                        txbDescripcion.Text = MateriaPrima.Descripcion;
                        txbClave.Text = MateriaPrima.Clave;
                        ckbCaducidad.Checked = MateriaPrima.Caducidad;
                        txbCantidad.Text = MateriaPrima.Cantidad.ToString();
                        ckbEstatus.Checked = MateriaPrima.Estatus;
                        ddlTipo.SelectedValue = MateriaPrima.idTipo;
                        txbPrecioPorUMD.Text = MateriaPrima.Precio.ToString();
                        if (MateriaPrima.FechaCaducidad.ToShortDateString() != "01/01/0001")
                        {
                            dtpFechaCaducidad.Value = MateriaPrima.FechaCaducidad;
                        }
                        break;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        #endregion
    }
}
