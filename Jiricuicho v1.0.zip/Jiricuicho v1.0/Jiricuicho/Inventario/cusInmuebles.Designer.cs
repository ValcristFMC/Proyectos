﻿namespace Jiricuicho.Inventario
{
    partial class cusInmuebles
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            spcInmuebles = new SplitContainer();
            btnGuardar = new Button();
            btnCancelar = new Button();
            lblClave = new Label();
            txbClave = new TextBox();
            txbDescripcion = new TextBox();
            lblDescripcion = new Label();
            ckbEstatus = new CheckBox();
            dgvInmuebles = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)spcInmuebles).BeginInit();
            spcInmuebles.Panel1.SuspendLayout();
            spcInmuebles.Panel2.SuspendLayout();
            spcInmuebles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvInmuebles).BeginInit();
            SuspendLayout();
            // 
            // spcInmuebles
            // 
            spcInmuebles.Dock = DockStyle.Fill;
            spcInmuebles.Location = new Point(0, 0);
            spcInmuebles.Name = "spcInmuebles";
            // 
            // spcInmuebles.Panel1
            // 
            spcInmuebles.Panel1.Controls.Add(btnGuardar);
            spcInmuebles.Panel1.Controls.Add(btnCancelar);
            spcInmuebles.Panel1.Controls.Add(lblClave);
            spcInmuebles.Panel1.Controls.Add(txbClave);
            spcInmuebles.Panel1.Controls.Add(txbDescripcion);
            spcInmuebles.Panel1.Controls.Add(lblDescripcion);
            spcInmuebles.Panel1.Controls.Add(ckbEstatus);
            // 
            // spcInmuebles.Panel2
            // 
            spcInmuebles.Panel2.Controls.Add(dgvInmuebles);
            spcInmuebles.Size = new Size(600, 400);
            spcInmuebles.SplitterDistance = 239;
            spcInmuebles.TabIndex = 0;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(21, 282);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 21;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(143, 282);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(75, 23);
            btnCancelar.TabIndex = 20;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            // 
            // lblClave
            // 
            lblClave.AutoSize = true;
            lblClave.Location = new Point(12, 247);
            lblClave.Name = "lblClave";
            lblClave.Size = new Size(36, 15);
            lblClave.TabIndex = 19;
            lblClave.Text = "Clave";
            // 
            // txbClave
            // 
            txbClave.Location = new Point(99, 244);
            txbClave.MaxLength = 8;
            txbClave.Name = "txbClave";
            txbClave.Size = new Size(128, 23);
            txbClave.TabIndex = 18;
            // 
            // txbDescripcion
            // 
            txbDescripcion.Location = new Point(12, 152);
            txbDescripcion.Multiline = true;
            txbDescripcion.Name = "txbDescripcion";
            txbDescripcion.Size = new Size(215, 81);
            txbDescripcion.TabIndex = 17;
            // 
            // lblDescripcion
            // 
            lblDescripcion.AutoSize = true;
            lblDescripcion.Location = new Point(12, 125);
            lblDescripcion.Name = "lblDescripcion";
            lblDescripcion.Size = new Size(69, 15);
            lblDescripcion.TabIndex = 16;
            lblDescripcion.Text = "Descripciòn";
            // 
            // ckbEstatus
            // 
            ckbEstatus.AutoSize = true;
            ckbEstatus.Location = new Point(12, 94);
            ckbEstatus.Name = "ckbEstatus";
            ckbEstatus.Size = new Size(55, 19);
            ckbEstatus.TabIndex = 15;
            ckbEstatus.Text = "Existe";
            ckbEstatus.UseVisualStyleBackColor = true;
            ckbEstatus.CheckedChanged += ckbEstatus_CheckedChanged;
            // 
            // dgvInmuebles
            // 
            dgvInmuebles.AllowUserToAddRows = false;
            dgvInmuebles.AllowUserToDeleteRows = false;
            dgvInmuebles.AllowUserToOrderColumns = true;
            dgvInmuebles.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dgvInmuebles.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvInmuebles.Dock = DockStyle.Fill;
            dgvInmuebles.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvInmuebles.Location = new Point(0, 0);
            dgvInmuebles.MultiSelect = false;
            dgvInmuebles.Name = "dgvInmuebles";
            dgvInmuebles.RowTemplate.Height = 25;
            dgvInmuebles.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvInmuebles.Size = new Size(357, 400);
            dgvInmuebles.TabIndex = 0;
            dgvInmuebles.CellClick += dgvInmuebles_CellClick;
            // 
            // cusInmuebles
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(spcInmuebles);
            Name = "cusInmuebles";
            Size = new Size(600, 400);
            spcInmuebles.Panel1.ResumeLayout(false);
            spcInmuebles.Panel1.PerformLayout();
            spcInmuebles.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)spcInmuebles).EndInit();
            spcInmuebles.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvInmuebles).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer spcInmuebles;
        private DataGridView dgvInmuebles;
        private Label lblClave;
        private TextBox txbClave;
        private TextBox txbDescripcion;
        private Label lblDescripcion;
        private CheckBox ckbEstatus;
        private Button btnGuardar;
        private Button btnCancelar;
    }
}
