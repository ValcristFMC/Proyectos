﻿using BusinessEntities;
using BusinessEntities.Inventario;
using BusinessEntities.RH;
using DataAccess.Inventario;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jiricuicho.Inventario
{
    public partial class cusInmuebles : UserControl
    {
        #region Variables y Constantes

        private char Tipo;
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsInmueblesBE Inmueble = new ClsInmueblesBE();
        private List<ClsInmueblesBE> ListaInmueble = new List<ClsInmueblesBE>();
        private ClsInmueblesDA InmuebleDA = new ClsInmueblesDA();
        private ClsUsuario Usuario = new ClsUsuario();
        private string Error = string.Empty;
        private int IndexDGV = 0;

        #endregion

        #region Funciones del Control

        public cusInmuebles(char tipo, BusinessEntities.RH.ClsUsuario usuario)
        {
            Usuario = usuario;
            Tipo = tipo;
            InitializeComponent();
        }

        protected void CargaInicial()
        {
            try
            {
                switch (Tipo)
                {
                    case 'A':
                        Inmueble.Estatus = ckbEstatus.Checked;
                        LimpiarCampos();
                        break;

                    case 'B':
                        Inmueble.Descripcion = txbDescripcion.Text;
                        Inmueble.Estatus = ckbEstatus.Checked;
                        ListaInmueble = InmuebleDA.ConsultarInmueble(Inmueble);
                        dgvInmuebles.DataSource = ListaInmueble;
                        btnGuardar.Text = "Modificar";
                        LimpiarCampos();
                        break;

                    case 'C':
                        Inmueble.Descripcion = txbDescripcion.Text;
                        Inmueble.Estatus = ckbEstatus.Checked;
                        btnGuardar.Text = "Consultar";
                        ckbEstatus.Enabled = false;
                        txbDescripcion.Enabled = false;
                        txbClave.Enabled = false;
                        LimpiarCampos();
                        break;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void LimpiarCampos()
        {
            try
            {
                txbDescripcion.Text = string.Empty;
                txbClave.Text = string.Empty;
                ckbEstatus.Checked = false;
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void ValidaCampos()
        {
            try
            {
                if (txbClave.Text == string.Empty)
                {
                    throw new Exception("La Clave no puede ir vacia");
                }

                if (txbDescripcion.Text == string.Empty)
                {
                    throw new Exception("La Descripción no puede ir vacia");
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void MostrarError(string strErr)
        {
            MessageBox.Show(strErr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        #endregion

        #region Eventos

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                Inmueble.Usuario = Usuario.Usuario;

                switch (Tipo)
                {
                    case 'A':
                        ValidaCampos();
                        Inmueble.Descripcion = txbDescripcion.Text;
                        Inmueble.Clave = txbClave.Text;
                        Inmueble.Estatus = ckbEstatus.Checked;
                        Inmueble.FechaAlta = DateTime.Now;
                        ListaInmueble = InmuebleDA.GuardarInmueble(Inmueble);
                        dgvInmuebles.DataSource = ListaInmueble;
                        this.dgvInmuebles.Columns["idInmueble"].Visible = false;
                        this.dgvInmuebles.Columns["FechaAlta"].Visible = false;
                        this.dgvInmuebles.Columns["FechaBaja"].Visible = false;
                        this.dgvInmuebles.Columns["FechaModificacion"].Visible = false;
                        this.dgvInmuebles.Columns["Usuario"].Visible = false;
                        this.dgvInmuebles.Columns["idTipo"].Visible = false;
                        LimpiarCampos();
                        break;
                    case 'B':
                        ValidaCampos();
                        Inmueble.Descripcion = txbDescripcion.Text;
                        Inmueble.Clave = txbClave.Text;
                        Inmueble.Estatus = ckbEstatus.Checked;
                        Inmueble.FechaModificacion = DateTime.Now;
                        ListaInmueble = InmuebleDA.ModificarInmueble(Inmueble);
                        dgvInmuebles.DataSource = ListaInmueble;
                        LimpiarCampos();
                        break;
                    case 'C':
                        Inmueble.Descripcion = txbDescripcion.Text;
                        Inmueble.Estatus = ckbEstatus.Checked;
                        ListaInmueble = InmuebleDA.ConsultarInmueble(Inmueble);
                        dgvInmuebles.DataSource = ListaInmueble;
                        this.dgvInmuebles.Columns["idInmueble"].Visible = false;
                        this.dgvInmuebles.Columns["FechaAlta"].Visible = false;
                        this.dgvInmuebles.Columns["FechaBaja"].Visible = false;
                        this.dgvInmuebles.Columns["FechaModificacion"].Visible = false;
                        this.dgvInmuebles.Columns["Usuario"].Visible = false;
                        this.dgvInmuebles.Columns["idTipo"].Visible = false;
                        break;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void dgvInmuebles_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                switch (Tipo)
                {
                    case 'B':
                        Inmueble = (ClsInmueblesBE)dgvInmuebles.Rows[e.RowIndex].DataBoundItem;
                        txbDescripcion.Text = Inmueble.Descripcion;
                        txbClave.Text = Inmueble.Clave;
                        ckbEstatus.Checked = Inmueble.Estatus;
                        break;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void ckbEstatus_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (ckbEstatus.Checked)
                {
                    ckbEstatus.Text = "Existencia";
                }
                else
                {
                    ckbEstatus.Text = "Agotado";
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        #endregion
    }
}
