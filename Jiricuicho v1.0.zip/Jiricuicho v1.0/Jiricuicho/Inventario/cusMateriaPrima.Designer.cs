﻿namespace Jiricuicho.Inventario
{
    partial class cusMateriaPrima
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            spcMateriaPrima = new SplitContainer();
            lblCostoPorTipo = new Label();
            txbPrecioPorUMD = new TextBox();
            lblSimbolo = new Label();
            lblEquivalencia = new Label();
            txbNombre = new TextBox();
            lblNombre = new Label();
            btnGuardar = new Button();
            btnCancelar = new Button();
            dtpFechaCaducidad = new DateTimePicker();
            lblTipo = new Label();
            ddlTipo = new ComboBox();
            ckbCaducidad = new CheckBox();
            lblCantidad = new Label();
            lblClave = new Label();
            txbCantidad = new TextBox();
            txbClave = new TextBox();
            txbDescripcion = new TextBox();
            lblDescripcion = new Label();
            ckbEstatus = new CheckBox();
            dgvMateriaPrima = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)spcMateriaPrima).BeginInit();
            spcMateriaPrima.Panel1.SuspendLayout();
            spcMateriaPrima.Panel2.SuspendLayout();
            spcMateriaPrima.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvMateriaPrima).BeginInit();
            SuspendLayout();
            // 
            // spcMateriaPrima
            // 
            spcMateriaPrima.Dock = DockStyle.Fill;
            spcMateriaPrima.Location = new Point(0, 0);
            spcMateriaPrima.Name = "spcMateriaPrima";
            // 
            // spcMateriaPrima.Panel1
            // 
            spcMateriaPrima.Panel1.Controls.Add(lblCostoPorTipo);
            spcMateriaPrima.Panel1.Controls.Add(txbPrecioPorUMD);
            spcMateriaPrima.Panel1.Controls.Add(lblSimbolo);
            spcMateriaPrima.Panel1.Controls.Add(lblEquivalencia);
            spcMateriaPrima.Panel1.Controls.Add(txbNombre);
            spcMateriaPrima.Panel1.Controls.Add(lblNombre);
            spcMateriaPrima.Panel1.Controls.Add(btnGuardar);
            spcMateriaPrima.Panel1.Controls.Add(btnCancelar);
            spcMateriaPrima.Panel1.Controls.Add(dtpFechaCaducidad);
            spcMateriaPrima.Panel1.Controls.Add(lblTipo);
            spcMateriaPrima.Panel1.Controls.Add(ddlTipo);
            spcMateriaPrima.Panel1.Controls.Add(ckbCaducidad);
            spcMateriaPrima.Panel1.Controls.Add(lblCantidad);
            spcMateriaPrima.Panel1.Controls.Add(lblClave);
            spcMateriaPrima.Panel1.Controls.Add(txbCantidad);
            spcMateriaPrima.Panel1.Controls.Add(txbClave);
            spcMateriaPrima.Panel1.Controls.Add(txbDescripcion);
            spcMateriaPrima.Panel1.Controls.Add(lblDescripcion);
            spcMateriaPrima.Panel1.Controls.Add(ckbEstatus);
            // 
            // spcMateriaPrima.Panel2
            // 
            spcMateriaPrima.Panel2.Controls.Add(dgvMateriaPrima);
            spcMateriaPrima.Size = new Size(600, 400);
            spcMateriaPrima.SplitterDistance = 239;
            spcMateriaPrima.TabIndex = 0;
            // 
            // lblCostoPorTipo
            // 
            lblCostoPorTipo.AutoSize = true;
            lblCostoPorTipo.Location = new Point(3, 251);
            lblCostoPorTipo.Name = "lblCostoPorTipo";
            lblCostoPorTipo.Size = new Size(91, 15);
            lblCostoPorTipo.TabIndex = 28;
            lblCostoPorTipo.Text = "Precio por UDM";
            // 
            // txbPrecioPorUMD
            // 
            txbPrecioPorUMD.Location = new Point(100, 248);
            txbPrecioPorUMD.Name = "txbPrecioPorUMD";
            txbPrecioPorUMD.Size = new Size(137, 23);
            txbPrecioPorUMD.TabIndex = 6;
            txbPrecioPorUMD.KeyPress += txbCostoPorTipo_KeyPress;
            // 
            // lblSimbolo
            // 
            lblSimbolo.AutoSize = true;
            lblSimbolo.Location = new Point(100, 222);
            lblSimbolo.Name = "lblSimbolo";
            lblSimbolo.Size = new Size(0, 15);
            lblSimbolo.TabIndex = 26;
            // 
            // lblEquivalencia
            // 
            lblEquivalencia.AutoSize = true;
            lblEquivalencia.Location = new Point(12, 223);
            lblEquivalencia.Name = "lblEquivalencia";
            lblEquivalencia.Size = new Size(0, 15);
            lblEquivalencia.TabIndex = 25;
            // 
            // txbNombre
            // 
            txbNombre.Location = new Point(78, 45);
            txbNombre.Name = "txbNombre";
            txbNombre.Size = new Size(159, 23);
            txbNombre.TabIndex = 1;
            txbNombre.KeyPress += txbNombre_KeyPress;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(3, 48);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(51, 15);
            lblNombre.TabIndex = 23;
            lblNombre.Text = "Nombre";
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(21, 347);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 9;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(144, 347);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(75, 23);
            btnCancelar.TabIndex = 10;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // dtpFechaCaducidad
            // 
            dtpFechaCaducidad.Enabled = false;
            dtpFechaCaducidad.Location = new Point(3, 309);
            dtpFechaCaducidad.Name = "dtpFechaCaducidad";
            dtpFechaCaducidad.Size = new Size(234, 23);
            dtpFechaCaducidad.TabIndex = 8;
            dtpFechaCaducidad.Visible = false;
            // 
            // lblTipo
            // 
            lblTipo.AutoSize = true;
            lblTipo.Location = new Point(3, 193);
            lblTipo.Name = "lblTipo";
            lblTipo.Size = new Size(31, 15);
            lblTipo.TabIndex = 9;
            lblTipo.Text = "Tipo";
            // 
            // ddlTipo
            // 
            ddlTipo.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            ddlTipo.AutoCompleteSource = AutoCompleteSource.ListItems;
            ddlTipo.FormattingEnabled = true;
            ddlTipo.Location = new Point(78, 190);
            ddlTipo.Name = "ddlTipo";
            ddlTipo.Size = new Size(159, 23);
            ddlTipo.TabIndex = 5;
            ddlTipo.SelectedIndexChanged += ddlTipo_SelectedIndexChanged;
            // 
            // ckbCaducidad
            // 
            ckbCaducidad.AutoSize = true;
            ckbCaducidad.Location = new Point(3, 284);
            ckbCaducidad.Name = "ckbCaducidad";
            ckbCaducidad.Size = new Size(83, 19);
            ckbCaducidad.TabIndex = 7;
            ckbCaducidad.Text = "Caducidad";
            ckbCaducidad.UseVisualStyleBackColor = true;
            ckbCaducidad.CheckStateChanged += ckbCaducidad_CheckStateChanged;
            // 
            // lblCantidad
            // 
            lblCantidad.AutoSize = true;
            lblCantidad.Location = new Point(3, 164);
            lblCantidad.Name = "lblCantidad";
            lblCantidad.Size = new Size(55, 15);
            lblCantidad.TabIndex = 6;
            lblCantidad.Text = "Cantidad";
            // 
            // lblClave
            // 
            lblClave.AutoSize = true;
            lblClave.Location = new Point(3, 135);
            lblClave.Name = "lblClave";
            lblClave.Size = new Size(36, 15);
            lblClave.TabIndex = 5;
            lblClave.Text = "Clave";
            // 
            // txbCantidad
            // 
            txbCantidad.Location = new Point(78, 161);
            txbCantidad.Name = "txbCantidad";
            txbCantidad.Size = new Size(159, 23);
            txbCantidad.TabIndex = 4;
            txbCantidad.KeyPress += txbCantidad_KeyPress;
            // 
            // txbClave
            // 
            txbClave.Location = new Point(78, 135);
            txbClave.Name = "txbClave";
            txbClave.Size = new Size(159, 23);
            txbClave.TabIndex = 3;
            txbClave.KeyPress += txbClave_KeyPress;
            // 
            // txbDescripcion
            // 
            txbDescripcion.Location = new Point(78, 74);
            txbDescripcion.Multiline = true;
            txbDescripcion.Name = "txbDescripcion";
            txbDescripcion.Size = new Size(159, 55);
            txbDescripcion.TabIndex = 2;
            // 
            // lblDescripcion
            // 
            lblDescripcion.AutoSize = true;
            lblDescripcion.Location = new Point(3, 77);
            lblDescripcion.Name = "lblDescripcion";
            lblDescripcion.Size = new Size(69, 15);
            lblDescripcion.TabIndex = 1;
            lblDescripcion.Text = "Descripciòn";
            // 
            // ckbEstatus
            // 
            ckbEstatus.AutoSize = true;
            ckbEstatus.Location = new Point(100, 20);
            ckbEstatus.Name = "ckbEstatus";
            ckbEstatus.Size = new Size(72, 19);
            ckbEstatus.TabIndex = 0;
            ckbEstatus.Text = "Agotado";
            ckbEstatus.UseVisualStyleBackColor = true;
            ckbEstatus.CheckedChanged += ckbEstatus_CheckedChanged;
            // 
            // dgvMateriaPrima
            // 
            dgvMateriaPrima.AllowUserToAddRows = false;
            dgvMateriaPrima.AllowUserToDeleteRows = false;
            dgvMateriaPrima.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dgvMateriaPrima.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMateriaPrima.Dock = DockStyle.Fill;
            dgvMateriaPrima.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvMateriaPrima.Location = new Point(0, 0);
            dgvMateriaPrima.MultiSelect = false;
            dgvMateriaPrima.Name = "dgvMateriaPrima";
            dgvMateriaPrima.RowTemplate.Height = 25;
            dgvMateriaPrima.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvMateriaPrima.Size = new Size(357, 400);
            dgvMateriaPrima.TabIndex = 0;
            dgvMateriaPrima.CellClick += dgvMateriaPrima_CellClick;
            // 
            // cusMateriaPrima
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(spcMateriaPrima);
            Name = "cusMateriaPrima";
            Size = new Size(600, 400);
            spcMateriaPrima.Panel1.ResumeLayout(false);
            spcMateriaPrima.Panel1.PerformLayout();
            spcMateriaPrima.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)spcMateriaPrima).EndInit();
            spcMateriaPrima.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvMateriaPrima).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer spcMateriaPrima;
        private DateTimePicker dtpFechaCaducidad;
        private Label lblTipo;
        private ComboBox ddlTipo;
        private CheckBox ckbCaducidad;
        private Label lblCantidad;
        private Label lblClave;
        private TextBox txbCantidad;
        private TextBox txbClave;
        private TextBox txbDescripcion;
        private Label lblDescripcion;
        private CheckBox ckbEstatus;
        private DataGridView dgvMateriaPrima;
        private Button btnGuardar;
        private Button btnCancelar;
        private TextBox txbNombre;
        private Label lblNombre;
        private Label lblSimbolo;
        private Label lblEquivalencia;
        private Label lblCostoPorTipo;
        private TextBox txbPrecioPorUMD;
    }
}
