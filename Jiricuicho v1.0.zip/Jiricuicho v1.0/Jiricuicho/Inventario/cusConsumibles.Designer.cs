﻿namespace Jiricuicho.Inventario
{
    partial class cusConsumibles
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            spcConsumibles = new SplitContainer();
            btnGuardar = new Button();
            btnCancelar = new Button();
            lblTipo = new Label();
            ddlTipo = new ComboBox();
            lblCantidad = new Label();
            lblClave = new Label();
            txbCantidad = new TextBox();
            txbClave = new TextBox();
            txbDescripcion = new TextBox();
            lblDescripcion = new Label();
            ckbEstatus = new CheckBox();
            dgvConsumibles = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)spcConsumibles).BeginInit();
            spcConsumibles.Panel1.SuspendLayout();
            spcConsumibles.Panel2.SuspendLayout();
            spcConsumibles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvConsumibles).BeginInit();
            SuspendLayout();
            // 
            // spcConsumibles
            // 
            spcConsumibles.Dock = DockStyle.Fill;
            spcConsumibles.Location = new Point(0, 0);
            spcConsumibles.Name = "spcConsumibles";
            // 
            // spcConsumibles.Panel1
            // 
            spcConsumibles.Panel1.Controls.Add(btnGuardar);
            spcConsumibles.Panel1.Controls.Add(btnCancelar);
            spcConsumibles.Panel1.Controls.Add(lblTipo);
            spcConsumibles.Panel1.Controls.Add(ddlTipo);
            spcConsumibles.Panel1.Controls.Add(lblCantidad);
            spcConsumibles.Panel1.Controls.Add(lblClave);
            spcConsumibles.Panel1.Controls.Add(txbCantidad);
            spcConsumibles.Panel1.Controls.Add(txbClave);
            spcConsumibles.Panel1.Controls.Add(txbDescripcion);
            spcConsumibles.Panel1.Controls.Add(lblDescripcion);
            spcConsumibles.Panel1.Controls.Add(ckbEstatus);
            // 
            // spcConsumibles.Panel2
            // 
            spcConsumibles.Panel2.Controls.Add(dgvConsumibles);
            spcConsumibles.Size = new Size(600, 400);
            spcConsumibles.SplitterDistance = 239;
            spcConsumibles.TabIndex = 0;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(21, 313);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 5;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(143, 313);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(75, 23);
            btnCancelar.TabIndex = 6;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            // 
            // lblTipo
            // 
            lblTipo.AutoSize = true;
            lblTipo.Location = new Point(12, 278);
            lblTipo.Name = "lblTipo";
            lblTipo.Size = new Size(31, 15);
            lblTipo.TabIndex = 17;
            lblTipo.Text = "Tipo";
            // 
            // ddlTipo
            // 
            ddlTipo.FormattingEnabled = true;
            ddlTipo.Location = new Point(99, 275);
            ddlTipo.Name = "ddlTipo";
            ddlTipo.Size = new Size(128, 23);
            ddlTipo.TabIndex = 4;
            // 
            // lblCantidad
            // 
            lblCantidad.AutoSize = true;
            lblCantidad.Location = new Point(12, 240);
            lblCantidad.Name = "lblCantidad";
            lblCantidad.Size = new Size(55, 15);
            lblCantidad.TabIndex = 15;
            lblCantidad.Text = "Cantidad";
            // 
            // lblClave
            // 
            lblClave.AutoSize = true;
            lblClave.Location = new Point(12, 202);
            lblClave.Name = "lblClave";
            lblClave.Size = new Size(36, 15);
            lblClave.TabIndex = 14;
            lblClave.Text = "Clave";
            // 
            // txbCantidad
            // 
            txbCantidad.Location = new Point(99, 237);
            txbCantidad.Name = "txbCantidad";
            txbCantidad.Size = new Size(128, 23);
            txbCantidad.TabIndex = 3;
            txbCantidad.KeyPress += txbCantidad_KeyPress;
            // 
            // txbClave
            // 
            txbClave.Location = new Point(99, 199);
            txbClave.MaxLength = 8;
            txbClave.Name = "txbClave";
            txbClave.Size = new Size(128, 23);
            txbClave.TabIndex = 2;
            // 
            // txbDescripcion
            // 
            txbDescripcion.Location = new Point(12, 107);
            txbDescripcion.Multiline = true;
            txbDescripcion.Name = "txbDescripcion";
            txbDescripcion.Size = new Size(215, 81);
            txbDescripcion.TabIndex = 1;
            // 
            // lblDescripcion
            // 
            lblDescripcion.AutoSize = true;
            lblDescripcion.Location = new Point(12, 80);
            lblDescripcion.Name = "lblDescripcion";
            lblDescripcion.Size = new Size(69, 15);
            lblDescripcion.TabIndex = 10;
            lblDescripcion.Text = "Descripciòn";
            // 
            // ckbEstatus
            // 
            ckbEstatus.AutoSize = true;
            ckbEstatus.Location = new Point(12, 49);
            ckbEstatus.Name = "ckbEstatus";
            ckbEstatus.Size = new Size(72, 19);
            ckbEstatus.TabIndex = 0;
            ckbEstatus.Text = "Agotado";
            ckbEstatus.UseVisualStyleBackColor = true;
            ckbEstatus.CheckedChanged += ckbEstatus_CheckedChanged;
            // 
            // dgvConsumibles
            // 
            dgvConsumibles.AllowUserToAddRows = false;
            dgvConsumibles.AllowUserToDeleteRows = false;
            dgvConsumibles.AllowUserToOrderColumns = true;
            dgvConsumibles.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            dgvConsumibles.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvConsumibles.Dock = DockStyle.Fill;
            dgvConsumibles.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvConsumibles.Location = new Point(0, 0);
            dgvConsumibles.MultiSelect = false;
            dgvConsumibles.Name = "dgvConsumibles";
            dgvConsumibles.RowTemplate.Height = 25;
            dgvConsumibles.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvConsumibles.Size = new Size(357, 400);
            dgvConsumibles.TabIndex = 0;
            dgvConsumibles.CellClick += dgvConsumibles_CellClick;
            // 
            // cusConsumibles
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(spcConsumibles);
            Name = "cusConsumibles";
            Size = new Size(600, 400);
            spcConsumibles.Panel1.ResumeLayout(false);
            spcConsumibles.Panel1.PerformLayout();
            spcConsumibles.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)spcConsumibles).EndInit();
            spcConsumibles.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvConsumibles).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer spcConsumibles;
        private CheckBox ckbEstatus;
        private Label lblTipo;
        private ComboBox ddlTipo;
        private Label lblCantidad;
        private Label lblClave;
        private TextBox txbCantidad;
        private TextBox txbClave;
        private TextBox txbDescripcion;
        private Label lblDescripcion;
        private DataGridView dgvConsumibles;
        private Button btnGuardar;
        private Button btnCancelar;
    }
}
