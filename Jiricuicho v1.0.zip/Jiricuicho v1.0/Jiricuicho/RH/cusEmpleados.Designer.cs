﻿namespace Jiricuicho.RH
{
    partial class cusEmpleados
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            splitContainer1 = new SplitContainer();
            txbNomina = new TextBox();
            lblNomina = new Label();
            chbConsulta = new CheckBox();
            txbClave = new TextBox();
            lblClave = new Label();
            txbIdEmpleado = new TextBox();
            label5 = new Label();
            chbActivo = new CheckBox();
            btnGuardar = new Button();
            txbEMail = new TextBox();
            lblCorreoElectronico = new Label();
            txbTelefono = new TextBox();
            lblTelefono = new Label();
            txbNoInterior = new TextBox();
            txbNoExterior = new TextBox();
            lblNoInterior = new Label();
            lblNoExterior = new Label();
            txbCalle = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            lblColonia = new Label();
            ddlColonia = new ComboBox();
            lblMunicipio = new Label();
            lblLocalidad = new Label();
            lblEstado = new Label();
            ddlMunicipio = new ComboBox();
            ddlLocalidad = new ComboBox();
            ddlEstado = new ComboBox();
            txbRFC = new TextBox();
            txbCodigoPostal = new TextBox();
            txbApellidoMaterno = new TextBox();
            lblApellidoMaterno = new Label();
            txbApellidoPaterno = new TextBox();
            txbNombre = new TextBox();
            lblApellidoPaterno = new Label();
            lblNombre = new Label();
            splitContainer2 = new SplitContainer();
            txbCuenta = new TextBox();
            lblCuenta = new Label();
            btnAgregarPermiso = new Button();
            btnQuitarPermiso = new Button();
            txbBanco = new TextBox();
            lblBanco = new Label();
            label4 = new Label();
            ddlPermiso = new ComboBox();
            lblPuesto = new Label();
            ddlPuesto = new ComboBox();
            txbContraseña = new TextBox();
            txbUsuario = new TextBox();
            lblContraseña = new Label();
            lblUsuario = new Label();
            dgvPermisos = new DataGridView();
            txbNSS = new TextBox();
            lblNSS = new Label();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer2).BeginInit();
            splitContainer2.Panel1.SuspendLayout();
            splitContainer2.Panel2.SuspendLayout();
            splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvPermisos).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            splitContainer1.Orientation = Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(txbNomina);
            splitContainer1.Panel1.Controls.Add(lblNomina);
            splitContainer1.Panel1.Controls.Add(chbConsulta);
            splitContainer1.Panel1.Controls.Add(txbClave);
            splitContainer1.Panel1.Controls.Add(lblClave);
            splitContainer1.Panel1.Controls.Add(txbIdEmpleado);
            splitContainer1.Panel1.Controls.Add(label5);
            splitContainer1.Panel1.Controls.Add(chbActivo);
            splitContainer1.Panel1.Controls.Add(btnGuardar);
            splitContainer1.Panel1.Controls.Add(txbEMail);
            splitContainer1.Panel1.Controls.Add(lblCorreoElectronico);
            splitContainer1.Panel1.Controls.Add(txbTelefono);
            splitContainer1.Panel1.Controls.Add(lblTelefono);
            splitContainer1.Panel1.Controls.Add(txbNoInterior);
            splitContainer1.Panel1.Controls.Add(txbNoExterior);
            splitContainer1.Panel1.Controls.Add(lblNoInterior);
            splitContainer1.Panel1.Controls.Add(lblNoExterior);
            splitContainer1.Panel1.Controls.Add(txbCalle);
            splitContainer1.Panel1.Controls.Add(label3);
            splitContainer1.Panel1.Controls.Add(label2);
            splitContainer1.Panel1.Controls.Add(label1);
            splitContainer1.Panel1.Controls.Add(lblColonia);
            splitContainer1.Panel1.Controls.Add(ddlColonia);
            splitContainer1.Panel1.Controls.Add(lblMunicipio);
            splitContainer1.Panel1.Controls.Add(lblLocalidad);
            splitContainer1.Panel1.Controls.Add(lblEstado);
            splitContainer1.Panel1.Controls.Add(ddlMunicipio);
            splitContainer1.Panel1.Controls.Add(ddlLocalidad);
            splitContainer1.Panel1.Controls.Add(ddlEstado);
            splitContainer1.Panel1.Controls.Add(txbRFC);
            splitContainer1.Panel1.Controls.Add(txbCodigoPostal);
            splitContainer1.Panel1.Controls.Add(txbApellidoMaterno);
            splitContainer1.Panel1.Controls.Add(lblApellidoMaterno);
            splitContainer1.Panel1.Controls.Add(txbApellidoPaterno);
            splitContainer1.Panel1.Controls.Add(txbNombre);
            splitContainer1.Panel1.Controls.Add(lblApellidoPaterno);
            splitContainer1.Panel1.Controls.Add(lblNombre);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(splitContainer2);
            splitContainer1.Size = new Size(600, 400);
            splitContainer1.SplitterDistance = 200;
            splitContainer1.TabIndex = 0;
            // 
            // txbNomina
            // 
            txbNomina.Location = new Point(353, 176);
            txbNomina.Name = "txbNomina";
            txbNomina.Size = new Size(88, 23);
            txbNomina.TabIndex = 71;
            // 
            // lblNomina
            // 
            lblNomina.AutoSize = true;
            lblNomina.Location = new Point(285, 179);
            lblNomina.Name = "lblNomina";
            lblNomina.Size = new Size(50, 15);
            lblNomina.TabIndex = 70;
            lblNomina.Text = "Nómina";
            // 
            // chbConsulta
            // 
            chbConsulta.AutoSize = true;
            chbConsulta.Location = new Point(207, 7);
            chbConsulta.Name = "chbConsulta";
            chbConsulta.Size = new Size(73, 19);
            chbConsulta.TabIndex = 69;
            chbConsulta.Text = "Consulta";
            chbConsulta.UseVisualStyleBackColor = true;
            chbConsulta.CheckedChanged += chbConsulta_CheckedChanged;
            // 
            // txbClave
            // 
            txbClave.Location = new Point(174, 176);
            txbClave.Name = "txbClave";
            txbClave.Size = new Size(106, 23);
            txbClave.TabIndex = 68;
            // 
            // lblClave
            // 
            lblClave.AutoSize = true;
            lblClave.Location = new Point(140, 179);
            lblClave.Name = "lblClave";
            lblClave.Size = new Size(27, 15);
            lblClave.TabIndex = 67;
            lblClave.Text = "Cve";
            // 
            // txbIdEmpleado
            // 
            txbIdEmpleado.Enabled = false;
            txbIdEmpleado.Location = new Point(117, 5);
            txbIdEmpleado.Name = "txbIdEmpleado";
            txbIdEmpleado.Size = new Size(54, 23);
            txbIdEmpleado.TabIndex = 66;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 8);
            label5.Name = "label5";
            label5.Size = new Size(74, 15);
            label5.TabIndex = 65;
            label5.Text = "ID Empleado";
            // 
            // chbActivo
            // 
            chbActivo.AutoSize = true;
            chbActivo.Location = new Point(447, 179);
            chbActivo.Name = "chbActivo";
            chbActivo.Size = new Size(60, 19);
            chbActivo.TabIndex = 64;
            chbActivo.Text = "Activo";
            chbActivo.UseVisualStyleBackColor = true;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(513, 176);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 61;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // txbEMail
            // 
            txbEMail.Location = new Point(353, 147);
            txbEMail.Name = "txbEMail";
            txbEMail.Size = new Size(235, 23);
            txbEMail.TabIndex = 60;
            // 
            // lblCorreoElectronico
            // 
            lblCorreoElectronico.AutoSize = true;
            lblCorreoElectronico.Location = new Point(286, 150);
            lblCorreoElectronico.Name = "lblCorreoElectronico";
            lblCorreoElectronico.Size = new Size(41, 15);
            lblCorreoElectronico.TabIndex = 59;
            lblCorreoElectronico.Text = "E-Mail";
            // 
            // txbTelefono
            // 
            txbTelefono.Location = new Point(174, 147);
            txbTelefono.Name = "txbTelefono";
            txbTelefono.Size = new Size(106, 23);
            txbTelefono.TabIndex = 58;
            txbTelefono.KeyPress += txbTelefono_KeyPress;
            // 
            // lblTelefono
            // 
            lblTelefono.AutoSize = true;
            lblTelefono.Location = new Point(140, 150);
            lblTelefono.Name = "lblTelefono";
            lblTelefono.Size = new Size(23, 15);
            lblTelefono.TabIndex = 57;
            lblTelefono.Text = "Tel";
            // 
            // txbNoInterior
            // 
            txbNoInterior.Location = new Point(80, 176);
            txbNoInterior.Name = "txbNoInterior";
            txbNoInterior.Size = new Size(54, 23);
            txbNoInterior.TabIndex = 56;
            // 
            // txbNoExterior
            // 
            txbNoExterior.Location = new Point(80, 147);
            txbNoExterior.Name = "txbNoExterior";
            txbNoExterior.Size = new Size(54, 23);
            txbNoExterior.TabIndex = 55;
            // 
            // lblNoInterior
            // 
            lblNoInterior.AutoSize = true;
            lblNoInterior.Location = new Point(12, 179);
            lblNoInterior.Name = "lblNoInterior";
            lblNoInterior.Size = new Size(62, 15);
            lblNoInterior.TabIndex = 54;
            lblNoInterior.Text = "N° Interior";
            // 
            // lblNoExterior
            // 
            lblNoExterior.AutoSize = true;
            lblNoExterior.Location = new Point(12, 150);
            lblNoExterior.Name = "lblNoExterior";
            lblNoExterior.Size = new Size(63, 15);
            lblNoExterior.TabIndex = 53;
            lblNoExterior.Text = "N° Exterior";
            // 
            // txbCalle
            // 
            txbCalle.Location = new Point(353, 118);
            txbCalle.Name = "txbCalle";
            txbCalle.Size = new Size(235, 23);
            txbCalle.TabIndex = 52;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(286, 121);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 51;
            label3.Text = "Calle";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(140, 121);
            label2.Name = "label2";
            label2.Size = new Size(28, 15);
            label2.TabIndex = 50;
            label2.Text = "RFC";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 121);
            label1.Name = "label1";
            label1.Size = new Size(22, 15);
            label1.TabIndex = 49;
            label1.Text = "CP";
            // 
            // lblColonia
            // 
            lblColonia.AutoSize = true;
            lblColonia.Location = new Point(286, 92);
            lblColonia.Name = "lblColonia";
            lblColonia.Size = new Size(48, 15);
            lblColonia.TabIndex = 48;
            lblColonia.Text = "Colonia";
            // 
            // ddlColonia
            // 
            ddlColonia.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlColonia.FormattingEnabled = true;
            ddlColonia.Location = new Point(353, 89);
            ddlColonia.Name = "ddlColonia";
            ddlColonia.Size = new Size(235, 23);
            ddlColonia.TabIndex = 47;
            // 
            // lblMunicipio
            // 
            lblMunicipio.AutoSize = true;
            lblMunicipio.Location = new Point(286, 63);
            lblMunicipio.Name = "lblMunicipio";
            lblMunicipio.Size = new Size(61, 15);
            lblMunicipio.TabIndex = 46;
            lblMunicipio.Text = "Municipio";
            // 
            // lblLocalidad
            // 
            lblLocalidad.AutoSize = true;
            lblLocalidad.Location = new Point(286, 34);
            lblLocalidad.Name = "lblLocalidad";
            lblLocalidad.Size = new Size(58, 15);
            lblLocalidad.TabIndex = 45;
            lblLocalidad.Text = "Localidad";
            // 
            // lblEstado
            // 
            lblEstado.AutoSize = true;
            lblEstado.Location = new Point(286, 8);
            lblEstado.Name = "lblEstado";
            lblEstado.Size = new Size(42, 15);
            lblEstado.TabIndex = 44;
            lblEstado.Text = "Estado";
            // 
            // ddlMunicipio
            // 
            ddlMunicipio.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlMunicipio.FormattingEnabled = true;
            ddlMunicipio.Location = new Point(353, 60);
            ddlMunicipio.Name = "ddlMunicipio";
            ddlMunicipio.Size = new Size(235, 23);
            ddlMunicipio.TabIndex = 43;
            // 
            // ddlLocalidad
            // 
            ddlLocalidad.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlLocalidad.FormattingEnabled = true;
            ddlLocalidad.Location = new Point(353, 31);
            ddlLocalidad.Name = "ddlLocalidad";
            ddlLocalidad.Size = new Size(235, 23);
            ddlLocalidad.TabIndex = 42;
            // 
            // ddlEstado
            // 
            ddlEstado.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlEstado.FormattingEnabled = true;
            ddlEstado.Location = new Point(353, 2);
            ddlEstado.Name = "ddlEstado";
            ddlEstado.Size = new Size(235, 23);
            ddlEstado.TabIndex = 41;
            // 
            // txbRFC
            // 
            txbRFC.Location = new Point(174, 118);
            txbRFC.Name = "txbRFC";
            txbRFC.Size = new Size(106, 23);
            txbRFC.TabIndex = 40;
            txbRFC.Text = "XAXX010101000";
            // 
            // txbCodigoPostal
            // 
            txbCodigoPostal.Location = new Point(80, 118);
            txbCodigoPostal.Name = "txbCodigoPostal";
            txbCodigoPostal.Size = new Size(54, 23);
            txbCodigoPostal.TabIndex = 39;
            txbCodigoPostal.TextChanged += txbCodigoPostal_TextChanged;
            txbCodigoPostal.KeyPress += txbCodigoPostal_KeyPress;
            // 
            // txbApellidoMaterno
            // 
            txbApellidoMaterno.Location = new Point(117, 89);
            txbApellidoMaterno.Name = "txbApellidoMaterno";
            txbApellidoMaterno.Size = new Size(163, 23);
            txbApellidoMaterno.TabIndex = 38;
            txbApellidoMaterno.KeyPress += txbApellidoMaterno_KeyPress;
            // 
            // lblApellidoMaterno
            // 
            lblApellidoMaterno.AutoSize = true;
            lblApellidoMaterno.Location = new Point(12, 92);
            lblApellidoMaterno.Name = "lblApellidoMaterno";
            lblApellidoMaterno.Size = new Size(99, 15);
            lblApellidoMaterno.TabIndex = 37;
            lblApellidoMaterno.Text = "Apellido Materno";
            // 
            // txbApellidoPaterno
            // 
            txbApellidoPaterno.Location = new Point(117, 60);
            txbApellidoPaterno.Name = "txbApellidoPaterno";
            txbApellidoPaterno.Size = new Size(163, 23);
            txbApellidoPaterno.TabIndex = 36;
            txbApellidoPaterno.KeyPress += txbApellidoPaterno_KeyPress;
            // 
            // txbNombre
            // 
            txbNombre.Location = new Point(117, 31);
            txbNombre.Name = "txbNombre";
            txbNombre.Size = new Size(163, 23);
            txbNombre.TabIndex = 35;
            txbNombre.KeyPress += txbNombre_KeyPress;
            // 
            // lblApellidoPaterno
            // 
            lblApellidoPaterno.AutoSize = true;
            lblApellidoPaterno.Location = new Point(12, 63);
            lblApellidoPaterno.Name = "lblApellidoPaterno";
            lblApellidoPaterno.Size = new Size(95, 15);
            lblApellidoPaterno.TabIndex = 34;
            lblApellidoPaterno.Text = "Apellido Paterno";
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(12, 37);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(51, 15);
            lblNombre.TabIndex = 33;
            lblNombre.Text = "Nombre";
            // 
            // splitContainer2
            // 
            splitContainer2.Dock = DockStyle.Fill;
            splitContainer2.Location = new Point(0, 0);
            splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            splitContainer2.Panel1.Controls.Add(txbNSS);
            splitContainer2.Panel1.Controls.Add(lblNSS);
            splitContainer2.Panel1.Controls.Add(txbCuenta);
            splitContainer2.Panel1.Controls.Add(lblCuenta);
            splitContainer2.Panel1.Controls.Add(btnAgregarPermiso);
            splitContainer2.Panel1.Controls.Add(btnQuitarPermiso);
            splitContainer2.Panel1.Controls.Add(txbBanco);
            splitContainer2.Panel1.Controls.Add(lblBanco);
            splitContainer2.Panel1.Controls.Add(label4);
            splitContainer2.Panel1.Controls.Add(ddlPermiso);
            splitContainer2.Panel1.Controls.Add(lblPuesto);
            splitContainer2.Panel1.Controls.Add(ddlPuesto);
            splitContainer2.Panel1.Controls.Add(txbContraseña);
            splitContainer2.Panel1.Controls.Add(txbUsuario);
            splitContainer2.Panel1.Controls.Add(lblContraseña);
            splitContainer2.Panel1.Controls.Add(lblUsuario);
            // 
            // splitContainer2.Panel2
            // 
            splitContainer2.Panel2.Controls.Add(dgvPermisos);
            splitContainer2.Size = new Size(600, 196);
            splitContainer2.SplitterDistance = 300;
            splitContainer2.TabIndex = 0;
            // 
            // txbCuenta
            // 
            txbCuenta.Location = new Point(82, 173);
            txbCuenta.Name = "txbCuenta";
            txbCuenta.Size = new Size(215, 23);
            txbCuenta.TabIndex = 70;
            // 
            // lblCuenta
            // 
            lblCuenta.AutoSize = true;
            lblCuenta.Location = new Point(12, 176);
            lblCuenta.Name = "lblCuenta";
            lblCuenta.Size = new Size(45, 15);
            lblCuenta.TabIndex = 69;
            lblCuenta.Text = "Cuenta";
            // 
            // btnAgregarPermiso
            // 
            btnAgregarPermiso.Location = new Point(193, 114);
            btnAgregarPermiso.Name = "btnAgregarPermiso";
            btnAgregarPermiso.Size = new Size(55, 23);
            btnAgregarPermiso.TabIndex = 63;
            btnAgregarPermiso.Text = "Agregar";
            btnAgregarPermiso.UseVisualStyleBackColor = true;
            btnAgregarPermiso.Click += btnAgregarPermiso_Click;
            // 
            // btnQuitarPermiso
            // 
            btnQuitarPermiso.Location = new Point(253, 114);
            btnQuitarPermiso.Name = "btnQuitarPermiso";
            btnQuitarPermiso.Size = new Size(44, 23);
            btnQuitarPermiso.TabIndex = 62;
            btnQuitarPermiso.Text = "Quitar";
            btnQuitarPermiso.UseVisualStyleBackColor = true;
            btnQuitarPermiso.Click += btnQuitarPermiso_Click;
            // 
            // txbBanco
            // 
            txbBanco.Location = new Point(81, 144);
            txbBanco.Name = "txbBanco";
            txbBanco.Size = new Size(216, 23);
            txbBanco.TabIndex = 68;
            // 
            // lblBanco
            // 
            lblBanco.AutoSize = true;
            lblBanco.Location = new Point(12, 147);
            lblBanco.Name = "lblBanco";
            lblBanco.Size = new Size(40, 15);
            lblBanco.TabIndex = 67;
            lblBanco.Text = "Banco";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 93);
            label4.Name = "label4";
            label4.Size = new Size(50, 15);
            label4.TabIndex = 48;
            label4.Text = "Permiso";
            // 
            // ddlPermiso
            // 
            ddlPermiso.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlPermiso.FormattingEnabled = true;
            ddlPermiso.Location = new Point(82, 90);
            ddlPermiso.Name = "ddlPermiso";
            ddlPermiso.Size = new Size(215, 23);
            ddlPermiso.TabIndex = 47;
            // 
            // lblPuesto
            // 
            lblPuesto.AutoSize = true;
            lblPuesto.Location = new Point(12, 64);
            lblPuesto.Name = "lblPuesto";
            lblPuesto.Size = new Size(43, 15);
            lblPuesto.TabIndex = 46;
            lblPuesto.Text = "Puesto";
            // 
            // ddlPuesto
            // 
            ddlPuesto.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlPuesto.FormattingEnabled = true;
            ddlPuesto.Location = new Point(81, 61);
            ddlPuesto.Name = "ddlPuesto";
            ddlPuesto.Size = new Size(216, 23);
            ddlPuesto.TabIndex = 45;
            // 
            // txbContraseña
            // 
            txbContraseña.Location = new Point(82, 32);
            txbContraseña.Name = "txbContraseña";
            txbContraseña.Size = new Size(215, 23);
            txbContraseña.TabIndex = 42;
            // 
            // txbUsuario
            // 
            txbUsuario.Location = new Point(82, 3);
            txbUsuario.Name = "txbUsuario";
            txbUsuario.Size = new Size(215, 23);
            txbUsuario.TabIndex = 41;
            // 
            // lblContraseña
            // 
            lblContraseña.AutoSize = true;
            lblContraseña.Location = new Point(12, 35);
            lblContraseña.Name = "lblContraseña";
            lblContraseña.Size = new Size(67, 15);
            lblContraseña.TabIndex = 40;
            lblContraseña.Text = "Contraseña";
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Location = new Point(12, 9);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(47, 15);
            lblUsuario.TabIndex = 39;
            lblUsuario.Text = "Usuario";
            // 
            // dgvPermisos
            // 
            dgvPermisos.AllowUserToAddRows = false;
            dgvPermisos.AllowUserToDeleteRows = false;
            dgvPermisos.AllowUserToOrderColumns = true;
            dgvPermisos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvPermisos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPermisos.Dock = DockStyle.Fill;
            dgvPermisos.EditMode = DataGridViewEditMode.EditProgrammatically;
            dgvPermisos.Location = new Point(0, 0);
            dgvPermisos.MultiSelect = false;
            dgvPermisos.Name = "dgvPermisos";
            dgvPermisos.RowTemplate.Height = 25;
            dgvPermisos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvPermisos.Size = new Size(296, 196);
            dgvPermisos.TabIndex = 0;
            dgvPermisos.CellClick += dgvPermisos_CellClick;
            // 
            // txbNSS
            // 
            txbNSS.Location = new Point(82, 115);
            txbNSS.Name = "txbNSS";
            txbNSS.Size = new Size(107, 23);
            txbNSS.TabIndex = 73;
            // 
            // lblNSS
            // 
            lblNSS.AutoSize = true;
            lblNSS.Location = new Point(12, 118);
            lblNSS.Name = "lblNSS";
            lblNSS.Size = new Size(28, 15);
            lblNSS.TabIndex = 72;
            lblNSS.Text = "NSS";
            // 
            // cusEmpleados
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(splitContainer1);
            Name = "cusEmpleados";
            Size = new Size(600, 400);
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            splitContainer2.Panel1.ResumeLayout(false);
            splitContainer2.Panel1.PerformLayout();
            splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer2).EndInit();
            splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvPermisos).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private TextBox txbIdEmpleado;
        private Label label5;
        private CheckBox chbActivo;
        private Button btnCancelar;
        private Button btnModificar;
        private Button btnGuardar;
        private TextBox txbEMail;
        private Label lblCorreoElectronico;
        private TextBox txbTelefono;
        private Label lblTelefono;
        private TextBox txbNoInterior;
        private TextBox txbNoExterior;
        private Label lblNoInterior;
        private Label lblNoExterior;
        private TextBox txbCalle;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label lblColonia;
        private ComboBox ddlColonia;
        private Label lblMunicipio;
        private Label lblLocalidad;
        private Label lblEstado;
        private ComboBox ddlMunicipio;
        private ComboBox ddlLocalidad;
        private ComboBox ddlEstado;
        private TextBox txbRFC;
        private TextBox txbCodigoPostal;
        private TextBox txbApellidoMaterno;
        private Label lblApellidoMaterno;
        private TextBox txbApellidoPaterno;
        private TextBox txbNombre;
        private Label lblApellidoPaterno;
        private Label lblNombre;
        private SplitContainer splitContainer2;
        private Label label4;
        private ComboBox ddlPermiso;
        private Label lblPuesto;
        private ComboBox ddlPuesto;
        private TextBox txbContraseña;
        private TextBox txbUsuario;
        private Label lblContraseña;
        private Label lblUsuario;
        private DataGridView dgvPermisos;
        private Button btnAgregarPermiso;
        private Button btnQuitarPermiso;
        private CheckBox chbConsulta;
        private TextBox txbClave;
        private Label lblClave;
        private TextBox txbCuenta;
        private Label lblCuenta;
        private TextBox txbBanco;
        private Label lblBanco;
        private TextBox txbNomina;
        private Label lblNomina;
        private TextBox txbNSS;
        private Label lblNSS;
    }
}
