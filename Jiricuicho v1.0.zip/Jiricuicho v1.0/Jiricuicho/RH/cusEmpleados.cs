﻿using BusinessEntities;
using BusinessEntities.Directorio;
using BusinessEntities.Entidades;
using BusinessEntities.RH;
using DataAccess.Directorio;
using DataAccess.RH;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jiricuicho.RH
{
    public partial class cusEmpleados : UserControl
    {
        #region Variables y Constantes

        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private ClsEmpleadosDA EmpleadosDA = new ClsEmpleadosDA();
        private ClsPermisosDA PermisosDA = new ClsPermisosDA();
        private ClsPuestosDA PuestosDA = new ClsPuestosDA();
        private ClsDirectorio Directorio = new ClsDirectorio();
        private ClsUsuario Usuario = new ClsUsuario();
        private List<ClsCodigosPostales> ListaCodigosPostales = new List<ClsCodigosPostales>();
        private List<ClsLocalidades> ListaLocalidades = new List<ClsLocalidades>();
        private List<ClsMunicipios> ListaMunicipios = new List<ClsMunicipios>();
        private List<ClsColonias> ListaColonias = new List<ClsColonias>();
        private List<ClsEstados> ListaEstados = new List<ClsEstados>();
        private List<ClsPermiso> ListaPermisos = new List<ClsPermiso>();
        private List<ClsPermiso> ListaPermisosDGV = new List<ClsPermiso>();
        private List<ClsPuestos> ListaPuestos = new List<ClsPuestos>();
        private int dgvIndex = 0;

        #endregion

        #region Funciones del Control

        public cusEmpleados(ClsUsuario usuario)
        {
            Usuario = usuario;
            InitializeComponent();
            CargaInicial();
        }

        protected void CargaInicial()
        {
            try
            {
                ListaPermisos = PermisosDA.ConsultarPermisos("Fernando");
                ddlPermiso.DataSource = ListaPermisos;
                ddlPermiso.DisplayMember = "Descripcion";
                ddlPermiso.ValueMember = "Clave";

                ListaPuestos = PuestosDA.ConsultarPuestos("Fernando");
                ddlPuesto.DataSource = ListaPuestos;
                ddlPuesto.DisplayMember = "Descripcion";
                ddlPuesto.ValueMember = "Clave";
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void ModoConsulta(bool Consulta)
        {
            try
            {
                txbIdEmpleado.Enabled = Consulta;
                txbNombre.Enabled = !Consulta;
                txbApellidoPaterno.Enabled = !Consulta;
                txbApellidoMaterno.Enabled = !Consulta;
                txbCodigoPostal.Enabled = !Consulta;
                txbRFC.Enabled = !Consulta;
                txbNoExterior.Enabled = !Consulta;
                txbTelefono.Enabled = !Consulta;
                txbNoInterior.Enabled = !Consulta;
                txbClave.Enabled = !Consulta;
                txbCalle.Enabled = !Consulta;
                txbEMail.Enabled = !Consulta;
                txbUsuario.Enabled = !Consulta;
                txbContraseña.Enabled = !Consulta;
                txbBanco.Enabled = !Consulta;
                txbCuenta.Enabled = !Consulta;
                chbActivo.Enabled = !Consulta;
                ddlEstado.Enabled = !Consulta;
                ddlLocalidad.Enabled = !Consulta;
                ddlMunicipio.Enabled = !Consulta;
                ddlColonia.Enabled = !Consulta;
                ddlPuesto.Enabled = !Consulta;
                ddlPermiso.Enabled = !Consulta;
                btnAgregarPermiso.Enabled = !Consulta;
                btnQuitarPermiso.Enabled = !Consulta;
                btnGuardar.Enabled = !Consulta;

                if (btnGuardar.Enabled)
                {
                    btnGuardar.Text = "Guardar";
                }
                else
                {
                    btnGuardar.Text = "Modificar";
                }

                txbIdEmpleado.Text = string.Empty;
                txbNombre.Text = string.Empty;
                txbApellidoPaterno.Text = string.Empty;
                txbApellidoMaterno.Text = string.Empty;
                txbCodigoPostal.Text = string.Empty;
                txbRFC.Text = string.Empty;
                txbNoExterior.Text = string.Empty;
                txbTelefono.Text = string.Empty;
                txbNoInterior.Text = string.Empty;
                txbClave.Text = string.Empty;
                txbCalle.Text = string.Empty;
                txbEMail.Text = string.Empty;
                txbUsuario.Text = string.Empty;
                txbContraseña.Text = string.Empty;
                txbBanco.Text = string.Empty;
                txbCuenta.Text = string.Empty;

                chbActivo.Checked = false;

                if (ddlEstado.SelectedIndex > 0)
                {
                    ddlEstado.SelectedIndex = 0;
                }

                if (ddlLocalidad.SelectedIndex > 0)
                {
                    ddlLocalidad.SelectedIndex = 0;
                }

                if (ddlMunicipio.SelectedIndex > 0)
                {
                    ddlMunicipio.SelectedIndex = 0;
                }

                if (ddlColonia.SelectedIndex > 0)
                {
                    ddlColonia.SelectedIndex = 0;
                }

                if (ddlPuesto.SelectedIndex > 0)
                {
                    ddlPuesto.SelectedIndex = 0;
                }

                if (ddlPermiso.SelectedIndex > 0)
                {
                    ddlPermiso.SelectedIndex = 0;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        protected void MostrarError(string strErr)
        {
            MessageBox.Show(strErr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        #endregion

        #region Eventos

        private void chbConsulta_CheckedChanged(object sender, EventArgs e)
        {
            ModoConsulta(chbConsulta.Checked);
        }

        private void txbCodigoPostal_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txbCodigoPostal.Text.Length == 5)
                {
                    ListaCodigosPostales = Directorio.ConsultaCodigoPostal(txbCodigoPostal.Text, Usuario.Usuario);

                    ListaLocalidades = Directorio.ConsultaListaLocalidades(ListaCodigosPostales[0].Estado, ListaCodigosPostales[0].Localidad, Usuario.Usuario);
                    ddlLocalidad.DataSource = ListaLocalidades;
                    ddlLocalidad.DisplayMember = "Descripcion";
                    ddlLocalidad.ValueMember = "Localidad";

                    ListaEstados = Directorio.ConsultaListaEstados(ListaCodigosPostales[0].Estado, Usuario.Usuario);
                    ddlEstado.DataSource = ListaEstados;
                    ddlEstado.DisplayMember = "Nombre";
                    ddlEstado.ValueMember = "Estado";

                    ListaColonias = Directorio.ConsultaListaColonias(ListaCodigosPostales[0].CodigoPostal, Usuario.Usuario);
                    ddlColonia.DataSource = ListaColonias;
                    ddlColonia.DisplayMember = "Asentamiento";
                    ddlColonia.ValueMember = "Colonia";

                    ListaMunicipios = Directorio.ConsultaListaMunicipios(ListaCodigosPostales[0].Estado, ListaLocalidades[0].Descripcion, Usuario.Usuario);
                    ddlMunicipio.DataSource = ListaMunicipios;
                    ddlMunicipio.DisplayMember = "Descripcion";
                    ddlMunicipio.ValueMember = "Municipio";
                }
                else
                {
                    ListaCodigosPostales.Clear();
                    ListaLocalidades.Clear();
                    ListaEstados.Clear();
                    ListaColonias.Clear();
                    ListaMunicipios.Clear();
                    ddlLocalidad.DataSource = null;
                    ddlEstado.DataSource = null;
                    ddlColonia.DataSource = null;
                    ddlMunicipio.DataSource = null;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbCodigoPostal_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloNumeros(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloNumeros(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloLetras(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbApellidoPaterno_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloLetras(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbApellidoMaterno_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloLetras(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                ClsDirecciones Direcciones = new ClsDirecciones();
                ClsEmpleado Empleado = new ClsEmpleado();
                ClsUsuario UsuarioEmp = new ClsUsuario();

                Direcciones.Calle = txbCalle.Text;
                Direcciones.Ciudad = ddlEstado.SelectedValue.ToString();
                Direcciones.Colonia = ddlColonia.SelectedValue.ToString();
                Direcciones.CP = txbCodigoPostal.Text;
                Direcciones.Estado = ddlEstado.SelectedValue.ToString();
                Direcciones.Fiscal = true;
                Direcciones.Localidad = ddlLocalidad.SelectedValue.ToString();
                Direcciones.Municipio = ddlMunicipio.SelectedValue == null ? string.Empty : ddlMunicipio.SelectedValue.ToString();
                Direcciones.NoExterior = txbNoExterior.Text;
                Direcciones.NoInterior = txbNoInterior.Text == string.Empty ? "S/N" : txbNoInterior.Text;
                Direcciones.Pais = "MEX";

                Empleado.ApellidoMaterno = txbApellidoMaterno.Text;
                Empleado.ApellidoPaterno = txbApellidoPaterno.Text;
                Empleado.Banco = txbBanco.Text;
                Empleado.CertSitFiscal = string.Empty;
                Empleado.Clave = txbClave.Text;
                Empleado.ClaveBancaria = txbCuenta.Text;
                Empleado.CorreoElectronico = txbEMail.Text;
                Empleado.Estatus = chbActivo.Checked;
                Empleado.FechaIngreso = DateTime.Now;
                Empleado.idPuesto = ((ClsPuestos)ddlPuesto.SelectedItem).idPuesto;
                Empleado.Nombre = txbNombre.Text;
                Empleado.Nomina = double.Parse(txbNomina.Text);
                Empleado.NSS = txbNSS.Text;
                Empleado.RFC = txbRFC.Text;
                Empleado.Telefono = txbTelefono.Text;
                Empleado.Usuario = Usuario.Usuario;

                UsuarioEmp.Contraseña = txbContraseña.Text;
                UsuarioEmp.Estatus = true;
                UsuarioEmp.idPuesto = ((ClsPuestos)ddlPuesto.SelectedItem).idPuesto;
                UsuarioEmp.Usuario = txbUsuario.Text;

                EmpleadosDA.GuardarEmpleado(Empleado, Usuario, ListaPermisosDGV, Direcciones);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void btnAgregarPermiso_Click(object sender, EventArgs e)
        {
            try
            {
                ClsPermiso Permiso = new ClsPermiso();
                Permiso = (ClsPermiso)ddlPermiso.SelectedItem;
                ListaPermisosDGV.Add(Permiso);
                dgvPermisos.DataSource = null;
                dgvPermisos.DataSource = ListaPermisosDGV;
                this.dgvPermisos.Columns["idPermiso"].Visible = false;
                this.dgvPermisos.Columns["Estatus"].Visible = false;
                dgvPermisos.Refresh();
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void btnQuitarPermiso_Click(object sender, EventArgs e)
        {
            try
            {
                if (ListaPermisosDGV.Count == 1)
                {
                    ListaPermisosDGV.Remove((ClsPermiso)dgvPermisos.Rows[0].DataBoundItem);
                }
                else
                {
                    ListaPermisosDGV.Remove((ClsPermiso)dgvPermisos.Rows[dgvIndex].DataBoundItem);
                }

                if (ListaPermisosDGV.Count == 0)
                {

                    dgvPermisos.DataSource = null;
                    dgvPermisos.Refresh();
                }
                else
                {
                    dgvPermisos.DataSource = null;
                    dgvPermisos.DataSource = ListaPermisosDGV;
                    this.dgvPermisos.Columns["idPermiso"].Visible = false;
                    this.dgvPermisos.Columns["Estatus"].Visible = false;
                    dgvPermisos.Refresh();
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void dgvPermisos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvIndex = e.RowIndex;
        }

        #endregion
    }
}
