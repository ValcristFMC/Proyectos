﻿using BusinessEntities.RH;
using DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jiricuicho
{
    public partial class InicioSesion : Form
    {
        private bool SecionIniciada = false;
        private ClsLogin Login = new ClsLogin();
        private List<ClsUsuario> ListaUsuario = new List<ClsUsuario>();

        public InicioSesion()
        {
            InitializeComponent();
        }

        /// <Carga las formas de las clases heredadas>
        /// Modificación: FMC 28/05/2019
        /// </summary>
        /// <param name="pstrNombre"></param>
        /// <returns></returns>
        protected bool formaCargada(string pstrNombre)
        {
            for (int X = 0; X < this.MdiChildren.Length; X++)
            {
                if (this.MdiChildren[X].Name == pstrNombre)
                {
                    this.MdiChildren[X].Activate();

                    return (true);
                }
            }

            return (false);
        }

        protected void MostrarError(string strErr)
        {
            MessageBox.Show(strErr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            try
            {
                ListaUsuario = Login.VerificaSesion(txbUsuario.Text, txbContraseña.Text);

                if (ListaUsuario.Count > 0)
                {
                    SecionIniciada = true;
                }
                else
                {
                    SecionIniciada = false;
                }

                bool Cancela = true;

                if (SecionIniciada)
                {
                    foreach (Form frm in Application.OpenForms)
                    {
                        if (frm.GetType() == typeof(Jiricuicho))
                        {
                            Cancela = false;
                            break;
                        }
                    }

                    if (Cancela)
                    {
                        if (!formaCargada("Jiricuicho"))
                        {
                            Jiricuicho MonitoreoProcesos = new Jiricuicho(ListaUsuario[0]);
                            MonitoreoProcesos.Show();
                            this.Hide();
                        }
                    }
                }
                else
                {
                    throw new Exception("Nombre de usuario y contraseña erroneos, intentarlo nuevamente");
                }
            }
            catch (Exception Error)
            {
                MessageBox.Show(Error.Message);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
