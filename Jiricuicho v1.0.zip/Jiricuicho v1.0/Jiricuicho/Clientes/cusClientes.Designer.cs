﻿namespace Jiricuicho.Clientes
{
    partial class cusClientes
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            splitContainer1 = new SplitContainer();
            chbActivo = new CheckBox();
            btnCancelar = new Button();
            btnModificar = new Button();
            btnAgregar = new Button();
            txbEMail = new TextBox();
            lblCorreoElectronico = new Label();
            txbTelefono = new TextBox();
            lblTelefono = new Label();
            txbNoInterior = new TextBox();
            txbNoExterior = new TextBox();
            lblNoInterior = new Label();
            lblNoExterior = new Label();
            txbCalle = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            lblColonia = new Label();
            ddlColonia = new ComboBox();
            lblMunicipio = new Label();
            lblLocalidad = new Label();
            lblEstado = new Label();
            ddlMunicipio = new ComboBox();
            ddlLocalidad = new ComboBox();
            ddlEstado = new ComboBox();
            txbRFC = new TextBox();
            txbCodigoPostal = new TextBox();
            txbApellidoMaterno = new TextBox();
            lblApellidoMaterno = new Label();
            txbApellidoPaterno = new TextBox();
            txbNombre = new TextBox();
            lblApellidoPaterno = new Label();
            lblNombre = new Label();
            dgvClientes = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvClientes).BeginInit();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            splitContainer1.Orientation = Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(chbActivo);
            splitContainer1.Panel1.Controls.Add(btnCancelar);
            splitContainer1.Panel1.Controls.Add(btnModificar);
            splitContainer1.Panel1.Controls.Add(btnAgregar);
            splitContainer1.Panel1.Controls.Add(txbEMail);
            splitContainer1.Panel1.Controls.Add(lblCorreoElectronico);
            splitContainer1.Panel1.Controls.Add(txbTelefono);
            splitContainer1.Panel1.Controls.Add(lblTelefono);
            splitContainer1.Panel1.Controls.Add(txbNoInterior);
            splitContainer1.Panel1.Controls.Add(txbNoExterior);
            splitContainer1.Panel1.Controls.Add(lblNoInterior);
            splitContainer1.Panel1.Controls.Add(lblNoExterior);
            splitContainer1.Panel1.Controls.Add(txbCalle);
            splitContainer1.Panel1.Controls.Add(label3);
            splitContainer1.Panel1.Controls.Add(label2);
            splitContainer1.Panel1.Controls.Add(label1);
            splitContainer1.Panel1.Controls.Add(lblColonia);
            splitContainer1.Panel1.Controls.Add(ddlColonia);
            splitContainer1.Panel1.Controls.Add(lblMunicipio);
            splitContainer1.Panel1.Controls.Add(lblLocalidad);
            splitContainer1.Panel1.Controls.Add(lblEstado);
            splitContainer1.Panel1.Controls.Add(ddlMunicipio);
            splitContainer1.Panel1.Controls.Add(ddlLocalidad);
            splitContainer1.Panel1.Controls.Add(ddlEstado);
            splitContainer1.Panel1.Controls.Add(txbRFC);
            splitContainer1.Panel1.Controls.Add(txbCodigoPostal);
            splitContainer1.Panel1.Controls.Add(txbApellidoMaterno);
            splitContainer1.Panel1.Controls.Add(lblApellidoMaterno);
            splitContainer1.Panel1.Controls.Add(txbApellidoPaterno);
            splitContainer1.Panel1.Controls.Add(txbNombre);
            splitContainer1.Panel1.Controls.Add(lblApellidoPaterno);
            splitContainer1.Panel1.Controls.Add(lblNombre);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(dgvClientes);
            splitContainer1.Size = new Size(600, 400);
            splitContainer1.SplitterDistance = 216;
            splitContainer1.TabIndex = 0;
            // 
            // chbActivo
            // 
            chbActivo.AutoSize = true;
            chbActivo.Location = new Point(220, 159);
            chbActivo.Name = "chbActivo";
            chbActivo.Size = new Size(60, 19);
            chbActivo.TabIndex = 32;
            chbActivo.Text = "Activo";
            chbActivo.UseVisualStyleBackColor = true;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(513, 186);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(75, 23);
            btnCancelar.TabIndex = 31;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnModificar
            // 
            btnModificar.Location = new Point(432, 186);
            btnModificar.Name = "btnModificar";
            btnModificar.Size = new Size(75, 23);
            btnModificar.TabIndex = 29;
            btnModificar.Text = "Modificar";
            btnModificar.UseVisualStyleBackColor = true;
            // 
            // btnAgregar
            // 
            btnAgregar.Location = new Point(351, 186);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(75, 23);
            btnAgregar.TabIndex = 28;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // txbEMail
            // 
            txbEMail.Location = new Point(353, 157);
            txbEMail.Name = "txbEMail";
            txbEMail.Size = new Size(235, 23);
            txbEMail.TabIndex = 27;
            // 
            // lblCorreoElectronico
            // 
            lblCorreoElectronico.AutoSize = true;
            lblCorreoElectronico.Location = new Point(286, 160);
            lblCorreoElectronico.Name = "lblCorreoElectronico";
            lblCorreoElectronico.Size = new Size(41, 15);
            lblCorreoElectronico.TabIndex = 26;
            lblCorreoElectronico.Text = "E-Mail";
            // 
            // txbTelefono
            // 
            txbTelefono.Location = new Point(80, 157);
            txbTelefono.Name = "txbTelefono";
            txbTelefono.Size = new Size(102, 23);
            txbTelefono.TabIndex = 25;
            txbTelefono.KeyPress += txbTelefono_KeyPress;
            // 
            // lblTelefono
            // 
            lblTelefono.AutoSize = true;
            lblTelefono.Location = new Point(12, 160);
            lblTelefono.Name = "lblTelefono";
            lblTelefono.Size = new Size(54, 15);
            lblTelefono.TabIndex = 24;
            lblTelefono.Text = "Teléfono";
            // 
            // txbNoInterior
            // 
            txbNoInterior.Location = new Point(226, 128);
            txbNoInterior.Name = "txbNoInterior";
            txbNoInterior.Size = new Size(54, 23);
            txbNoInterior.TabIndex = 23;
            // 
            // txbNoExterior
            // 
            txbNoExterior.Location = new Point(80, 128);
            txbNoExterior.Name = "txbNoExterior";
            txbNoExterior.Size = new Size(54, 23);
            txbNoExterior.TabIndex = 22;
            // 
            // lblNoInterior
            // 
            lblNoInterior.AutoSize = true;
            lblNoInterior.Location = new Point(140, 131);
            lblNoInterior.Name = "lblNoInterior";
            lblNoInterior.Size = new Size(62, 15);
            lblNoInterior.TabIndex = 21;
            lblNoInterior.Text = "N° Interior";
            // 
            // lblNoExterior
            // 
            lblNoExterior.AutoSize = true;
            lblNoExterior.Location = new Point(12, 131);
            lblNoExterior.Name = "lblNoExterior";
            lblNoExterior.Size = new Size(63, 15);
            lblNoExterior.TabIndex = 20;
            lblNoExterior.Text = "N° Exterior";
            // 
            // txbCalle
            // 
            txbCalle.Location = new Point(353, 128);
            txbCalle.Name = "txbCalle";
            txbCalle.Size = new Size(235, 23);
            txbCalle.TabIndex = 19;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(286, 131);
            label3.Name = "label3";
            label3.Size = new Size(33, 15);
            label3.TabIndex = 18;
            label3.Text = "Calle";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(146, 102);
            label2.Name = "label2";
            label2.Size = new Size(28, 15);
            label2.TabIndex = 17;
            label2.Text = "RFC";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 102);
            label1.Name = "label1";
            label1.Size = new Size(22, 15);
            label1.TabIndex = 16;
            label1.Text = "CP";
            // 
            // lblColonia
            // 
            lblColonia.AutoSize = true;
            lblColonia.Location = new Point(286, 102);
            lblColonia.Name = "lblColonia";
            lblColonia.Size = new Size(48, 15);
            lblColonia.TabIndex = 15;
            lblColonia.Text = "Colonia";
            // 
            // ddlColonia
            // 
            ddlColonia.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlColonia.FormattingEnabled = true;
            ddlColonia.Location = new Point(353, 99);
            ddlColonia.Name = "ddlColonia";
            ddlColonia.Size = new Size(235, 23);
            ddlColonia.TabIndex = 14;
            // 
            // lblMunicipio
            // 
            lblMunicipio.AutoSize = true;
            lblMunicipio.Location = new Point(286, 73);
            lblMunicipio.Name = "lblMunicipio";
            lblMunicipio.Size = new Size(61, 15);
            lblMunicipio.TabIndex = 13;
            lblMunicipio.Text = "Municipio";
            // 
            // lblLocalidad
            // 
            lblLocalidad.AutoSize = true;
            lblLocalidad.Location = new Point(286, 44);
            lblLocalidad.Name = "lblLocalidad";
            lblLocalidad.Size = new Size(58, 15);
            lblLocalidad.TabIndex = 12;
            lblLocalidad.Text = "Localidad";
            // 
            // lblEstado
            // 
            lblEstado.AutoSize = true;
            lblEstado.Location = new Point(286, 18);
            lblEstado.Name = "lblEstado";
            lblEstado.Size = new Size(42, 15);
            lblEstado.TabIndex = 11;
            lblEstado.Text = "Estado";
            // 
            // ddlMunicipio
            // 
            ddlMunicipio.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlMunicipio.FormattingEnabled = true;
            ddlMunicipio.Location = new Point(353, 70);
            ddlMunicipio.Name = "ddlMunicipio";
            ddlMunicipio.Size = new Size(235, 23);
            ddlMunicipio.TabIndex = 10;
            // 
            // ddlLocalidad
            // 
            ddlLocalidad.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlLocalidad.FormattingEnabled = true;
            ddlLocalidad.Location = new Point(353, 41);
            ddlLocalidad.Name = "ddlLocalidad";
            ddlLocalidad.Size = new Size(235, 23);
            ddlLocalidad.TabIndex = 9;
            // 
            // ddlEstado
            // 
            ddlEstado.DropDownStyle = ComboBoxStyle.DropDownList;
            ddlEstado.FormattingEnabled = true;
            ddlEstado.Location = new Point(353, 12);
            ddlEstado.Name = "ddlEstado";
            ddlEstado.Size = new Size(235, 23);
            ddlEstado.TabIndex = 8;
            // 
            // txbRFC
            // 
            txbRFC.Location = new Point(180, 99);
            txbRFC.Name = "txbRFC";
            txbRFC.Size = new Size(100, 23);
            txbRFC.TabIndex = 7;
            // 
            // txbCodigoPostal
            // 
            txbCodigoPostal.Location = new Point(80, 99);
            txbCodigoPostal.Name = "txbCodigoPostal";
            txbCodigoPostal.Size = new Size(54, 23);
            txbCodigoPostal.TabIndex = 6;
            txbCodigoPostal.TextChanged += txbCodigoPostal_TextChanged;
            txbCodigoPostal.KeyPress += txbCodigoPostal_KeyPress;
            // 
            // txbApellidoMaterno
            // 
            txbApellidoMaterno.Location = new Point(117, 70);
            txbApellidoMaterno.Name = "txbApellidoMaterno";
            txbApellidoMaterno.Size = new Size(163, 23);
            txbApellidoMaterno.TabIndex = 5;
            txbApellidoMaterno.KeyPress += txbApellidoMaterno_KeyPress;
            // 
            // lblApellidoMaterno
            // 
            lblApellidoMaterno.AutoSize = true;
            lblApellidoMaterno.Location = new Point(12, 73);
            lblApellidoMaterno.Name = "lblApellidoMaterno";
            lblApellidoMaterno.Size = new Size(99, 15);
            lblApellidoMaterno.TabIndex = 4;
            lblApellidoMaterno.Text = "Apellido Materno";
            // 
            // txbApellidoPaterno
            // 
            txbApellidoPaterno.Location = new Point(117, 41);
            txbApellidoPaterno.Name = "txbApellidoPaterno";
            txbApellidoPaterno.Size = new Size(163, 23);
            txbApellidoPaterno.TabIndex = 3;
            txbApellidoPaterno.KeyPress += txbApellidoPaterno_KeyPress;
            // 
            // txbNombre
            // 
            txbNombre.Location = new Point(117, 12);
            txbNombre.Name = "txbNombre";
            txbNombre.Size = new Size(163, 23);
            txbNombre.TabIndex = 2;
            txbNombre.KeyPress += txbNombre_KeyPress;
            // 
            // lblApellidoPaterno
            // 
            lblApellidoPaterno.AutoSize = true;
            lblApellidoPaterno.Location = new Point(12, 44);
            lblApellidoPaterno.Name = "lblApellidoPaterno";
            lblApellidoPaterno.Size = new Size(95, 15);
            lblApellidoPaterno.TabIndex = 1;
            lblApellidoPaterno.Text = "Apellido Paterno";
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(12, 18);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(51, 15);
            lblNombre.TabIndex = 0;
            lblNombre.Text = "Nombre";
            // 
            // dgvClientes
            // 
            dgvClientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvClientes.Dock = DockStyle.Fill;
            dgvClientes.Location = new Point(0, 0);
            dgvClientes.Name = "dgvClientes";
            dgvClientes.RowTemplate.Height = 25;
            dgvClientes.Size = new Size(600, 180);
            dgvClientes.TabIndex = 0;
            // 
            // cusClientes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(splitContainer1);
            Name = "cusClientes";
            Size = new Size(600, 400);
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvClientes).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private CheckBox chbActivo;
        private Button btnCancelar;
        private Button btnModificar;
        private Button btnAgregar;
        private TextBox txbEMail;
        private Label lblCorreoElectronico;
        private TextBox txbTelefono;
        private Label lblTelefono;
        private TextBox txbNoInterior;
        private TextBox txbNoExterior;
        private Label lblNoInterior;
        private Label lblNoExterior;
        private TextBox txbCalle;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label lblColonia;
        private ComboBox ddlColonia;
        private Label lblMunicipio;
        private Label lblLocalidad;
        private Label lblEstado;
        private ComboBox ddlMunicipio;
        private ComboBox ddlLocalidad;
        private ComboBox ddlEstado;
        private TextBox txbRFC;
        private TextBox txbCodigoPostal;
        private TextBox txbApellidoMaterno;
        private Label lblApellidoMaterno;
        private TextBox txbApellidoPaterno;
        private TextBox txbNombre;
        private Label lblApellidoPaterno;
        private Label lblNombre;
        private DataGridView dgvClientes;
    }
}
