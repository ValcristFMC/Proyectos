﻿using BusinessEntities;
using BusinessEntities.Clientes;
using BusinessEntities.Directorio;
using BusinessEntities.Entidades;
using BusinessEntities.RH;
using DataAccess.Clientes;
using DataAccess.Directorio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jiricuicho.Clientes
{
    public partial class cusClientes : UserControl
    {
        #region Variables y Constantes

        private ClsDirectorio Directorio = new ClsDirectorio();
        private ClsFuncionesGenerales Funciones = new ClsFuncionesGenerales();
        private List<ClsClientes> ListaCliente = new List<ClsClientes>();
        private List<ClsCodigosPostales> ListaCodigosPostales = new List<ClsCodigosPostales>();
        private List<ClsLocalidades> ListaLocalidades = new List<ClsLocalidades>();
        private List<ClsMunicipios> ListaMunicipios = new List<ClsMunicipios>();
        private List<ClsColonias> ListaColonias = new List<ClsColonias>();
        private List<ClsEstados> ListaEstados = new List<ClsEstados>();
        private string Error = string.Empty;
        private bool FisicaMoral;
        private ClsClientes Cliente = new ClsClientes();
        private ClsClientesDA Clientes = new ClsClientesDA();
        private ClsDirecciones Direccion = new ClsDirecciones();
        private ClsUsuario Usuario = new ClsUsuario();

        #endregion

        #region Funciones del Control

        public cusClientes(BusinessEntities.RH.ClsUsuario usuario)
        {
            Usuario = usuario;
            InitializeComponent();
        }

        public void ValidaCampos()
        {
            if (txbNombre.Text == string.Empty)
            {
                Error = Error + "El nombre es obligatorio /n";
            }

            if (txbCodigoPostal.Text == string.Empty)
            {
                Error = Error + "El Código Postal es obligatorio";
            }

            if (txbTelefono.Text == string.Empty)
            {
                Error = Error + "El Teléfono es obligatorio";
            }

            if (txbEMail.Text == string.Empty)
            {
                Error = Error + "Se te olvido poner el nombre";
            }

            if (txbRFC.Text == string.Empty)
            {
                Error = Error + "El RFC es obligatorio";
            }

            if (txbNoExterior.Text == string.Empty)
            {
                Error = Error + "El número exterior es obligatorio";
            }

            if (txbCalle.Text == string.Empty)
            {
                Error = Error + "La Calle es obligatoria";
            }
        }

        protected void MostrarError(string strErr)
        {
            MessageBox.Show(strErr, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        #endregion

        #region Eventos

        private void txbCodigoPostal_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloNumeros(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloLetras(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbApellidoPaterno_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloLetras(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbApellidoMaterno_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloLetras(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                e = Funciones.SoloNumeros(e);
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void txbCodigoPostal_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (txbCodigoPostal.Text.Length == 5)
                {
                    ListaCodigosPostales = Directorio.ConsultaCodigoPostal(txbCodigoPostal.Text, Usuario.Usuario);

                    ListaLocalidades = Directorio.ConsultaListaLocalidades(ListaCodigosPostales[0].Estado, ListaCodigosPostales[0].Localidad, Usuario.Usuario);
                    ddlLocalidad.DataSource = ListaLocalidades;
                    ddlLocalidad.DisplayMember = "Descripcion";
                    ddlLocalidad.ValueMember = "Localidad";

                    ListaEstados = Directorio.ConsultaListaEstados(ListaCodigosPostales[0].Estado, Usuario.Usuario);
                    ddlEstado.DataSource = ListaEstados;
                    ddlEstado.DisplayMember = "Nombre";
                    ddlEstado.ValueMember = "Estado";

                    ListaColonias = Directorio.ConsultaListaColonias(ListaCodigosPostales[0].CodigoPostal, Usuario.Usuario);
                    ddlColonia.DataSource = ListaColonias;
                    ddlColonia.DisplayMember = "Asentamiento";
                    ddlColonia.ValueMember = "Colonia";

                    ListaMunicipios = Directorio.ConsultaListaMunicipios(ListaCodigosPostales[0].Estado, ListaLocalidades[0].Descripcion, Usuario.Usuario);
                    ddlMunicipio.DataSource = ListaMunicipios;
                    ddlMunicipio.DisplayMember = "Descripcion";
                    ddlMunicipio.ValueMember = "Municipio";
                }
                else
                {
                    ListaCodigosPostales.Clear();
                    ListaLocalidades.Clear();
                    ListaEstados.Clear();
                    ListaColonias.Clear();
                    ListaMunicipios.Clear();
                    ddlLocalidad.DataSource = null;
                    ddlEstado.DataSource = null;
                    ddlColonia.DataSource = null;
                    ddlMunicipio.DataSource = null;
                }
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente.Usuario = Usuario.Usuario;
                ValidaCampos();
                Cliente.Nombre = txbNombre.Text;
                Cliente.ApellidoPaterno = txbApellidoPaterno.Text;
                Cliente.ApellidoMaterno = txbApellidoMaterno.Text;
                Direccion.CP = txbCodigoPostal.Text;

                if (txbRFC.Text.Length == 12)
                {
                    FisicaMoral = true;
                }
                else if (txbRFC.Text.Length == 13)
                {
                    FisicaMoral = false;
                }

                Funciones.RFCFisicaMoral(txbRFC.Text, FisicaMoral);
                Cliente.RFC = txbRFC.Text;
                Direccion.Estado = ddlEstado.SelectedValue.ToString();
                Direccion.Localidad = ddlLocalidad.SelectedValue.ToString();
                Direccion.Municipio = ddlMunicipio.SelectedValue.ToString();
                if (ddlColonia.SelectedValue != null)
                {
                    Direccion.Colonia = ddlColonia.SelectedValue.ToString();
                }
                Direccion.Calle = txbCalle.Text;
                Direccion.NoInterior = txbNoInterior.Text;
                Direccion.NoExterior = txbNoExterior.Text;
                Cliente.Telefono = txbTelefono.Text;

                if (Funciones.ValidarCorreoElectrónico(txbEMail.Text))
                {
                    Cliente.CorreoElectronico = txbEMail.Text;
                }
                else
                {
                    throw new Exception("El correo electronico no es valido");
                }

                ListaCliente = Clientes.GuardarCliente(Cliente, Direccion);
                dgvClientes.DataSource = ListaCliente;
            }
            catch (Exception Error)
            {
                MostrarError(Error.Message);
            }
        }

        #endregion
    }
}
