﻿namespace Jiricuicho
{
    partial class Jiricuicho
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            tsmCompras = new ToolStripMenuItem();
            tsmFacturacion = new ToolStripMenuItem();
            tsmFacturación4 = new ToolStripMenuItem();
            tsmPagos = new ToolStripMenuItem();
            tsmNotas = new ToolStripMenuItem();
            créditoToolStripMenuItem = new ToolStripMenuItem();
            débitoToolStripMenuItem = new ToolStripMenuItem();
            tsmCrèditos = new ToolStripMenuItem();
            tsmOrdenDeCompras = new ToolStripMenuItem();
            tsmOrdenDeVenta = new ToolStripMenuItem();
            tsmInventario = new ToolStripMenuItem();
            tsmInventarioBodega = new ToolStripMenuItem();
            tsmBodegaAltas = new ToolStripMenuItem();
            tsmBodegaExistencias = new ToolStripMenuItem();
            tsmBodegaBajas = new ToolStripMenuItem();
            tsmInventarioMateriaPrima = new ToolStripMenuItem();
            tsmMateriaPrimaAltas = new ToolStripMenuItem();
            tsmMateriaPrimaConsumo = new ToolStripMenuItem();
            tsmMateriaPrimaCostos = new ToolStripMenuItem();
            tsmInventarioConsumibles = new ToolStripMenuItem();
            tsmConsumiblesAlta = new ToolStripMenuItem();
            tsmConsumiblesExistencias = new ToolStripMenuItem();
            tsmInventarioInmuebles = new ToolStripMenuItem();
            tsmInmueblesAltas = new ToolStripMenuItem();
            tsmInmueblesBajas = new ToolStripMenuItem();
            tsmInventarioServicios = new ToolStripMenuItem();
            tsmProductos = new ToolStripMenuItem();
            tsmAlimentos = new ToolStripMenuItem();
            tsmSoubenir = new ToolStripMenuItem();
            tsmCervezas = new ToolStripMenuItem();
            tiposToolStripMenuItem = new ToolStripMenuItem();
            tsmProveedores = new ToolStripMenuItem();
            tsmClientes = new ToolStripMenuItem();
            tsmRecursosHumanos = new ToolStripMenuItem();
            tsmEmpleados = new ToolStripMenuItem();
            tsmContratos = new ToolStripMenuItem();
            tsmNomina = new ToolStripMenuItem();
            tsmChecador = new ToolStripMenuItem();
            tsmServicios = new ToolStripMenuItem();
            tsmProducción = new ToolStripMenuItem();
            spcJiricuicho = new SplitContainer();
            lblNombreMenu = new Label();
            lblNombreAccion = new Label();
            lblNombreUsuario = new Label();
            lblUsuario = new Label();
            lblSeccion = new Label();
            lblAccion = new Label();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)spcJiricuicho).BeginInit();
            spcJiricuicho.Panel1.SuspendLayout();
            spcJiricuicho.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { tsmCompras, tsmInventario, tsmProductos, tsmProveedores, tsmClientes, tsmRecursosHumanos, tsmProducción });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(805, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // tsmCompras
            // 
            tsmCompras.DropDownItems.AddRange(new ToolStripItem[] { tsmFacturacion, tsmNotas, tsmCrèditos, tsmOrdenDeCompras, tsmOrdenDeVenta });
            tsmCompras.Name = "tsmCompras";
            tsmCompras.Size = new Size(67, 20);
            tsmCompras.Text = "Compras";
            // 
            // tsmFacturacion
            // 
            tsmFacturacion.DropDownItems.AddRange(new ToolStripItem[] { tsmFacturación4, tsmPagos });
            tsmFacturacion.Name = "tsmFacturacion";
            tsmFacturacion.Size = new Size(180, 22);
            tsmFacturacion.Text = "Facturación";
            // 
            // tsmFacturación4
            // 
            tsmFacturación4.Name = "tsmFacturación4";
            tsmFacturación4.Size = new Size(180, 22);
            tsmFacturación4.Text = "Facturación 4.0";
            // 
            // tsmPagos
            // 
            tsmPagos.Name = "tsmPagos";
            tsmPagos.Size = new Size(180, 22);
            tsmPagos.Text = "Pagos";
            // 
            // tsmNotas
            // 
            tsmNotas.DropDownItems.AddRange(new ToolStripItem[] { créditoToolStripMenuItem, débitoToolStripMenuItem });
            tsmNotas.Name = "tsmNotas";
            tsmNotas.Size = new Size(180, 22);
            tsmNotas.Text = "Notas";
            // 
            // créditoToolStripMenuItem
            // 
            créditoToolStripMenuItem.Name = "créditoToolStripMenuItem";
            créditoToolStripMenuItem.Size = new Size(180, 22);
            créditoToolStripMenuItem.Text = "Crédito";
            // 
            // débitoToolStripMenuItem
            // 
            débitoToolStripMenuItem.Name = "débitoToolStripMenuItem";
            débitoToolStripMenuItem.Size = new Size(180, 22);
            débitoToolStripMenuItem.Text = "Débito";
            // 
            // tsmCrèditos
            // 
            tsmCrèditos.Name = "tsmCrèditos";
            tsmCrèditos.Size = new Size(180, 22);
            tsmCrèditos.Text = "Créditos";
            // 
            // tsmOrdenDeCompras
            // 
            tsmOrdenDeCompras.Name = "tsmOrdenDeCompras";
            tsmOrdenDeCompras.Size = new Size(180, 22);
            tsmOrdenDeCompras.Text = "Orden de Compra";
            // 
            // tsmOrdenDeVenta
            // 
            tsmOrdenDeVenta.Name = "tsmOrdenDeVenta";
            tsmOrdenDeVenta.Size = new Size(180, 22);
            tsmOrdenDeVenta.Text = "Orden de Venta";
            // 
            // tsmInventario
            // 
            tsmInventario.DropDownItems.AddRange(new ToolStripItem[] { tsmInventarioBodega, tsmInventarioMateriaPrima, tsmInventarioConsumibles, tsmInventarioInmuebles, tsmInventarioServicios });
            tsmInventario.Name = "tsmInventario";
            tsmInventario.Size = new Size(72, 20);
            tsmInventario.Text = "Inventario";
            // 
            // tsmInventarioBodega
            // 
            tsmInventarioBodega.DropDownItems.AddRange(new ToolStripItem[] { tsmBodegaAltas, tsmBodegaExistencias, tsmBodegaBajas });
            tsmInventarioBodega.Name = "tsmInventarioBodega";
            tsmInventarioBodega.Size = new Size(148, 22);
            tsmInventarioBodega.Text = "Bodega";
            // 
            // tsmBodegaAltas
            // 
            tsmBodegaAltas.Name = "tsmBodegaAltas";
            tsmBodegaAltas.Size = new Size(180, 22);
            tsmBodegaAltas.Text = "Altas";
            tsmBodegaAltas.Click += tsmBodegaAltas_Click;
            // 
            // tsmBodegaExistencias
            // 
            tsmBodegaExistencias.Name = "tsmBodegaExistencias";
            tsmBodegaExistencias.Size = new Size(180, 22);
            tsmBodegaExistencias.Text = "Existencias";
            tsmBodegaExistencias.Click += tsmBodegaExistencias_Click;
            // 
            // tsmBodegaBajas
            // 
            tsmBodegaBajas.Name = "tsmBodegaBajas";
            tsmBodegaBajas.Size = new Size(180, 22);
            tsmBodegaBajas.Text = "Bajas";
            tsmBodegaBajas.Click += tsmBodegaBajas_Click;
            // 
            // tsmInventarioMateriaPrima
            // 
            tsmInventarioMateriaPrima.DropDownItems.AddRange(new ToolStripItem[] { tsmMateriaPrimaAltas, tsmMateriaPrimaConsumo, tsmMateriaPrimaCostos });
            tsmInventarioMateriaPrima.Name = "tsmInventarioMateriaPrima";
            tsmInventarioMateriaPrima.Size = new Size(148, 22);
            tsmInventarioMateriaPrima.Text = "Materia Prima";
            // 
            // tsmMateriaPrimaAltas
            // 
            tsmMateriaPrimaAltas.Name = "tsmMateriaPrimaAltas";
            tsmMateriaPrimaAltas.Size = new Size(180, 22);
            tsmMateriaPrimaAltas.Text = "Altas";
            tsmMateriaPrimaAltas.Click += tsmMateriaPrimaAltas_Click;
            // 
            // tsmMateriaPrimaConsumo
            // 
            tsmMateriaPrimaConsumo.Name = "tsmMateriaPrimaConsumo";
            tsmMateriaPrimaConsumo.Size = new Size(180, 22);
            tsmMateriaPrimaConsumo.Text = "Modificar";
            tsmMateriaPrimaConsumo.Click += tsmMateriaPrimaConsumo_Click;
            // 
            // tsmMateriaPrimaCostos
            // 
            tsmMateriaPrimaCostos.Name = "tsmMateriaPrimaCostos";
            tsmMateriaPrimaCostos.Size = new Size(180, 22);
            tsmMateriaPrimaCostos.Text = "Costos";
            tsmMateriaPrimaCostos.Click += tsmMateriaPrimaCostos_Click;
            // 
            // tsmInventarioConsumibles
            // 
            tsmInventarioConsumibles.DropDownItems.AddRange(new ToolStripItem[] { tsmConsumiblesAlta, tsmConsumiblesExistencias });
            tsmInventarioConsumibles.Name = "tsmInventarioConsumibles";
            tsmInventarioConsumibles.Size = new Size(148, 22);
            tsmInventarioConsumibles.Text = "Consumibles";
            // 
            // tsmConsumiblesAlta
            // 
            tsmConsumiblesAlta.Name = "tsmConsumiblesAlta";
            tsmConsumiblesAlta.Size = new Size(180, 22);
            tsmConsumiblesAlta.Text = "Alta";
            tsmConsumiblesAlta.Click += tsmConsumiblesAlta_Click;
            // 
            // tsmConsumiblesExistencias
            // 
            tsmConsumiblesExistencias.Name = "tsmConsumiblesExistencias";
            tsmConsumiblesExistencias.Size = new Size(180, 22);
            tsmConsumiblesExistencias.Text = "Existencias";
            tsmConsumiblesExistencias.Click += tsmConsumiblesExistencias_Click;
            // 
            // tsmInventarioInmuebles
            // 
            tsmInventarioInmuebles.DropDownItems.AddRange(new ToolStripItem[] { tsmInmueblesAltas, tsmInmueblesBajas });
            tsmInventarioInmuebles.Name = "tsmInventarioInmuebles";
            tsmInventarioInmuebles.Size = new Size(148, 22);
            tsmInventarioInmuebles.Text = "Inmuebles";
            // 
            // tsmInmueblesAltas
            // 
            tsmInmueblesAltas.Name = "tsmInmueblesAltas";
            tsmInmueblesAltas.Size = new Size(180, 22);
            tsmInmueblesAltas.Text = "Altas";
            tsmInmueblesAltas.Click += tsmInmueblesPropios_Click;
            // 
            // tsmInmueblesBajas
            // 
            tsmInmueblesBajas.Name = "tsmInmueblesBajas";
            tsmInmueblesBajas.Size = new Size(180, 22);
            tsmInmueblesBajas.Text = "Bajas";
            tsmInmueblesBajas.Click += tsmInmueblesRentados_Click;
            // 
            // tsmInventarioServicios
            // 
            tsmInventarioServicios.Name = "tsmInventarioServicios";
            tsmInventarioServicios.Size = new Size(148, 22);
            tsmInventarioServicios.Text = "Servicios";
            tsmInventarioServicios.Click += tsmInventarioServicios_Click;
            // 
            // tsmProductos
            // 
            tsmProductos.DropDownItems.AddRange(new ToolStripItem[] { tsmAlimentos, tsmSoubenir, tsmCervezas });
            tsmProductos.Name = "tsmProductos";
            tsmProductos.Size = new Size(73, 20);
            tsmProductos.Text = "Productos";
            // 
            // tsmAlimentos
            // 
            tsmAlimentos.Name = "tsmAlimentos";
            tsmAlimentos.Size = new Size(180, 22);
            tsmAlimentos.Text = "Alimentos";
            // 
            // tsmSoubenir
            // 
            tsmSoubenir.Name = "tsmSoubenir";
            tsmSoubenir.Size = new Size(180, 22);
            tsmSoubenir.Text = "Soubenir";
            // 
            // tsmCervezas
            // 
            tsmCervezas.DropDownItems.AddRange(new ToolStripItem[] { tiposToolStripMenuItem });
            tsmCervezas.Name = "tsmCervezas";
            tsmCervezas.Size = new Size(180, 22);
            tsmCervezas.Text = "Cervezas";
            // 
            // tiposToolStripMenuItem
            // 
            tiposToolStripMenuItem.Name = "tiposToolStripMenuItem";
            tiposToolStripMenuItem.Size = new Size(180, 22);
            tiposToolStripMenuItem.Text = "Tipo";
            // 
            // tsmProveedores
            // 
            tsmProveedores.Name = "tsmProveedores";
            tsmProveedores.Size = new Size(84, 20);
            tsmProveedores.Text = "Proveedores";
            // 
            // tsmClientes
            // 
            tsmClientes.Name = "tsmClientes";
            tsmClientes.Size = new Size(61, 20);
            tsmClientes.Text = "Clientes";
            tsmClientes.Click += clientesToolStripMenuItem_Click;
            // 
            // tsmRecursosHumanos
            // 
            tsmRecursosHumanos.DropDownItems.AddRange(new ToolStripItem[] { tsmEmpleados, tsmContratos, tsmNomina, tsmChecador, tsmServicios });
            tsmRecursosHumanos.Name = "tsmRecursosHumanos";
            tsmRecursosHumanos.Size = new Size(121, 20);
            tsmRecursosHumanos.Text = "Recursos Humanos";
            // 
            // tsmEmpleados
            // 
            tsmEmpleados.Name = "tsmEmpleados";
            tsmEmpleados.Size = new Size(180, 22);
            tsmEmpleados.Text = "Empleados";
            tsmEmpleados.Click += tsmEmpleados_Click;
            // 
            // tsmContratos
            // 
            tsmContratos.Name = "tsmContratos";
            tsmContratos.Size = new Size(180, 22);
            tsmContratos.Text = "Contratos";
            // 
            // tsmNomina
            // 
            tsmNomina.Name = "tsmNomina";
            tsmNomina.Size = new Size(180, 22);
            tsmNomina.Text = "Nómina";
            // 
            // tsmChecador
            // 
            tsmChecador.Name = "tsmChecador";
            tsmChecador.Size = new Size(180, 22);
            tsmChecador.Text = "Checador";
            // 
            // tsmServicios
            // 
            tsmServicios.Name = "tsmServicios";
            tsmServicios.Size = new Size(180, 22);
            tsmServicios.Text = "Servicios";
            // 
            // tsmProducción
            // 
            tsmProducción.Name = "tsmProducción";
            tsmProducción.Size = new Size(80, 20);
            tsmProducción.Text = "Producción";
            // 
            // spcJiricuicho
            // 
            spcJiricuicho.Dock = DockStyle.Fill;
            spcJiricuicho.Location = new Point(0, 24);
            spcJiricuicho.Name = "spcJiricuicho";
            // 
            // spcJiricuicho.Panel1
            // 
            spcJiricuicho.Panel1.Controls.Add(lblNombreMenu);
            spcJiricuicho.Panel1.Controls.Add(lblNombreAccion);
            spcJiricuicho.Panel1.Controls.Add(lblNombreUsuario);
            spcJiricuicho.Panel1.Controls.Add(lblUsuario);
            spcJiricuicho.Panel1.Controls.Add(lblSeccion);
            spcJiricuicho.Panel1.Controls.Add(lblAccion);
            // 
            // spcJiricuicho.Panel2
            // 
            spcJiricuicho.Panel2.AutoScroll = true;
            spcJiricuicho.Size = new Size(805, 420);
            spcJiricuicho.SplitterDistance = 181;
            spcJiricuicho.TabIndex = 1;
            // 
            // lblNombreMenu
            // 
            lblNombreMenu.AutoSize = true;
            lblNombreMenu.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblNombreMenu.Location = new Point(59, 9);
            lblNombreMenu.Name = "lblNombreMenu";
            lblNombreMenu.Size = new Size(54, 15);
            lblNombreMenu.TabIndex = 5;
            lblNombreMenu.Text = "Principal";
            // 
            // lblNombreAccion
            // 
            lblNombreAccion.AutoSize = true;
            lblNombreAccion.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblNombreAccion.Location = new Point(59, 34);
            lblNombreAccion.Name = "lblNombreAccion";
            lblNombreAccion.Size = new Size(119, 15);
            lblNombreAccion.TabIndex = 4;
            lblNombreAccion.Text = "Seleccione un Menú";
            // 
            // lblNombreUsuario
            // 
            lblNombreUsuario.AutoSize = true;
            lblNombreUsuario.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            lblNombreUsuario.Location = new Point(59, 58);
            lblNombreUsuario.Name = "lblNombreUsuario";
            lblNombreUsuario.Size = new Size(86, 15);
            lblNombreUsuario.TabIndex = 3;
            lblNombreUsuario.Text = "Administrador";
            // 
            // lblUsuario
            // 
            lblUsuario.AutoSize = true;
            lblUsuario.Location = new Point(3, 58);
            lblUsuario.Name = "lblUsuario";
            lblUsuario.Size = new Size(50, 15);
            lblUsuario.TabIndex = 2;
            lblUsuario.Text = "Usuario:";
            // 
            // lblSeccion
            // 
            lblSeccion.AutoSize = true;
            lblSeccion.Location = new Point(3, 9);
            lblSeccion.Name = "lblSeccion";
            lblSeccion.Size = new Size(41, 15);
            lblSeccion.TabIndex = 1;
            lblSeccion.Text = "Menú:";
            // 
            // lblAccion
            // 
            lblAccion.AutoSize = true;
            lblAccion.Location = new Point(3, 34);
            lblAccion.Name = "lblAccion";
            lblAccion.Size = new Size(47, 15);
            lblAccion.TabIndex = 0;
            lblAccion.Text = "Acción:";
            // 
            // Jiricuicho
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(805, 444);
            Controls.Add(spcJiricuicho);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Jiricuicho";
            Text = "Jiricuicho Cerveza Artesanal";
            FormClosing += Jiricuicho_FormClosing;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            spcJiricuicho.Panel1.ResumeLayout(false);
            spcJiricuicho.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)spcJiricuicho).EndInit();
            spcJiricuicho.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem tsmCompras;
        private ToolStripMenuItem tsmInventario;
        private ToolStripMenuItem tsmFacturacion;
        private ToolStripMenuItem tsmNotas;
        private ToolStripMenuItem tsmCrèditos;
        private ToolStripMenuItem tsmProductos;
        private ToolStripMenuItem tsmOrdenDeCompras;
        private ToolStripMenuItem tsmOrdenDeVenta;
        private ToolStripMenuItem tsmInventarioBodega;
        private ToolStripMenuItem tsmInventarioMateriaPrima;
        private ToolStripMenuItem tsmInventarioConsumibles;
        private ToolStripMenuItem tsmInventarioInmuebles;
        private ToolStripMenuItem tsmAlimentos;
        private ToolStripMenuItem tsmSoubenir;
        private ToolStripMenuItem tsmProveedores;
        private ToolStripMenuItem tsmClientes;
        private ToolStripMenuItem tsmRecursosHumanos;
        private ToolStripMenuItem tsmEmpleados;
        private ToolStripMenuItem tsmContratos;
        private ToolStripMenuItem tsmNomina;
        private ToolStripMenuItem tsmChecador;
        private ToolStripMenuItem tsmCervezas;
        private ToolStripMenuItem tsmFacturación4;
        private ToolStripMenuItem tsmPagos;
        private ToolStripMenuItem créditoToolStripMenuItem;
        private ToolStripMenuItem débitoToolStripMenuItem;
        private ToolStripMenuItem tsmBodegaAltas;
        private ToolStripMenuItem tsmBodegaExistencias;
        private ToolStripMenuItem tsmBodegaBajas;
        private ToolStripMenuItem tsmMateriaPrimaAltas;
        private ToolStripMenuItem tsmMateriaPrimaConsumo;
        private ToolStripMenuItem tsmMateriaPrimaCostos;
        private ToolStripMenuItem tsmConsumiblesAlta;
        private ToolStripMenuItem tsmConsumiblesExistencias;
        private ToolStripMenuItem tsmInmueblesAltas;
        private ToolStripMenuItem tsmInmueblesBajas;
        private ToolStripMenuItem tiposToolStripMenuItem;
        private ToolStripMenuItem tsmServicios;
        private ToolStripMenuItem tsmProducción;
        private SplitContainer spcJiricuicho;
        private ToolStripMenuItem tsmInventarioServicios;
        private Label lblNombreMenu;
        private Label lblNombreAccion;
        private Label lblNombreUsuario;
        private Label lblUsuario;
        private Label lblSeccion;
        private Label lblAccion;
    }
}