﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.Inventario
{
    public class ClsTipos
    {
        public int idTipo { get; set; }
        public bool Estatus { get; set; }
        public string Descripcion { get; set; }
        public string Nombre { get; set; }
        public string Simbolo { get; set; }
        public string Equivalencia { get; set; }
        public string Usuario { get; set; }
    }
}
