﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.Inventario
{
    public class ClsBodegaBE
    {
        public int idBodega { get; set; }
        public int idMateriaPrima { get; set; }
        public int idConsumible { get; set; }
        public int idInmueble { get; set; }
        public bool Estatus { get; set; }
        public string Descripcion { get; set; }
        public string Clave { get; set; }
        public DateTime FechaAlta { get; set; }
        public DateTime FechaBaja { get; set; }
        public DateTime FechaModificacion { get; set; }
        public string Usuario { get; set; }
    }
}
