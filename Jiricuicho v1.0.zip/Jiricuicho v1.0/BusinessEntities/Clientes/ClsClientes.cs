﻿using System;

namespace BusinessEntities.Clientes
{
    public class ClsClientes
    {
        public int idCliente { get; set; }
        public bool Estatus { get; set; }
        public string Nombre { get; set; }
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public int RazonSocial { get; set; }
        public string RFC { get; set; }
        public string Telefono { get; set; }
        public string CorreoElectronico { get; set; }
        public int idDireccion { get; set; }
        public DateTime FechaAlta { get; set; }
        public DateTime FechaBaja { get; set; }
        public DateTime FechaModificacion { get; set; }
        public string Usuario { get; set; }
    }
}
