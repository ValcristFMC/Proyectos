﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace BusinessEntities.Clientes
{
    public class ClsRFC
    {
        private string Letras;
        private int Digitos;
        private string Alfanumericos;
        private string Tipo;
        public string letras
        {
            get { return Letras; }
            set { Letras = value; }
        }
        public int digitos
        {
            get { return Digitos; }
            set { Digitos = value; }
        }
        public string alfanumericos
        {
            get { return Alfanumericos; }
            set { Alfanumericos = value; }
        }
        public string tipo
        {
            get { return Tipo; }
            set { Tipo = value; }
        }
    }
}
