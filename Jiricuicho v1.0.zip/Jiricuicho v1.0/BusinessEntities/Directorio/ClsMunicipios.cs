﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.Entidades
{
    public class ClsMunicipios
    {
        public int idMunicipio { get; set; }
	    public string Municipio { get; set; }
        public string Estado { get; set; }
        public string Descripcion { get; set; }
    }
}
