﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.Entidades
{
    public class ClsLocalidades
    {
        public int idLocalidad { get; set; }
	    public string Localidad { get; set; }
        public string Estado { get; set; }
        public string Descripcion { get; set; }
    }
}
