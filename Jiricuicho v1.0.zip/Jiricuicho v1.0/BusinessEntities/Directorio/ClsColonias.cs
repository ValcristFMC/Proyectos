﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.Entidades
{
    public class ClsColonias
    {
        public int idColonia {get; set;}
	    public string Colonia {get; set;}
	    public string CodigoPostal { get; set; }
	    public string Asentamiento { get; set; }
    }
}
