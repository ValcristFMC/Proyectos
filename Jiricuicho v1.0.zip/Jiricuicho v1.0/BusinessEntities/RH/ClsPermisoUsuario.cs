﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.RH
{
    public class ClsPermisoUsuario
    {
        public int idPermiso { get; set; }
        public int idUsuario { get; set; }
    }
}
