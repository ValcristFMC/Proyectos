﻿using BusinessEntities.Directorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.RH
{
    public class ClsEmpleado
    {
        public int idEmpleado { get; set; }
        public string Clave { get; set; }
        public int idPuesto { get; set; }
        public bool Estatus { get; set; }
        public string Nombre { get; set; }
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public int idDireccion { get; set; }
        public string Telefono { get; set; }
        public string CorreoElectronico { get; set; }
        public DateTime FechaIngreso { get; set; }
        public DateTime FechaModificacion { get; set; }
        public string NSS { get; set; }
        public string RFC { get; set; }
        public string CertSitFiscal { get; set; }
        public double Nomina { get; set; }
        public string ClaveBancaria { get; set; }
        public string Banco { get; set; }
        public string Usuario { get; set; }
    }
}
