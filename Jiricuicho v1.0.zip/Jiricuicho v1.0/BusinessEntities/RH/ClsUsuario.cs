﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.RH
{
    public class ClsUsuario
    {
        public int idUsuario { get; set; }
        public int idPuesto { get; set; }
        public int idEmpleado { get; set; }
        public string Usuario { get; set; }
        public bool Estatus { get; set; }
        public string Contraseña { get; set; }
    }
}
