﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntities.RH
{
    public class ClsPermiso
    {
        public int idPermiso { get; set; }
        public string Clave { get; set; }
        public string Descripcion { get; set; }
        public bool Estatus { get; set; }
    }
}
