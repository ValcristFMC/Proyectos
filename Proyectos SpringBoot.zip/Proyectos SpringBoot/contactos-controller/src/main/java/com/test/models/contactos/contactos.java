package com.test.models.contactos;

public class contactos {
	private int Id;
	private String Nombre;
	private String Apellidos;
	private String Grupo;
	private String Email;
	private String Telefono;
	private String Direccion;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getApellidos() {
		return Apellidos;
	}
	public void setApellidos(String apellidos) {
		Apellidos = apellidos;
	}
	public String getGrupo() {
		return Grupo;
	}
	public void setGrupo(String grupo) {
		Grupo = grupo;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getTelefono() {
		return Telefono;
	}
	public void setTelefono(String telefono) {
		Telefono = telefono;
	}
	public String getDireccion() {
		return Direccion;
	}
	public void setDireccion(String direccion) {
		Direccion = direccion;
	}
	
	public contactos(int id, String nombre, String apellidos, String grupo, String email, String telefono,
			String direccion) {
		super();
		Id = id;
		Nombre = nombre;
		Apellidos = apellidos;
		Grupo = grupo;
		Email = email;
		Telefono = telefono;
		Direccion = direccion;
	}
	
	@Override
	public String toString() {
		return "contactos [Id=" + Id + ", Nombre=" + Nombre + ", Apellidos=" + Apellidos + ", Grupo=" + Grupo
				+ ", Email=" + Email + ", Telefono=" + Telefono + ", Direccion=" + Direccion + "]";
	}

	
}