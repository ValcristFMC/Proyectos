package com.test.contactos;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;

import com.test.interfase.contactos.ContactosInterface;
import com.test.service.contactos.ContactosService;

@Configuration
public class ContactosConfig {
	@Bean(name="ContactosDAO")
	@RequestScope
	public ContactosInterface getContactosService() {
		return new ContactosService();
	}
}
