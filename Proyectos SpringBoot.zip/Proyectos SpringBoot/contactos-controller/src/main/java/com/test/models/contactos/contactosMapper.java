package com.test.models.contactos;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class contactosMapper implements RowMapper<contactos>{

	@Override
	public contactos mapRow(ResultSet rs, int rowNum) throws SQLException {
		contactos contacto = new contactos(rs.getInt("id")
				, rs.getString("nombre")
				, rs.getString("apellidos")
				, rs.getString("grupo")
				, rs.getString("email")
				, rs.getString("telefono")
				, rs.getString("direccion"));
		
		
		return contacto;
	}

}
