package com.test.data.contactos;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.test.interfase.contactos.ContactosInterface;
import com.test.models.contactos.contactos;

@Repository
public class ContactosDAO implements ContactosInterface{

	@Override
	public contactos getById(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<contactos> getContacto() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<contactos> searchContacto(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long addContacto(contactos contacto) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean deleteContacto(long id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public contactos updateContacto(long id, contactos contacto) {
		// TODO Auto-generated method stub
		return null;
	}
	
}