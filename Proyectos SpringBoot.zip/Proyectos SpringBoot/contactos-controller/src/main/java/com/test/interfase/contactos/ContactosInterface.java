package com.test.interfase.contactos;

import java.util.List;

import com.test.models.contactos.contactos;

public interface ContactosInterface {
	public contactos getById(long id);
	public List<contactos> getContacto();
	public List<contactos> searchContacto(String nombre);
	public long addContacto(contactos contacto);
	public boolean deleteContacto(long id);
	public contactos updateContacto(long id, contactos contacto);
}
