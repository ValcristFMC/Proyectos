package com.test.controller.contactos;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.interfase.contactos.ContactosInterface;
import com.test.models.contactos.contactos;

@RestController
@RequestMapping("/api/service/contactos")
public class ContactosRestController {
	
	ContactosInterface service;
	
	public ContactosRestController(ContactosInterface service) {
		super();
		this.service = service;
	}
	
	@GetMapping("/")
	public List<contactos> GetContactos() {
		List<contactos> ListaContactos = service.getContacto();
		return ListaContactos;
	}
	
	@GetMapping("/{id}")
	public contactos getById(@PathVariable(name="id") long id) {
		return service.getById(id);
	}
	
	@GetMapping("/")
	public long addContacto(@RequestBody contactos contacto) {
		return service.addContacto(contacto);
	}
	
	@GetMapping("/delete/{id}")
	public boolean deleteContacto(@PathVariable(name="id") long id) {
		return service.deleteContacto(id);
	}
	
	@GetMapping("/update/{id}")
	public contactos updateContacto(@RequestBody contactos  contacto, @PathVariable(name="id") long id) {
		return service.updateContacto(id, contacto);
	}
	
	@GetMapping("/search/{id}")
	public List<contactos> searchContacto(@PathVariable(name="nombre") String nombre) {
		return service.searchContacto(nombre);
	}
}
