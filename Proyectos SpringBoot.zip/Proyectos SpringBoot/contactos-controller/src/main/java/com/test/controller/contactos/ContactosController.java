package com.test.controller.contactos;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.test.models.contactos.contactos;

@Controller
public class ContactosController {
	@GetMapping("/contacto")
	@ResponseBody
	public String ObtenerContacto() {
		return "Contacto Obtenido...";
	}
	
	@GetMapping("/controllercontacto")
	public String ShowControllerPage(Model model) {
		model.addAttribute("message", "Primer contacto");
		return "ContactoPage";
	}
	
	@GetMapping("/controllercontactomv")
	public ModelAndView ShowControllerPage() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("message", "Primer contacto");
		mv.setViewName("ContactoPage");
		return mv;
	}
	
	@GetMapping("/controllercontactoparam")
	public String ShowControllerPageParam(@RequestParam("message") String message, Model model) {
		model.addAttribute("message", message);
		return "ContactoPage";
	}
	
	@GetMapping("/ListaContactos")
	public String ShowListaContactosPage(Model model) {
		List<contactos> ListaContactos = new ArrayList<contactos>();
		ListaContactos.add(new contactos(1,"Fer", "MC", "Familia", "fmc@gmail.com", "4621231234", "Calle Numero Ciudad"));
		ListaContactos.add(new contactos(1,"Kari", "HH", "Amigos", "khh@gmail.com", "4624324321", "Calle Numero Ciudad"));
		model.addAttribute("contactos", ListaContactos);
		return "ListaContactoPage.html";
	}
	
	@GetMapping("/ListaContactosJSON")
	@ResponseBody
	public List<contactos> ShowListaContactosPageJSON(Model model) {
		List<contactos> ListaContactos = new ArrayList<contactos>();
		ListaContactos.add(new contactos(1,"Fer", "MC", "Familia", "fmc@gmail.com", "4621231234", "Calle Numero Ciudad"));
		ListaContactos.add(new contactos(1,"Kari", "HH", "Amigos", "khh@gmail.com", "4624324321", "Calle Numero Ciudad"));
		model.addAttribute("contactos", ListaContactos);
		return ListaContactos;
	}
}
