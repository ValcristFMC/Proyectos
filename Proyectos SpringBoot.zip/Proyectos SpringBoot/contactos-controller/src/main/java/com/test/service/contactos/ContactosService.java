package com.test.service.contactos;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.test.interfase.contactos.ContactosInterface;
import com.test.models.contactos.contactos;
import com.test.models.contactos.contactosMapper;

@Repository
@Primary
public class ContactosService implements ContactosInterface{
	
	@Autowired
	DataSource ds;
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public contactos getById(long id) {
		List<contactos> contacto = jdbcTemplate.query("select * from contactos where id = ?", new contactosMapper(), id);
		
		if(contacto.size() > 0)
			return contacto.get(0);
		else
			return null;
	}

	@Override
	public List<contactos> getContacto() {
		List<contactos> ListaContactos = jdbcTemplate.query("select * from contactos", new contactosMapper());
		return ListaContactos;
	}

	@Override
	public List<contactos> searchContacto(String nombre) {
		List<contactos> ListaContactos = jdbcTemplate.query("select * from contactos where nombre like ?"
				, new contactosMapper(), "%" + nombre + "%");
		return ListaContactos;
	}

	@Override
	public long addContacto(contactos contacto) {
		long result = jdbcTemplate.update("insert into contactos(nombre"
				+ ", apellidos"
				+ ", grupo"
				+ ", email"
				+ ", telefono"
				+ ", direccion)"
				+ " values(?,?,?,?,?,?)"
				, contacto.getNombre()
				, contacto.getApellidos()
				, contacto.getGrupo()
				, contacto.getEmail()
				, contacto.getTelefono()
				, contacto.getDireccion());
		return result;
	}

	@Override
	public boolean deleteContacto(long id) {
		int Contacto = jdbcTemplate.update("delete from contactos where id = ?", id);
		
		if(Contacto > 0)
			return true;
		else
			return false;
	}

	@Override
	public contactos updateContacto(long id, contactos contacto) {
		// TODO Auto-generated method stub
		return null;
	}

}
