package Test.crud.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
class CrudController {

    @GetMapping("/")
    public String showIndex() {
        return "index";
    }
}
