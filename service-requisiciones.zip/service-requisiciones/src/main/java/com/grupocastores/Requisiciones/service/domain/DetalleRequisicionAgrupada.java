package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de CatalogoRequisiciones", description = "mapea tabla de siat.requisiciones")
@Entity
@Table(name = "siat.requisiciones2023")
public class DetalleRequisicionAgrupada {
	
	@Id
	@Column(name="idrefaccion")
	private int idrefaccion;
	@Column(name = "presentacion")
	private String presentacion;
	@Column(name = "unidad")
	private String unidad;
	@Column(name = "cantsolicitada")
	private Double cantsolicitada;
	@Column(name = "clave")
	private String clave;
	@Column(name = "nomref")
	private String nomref;
	@Column(name="idgrupo")
	private int idgrupo;
	@Column(name="grupo")
	private String grupo;
	@Column(name="idtiposubrequisicion")
	private int idtiposubrequisicion;
	@Column(name="noeconomico")
	private String noeconomico;
	@Column(name="serie")
	private int serie;
}
