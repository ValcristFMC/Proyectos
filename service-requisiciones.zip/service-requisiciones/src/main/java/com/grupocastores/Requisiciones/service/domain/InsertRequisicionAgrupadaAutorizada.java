package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de requisicionagrupadaautoriza", description = "mapea tabla de siat.requisiciones")
@Entity
@Table(name = "siat.requisicionagrupadaautoriza")
public class InsertRequisicionAgrupadaAutorizada {
	
	@Id
	@Column(name="claveautorizada")
	private int claveautorizada;
	@Column(name = "observaciones")
	private String observaciones;
	@Column(name = "idautoriza")
	private int idautoriza;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;

}
