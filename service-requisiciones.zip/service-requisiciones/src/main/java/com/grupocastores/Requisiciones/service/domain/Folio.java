package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de folios Siat", description = "mapea tabla de siat.folios")
@Entity
@Table(name = "siat.folios")
public class Folio {
	
	@Id
	@Column(name="tipofolio")
	private int tipofolio;
	@Column(name = "idfolio")
	private int idfolio;
	@Column(name = "clavefolio")
	private String clavefolio;
	@Column(name = "descripcion")
	private String descripcion;
	
}
