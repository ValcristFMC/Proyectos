package com.grupocastores.Requisiciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Clase principal, anotada como SpringBootApplication
 *
 * @author Castores - Desarrollo TI
 */
@EnableEurekaClient
@EnableFeignClients
@SpringBootApplication
@EnableSwagger2
@EnableJpaAuditing
@ComponentScan({"com.grupocastores.Requisiciones.*"})
public class RequisicionesApplication 
{
	public static void main( String[] args )
	{
		SpringApplication.run(RequisicionesApplication.class, args);
	}
}
