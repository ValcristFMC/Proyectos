package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion para la modificacion de requisicion de la urgencia y almacen", description = "mapea tabla de siat.urgencia")
@Entity
@Table(name = "siat.urgencia")
public class GetModUrgencia {
	
	@Id
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name = "urgencia")
	private String urgencia;
	@Column(name = "nomAlmacen")
	private String nomAlmacen;
}
