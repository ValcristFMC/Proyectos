package com.grupocastores.Requisiciones.service;

import java.util.List;

import com.grupocastores.Requisiciones.service.domain.Requisiciones;
import com.grupocastores.Requisiciones.service.domain.CuerpoDetalle;
import com.grupocastores.Requisiciones.service.domain.CuerpoRequisicionAnio;
import com.grupocastores.Requisiciones.service.domain.DetalleRequisicionAgrupada;
import com.grupocastores.Requisiciones.service.domain.Folio;
import com.grupocastores.Requisiciones.service.domain.GetModHerrDestino;
import com.grupocastores.Requisiciones.service.domain.GetModHistoricoOrdenCompra;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicion;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicionAgrupada;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicionesHistorico;
import com.grupocastores.Requisiciones.service.domain.GetModSocios;
import com.grupocastores.Requisiciones.service.domain.GetModSociosAgrupada;
import com.grupocastores.Requisiciones.service.domain.GetModUrgencia;
import com.grupocastores.Requisiciones.service.domain.ListadoRequisicion;
import com.grupocastores.Requisiciones.service.domain.ListadoRequisicionAutorizada;
import com.grupocastores.Requisiciones.service.domain.ObtenerInformacionRequisicion;
import com.grupocastores.Requisiciones.service.domain.ObtenerRefaccionesCanceladas;
import com.grupocastores.Requisiciones.service.domain.ProveedorRefaccion;
import com.grupocastores.Requisiciones.service.domain.RefaccionConsignacion;
import com.grupocastores.Requisiciones.service.domain.RefaccionPorAlmacen;
import com.grupocastores.Requisiciones.service.domain.RefaccionesConvenio;
import com.grupocastores.Requisiciones.service.domain.RequisicionAnio;
import com.grupocastores.Requisiciones.service.domain.RequisicionAutorizada;
import com.grupocastores.Requisiciones.service.domain.RequisicionHistorico;
import com.grupocastores.Requisiciones.service.domain.RequisicionRefClasificacion;
import com.grupocastores.Requisiciones.dto.ResponseDTO;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisiciones;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisicionesAgrupadas;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisicionesPorAutorizar;
import com.grupocastores.Requisiciones.service.domain.CatalogoSocios;
import com.grupocastores.Requisiciones.service.domain.ClasificacionRef;
import com.grupocastores.Requisiciones.service.domain.Autorizaciones;
import com.grupocastores.Requisiciones.service.domain.CantidadNoConv;
import com.grupocastores.Requisiciones.service.domain.CantidadReq;
import com.grupocastores.Requisiciones.service.domain.CatalogoAlmacen;
import com.grupocastores.Requisiciones.service.domain.SemaforoSiat;
import com.grupocastores.Requisiciones.service.domain.SiatRequisiciones;
import com.grupocastores.Requisiciones.service.domain.TipoAutorizacion;
import com.grupocastores.Requisiciones.service.domain.UpdateCantidadRequerida;
import com.grupocastores.Requisiciones.service.domain.UpdateObservaciones;
import com.grupocastores.Requisiciones.service.domain.ValidaUnidades;
import com.grupocastores.Requisiciones.service.domain.RequisicionClasificacion;
import com.grupocastores.Requisiciones.service.domain.RefaccionesRev;
import com.grupocastores.Requisiciones.service.domain.RequisicionSocios;
import com.grupocastores.Requisiciones.service.domain.HerramientaDestino;
import com.grupocastores.Requisiciones.service.domain.HerramientaDestinoAgrupada;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionAgrupadaAutorizada;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionAgrupadaExt;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionesAgrupadas;

/**
 * Requisiciones Service, define el caso de uso del API
 *
 * @author Castores - Desarrollo TI
 *
 */
public interface IRequisicionesService 
{
	List<Requisiciones> getAll();

	Requisiciones save(Requisiciones requisiciones);

	Requisiciones update(Requisiciones requisiciones);

	Requisiciones delete(Integer idrequisicion);

	Requisiciones getById(Integer idrequisicion);
	
	/**
	 * getGridRequisiciones: obtiene grid de requisiciones.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-07-04
	 */
	ResponseDTO<List<CatalogoRequisiciones>> getGridRequisiciones(int anio, int almacen, int tipoalmacen);
	
	/**
	 * getGridRequisiciones: obtiene grid de requisiciones por almacen.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-07-24
	 */
	ResponseDTO<List<CatalogoRequisiciones>> getGridRequiPorAlmacen(int anio, int idAlmacen);
	
	/**
	 * getGridRequisiciones: obtiene grid de requisiciones por anio.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-07-24
	 */
	ResponseDTO<List<CatalogoRequisiciones>> getGridRequiPorAnio(int anio, int idAlmacen, int mes, int tipoalmacen);
	
	/**
	 * getAlmacenes: obtiene los almacenes.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<Almacen>>
	 * @throws Exception 
	 * @date 2023-07-04
	 */
	ResponseDTO<List<CatalogoAlmacen>> getAlmacen(int tipoAlmacen, String nomAlmacen);
	
	/**
	 * getSemaforoSiat: obtiene semaforo siat.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<Almacen>>
	 * @throws Exception 
	 * @date 2023-08-08
	 */
	ResponseDTO<List<SemaforoSiat>> getSemaforoSiat(int estatus);
	
	/**
	 * createCuerpoDetalle: inserta registro en Cuerpo Detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-07-28
	 */
	public ResponseDTO<Boolean> createCuerpoDetalle(CuerpoDetalle cuerpoDetalle);
	
	/**
	 * createRequisicionRefClasificacion: inserta registro en RequisicionRefClasificacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-07-28
	 */
	public ResponseDTO<Boolean> createRequisicionRefClasificacion(RequisicionRefClasificacion requisicionRefClasificacion);
	
	/**
	 * createRequisicionHistorico: inserta registro en RequisicionHistorico
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-07-28
	 */
	public ResponseDTO<Boolean> createRequisicionHistorico(RequisicionHistorico requisicionHistorico);
	
	/**
	 * createRequisicionAnio: inserta registro en RequisicionAnio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-07-28
	 */
	public ResponseDTO<Boolean> createRequisicionAnio(RequisicionAnio requisicionAnio, int anio);
	
	/**
	 * getFolio: obtiene folios siat.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<Folio>>
	 * @throws Exception 
	 * @date 2023-09-15
	 */
	ResponseDTO<List<Folio>> getFolio(int tipofolio);
	
	/**
	 * getRefPorAlmacen: obtiene refaccion por almacen.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<RefaccionPorAlmacen>>
	 * @throws Exception 
	 * @date 2023-08-10
	 */
	ResponseDTO<List<RefaccionPorAlmacen>> getRefPorAlmacen(int idalmacen, int tiporef);
	
	/**
	 * getProveedorRef: obtiene proveedor de refaccion.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<ProveedorRefaccion>>
	 * @throws Exception 
	 * @date 2023-08-10
	 */
	ResponseDTO<List<ProveedorRefaccion>> getProveedorRef(int idrefaccion);
	
	/**
	 * getArrRefaccionesRev: obtiene proveedor de refaccion si tienen convenio.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<RefaccionesRev>>
	 * @throws Exception 
	 * @date 2023-08-21
	 */
	ResponseDTO<List<RefaccionesRev>> getArrRefaccionesRev(String refaccionesRev);
	
	/**
	 * createAutorizaciones: inserta registro en Autorizaciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-08-21
	 */
	public ResponseDTO<Boolean> createAutorizaciones(Autorizaciones autorizaciones);
	
	/**
	 * getTipoAutorizacion: obtiene tipo de autorizacion.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<TipoAutorizacion>>
	 * @throws Exception 
	 * @date 2023-08-21
	 */
	ResponseDTO<List<TipoAutorizacion>> getTipoAutorizacion(int idtipoautorizacion);
	
	/**
	 * getRefaccionesEnConvenio: obtiene si la refaccion cuenta con un convenio.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<RefaccionesConvenio>>
	 * @throws Exception 
	 * @date 2023-08-22
	 */
	ResponseDTO<List<RefaccionesConvenio>> getRefaccionesEnConvenio(int idrefaccion);
	
	/**
	 * getRefaccionesEnConvenioProv: obtiene tipo de autorizacion.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<RefaccionesConvenio>>
	 * @throws Exception 
	 * @date 2023-08-22
	 */
	ResponseDTO<List<RefaccionesConvenio>> getRefaccionesEnConvenioProv(int idrefaccion, int idproveedor);
	
	/**
	 * getListadoRequisiciones: obtiene listado de requisiciones.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<ListadoRequisicion>>
	 * @throws Exception 
	 * @date 2023-08-22
	 */
	ResponseDTO<List<ListadoRequisicion>> getListadoRequisiciones(int idrefaccion, int idrequisicion);
	
	/**
	 * getCantidadListado: obtiene la cantidad del listado de requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-13
	 */
	ResponseDTO<List<CantidadReq>> getCantidadListado(int idrefaccion, int idrequisicion);
	
	/**
	 * getCantidadReq: obtiene la cantidad requisicion.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<CantidadReq>>
	 * @throws Exception 
	 * @date 2023-08-23
	 */
	ResponseDTO<List<CantidadReq>> getCantidadReq(int anio, String idrequisicion, int almacen,int idrefaccion);
	
	/**
	 * getCantidadConvenio: obtiene la cantidad si la refaccion tiene convenio.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<CantidadReq>>
	 * @throws Exception 
	 * @date 2023-08-23
	 */
	ResponseDTO<List<CantidadReq>> getCantidadConvenio(int idrefaccion);
	
	/**
	 * getCantidadNoConvenio: obtiene la cantidad si la refaccion no tiene convenio.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<CantidadNoConv>>
	 * @throws Exception 
	 * @date 2023-08-23
	 */
	ResponseDTO<List<CantidadNoConv>> getCantidadNoConvenio(int idrefaccion, int almacen);
	
	/**
	 * createFolio: inserta registro en folios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-07-28
	 */
	public ResponseDTO<Boolean> createFolio(Folio folio, int tipofolio);
	
	/**
	 * getSocios: obtiene socios.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<CatalogoSocios>>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	ResponseDTO<List<CatalogoSocios>> getSocios(String nombre);
	
	/**
	 * getUnidades: obtiene unidad por noeconomico.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<ValidaUnidades>>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	ResponseDTO<List<ValidaUnidades>> getUnidadEco(int socio, int noeconomico);
	
	/**
	 * getUnidades: obtiene unidad por serie.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<ValidaUnidades>>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	ResponseDTO<List<ValidaUnidades>> getUnidadSerie(int socio, String serie);
	
	/**
	 * getRelacionConsig: obtiene la relacion consignacion de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<ValidaUnidades>>
	 * @throws Exception 
	 * @date 2023-09-14
	 */
	ResponseDTO<List<RefaccionConsignacion>> getRelacionConsig(int idrefaccion);
	
	/**
	 * createHerramientaDestino: inserta registro en herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-09-14
	 */
	public ResponseDTO<Boolean> createHerramientaDestino(HerramientaDestino herramienta);
	
	/**
	 * createRequisicionSocios: inserta registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-09-14
	 */
	public ResponseDTO<Boolean> createRequisicionSocios(RequisicionSocios socios);
	
	/**
	 * createCuerpoRequisicionAnio: inserta registro en cuerpo requisicion anio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-09-15
	 */
	public ResponseDTO<Boolean> createCuerpoRequisicionAnio(CuerpoRequisicionAnio cuerpoRequisicionAnio, int anio);
	
	/**
	 * createRequisiciones: inserta registro en requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-09-15
	 */
	public ResponseDTO<Boolean> createRequisiciones(SiatRequisiciones siatRequisiciones);
	
	/**
	 * getClasificacionRef: obtiene la clasificacion de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<ClasificacionRef>>
	 * @throws Exception 
	 * @date 2023-09-18
	 */
	ResponseDTO<List<ClasificacionRef>> getClasificacionRef(int idrefaccion);
	
	/**
	 * getModHistoricoOrdenCompra: obtiene la información para la modificacion de orden compra.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	ResponseDTO<List<GetModRequisicion>> getModRequisicion(int anio, int idrequisicion);
	
	/**
	 * getModRequisicionesHistorico: obtiene la información para la modificacion de requisicio historico.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	ResponseDTO<List<GetModRequisicionesHistorico>> getModRequisicionesHistorico(int idrequisicion);
	
	/**
	 * getModRequisiciones: obtiene la información para la modificacion de requisicion.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	ResponseDTO<List<GetModHistoricoOrdenCompra>> getModHistoricoOrdenCompra(int idrequisicion);
	
	/**
	 * getModUrgencia: obtiene la información para la modificacion de urgencia y almacen.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	ResponseDTO<List<GetModUrgencia>> getModUrgencia(int anio, int idrequisicion);
	
	/**
	 * getModUrgencia: obtiene la información para la modificacion de urgencia y almacen.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	ResponseDTO<List<GetModHerrDestino>> getModHerrDestino(int idrequisicion);
	
	/**
	 * getModUrgencia: obtiene la información para la modificacion de urgencia y almacen.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	ResponseDTO<List<GetModSocios>> getModSocios(int idrequisicion);
	
	/**
	 * getAcomuladoCuerpoDet: obtiene la cantidad del cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-25
	 */
	ResponseDTO<List<CantidadReq>> queryGetAcomuladoCuerpoDet(int idrequisicion);
	
	/**
	 * updateCantidadRequi:update registro en requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	public ResponseDTO<Boolean> updateCantidadRequerida(UpdateCantidadRequerida updateCantidadRequerida, int anio, int idrequisicion, int idrefaccion);
	
	/**
	 * updateRequisicionSocios:update registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	public ResponseDTO<Boolean> updateRequisicionSocios(RequisicionSocios socios, int idrequisicion, int idrefaccion);
	
	/**
	 * updateRequisicionHerramientaDestino:update registro en requisicion herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	public ResponseDTO<Boolean> updateRequisicionHerramientaDestino (HerramientaDestino herramienta, int idrequisicion, int idrefaccion);
	
	/**
	 * deleteCuerpoDetalle:delete registro en cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	public ResponseDTO<Boolean> deleteCuerpoDetalle(int idrequisicion, int idrefaccion);
	
	/**
	 * deleteCuerpoRequisicionAnio :delete registro en cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	public ResponseDTO<Boolean> deleteCuerpoRequisicionAnio(int anio, int idrequisicion, int idrefaccion);
	
	/**
	 * deleteRequisicionSocios :delete registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	public ResponseDTO<Boolean> deleteRequisicionSocios(int idrequisicion, int idrefaccion);
	
	/**
	 * deleteRequisicionHerramientaDestino :delete registro en requisicion herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	public ResponseDTO<Boolean> deleteRequisicionHerramientaDestino(int idrequisicion, int idrefaccion);
	
	/**
	 * deleteRequisicionRefClas :delete registro en requisicion refaccion clasificacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	public ResponseDTO<Boolean> deleteRequisicionRefClas(int idrequisicion, int idrefaccion);
	
	/**
	 * cancelarRequisiciones: cancela la requisicion en la tabla requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	public ResponseDTO<Boolean> cancelarRequisicionAnio(int anio,int idrequisicion);
	
	/**
	 * cancelarRequisiciones: cancela la requisicion en la tabla requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	public ResponseDTO<Boolean> cancelarRequisiciones(int idrequisicion);
	
	/**
	 * cancelarCuerpoRequisicionAnio: cancela el cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-27
	 */
	public ResponseDTO<Boolean> cancelarCuerpoRequisicionAnio(int anio,int idrequisicion);
	
	/**
	 * updateRequisicionAnio: hace un update en las observaciones la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	public ResponseDTO<Boolean> updateRequisicionAnio(UpdateObservaciones ra,int anio,int idrequisicion);
	
	/**
	 * updateRequisiciones: update en la tabla requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-28
	 */
	public ResponseDTO<Boolean> updateRequisiciones(int idrequisicion, int idestatus);
	
	/**
	 * updateEstatusRequisicionAnio: hace un update idestatus en las observaciones la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-28
	 */
	public ResponseDTO<Boolean> updateEstatusRequisicionAnio(int anio,int idrequisicion, int idestatus);
	
	/**
	 * getGridRequisicionesAgrupada: obtiene grid de requisiciones.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-10-05
	 */
	ResponseDTO<List<CatalogoRequisicionesAgrupadas>> getGridRequisicionesAgrupada(int anio, int almacen, int mes, int tipoAlmacen);
	
	/**
	 * getGridRequisicionesAgrupada: obtiene grid de requisiciones por autorizar.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-10-05
	 */
	ResponseDTO<List<CatalogoRequisicionesPorAutorizar>> getGridRequisicionesPorAutorizar(int anio, int almacen, int mes, int tipoAlmacen);
	
	/**
	 * getGridDetalleRequisicionAgrupada: obtiene grid del detalle de requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-10-05
	 */
	ResponseDTO<List<DetalleRequisicionAgrupada>> getGridDetalleRequisicionAgrupada(int anio, int idalmacen, int mes,int tipoAlmacen, int tiposubrequisicion);
	
	/**
	 * getGridDetalleRequisicionAgrupadaSocio: obtiene grid del detalle de requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-10-05
	 */
	ResponseDTO<List<DetalleRequisicionAgrupada>> getGridDetalleRequisicionAgrupadaSocio(int anio, int idalmacen, int mes,int tipoAlmacen, int tiposubrequisicion, int idsocio);

	/**
	 * insertRequisicionAgrupada:inserta registro en requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-10
	 */
	public ResponseDTO<Boolean> createRequisicionAgrupada (InsertRequisicionesAgrupadas iReqAg, int anio);
	
	/**
	 * insertRequisicionAgrupadaExt:inserta registro en requisicion agrupada extension
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-10
	 */
	public ResponseDTO<Boolean> createRequisicionAgrupadaExt (InsertRequisicionAgrupadaExt iReqAgExt, int anio) ;
	
	/**
	 * insertRequisicionClasificacion :inserta registro en requisicion clasificacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-12
	 */
	public ResponseDTO<Boolean> createRequisicionClasificacion (RequisicionClasificacion ReqClaf) ;
	
	/**
	 * getListadoRequisicionAgrupada: obtiene el listado de requisiciones agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-25
	 */
	ResponseDTO<List<ListadoRequisicion>> getListadoRequisicionesAgrupadas(int anio, int idrefaccion, int idrequisicion);
	
	/**
	 * getCantidadListadoAgrupada: obtiene la cantidad del listado de requisiciones agrupadas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-25
	 */
	ResponseDTO<List<CantidadReq>> getCantidadListadoAgrupadas(int anio, int idrefaccion, int idrequisicion);
	
	/**
	 * getCantidadReqAgrupada: obtiene la cantidad de la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-25
	 */
	ResponseDTO<List<CantidadReq>> getCantidadReqAgrupadas(int anio, String idrequisicion, int almacen,int idrefaccion);
	
	/**
	 * deleteRequisicionAgrupada :delete registro en requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	public ResponseDTO<Boolean> deleteRequisicionAgrupada(int anio, int idrequisicion);
	
	/**
	 * deleteAgrupadaExtension :delete registro en requisicion agrupada extension
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	public ResponseDTO<Boolean> deleteAgrupadaExtension(int anio, int idrequisicion);
	
	/**
	 * getModRequisicionesAgrupadas: obtiene la información para la modificacion de requisicion agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	ResponseDTO<List<GetModRequisicionAgrupada>> getModRequisicionAgrupada(int anio, int idrequisicion);
	
	/**
	 * getModSociosAgrupada: obtiene la información para la modificacion de socios agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	ResponseDTO<List<GetModSociosAgrupada>> getModSociosAgrupada(int anio, int idrequisicion);
	
	/**
	 * cancelarRequisicionAgrupada: cancela la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	public ResponseDTO<Boolean> cancelarRequisicionAgrupada(int anio,int idrequisicion);
	
	/**
	 * updateRequisicionAgrupada: hace un update en las observaciones la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	public ResponseDTO<Boolean> updateRequisicionAgrupada(UpdateObservaciones ra, int anio, int idrequisicion);

	
	/**
	 * updateCantidadSolicitadaAgrupda:update registro en requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	public ResponseDTO<Boolean> updateCantidadSolicitadaAgrupada(UpdateCantidadRequerida updateCantidadRequerida, int anio, int idrequisicion, int idrefaccion);
	
	/**
	 * updateRequisicionSociosAgrupada:update registro en requisicion socios agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */ ResponseDTO<Boolean> updateRequisicionSociosAgrupada(RequisicionSocios socios, int idrequisicion, int idrefaccion);
	
	/**
	 * updateRequisicionHerramientaDestino:update registro en requisicion herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	public ResponseDTO<Boolean> updateRequisicionHerramientaDestinoAgrupada(HerramientaDestinoAgrupada herramienta, int idrequisicion, int idrefaccion);

	/**
	 * createRequisicionHistoricoAgrupadas: Servicio insertar para Requisicion Historico Agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-11-02
	 */
	public ResponseDTO<Boolean> createRequisicionHistoricoAgrupadas(RequisicionHistorico requisicionHistorico);
	
	/**
	 * getModRequisicionesHistoricoAgrupadas: obtiene la información para la modificacion de requisicio historico agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	ResponseDTO<List<GetModRequisicionesHistorico>> getModRequisicionesHistoricoAgrupadas(int idrequisicion);
	
	/**
	 * updateClaveAutorizada:update registro en la refaccion con clave autorizada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	public ResponseDTO<Boolean> updateClaveAutorizada( int anio, int idrefaccion, int tiposolicitud, int claveautorizada);
	
	/**
	 * updateEstatusRefaccion:update estatus en la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	public ResponseDTO<Boolean> updateEstatusRefaccion( int anio, int idrefaccion, int tiposolicitud, int idsocio, int idestatusrefaccion);
	
	/**
	 * insertRequisicionAgrupadaAutoriza:inserta registro en requisicion agrupada autoriza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	public ResponseDTO<Boolean> createRequisicionAgrupadaAutoriza (InsertRequisicionAgrupadaAutorizada iReqAg);
	
	/**
	 * getListObtenerIdRequisicion: obtiene liestado de la id requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-11-08
	 */
	ResponseDTO<List<ListadoRequisicionAutorizada>> getListObtenerIdRequisicion(int anio, int idalmacen, int mes,int tipoAlmacen, int tiposubrequisicion,int idrefaccion);

	/**
	 * getListObtenerRefaccionesCanceladas: obtiene liestado de la id requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-11-08
	 */
	ResponseDTO<List<ObtenerRefaccionesCanceladas>> getListObtenerRefaccionesCanceladas(int anio,int idrequisicion);
	
	/**
	 * updateEstatusRequisicion:update estatus en la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	public ResponseDTO<Boolean> updateEstatusRequisicion(int anio, int idrequisicion, int idestatus);
	
	/**
	 * updateEstatusRequisicion:update estatus en la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	public ResponseDTO<Boolean> updateEstatusRequisicionProgramada();
	
	/**
	 * updateEstatusRefaccionProgramada:update estatus en la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	public ResponseDTO<Boolean> updateEstatusRefaccionProgramada();
	
	/**
	 * getListInformacionRequisicion: obtiene la informacion de la requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<ObtenerInformacionRequisicion>>
	 * @throws Exception 
	 * @date 2023-11-10
	 */
	ResponseDTO<List<ObtenerInformacionRequisicion>> getListInformacionRequisicion(int anio,int idrequisicion);
	
	/**
	 * getRequisicionSeguimiento: obtiene la informacion de la requisiciones seguimiento.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<RequisicionAutorizada>>
	 * @throws Exception 
	 * @date 2023-11-10
	 */
	ResponseDTO<List<RequisicionAutorizada>> getRequisicionSeguimiento(int anio, int tipoAlmacen, int mes);
}
