package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de proveedores", description = "mapea tabla de siat.proveedores")
@Entity
@Table(name = "siat.proveedores")
public class ProveedorRefaccion {
	
	@Id
	@Column(name="idproveedor")
	private int idproveedor;
	@Column(name="idrefaccion")
	private int idrefaccion;
	@Column(name="razonsocial")
	private String razonsocial;
	@Column(name = "tel1")
	private String tel1;
}
