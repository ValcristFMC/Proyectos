package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de CatalogoRequisiciones", description = "mapea tabla de siat.requisiciones")
@Entity
@Table(name = "siat.requisiciones2023")
public class CatalogoRequisicionesPorAutorizar {
	
	@Id
	@Column(name = "hora")
	private LocalTime hora;
	@Column(name="idtiposubrequisicion")
	private int idtiposubrequisicion;
	@Column(name="idtiporequisicion")
	private int idtiporequisicion;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "idalmacen")
	private int idalmacen;
	@Column(name = "nomAlmacen")
	private String nomAlmacen;
	@Column(name = "fechaAgrupada")
	private String fechaAgrupada;
	@Column(name = "mesFecha")
	private String mesFecha;
	@Column(name = "tipoAlmacen")
	private int tipoAlmacen;
	@Column(name = "idsocio")
	private int idsocio;
	@Column(name = "nombreSocio")
	private String nombreSocio;
}
