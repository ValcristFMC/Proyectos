package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Tipo Autorizacion", description = "mapea tabla de siat.tipoautorizacion")
@Entity
@Table(name = "siat.tipoautorizacion")
public class TipoAutorizacion {
	
	@Id
	@Column(name="idtipoautorizacion")
	private int idtipoautorizacion;
	@Column(name = "tipoautorizacion")
	private String tipoautorizacion;
	@Column(name = "permisopedido")
	private int permisopedido;
	@Column(name = "idpersonal")
	private int idpersonal;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
}
