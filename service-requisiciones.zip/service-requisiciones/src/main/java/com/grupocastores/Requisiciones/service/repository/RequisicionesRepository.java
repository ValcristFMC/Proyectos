package com.grupocastores.Requisiciones.service.repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.Query;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.bouncycastle.cert.ocsp.Req;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.grupocastores.Requisiciones.service.domain.Requisiciones;
import com.grupocastores.Requisiciones.utils.UtilitiesRepository;
import com.grupocastores.Requisiciones.utils.UtilsFileManager;
import com.grupocastores.Requisiciones.service.domain.CuerpoDetalle;
import com.grupocastores.Requisiciones.service.domain.CuerpoRequisicionAnio;
import com.grupocastores.Requisiciones.service.domain.DetalleRequisicionAgrupada;
import com.grupocastores.Requisiciones.service.domain.Folio;
import com.grupocastores.Requisiciones.service.domain.GetModHerrDestino;
import com.grupocastores.Requisiciones.service.domain.GetModHistoricoOrdenCompra;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicion;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicionAgrupada;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicionesHistorico;
import com.grupocastores.Requisiciones.service.domain.GetModSocios;
import com.grupocastores.Requisiciones.service.domain.GetModSociosAgrupada;
import com.grupocastores.Requisiciones.service.domain.GetModUrgencia;
import com.grupocastores.Requisiciones.service.domain.ListadoRequisicion;
import com.grupocastores.Requisiciones.service.domain.ListadoRequisicionAutorizada;
import com.grupocastores.Requisiciones.service.domain.ObtenerInformacionRequisicion;
import com.grupocastores.Requisiciones.service.domain.ObtenerRefaccionesCanceladas;
import com.grupocastores.Requisiciones.service.domain.ProveedorRefaccion;
import com.grupocastores.Requisiciones.service.domain.RefaccionConsignacion;
import com.grupocastores.Requisiciones.service.domain.RefaccionPorAlmacen;
import com.grupocastores.Requisiciones.service.domain.RefaccionesConvenio;
import com.grupocastores.Requisiciones.service.domain.RequisicionAnio;
import com.grupocastores.Requisiciones.service.domain.RequisicionAutorizada;
import com.grupocastores.Requisiciones.service.domain.RequisicionClasificacion;
import com.grupocastores.Requisiciones.service.domain.RequisicionHistorico;
import com.grupocastores.Requisiciones.service.domain.RequisicionRefClasificacion;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisiciones;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisicionesAgrupadas;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisicionesPorAutorizar;
import com.grupocastores.Requisiciones.service.domain.CatalogoSocios;
import com.grupocastores.Requisiciones.service.domain.ClasificacionRef;
import com.grupocastores.Requisiciones.service.domain.Autorizaciones;
import com.grupocastores.Requisiciones.service.domain.CantidadNoConv;
import com.grupocastores.Requisiciones.service.domain.CantidadReq;
import com.grupocastores.Requisiciones.service.domain.CatalogoAlmacen;
import com.grupocastores.Requisiciones.service.domain.SemaforoSiat;
import com.grupocastores.Requisiciones.service.domain.SiatRequisiciones;
import com.grupocastores.Requisiciones.service.domain.TipoAutorizacion;
import com.grupocastores.Requisiciones.service.domain.UpdateCantidadRequerida;
import com.grupocastores.Requisiciones.service.domain.UpdateObservaciones;
import com.grupocastores.Requisiciones.service.domain.ValidaUnidades;
import com.grupocastores.Requisiciones.service.domain.RefaccionesRev;
import com.grupocastores.Requisiciones.service.domain.HerramientaDestino;
import com.grupocastores.Requisiciones.service.domain.HerramientaDestinoAgrupada;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionAgrupadaAutorizada;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionAgrupadaExt;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionesAgrupadas;
import com.grupocastores.Requisiciones.service.domain.RequisicionSocios;

/**
 * RequisicionesRepository Repositorio para el almacenamiento de {@link com.grupocastores.Requisiciones.service.domain.Requisiciones} 
 *
 * @author Castores - Desarrollo TI
 *
 */
@Repository
public class RequisicionesRepository 
{
	public static final String DB_13 = "PRUEBAS13";
	
	public static final String AlmacenesCorpo = "28,34,21,6,36,4,10,37,9,15,11,1,2,24,8,3"; 
	
	public static final String AlmacenesForaneos = "27,29,19,25,17,7,5,31,18,35,22,13,26,16,32,14,23,33,20,38"; 
	
	@Autowired
	private UtilitiesRepository utilitiesRepository;

	@Autowired
	private UtilsFileManager utilsFileManager;

	@PersistenceContext
	private EntityManager entityManager;

	static final String queryRequisicionSeguimiento = "SELECT * FROM OPENQUERY (%s, 'SELECT raa.claveautorizada, ra.idtiporequisicion, ra.idtiposubrequisicion, raa.fecha AS fechaautorizada, ra.idestatus, ra.idalmacen, ra.tipoAlmacen, p.razonsocial  FROM siat.requisicionagrupadaautorizada raa LEFT JOIN siat.agrupadaextencion%s ae ON ae.claveautorizada = raa.claveautorizada LEFT JOIN siat.requisicionagrupada%s ra ON ra.idrequisicion = ae.idrequisicion LEFT JOIN siat.refaproveedor rp ON rp.idrefaccion = ae.idrefaccion LEFT JOIN siat.proveedores p ON  rp.idproveedor = p.idproveedor;');";
	
	static final String queryGetGridRequisiciones = "SELECT * FROM OPENQUERY (%s, 'SELECT r.idrequisicion AS idrequisicion ,r.clave AS clave, u.nombre AS nomUrgencias, r.fecha AS fechaReq, e.nombre AS estatusReq, a.nombre AS nomAlmacen,CONCAT_WS(\" \", p1.apepaterno, p1.apematerno, p1.nombre) AS autoriza, CONCAT_WS(\" \", p2.apepaterno, p2.apematerno, p2.nombre) AS revisa, rc.tipoalmacen, rc.idtiporequisicion, rc.idsubtiporequisicion FROM siat.requisicion%s r LEFT JOIN  siat.estatus  e ON e.idestatus  = r.idestatus AND e.tipo= 1 LEFT JOIN  siat.urgencia u ON u.idurgencia = r.idurgencia LEFT JOIN  siat.almacen  a ON a.idalmacen  = r.idalmacen LEFT JOIN  personal.personal p1 ON p1.idpersonal = r.idautoriza LEFT JOIN  personal.personal p2 ON p2.idpersonal = r.idreviso LEFT JOIN siat.requisicionesautomaticas ra ON ra.idrequisicion=r.idrequisicion LEFT JOIN siat.requisicionclasificacion rc ON rc.idrequisicion = r.idrequisicion WHERE a.idalmacen = %s AND MONTH(r.fecha) = %s AND rc.tipoalmacen = %s ORDER BY r.idrequisicion DESC');";  
	
	static final String queryGetGridRequiPorAlmacen = "SELECT * FROM OPENQUERY (%s, 'SELECT r.idrequisicion AS idrequisicion ,r.clave AS clave, u.nombre AS nomUrgencias, r.fecha AS fechaReq, e.nombre AS estatusReq, a.nombre AS nomAlmacen,CONCAT_WS(\" \", p1.apepaterno, p1.apematerno, p1.nombre) AS autoriza, CONCAT_WS(\" \", p2.apepaterno, p2.apematerno, p2.nombre) AS revisa FROM siat.requisicion%s r LEFT JOIN  siat.estatus  e ON e.idestatus  = r.idestatus AND e.tipo= 1 LEFT JOIN  siat.urgencia u ON u.idurgencia = r.idurgencia LEFT JOIN  siat.almacen  a ON a.idalmacen  = r.idalmacen LEFT JOIN  personal.personal p1 ON p1.idpersonal = r.idautoriza LEFT JOIN  personal.personal p2 ON p2.idpersonal = r.idreviso LEFT JOIN siat.requisicionesautomaticas ra ON ra.idrequisicion=r.idrequisicion WHERE a.idalmacen = %s');";  
	
	static final String queryGetGridRequiPorAnio = "SELECT * FROM OPENQUERY (%s, 'SELECT r.idrequisicion AS idrequisicion ,r.clave AS clave, u.nombre AS nomUrgencias, r.fecha AS fechaReq, e.nombre AS estatusReq, a.nombre AS nomAlmacen,CONCAT_WS(\" \", p1.apepaterno, p1.apematerno, p1.nombre) AS autoriza, CONCAT_WS(\" \", p2.apepaterno, p2.apematerno, p2.nombre) AS revisa, rc.tipoalmacen, rc.idtiporequisicion, rc.idsubtiporequisicion FROM siat.requisicion%s r LEFT JOIN  siat.estatus  e ON e.idestatus  = r.idestatus AND e.tipo= 1 LEFT JOIN  siat.urgencia u ON u.idurgencia = r.idurgencia LEFT JOIN  siat.almacen  a ON a.idalmacen  = r.idalmacen LEFT JOIN  personal.personal p1 ON p1.idpersonal = r.idautoriza LEFT JOIN  personal.personal p2 ON p2.idpersonal = r.idreviso LEFT JOIN siat.requisicionesautomaticas ra ON ra.idrequisicion=r.idrequisicion LEFT JOIN siat.requisicionclasificacion rc ON rc.idrequisicion = r.idrequisicion WHERE a.idalmacen = %s AND MONTH(r.fecha) = %s AND rc.tipoalmacen = %s ORDER BY r.idrequisicion DESC');";  
	
	static final String queryGetAlmacen = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.almacen a where a.idalmacen IN (%s) AND a.nombre LIKE \"%s\" ;');";  
	
	static final String queryInsertCuerpoDetalle = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.cuerpodetalle' ) VALUES('%s','%s','%s','%s','%s','%s')";
	
	static final String queryInsertRequisicionRefClas = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.requisicionrefaccionclasificacion' ) VALUES('%s','%s','%s')";
	
	static final String queryInsertRequisicionHistorico = "EXEC('INSERT INTO siat.requisicionhistorico VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\")') AT %s";

	static final String queryInsertRequisicionAnio = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.requisicion%s' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryGetSemaforo = "SELECT * FROM OPENQUERY ( %s  , 'SELECT s.*, CONCAT_WS(\" \", p.apepaterno, p.apematerno, p.nombre) AS nompersonal FROM siat.semaforosiat s LEFT JOIN  personal.personal p ON p.idpersonal = s.idpersonal WHERE idsemaforosiat = %s;');";	
	
	static final String queryGetFolio = "SELECT * FROM OPENQUERY (" + DB_13 + ", 'SELECT * FROM siat.folios WHERE tipofolio = %s;');";  
	
	static final String queryGetRefPorAlmacen = "SELECT * FROM OPENQUERY (" + DB_13 + ", 'SELECT r.idrefaccion, r.clave, r.nombre, r.idmedida, ra.estatus, m.nombre AS nombrePieza, m.tipo_medida, rd.presentacion FROM siat.refacciones r INNER JOIN siat.refacciones_por_almacen ra ON r.idrefaccion = ra.idrefaccion LEFT JOIN siat.medidas m ON m.idmedida = r.idmedida LEFT JOIN siat.refacciones_datosadicionales rd ON rd.id_refaccion = r.idrefaccion WHERE ra.estatus = 1 AND ra.idalmacen = %s AND r.tiporef = %s;');";  
	
	static final String queryGetProveedorRef = "SELECT * FROM OPENQUERY (%s, 'SELECT rp.idproveedor,rp.idrefaccion,p.razonsocial,p.tel1 FROM siat.refaproveedor rp LEFT JOIN siat.proveedores p ON  rp.idproveedor = p.idproveedor WHERE rp.idrefaccion = %s;');";  

	static final String queryGetArrRefaccionesRev = "SELECT * FROM OPENQUERY (" + DB_13 + ", 'SELECT r.clave, r.nombre, c.idconvenio, r.idrefaccion FROM siat.convenios c INNER JOIN siat.cuerpoconvenio cc ON c.idconvenio = cc.idconvenio INNER JOIN siat.refacciones r ON cc.idrefaccion = r.idrefaccion WHERE c.estatus = 1  AND cc.idrefaccion IN (\"%s\");');";  

	static final String queryGetTipoAutorizacion = "SELECT * FROM OPENQUERY (" + DB_13 + ", 'SELECT * FROM siat.tipoautorizacion WHERE idtipoautorizacion = %s;');";  
	
	static final String queryInsertAutorizaciones = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.autorizaciones' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryGetRefaccionesEnConvenio = "SELECT * FROM OPENQUERY (%s, 'SELECT c.idconvenio, cc.idrefaccion FROM siat.convenios c, siat.cuerpoconvenio cc WHERE c.idconvenio = cc.idconvenio AND cc.idrefaccion = %s AND c.estatus IN (1,3) AND cc.cantidad = cc.cantidad_surtida;');";  
	
	static final String queryGetRefaccionesEnConvenioProv = "SELECT * FROM OPENQUERY (%s, 'SELECT c.idconvenio, cc.idrefaccion FROM siat.convenios c, siat.cuerpoconvenio cc WHERE c.idconvenio = cc.idconvenio AND cc.idrefaccion = %s AND c.estatus IN (1,3) AND cc.cantidad = cc.cantidad_surtida AND c.idproveedor = %s;');";  
	
	static final String queryGetListadoRequisicion = "SELECT * FROM OPENQUERY (%s, 'SELECT re.idrequisicion FROM siat.cuerpodetalle cu INNER JOIN siat.requisiciones re ON re.idrequisicion = cu.idrequisicion AND re.idestatus NOT IN (3,4,8,9) WHERE cu.idrefaccion =  %s AND cu.idrequisicion <> %s;');";  

	static final String queryGetCantidadListado = "SELECT * FROM OPENQUERY (%s, 'SELECT cast(SUM(cu.cantrequisicion - cu.cantentrada)as decimal(38,6)) AS cantidad FROM siat.cuerpodetalle cu INNER JOIN siat.requisiciones re ON re.idrequisicion = cu.idrequisicion AND re.idestatus NOT IN (3,4,8,9) WHERE cu.idrefaccion =  %s AND cu.idrequisicion <> %s;');";  
	
	static final String queryGetCantidadReq = "SELECT * FROM OPENQUERY (%s, 'SELECT cast(SUM(cu.cantrequisicion - cu.cantentrada)as decimal(38,6)) AS cantidad FROM siat.cuerpodetalle cu  INNER JOIN siat.requisicion%s re ON re.idrequisicion = cu.idrequisicion WHERE cu.idrequisicion IN (%s) AND re.idalmacen = %s AND cu.idrefaccion = %s;');";  

	static final String queryGetCantidadConvenio = "SELECT * FROM OPENQUERY (%s, 'SELECT cantidad FROM siat.convenios c INNER JOIN siat.cuerpoconvenio cc ON c.idconvenio = cc.idconvenio WHERE c.estatus = 1  AND idrefaccion = %s;');";  

	static final String queryGetCantidadNoConvenio = "SELECT * FROM OPENQUERY (%s, 'SELECT existencia, maximo  FROM siat.refacciones_por_almacen  WHERE idrefaccion = %s AND idalmacen = %s;');";  

	static final String queryInsertFolio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.folios WHERE tipofolio = %s' ) SET tipofolio = '%s', idfolio = '%s', clavefolio = '%s', descripcion = '%s'   ";
	
	static final String queryGetSocios = "SELECT * FROM OPENQUERY ( %s  , 'SELECT s.idsocio, c.nombre, s.acciones, CONCAT_WS(\" \", p.apepaterno, p.apematerno, p.nombre) AS altapor, s.estatus, s.fecha, s.hora FROM siat.sociossiat AS s, camiones.socios AS c, personal.personal AS p WHERE s.idsocio = c.idpersonal AND s.idpersonal = p.idpersonal AND c.nombre LIKE \"%s\" ORDER BY c.nombre');";	
	
	static final String queryGetUnidadEco = "SELECT * FROM OPENQUERY (%s, 'SELECT u.idunidad, u.noeconomico, u.socio, u.serie FROM camiones.unidades u WHERE u.socio =  %s AND u.noeconomico = %s AND u.estatus = 1');";  

	static final String queryGetUnidadSerie = "SELECT * FROM OPENQUERY (%s, 'SELECT u.idunidad, u.noeconomico, u.socio, u.serie FROM camiones.unidades u WHERE u.socio =  %s AND u.serie = \"%s\";');";  

	static final String queryGetRefaccionConsig = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.relacion_consignacion rc WHERE rc.idrefaccion =  %s;');";  

	static final String queryInsertHerramientaDestino = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.requisicionherramientadestino' ) VALUES('%s','%s','%s','%s','%s','%s')";

	static final String queryInsertRequisicionSocios = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.requisicionsocios' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryInsertCuerpoRequisicionAnio = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.cuerporequisicion%s' ) VALUES('%s','%s','%s','%s','%s','%s')";

	static final String queryInsertRequisiciones = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.requisiciones' ) VALUES('%s','%s','%s','%s','%s','%s','%s')";

	static final String queryGetClasificacionRefaccion = "SELECT * FROM OPENQUERY (%s, 'SELECT rc.idrefaccion, rc.idclasificacion FROM siat.refacciones_clasificacion_relacion rc WHERE rc.idrefaccion = %s;');";  

	static final String queryGetModRequisiciones = "SELECT * FROM OPENQUERY (%s, 'SELECT  r.idrefaccion, ra.idrequisicion,  r.clave, cr.cantsolicitada ,cr.idmedida, m.nombre AS nombrePieza, m.tipo_medida, ra.observaciones, alm.nombre AS nomAlmacen, e.nombre AS estatus, r.nombre AS nomRefaccion, rc.idsubtiporequisicion AS tipoRef, alm.idalmacen, ra.idpersonal, CONCAT_WS(\" \", p1.apepaterno, p1.apematerno, p1.nombre) AS autoriza, rd.presentacion FROM siat.requisicion%s ra LEFT JOIN siat.cuerporequisicion%s cr ON ra.idrequisicion = cr.idrequisicion LEFT JOIN siat.refacciones r ON cr.idrefaccion =  r.idrefaccion LEFT JOIN siat.medidas m ON m.idmedida = r.idmedida LEFT JOIN siat.almacen alm ON alm.idalmacen = ra.idalmacen LEFT JOIN siat.estatus e ON cr.idestatus = e.idestatus AND e.tipo= 2 LEFT JOIN siat.requisicionclasificacion rc ON rc.idrequisicion = ra.idrequisicion LEFT JOIN  personal.personal p1 ON p1.idpersonal = ra.idpersonal LEFT JOIN siat.refacciones_datosadicionales rd ON rd.id_refaccion = r.idrefaccion WHERE ra.idrequisicion = %s ORDER BY ra.hora DESC;');";  

	static final String queryGetModRequisicionesHistorico = "SELECT * FROM OPENQUERY (%s, 'SELECT rh.hora, rh.idrequisicion, rh.fecha, rh.idpersonal, e.nombre AS nombreEstatus, e.idestatus, rh.observaciones, CONCAT_WS(\" \", p1.apepaterno, p1.apematerno, p1.nombre) AS personal FROM siat.requisicionhistorico rh LEFT JOIN siat.estatus e ON rh.idestatus = e.idestatus AND e.tipo= 1  LEFT JOIN  personal.personal p1 ON p1.idpersonal = rh.idpersonal WHERE idrequisicion = %s;');";  

	static final String queryGetModHistoricoOrdenCompra = "SELECT * FROM OPENQUERY (%s, 'SELECT o.idordencompra, o.fecha, e.nombre FROM siat.ordenes o INNER JOIN siat.estatus e ON o.idestatus = e.idestatus AND e.tipo = 3 WHERE idrequisicion = %s;');";  
	
	static final String queryGetModUrgencia = "SELECT * FROM OPENQUERY (%s, 'SELECT r.idrequisicion, u.nombre AS urgencia, a.nombre AS nomAlmacen FROM siat.requisicion%s r LEFT JOIN siat.urgencia u ON r.idurgencia = u.idurgencia LEFT JOIN siat.almacen a ON r.idalmacen = a.idalmacen WHERE r.idrequisicion = %s;');";  

	static final String queryGetModHerrDestino = "SELECT * FROM OPENQUERY (%s, 'SELECT rh.idrequisicion, rh.idalmacen, rh.nombrealmacen FROM siat.requisicionherramientadestino rh WHERE rh.idrequisicion = %s;');";  

	static final String queryGetModSocios= "SELECT * FROM OPENQUERY (%s, 'SELECT rs.idrequisicionsocios, rs.idrequisicion, rs.idsocio, rs.idunidad, rs.noeconomico, rs.serie, s.nombre AS nombreSocio, rs.idrefaccion from siat.requisicionsocios rs LEFT JOIN camiones.socios s ON s.idpersonal = rs.idsocio where rs.idrequisicion = %s ORDER BY rs.hora ASC;');";  
	
	static final String queryGetAcomuladoCuerpoDet = "SELECT * FROM OPENQUERY (%s, 'SELECT SUM(cantordenada) AS cantidad FROM siat.cuerpodetalle WHERE idrequisicion = %s;');";  

	static final String queryUpdateCantidadRequi = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.cuerporequisicion%s WHERE idrequisicion = %s AND idrefaccion = %s' ) SET cantsolicitada = '%s';";

	static final String queryUpdateRequisicionSocios = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicionsocios WHERE idrequisicion = %s AND idrefaccion = %s' )  SET idrequisicion = '%s', idsocio = '%s',idunidad = '%s', noeconomico = '%s', serie = '%s', fecha = '%s', hora = '%s', idrefaccion = '%s';";
	
	static final String queryUpdateRequisicionHerramientaDestino = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicionherramientadestino WHERE idrequisicion = %s AND idrefaccion = %s' ) SET idrequisicion = '%s', idalmacen = '%s', nombreAlmacen = '%s', fecha = '%s', hora = '%s';";
	
	static final String queryDeleteCuerpoDetalle = "DELETE OPENQUERY(%s, 'SELECT * FROM siat.cuerpodetalle WHERE idrequisicion = %s AND idrefaccion = %s');";

	static final String queryDeleteCuerpoRequisicionAnio = "DELETE OPENQUERY(%s, 'SELECT * FROM siat.cuerporequisicion%s WHERE idrequisicion = %s AND idrefaccion = %s');";

	static final String queryDeleteRequisicionSocios = "DELETE OPENQUERY(%s, 'SELECT * FROM siat.requisicionsocios WHERE idrequisicion = %s AND idrefaccion = %s');";
	
	static final String queryDeleteRequisicionHerramientaDestino = "DELETE OPENQUERY(%s, 'SELECT * FROM siat.requisicionherramientadestino WHERE idrequisicion = %s AND idrefaccion = %s');";

	static final String queryDeleteRequisicionRefClas = "DELETE OPENQUERY(%s, 'SELECT * FROM siat.requisicionrefaccionclasificacion WHERE idrequisicion = %s AND idrefaccion = %s');";

	static final String queryCancelarRequisicionAnio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicion%s WHERE idrequisicion = %s' ) SET idestatus = 4;";

	static final String queryCancelarRequisiciones = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisiciones WHERE idrequisicion = %s' ) SET idestatus = 4;";
	
	static final String queryCancelarCuerpoRequisicion = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.cuerporequisicion%s WHERE idrequisicion = %s' ) SET idestatus = 4;";
	
	static final String queryUpdateRequisicionAnio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicion%s WHERE idrequisicion = %s' ) SET observaciones = '%s';";
	
	static final String queryUpdateRequisiciones = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisiciones WHERE idrequisicion = %s' ) SET idestatus = %s;";

	static final String queryUpdateEstatusRequisicionAnio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicion%s WHERE idrequisicion = %s' ) SET idestatus = '%s';";

	static final String queryGetGridRequisicionesAgrupada = "SELECT * FROM OPENQUERY (%s, 'SELECT r.idrequisicion AS idrequisicion ,r.clave AS clave, u.nombre AS nomUrgencias, r.fecha AS fechaReq, e.nombre AS estatusReq, a.nombre AS nomAlmacen,CONCAT_WS(\" \", p1.apepaterno, p1.apematerno, p1.nombre) AS autoriza, CONCAT_WS(\" \", p2.apepaterno, p2.apematerno, p2.nombre) AS revisa, r.tipoAlmacen, r.idtiporequisicion, idtiposubrequisicion, estatusrequisicion FROM siat.requisicionagrupada%s r LEFT JOIN  siat.estatus  e ON e.idestatus  = r.idestatus AND e.tipo= 1 LEFT JOIN  siat.urgencia u ON u.idurgencia = r.idurgencia LEFT JOIN  siat.almacen  a ON a.idalmacen  = r.idalmacen LEFT JOIN  personal.personal p1 ON p1.idpersonal = r.idautoriza LEFT JOIN  personal.personal p2 ON p2.idpersonal = r.idreviso WHERE a.idalmacen IN(%s) AND MONTH(r.fecha) = %s AND r.tipoAlmacen = %s ORDER BY r.idrequisicion DESC');";  
	
	static final String queryGetGridRequisicionesPorAutorizar = "SELECT * FROM OPENQUERY (%s, 'SELECT ra.hora, ra.idtiposubrequisicion, ra.idtiporequisicion, ra.fecha, ra.idalmacen, a.nombre AS nomAlmacen, CURDATE() AS fechaAgrupada,  MONTH(ra.fecha) AS mesFecha, ra.tipoAlmacen, ae.idsocio, s.nombre AS nombreSocio  FROM siat.agrupadaextencion%s ae LEFT JOIN siat.requisicionagrupada%s ra ON ra.idrequisicion = ae.idrequisicion LEFT JOIN  siat.almacen a ON a.idalmacen  = ra.idalmacen LEFT JOIN camiones.socios s ON s.idpersonal = ae.idsocio WHERE a.idalmacen IN(%s) AND MONTH(ra.fecha) = %s AND ra.tipoAlmacen = %s AND ae.idestatusrefaccion = 3 AND ra.idestatus = 2 GROUP BY ra.idtiposubrequisicion, ae.idsocio ORDER BY ra.idtiposubrequisicion ASC');";  

	static final String queryGetGridDetalleRequisicionAgrupada = "SELECT * FROM OPENQUERY (%s, 'SELECT ae.idrefaccion, rd.presentacion, m.nombre AS unidad, SUM(ae.cantsolicitada) AS cantsolicitada, ra.clave, r.nombre AS nomref, g.idgrupo ,g.nombre AS grupo, ra.idtiposubrequisicion, ae.noeconomico, ae.serie  FROM siat.requisicionagrupada%s ra LEFT JOIN siat.agrupadaextencion%s ae ON ra.idrequisicion = ae.idrequisicion LEFT JOIN  siat.almacen a ON a.idalmacen  = ra.idalmacen LEFT JOIN siat.refacciones r ON r.idrefaccion = ae.idrefaccion LEFT JOIN siat.refacciones_datosadicionales rd ON rd.id_refaccion = r.idrefaccion LEFT JOIN siat.medidas m ON m.idmedida = r.idmedida LEFT JOIN siat.grupos g ON r.idgrupo = g.idgrupo WHERE a.idalmacen IN(%s) AND MONTH(ra.fecha) = %s AND ra.tipoAlmacen = %s AND ra.estatusrequisicion = 1 AND ra.idestatus = 2 AND ra.idtiposubrequisicion = %s AND ae.cantsolicitada <> 0 AND ae.idestatusrefaccion = 3 GROUP BY ae.idrefaccion ORDER BY ra.idtiposubrequisicion DESC');";  
	
	static final String queryGetGridDetalleRequisicionAgrupadaSocio = "SELECT * FROM OPENQUERY (%s, 'SELECT ae.idrefaccion,rd.presentacion, m.nombre AS unidad, SUM(ae.cantsolicitada) AS cantsolicitada, ra.clave, r.nombre AS nomref, g.idgrupo ,g.nombre AS grupo, ra.idtiposubrequisicion, ae.noeconomico, ae.serie  FROM siat.requisicionagrupada%s ra LEFT JOIN siat.agrupadaextencion%s ae ON ra.idrequisicion = ae.idrequisicion LEFT JOIN  siat.almacen a ON a.idalmacen  = ra.idalmacen LEFT JOIN siat.refacciones r ON r.idrefaccion = ae.idrefaccion LEFT JOIN siat.refacciones_datosadicionales rd ON rd.id_refaccion = r.idrefaccion LEFT JOIN siat.medidas m ON m.idmedida = r.idmedida LEFT JOIN siat.grupos g ON r.idgrupo = g.idgrupo WHERE a.idalmacen IN(%s) AND MONTH(ra.fecha) = %s AND ra.tipoAlmacen = %s AND ra.estatusrequisicion = 1 AND ra.idtiposubrequisicion = %s AND ra.idestatus = 2 AND ae.cantsolicitada <> 0 AND ae.idestatusrefaccion = 3 AND ae.idsocio = %s GROUP BY ae.idrefaccion ORDER BY ra.idtiposubrequisicion DESC');";  
	
	static final String queryGetFolioAgrupada = "SELECT * FROM OPENQUERY (" + DB_13 + ", 'SELECT * FROM siat.folios WHERE tipofolio = %s;');"; 
	
	static final String queryInsertFolioAgrupada = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.folios WHERE tipofolio = 89' ) SET tipofolio = '%s', idfolio = '%s', clavefolio = '%s', descripcion = '%s'   ";

	static final String queryInsertRequisicionAgrupada = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.requisicionagrupada%s' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryInsertRequisicionAgrupadaExt = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.agrupadaextencion%s' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryInsertRequisicionClasificacion = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.requisicionclasificacion' ) VALUES ('%s','%s','%s','%s') ";

	static final String queryGetListadoRequisicionAgrupada = "SELECT * FROM OPENQUERY (%s, 'SELECT re.idrequisicion FROM siat.agrupadaextencion%s cu INNER JOIN siat.requisicionagrupada%s re ON re.idrequisicion = cu.idrequisicion AND re.idestatus NOT IN (3,4,8,9) WHERE cu.idrefaccion =  %s AND cu.idrequisicion <> %s;');";  

	static final String queryGetCantidadListadoAgrupada = "SELECT * FROM OPENQUERY (%s, 'SELECT cast(SUM(cu.cantrequisicion - cu.cantentrada)as decimal(38,6)) AS cantidad FROM siat.agrupadaextencion%s cu INNER JOIN siat.requisicionagrupada%s re ON re.idrequisicion = cu.idrequisicion AND re.idestatus NOT IN (3,4,8,9) WHERE cu.idrefaccion =  %s AND cu.idrequisicion <> %s;');";  
	
	static final String queryGetCantidadReqAgrupada = "SELECT * FROM OPENQUERY (%s, 'SELECT cast(SUM(cu.cantrequisicion - cu.cantentrada)as decimal(38,6)) AS cantidad FROM siat.agrupadaextencion%s cu INNER JOIN siat.requisicionagrupada%s re ON re.idrequisicion = cu.idrequisicion WHERE cu.idrequisicion IN (%s) AND re.idalmacen = %s AND cu.idrefaccion = %s AND re.idestatus IN (1,2) AND cu.idestatusrefaccion IN (1,3);');";  

	static final String queryDeleteRequisicionAgrupada = "DELETE OPENQUERY(%s, 'SELECT * FROM siat.requisicionagrupada%s WHERE idrequisicion = %s');";

	static final String queryDeleteAgrupadaExtension = "DELETE OPENQUERY(%s, 'SELECT * FROM siat.agrupadaextencion%s WHERE idrequisicion = %s');";

	static final String queryGetModRequisicionAgrupada = "SELECT * FROM OPENQUERY (%s, 'SELECT  r.idrefaccion, ra.idrequisicion,  r.clave, ae.cantsolicitada ,ae.idmedida, m.nombre AS nombrePieza, m.tipo_medida, ra.observaciones, ra.idestatus ,alm.nombre AS nomAlmacen, e.nombre AS estatus, r.nombre AS nomRefaccion, ra.idtiposubrequisicion AS tipoRef, alm.idalmacen, ra.idpersonal, CONCAT_WS(\" \", p1.apepaterno, p1.apematerno, p1.nombre) AS autoriza, u.nombre AS urgencia, ae.idalmacendestino ,ae.nombrealmacendestino, rd.presentacion FROM siat.requisicionagrupada%s ra LEFT JOIN siat.agrupadaextencion%s ae ON ae.idrequisicion = ra.idrequisicion LEFT JOIN siat.refacciones r ON ae.idrefaccion =  r.idrefaccion LEFT JOIN siat.medidas m ON m.idmedida = r.idmedida LEFT JOIN siat.almacen alm ON alm.idalmacen = ra.idalmacen LEFT JOIN siat.estatus e ON ra.idestatus = e.idestatus AND e.tipo= 2 LEFT JOIN siat.requisicionclasificacion rc ON rc.idrequisicion = ra.idrequisicion LEFT JOIN  personal.personal p1 ON p1.idpersonal = ra.idpersonal  LEFT JOIN siat.urgencia u ON ra.idurgencia = u.idurgencia LEFT JOIN siat.refacciones_datosadicionales rd ON rd.id_refaccion = ae.idrefaccion WHERE ra.idrequisicion = %s ORDER BY ra.hora DESC;');";
	
	static final String queryGetModSociosAgrupada= "SELECT * FROM OPENQUERY (%s, 'SELECT ra.idrequisicion, rs.idsocio, rs.idunidad, rs.noeconomico, rs.serie, s.nombre AS nombreSocio, rs.idrefaccion from siat.agrupadaextencion%s rs LEFT JOIN siat.requisicionagrupada%s ra ON ra.idrequisicion = rs.idrequisicion RIGHT JOIN camiones.socios s ON s.idpersonal = rs.idsocio where ra.idrequisicion = %s ORDER BY ra.hora ASC;');";  

	static final String queryCancelarRequisicionAgrupada = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicionagrupada%s WHERE idrequisicion = %s' ) SET idestatus = 3;";

	static final String queryUpdateRequisicionAgrupada = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicionagrupada%s WHERE idrequisicion = %s' ) SET observaciones = '%s';";
	
	static final String queryUpdateCantidadSolicitadaAgrupada = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.agrupadaextencion%s WHERE idrequisicion = %s AND idrefaccion = %s' ) SET cantsolicitada = '%s';";

	static final String queryUpdateRequisicionSociosAgrupada = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.agrupadaextencion%s WHERE idrequisicion = %s AND idrefaccion = %s' )  SET idrequisicion = '%s', idsocio = '%s',idunidad = '%s', noeconomico = '%s', serie = '%s', fecha = '%s', hora = '%s', idrefaccion = '%s';";
	
	static final String queryUpdateRequisicionHerramientaDestinoAgrupada = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.agrupadaextencion%s WHERE idrequisicion = %s AND idrefaccion = %s' ) SET idrequisicion = '%s', idalmacendestino = '%s', nombrealmacendestino = '%s', fecha = '%s', hora = '%s';";

	static final String queryInsertRequisicionHistoricoAgrupadas = "EXEC('INSERT INTO siat.requisicionagrupadahistorico VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\")') AT %s";

	static final String queryGetModRequisicionesHistoricoAgrupada = "SELECT * FROM OPENQUERY (%s, 'SELECT rh.hora, rh.idrequisicion, rh.fecha, rh.idpersonal, e.nombre AS nombreEstatus, e.idestatus, rh.observaciones, CONCAT_WS(\" \", p1.apepaterno, p1.apematerno, p1.nombre) AS personal FROM siat.requisicionagrupadahistorico rh LEFT JOIN siat.estatus e ON rh.idestatus = e.idestatus AND e.tipo= 1  LEFT JOIN  personal.personal p1 ON p1.idpersonal = rh.idpersonal WHERE idrequisicion = %s;');";  

	static final String queryUpdateClaveAutorizada = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.agrupadaextencion%s WHERE idrefaccion = %s AND tiposolicitud = %s AND idestatusrefaccion = 3' ) SET claveautorizada = '%s';";

	static final String queryUpdateEstatusRefaccion = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.agrupadaextencion%s WHERE idrefaccion = %s AND tiposolicitud = %s AND idsocio = %s AND idestatusrefaccion = 3' ) SET idestatusrefaccion = %s;";

	static final String queryInsertRequisicionAgrupadaAutoriza = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.requisicionagrupadaautorizada' ) VALUES('%s','%s','%s','%s','%s')";

	static final String queryGetListObtenerIdRequisicion = "SELECT * FROM OPENQUERY (%s, 'SELECT ae.idrequisicion, ra.clave FROM siat.requisicionagrupada%s ra LEFT JOIN siat.agrupadaextencion%s ae ON ra.idrequisicion = ae.idrequisicion LEFT JOIN  siat.almacen a ON a.idalmacen  = ra.idalmacen LEFT JOIN siat.refacciones r ON r.idrefaccion = ae.idrefaccion LEFT JOIN siat.refacciones_datosadicionales rd ON rd.id_refaccion = r.idrefaccion LEFT JOIN siat.medidas m ON m.idmedida = r.idmedida LEFT JOIN siat.grupos g ON r.idgrupo = g.idgrupo WHERE a.idalmacen IN(%s) AND MONTH(ra.fecha) = %s AND ra.tipoAlmacen = %s AND ra.estatusrequisicion = 1 AND ra.idtiposubrequisicion = %s AND ae.cantsolicitada <> 0 AND ae.idestatusrefaccion = 3 AND ae.idrefaccion = %s ORDER BY ra.idtiposubrequisicion DESC');";  

	static final String queryGetListObtenerRefaccionesCanceladas = "SELECT * FROM OPENQUERY (%s, 'SELECT ra.idrequisicion, ae.idrefaccion, SUM(ae.idestatusrefaccion) AS sumrefa FROM siat.requisicionagrupada%s ra LEFT JOIN siat.agrupadaextencion%s ae ON ra.idrequisicion = ae.idrequisicion WHERE ra.idrequisicion = %s;');";  

	static final String queryUpdateEstatusRequisicion = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicionagrupada%s WHERE idrequisicion = %s' ) SET idestatus = %s;";

	static final String queryUpdateEstatusRequisicionProgramada = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicionagrupada%s WHERE idestatus = 1' ) SET idestatus = 2;";
	
	static final String queryUpdateEstatusRefaccionProgramada = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.agrupadaextencion%s WHERE idestatusrefaccion = 1' ) SET idestatusrefaccion = 3;";

	static final String queryGetListInformacionRequisicion = "SELECT * FROM OPENQUERY (%s, 'SELECT ae.idrefaccion, r.nombre AS nomref, ae.cantsolicitada, ae.cantentrada, ae.fecha FROM siat.agrupadaextencion%s ae LEFT JOIN siat.refacciones r ON r.idrefaccion = ae.idrefaccion WHERE ae.idrequisicion = %s;');";  

	static final String queryGridRequisicionSeguimiento = "SELECT * FROM OPENQUERY (%s, 'SELECT raa.claveautorizada, ra.idtiporequisicion, ra.idtiposubrequisicion,ra.fecha AS fecha, raa.fecha AS fechaautorizada, ra.idestatus, e.nombre AS estatus, ra.idalmacen, a.nombre AS nomAlmacen,IF(ra.tipoAlmacen = 1, \" COORPORATIVO \" , \" FORANEO \" ) AS tipoAlmacen, p.razonsocial, s.nombre AS nombreSocio FROM siat.requisicionagrupadaautorizada raa LEFT JOIN siat.agrupadaextencion%s ae ON ae.claveautorizada = raa.claveautorizada LEFT JOIN siat.requisicionagrupada%s ra ON ra.idrequisicion = ae.idrequisicion LEFT JOIN siat.refaproveedor rp ON rp.idrefaccion = ae.idrefaccion LEFT JOIN siat.proveedores p ON  rp.idproveedor = p.idproveedor LEFT JOIN  siat.almacen  a ON a.idalmacen  = ra.idalmacen LEFT JOIN siat.estatus e ON e.idestatus = ra.idestatus AND e.tipo = 9 LEFT JOIN camiones.socios s ON s.idpersonal = ae.idsocio WHERE ra.idtiporequisicion <> 0 AND ra.tipoAlmacen = %s AND MONTH(raa.fecha) = %s GROUP BY raa.claveautorizada ORDER BY raa.claveautorizada ASC;');";  

	public List<CatalogoRequisiciones> getGridRequisiciones(int anio, int almacen, int tipoalmacen) {
		
		int fecha = LocalDate.now().getMonthValue();

		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGridRequisiciones,
						DB_13,
						anio, 
						almacen,
						fecha,
						tipoalmacen,
						utilitiesRepository.getDb13()),
						CatalogoRequisiciones.class);

		return (List<CatalogoRequisiciones>) query.getResultList();
	}
	
	/**
	 * getGridRequiPorAnio: obtiene el grid de requisiciones por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-24
	 */
	public List<CatalogoRequisiciones> getGridRequiPorAlmacen(int anio, int almacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGridRequiPorAlmacen,
						DB_13,
						anio,
						almacen
						),
						CatalogoRequisiciones.class);

		return (List<CatalogoRequisiciones>) query.getResultList();
	}
	
	/**
	 * getGridRequiPorAnio: obtiene el grid de requisiciones por almacen, mes y año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-24
	 */
	public List<CatalogoRequisiciones> getGridRequiPorAnio(int anio, int almacen, int mes, int tipoalmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGridRequiPorAnio,
						DB_13,
						anio,
						almacen,
						mes,
						tipoalmacen
						),
						CatalogoRequisiciones.class);

		return (List<CatalogoRequisiciones>) query.getResultList();
	}
	
	/**
	 * getCatalogoAlmacen: obtiene los almacenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-24
	 */
	public List<CatalogoAlmacen> getAlmacen(int tipoAlmacen,String nomAlmacen) {
		String almacenesRef;
		if(tipoAlmacen == 1) {
			almacenesRef = AlmacenesCorpo;
		}else {
			almacenesRef = AlmacenesForaneos;
		}
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetAlmacen,
						DB_13,
						almacenesRef,
						"%"+nomAlmacen+"%",
						utilitiesRepository.getDb13()),
						CatalogoAlmacen.class);

		return (List<CatalogoAlmacen>) query.getResultList();
	}
	
	/**
	 * getSemaforoSiat: obtiene el semaforo siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-08
	 */
	public List<SemaforoSiat> getSemaforo(int estatus) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetSemaforo,
						DB_13,
						estatus,
						utilitiesRepository.getDb13()),
						SemaforoSiat.class);

		return (List<SemaforoSiat>) query.getResultList();
	}
	
	/**
	 * insertCuerpoDetalle:inserta registro en cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-07-26
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertCuerpoDetalle(CuerpoDetalle cuerpoDetalle) {
		
		LocalDate fechaMod = LocalDate.now();
		LocalTime horaMod = LocalTime.now();
		String stringInsert = String.format(queryInsertCuerpoDetalle,
				cuerpoDetalle.getIdrequisicion(),
				cuerpoDetalle.getIdrefaccion(),
				cuerpoDetalle.getCantrequisicion(),
				cuerpoDetalle.getCantordenada(),
				cuerpoDetalle.getCantfacturada(),
				cuerpoDetalle.getCantentrada()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertCuerpoDetalle:inserta registro en cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-07-26
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionRefClasificacion(RequisicionRefClasificacion requiRefClas) {
		
		String stringInsert = String.format(queryInsertRequisicionRefClas,
				requiRefClas.getIdrequisicion(),
				requiRefClas.getIdrefaccion(),
				requiRefClas.getIdclasificacion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertRequisicionHistorico:inserta registro en requisicion historico
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-07-26
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionHistorico(RequisicionHistorico requisicionHistorico) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisicionHistorico,
				requisicionHistorico.getIdrequisicion(),
				requisicionHistorico.getIdestatus(),
				fecha,
				hora,
				requisicionHistorico.getIdpersonal(),
				requisicionHistorico.getObservaciones(),
				DB_13
				);
		System.out.println(stringInsert);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertRequisicionAnio:inserta registro en requisicion anio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-07-26
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionAnio(RequisicionAnio requisicionAnio, int anio) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisicionAnio,
				anio,
				requisicionAnio.getIdrequisicion(),
				requisicionAnio.getClave(),
				requisicionAnio.getIdsolicita(),
				requisicionAnio.getObservaciones(),
				requisicionAnio.getIdurgencia(),
				requisicionAnio.getIdestatus(),
				requisicionAnio.getIdalmacen(),
				requisicionAnio.getIdautoriza(),
				requisicionAnio.getIdreviso(),
				requisicionAnio.getEsnueva(),
				requisicionAnio.getIdpersonal(),
				fecha,
				hora
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getFolio: obtiene el folio siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-10
	 */
	public List<Folio> getFolio(int tipofolio) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetFolio,
						tipofolio,
						utilitiesRepository.getDb13()),
						Folio.class);

		return (List<Folio>) query.getResultList();
	}
	
	/**
	 * GetRefPorAlmacen: obtiene las refacciones pora almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-10
	 */
	public List<RefaccionPorAlmacen> getRefPorAlmacen(int idalmacen, int tiporef) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRefPorAlmacen,
						idalmacen,
						tiporef,
						utilitiesRepository.getDb13()),
						RefaccionPorAlmacen.class);

		return (List<RefaccionPorAlmacen>) query.getResultList();
	}
	
	/**
	 * getProveedorRef: obtiene el proveedor de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-11
	 */
	public List<ProveedorRefaccion> getProveedorRef(int idrefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetProveedorRef,
						DB_13,
						idrefaccion,
						utilitiesRepository.getDb13()),
						ProveedorRefaccion.class);
		System.out.println("resultados "+query.getResultList());
		return (List<ProveedorRefaccion>) query.getResultList();
	}

	/**
	 * getArrRefaccionesRev: obtiene las refacciones si tienen convenios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-21
	 */
	public List<RefaccionesRev> getArrRefaccionesRev(String refaccionesRev) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetArrRefaccionesRev,
						refaccionesRev,
						utilitiesRepository.getDb13()),
						RefaccionesRev.class);

		return (List<RefaccionesRev>) query.getResultList();
	}
	
	/**
	 * getTipoAutorizacion: obtiene el tipo de autorizacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-21
	 */
	public List<TipoAutorizacion> getTipoAutorizacion(int idtipoautorizacion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetArrRefaccionesRev,
						idtipoautorizacion,
						utilitiesRepository.getDb13()),
						TipoAutorizacion.class);

		return (List<TipoAutorizacion>) query.getResultList();
	}
	
	/**
	 * insertCuerpoDetalle:inserta registro en cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-07-26
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertAutorizaciones(Autorizaciones autorizaciones) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertAutorizaciones,
				autorizaciones.getTipomovimiento(),
				autorizaciones.getNomovimiento(),
				autorizaciones.getIdautorizo(),
				autorizaciones.getIdtipoautorizacion(),
				autorizaciones.getIdpersonal(),
				autorizaciones.getObservaciones(),
				fecha,
				hora,
				autorizaciones.getIdautsistema()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getRefaccionesEnConvenio: obtiene si las refacciones tienen convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-22
	 */
	public List<RefaccionesConvenio> queryGetRefaccionesEnConvenio(int idrefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRefaccionesEnConvenio,
						DB_13,
						idrefaccion,
						utilitiesRepository.getDb13()),
						RefaccionesConvenio.class);

		return (List<RefaccionesConvenio>) query.getResultList();
	}
	
	/**
	 * getRefaccionesEnConvenioProv: obtiene si las refacciones tienen convenio donde tenga proveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-22
	 */
	public List<RefaccionesConvenio> queryGetRefaccionesEnConvenioProv(int idrefaccion, int idproveedor) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRefaccionesEnConvenioProv,
						DB_13,
						idrefaccion,
						idproveedor,
						utilitiesRepository.getDb13()),
						RefaccionesConvenio.class);

		return (List<RefaccionesConvenio>) query.getResultList();
	}
	
	/**
	 * getListadoRequisicion: obtiene el listado de requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-22
	 */
	public List<ListadoRequisicion> queryGetListadoRequisiciones(int idrefaccion, int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetListadoRequisicion,
						DB_13,
						idrefaccion,
						idrequisicion,
						utilitiesRepository.getDb13()),
						ListadoRequisicion.class);

		return (List<ListadoRequisicion>) query.getResultList();
	}
	
	/**
	 * getCantidadListado: obtiene la cantidad del listado de requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-13
	 */
	public List<CantidadReq> queryGetCantidadListado(int idrefaccion, int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCantidadListado,
						DB_13,
						idrefaccion,
						idrequisicion,
						utilitiesRepository.getDb13()),
						CantidadReq.class);

		return (List<CantidadReq>) query.getResultList();
	}
	
	/**
	 * getCantidadReq: obtiene la cantidad de la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-23
	 */
	public List<CantidadReq> queryGetCantidadReq(int anio, String idrequisicion,int idalmacen, int idrefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCantidadReq,
						DB_13,
						anio,
						idrequisicion,
						idalmacen,
						idrefaccion,
						utilitiesRepository.getDb13()),
						CantidadReq.class);

		return (List<CantidadReq>) query.getResultList();
	}
	
	/**
	 * getCantidadConvenio: obtiene la cantidad si tiene convenio la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-23
	 */
	public List<CantidadReq> queryGetCantidadConvenio(int idrefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCantidadConvenio,
						DB_13,
						idrefaccion,
						utilitiesRepository.getDb13()),
						CantidadReq.class);

		return (List<CantidadReq>) query.getResultList();
	}
	
	/**
	 * getCantidadNoConv: obtiene la cantidad de la requisicion si no tiene convenio la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-23
	 */
	public List<CantidadNoConv> queryGetCantidadNoConvenio(int idrefaccion,int idalmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCantidadNoConvenio,
						DB_13,
						idrefaccion,
						idalmacen,
						utilitiesRepository.getDb13()),
						CantidadNoConv.class);

		return (List<CantidadNoConv>) query.getResultList();
	}
	
	/**
	 * insertFolio:inserta registro en folios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-12
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertFolio(Folio folio, int tipofolio) {
		
		String stringInsert = String.format(queryInsertFolio,
				DB_13,
				tipofolio,
				folio.getTipofolio(),
				folio.getIdfolio(),
				folio.getClavefolio(),
				folio.getDescripcion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getSocios: obtiene el catalogo de socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	public List<CatalogoSocios> getSocios(String nombre) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetSocios,
						DB_13,
						"%"+nombre+"%",
						utilitiesRepository.getDb13()),
						CatalogoSocios.class);

		return (List<CatalogoSocios>) query.getResultList();
	}
	
	/**
	 * getUnidaes: obtiene el catalogo de unidades por noeconomico
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	public List<ValidaUnidades> getUnidadEco(int socio, int noeconomico) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetUnidadEco,
						DB_13,
						socio,
						noeconomico,
						utilitiesRepository.getDb13()),
						ValidaUnidades.class);

		return (List<ValidaUnidades>) query.getResultList();
	}
	
	/**
	 * getUnidaes: obtiene el catalogo de unidades por serie
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	public List<ValidaUnidades> getUnidadSerie(int socio, String serie) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetUnidadSerie,
						DB_13,
						socio,
						serie,
						utilitiesRepository.getDb13()),
						ValidaUnidades.class);

		return (List<ValidaUnidades>) query.getResultList();
	}
	
	/**
	 * getUnidaes: obtiene la relacion consignacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-14
	 */
	public List<RefaccionConsignacion> getRelacionConsig(int idrefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRefaccionConsig,
						DB_13,
						idrefaccion,
						utilitiesRepository.getDb13()),
						RefaccionConsignacion.class);

		return (List<RefaccionConsignacion>) query.getResultList();
	}
	
	/**
	 * insertHerramientaDestino:inserta registro en Herramienta Destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-14
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertHeramientaDestino(HerramientaDestino herramienta) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertHerramientaDestino,
				DB_13,
				herramienta.getIdrequisicionherramienta(),
				herramienta.getIdrequisicion(),
				herramienta.getIdalmacen(),
				herramienta.getNombrealmacen(),
				fecha,
				hora
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertRequisicionSocios:inserta registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-14
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionSocios(RequisicionSocios socios) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisicionSocios,
				DB_13,
				socios.getIdrequisicionsocios(),
				socios.getIdrequisicion(),
				socios.getIdsocio(),
				socios.getIdunidad(),
				socios.getNoeconomico(),
				socios.getSerie(),
				fecha,
				hora,
				socios.getIdrefaccion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertCuerpoRequisicionAnio:inserta registro en cuerpo requisicion anio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-15
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertCuerpoRequisicionAnio(CuerpoRequisicionAnio cuerpoRequisicionAnio, int anio) {
		
		LocalDate fechaMod = LocalDate.now();
		LocalTime horaMod = LocalTime.now();
		String stringInsert = String.format(queryInsertCuerpoRequisicionAnio,
				DB_13,
				anio,
				cuerpoRequisicionAnio.getIdrequisicion(),
				cuerpoRequisicionAnio.getIdrefaccion(),
				cuerpoRequisicionAnio.getIdmedida(),
				cuerpoRequisicionAnio.getCantsolicitada(),
				cuerpoRequisicionAnio.getTiposolicitud(),
				cuerpoRequisicionAnio.getIdestatus()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertRequisiciones:inserta registro en requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-15
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisiciones(SiatRequisiciones siatRequisiciones) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisiciones,
				siatRequisiciones.getIdrequisicion(),
				siatRequisiciones.getClave(),
				siatRequisiciones.getIdestatus(),
				siatRequisiciones.getTabla(),
				fecha,
				hora,
				siatRequisiciones.getTiposolicitud()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getClasificacionRefacion: obtiene la clasificacion refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-18
	 */
	public List<ClasificacionRef> getClasificacionRef(int idrefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetClasificacionRefaccion,
						DB_13,
						idrefaccion,
						utilitiesRepository.getDb13()),
						ClasificacionRef.class);

		return (List<ClasificacionRef>) query.getResultList();
	}
	
	/**
	 * getModRequisiciones: obtiene la información para la modificacion de requisicion.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	public List<GetModRequisicion> getModRequisicion(int anio, int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetModRequisiciones,
						DB_13,
						anio,
						anio,
						idrequisicion,
						utilitiesRepository.getDb13()),
						GetModRequisicion.class);

		return (List<GetModRequisicion>) query.getResultList();
	}
	
	/**
	 * getModRequisicionesHistorico: obtiene la información para la modificacion de requisicio historico.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	public List<GetModRequisicionesHistorico> getModRequisicionesHistorico(int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetModRequisicionesHistorico,
						DB_13,
						idrequisicion,
						utilitiesRepository.getDb13()),
						GetModRequisicionesHistorico.class);

		return (List<GetModRequisicionesHistorico>) query.getResultList();
	}
	
	/**
	 * getModHistoricoOrdenCompra: obtiene la información para la modificacion de orden compra.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	public List<GetModHistoricoOrdenCompra> getModHistoricoOrdenCompra(int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetModHistoricoOrdenCompra,
						DB_13,
						idrequisicion,
						utilitiesRepository.getDb13()),
						GetModHistoricoOrdenCompra.class);

		return (List<GetModHistoricoOrdenCompra>) query.getResultList();
	}
	
	/**
	 * getModUrgencia: obtiene la información para la modificacion de urgencia y almacen.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	public List<GetModUrgencia> getModUrgencia(int anio,int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetModUrgencia,
						DB_13,
						anio,
						idrequisicion,
						utilitiesRepository.getDb13()),
						GetModUrgencia.class);

		return (List<GetModUrgencia>) query.getResultList();
	}
	
	/**
	 * getModHerrDestino: obtiene la información para la modificacion de herramienta destino.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-22
	 */
	public List<GetModHerrDestino> getModHerrDestino(int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetModHerrDestino,
						DB_13,
						idrequisicion,
						utilitiesRepository.getDb13()),
						GetModHerrDestino.class);

		return (List<GetModHerrDestino>) query.getResultList();
	}
	
	/**
	 * getModSocios: obtiene la información para la modificacion de socios.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-22
	 */
	public List<GetModSocios> getModSocios(int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetModSocios,
						DB_13,
						idrequisicion,
						utilitiesRepository.getDb13()),
						GetModSocios.class);

		return (List<GetModSocios>) query.getResultList();
	}
	
	/**
	 * getAcomuladoCuerpoDet: obtiene la cantidad del cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-25
	 */
	public List<CantidadReq> queryGetAcomuladoCuerpoDet(int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetAcomuladoCuerpoDet,
						DB_13,
						idrequisicion,
						utilitiesRepository.getDb13()),
						CantidadReq.class);

		return (List<CantidadReq>) query.getResultList();
	}
	
	/**
	 * updateCantidadRequi:update registro en requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateCantidadRequerida(UpdateCantidadRequerida updateCantidadRequerida, int anio, int idrequisicion, int idrefaccion) {
		
		String stringInsert = String.format(queryUpdateCantidadRequi,
				DB_13,
				anio, 
				idrequisicion,
				idrefaccion,
				updateCantidadRequerida.getCantsolicitada()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateRequisicionSocios:update registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateRequisicionSocios(RequisicionSocios socios, int idrequisicion, int idrefaccion) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryUpdateRequisicionSocios,
				DB_13,
				idrequisicion,
				idrefaccion,
				socios.getIdrequisicion(),
				socios.getIdsocio(),
				socios.getNoeconomico(),
				socios.getSerie(),
				fecha,
				hora,
				socios.getIdrefaccion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateRequisicionHerramientaDestino:update registro en requisicion herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateRequisicionHerramientaDestino(HerramientaDestino herramienta, int idrequisicion, int idrefaccion) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryUpdateRequisicionHerramientaDestino,
				DB_13,
				idrequisicion,
				idrefaccion,
				herramienta.getIdrequisicion(),
				herramienta.getIdalmacen(),
				herramienta.getNombrealmacen(),
				fecha,
				hora
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * deleteCuerpoDetalle:delete registro en cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteCuerpoDetalle(int idrequisicion, int idrefaccion) {
		
		String stringInsert = String.format(queryDeleteCuerpoDetalle,
				DB_13,
				idrequisicion,
				idrefaccion
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * deleteCuerpoRequisicionAnio :delete registro en cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteCuerpoRequisicionAnio(int anio, int idrequisicion, int idrefaccion) {
		
		String stringInsert = String.format(queryDeleteCuerpoRequisicionAnio,
				DB_13,
				anio,
				idrequisicion,
				idrefaccion
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * deleteRequisicionSocios :delete registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteRequisicionSocios(int idrequisicion, int idrefaccion) {
		
		String stringInsert = String.format(queryDeleteRequisicionSocios,
				DB_13,
				idrequisicion,
				idrefaccion
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * deleteRequisicionHerramientaDestino :delete registro en requisicion herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteRequisicionHerramientaDestino(int idrequisicion, int idrefaccion) {
		
		String stringInsert = String.format(queryDeleteRequisicionHerramientaDestino,
				DB_13,
				idrequisicion,
				idrefaccion
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * deleteRequisicionRefClas :delete registro en requisicion refaccion clasificacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteRequisicionRefClas(int idrequisicion, int idrefaccion) {
		
		String stringInsert = String.format(queryDeleteRequisicionRefClas,
				DB_13,
				idrequisicion,
				idrefaccion
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * cancelarRequisicionAnio: cancela la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	public Boolean cancelarRequisicionAnio(int anio,int idrequisicion) {
		
		String stringInsert = String.format(queryCancelarRequisicionAnio,
						DB_13,
						anio, 
						idrequisicion
						);

		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * cancelarRequisiciones: cancela la requisicion en la tabla requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	public Boolean cancelarRequisiciones(int idrequisicion) {
		
		String stringInsert = String.format(queryCancelarRequisiciones,
						DB_13,
						idrequisicion
						);

		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * cancelarCuerpoRequisicionAnio: cancela el cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-27
	 */
	public Boolean cancelarCuerpoRequisicionAnio(int anio,int idrequisicion) {
		
		String stringInsert = String.format(queryCancelarCuerpoRequisicion,
						DB_13,
						anio, 
						idrequisicion
						);

		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateRequisicionAnio: hace un update en las observaciones la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	public Boolean updateRequisicionAnio(UpdateObservaciones ra, int anio,int idrequisicion) {
		
		String stringInsert = String.format(queryUpdateRequisicionAnio,
						DB_13,
						anio, 
						idrequisicion,
						ra.getObservaciones()
						);

		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateRequisiciones: update en la tabla requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-28
	 */
	public Boolean updateRequisiciones(int idrequisicion, int idestatus) {
		
		String stringInsert = String.format(queryUpdateRequisiciones,
						DB_13,
						idrequisicion,
						idestatus
						);

		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateEstatusRequisicionAnio: hace un update idestatus en las observaciones la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-28
	 */
	public Boolean updateEstatusRequisicionAnio( int anio,int idrequisicion, int idestatus) {
		
		String stringInsert = String.format(queryUpdateRequisicionAnio,
						DB_13,
						anio, 
						idrequisicion,
						idestatus
						);

		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
//	public List<CatalogoRequisicionesAgrupadas> getGridRequisicionesAgrupadas(int anio, int almacen, int mes, int tipoAlmacen) {
//		String almacenesRef;
//		if(almacen == 1) {
//			almacenesRef = AlmacenesCorpo;
//		}else {
//			almacenesRef = AlmacenesForaneos;
//		}
//		
//		int fecha = LocalDate.now().getMonthValue();
//
//		Query query = entityManager
//				.createNativeQuery(String.format(				
//						queryGetGridRequisicionesAgrupada,
//						DB_13,
//						anio, 
//						almacenesRef,
//						mes,
//						tipoAlmacen,
//						utilitiesRepository.getDb13()),
//						CatalogoRequisicionesAgrupadas.class);
//
//		return (List<CatalogoRequisicionesAgrupadas>) query.getResultList();
//	}
	
	public List<CatalogoRequisicionesAgrupadas> getGridRequisicionesAgrupadas(int anio, int almacen, int mes, int tipoAlmacen) {
		String almacenesRef;
		if(almacen == 1) {
			almacenesRef = AlmacenesCorpo;
		}else {
			almacenesRef = AlmacenesForaneos;
		}
		
		int fecha = LocalDate.now().getMonthValue();
	
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGridRequisicionesAgrupada,
						DB_13,
						anio, 
						almacenesRef,
						mes,
						tipoAlmacen,
						utilitiesRepository.getDb13()),
						CatalogoRequisicionesAgrupadas.class);
	
		return (List<CatalogoRequisicionesAgrupadas>) query.getResultList();
	}

	public List<CatalogoRequisicionesPorAutorizar> getGridRequisicionesPorAutorizar(int anio, int almacen,int mes,int tipoAlmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGridRequisicionesPorAutorizar,
						DB_13,
						anio, 
						anio,
						almacen,
						mes,
						tipoAlmacen,
						utilitiesRepository.getDb13()),
						CatalogoRequisicionesPorAutorizar.class);

		return (List<CatalogoRequisicionesPorAutorizar>) query.getResultList();
	}
	
	public List<DetalleRequisicionAgrupada> getGridDetalleRequisicionAgrupada(int anio, int idalmacen, int mes,int tipoAlmacen, int tiposubrequisicion ) {

		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGridDetalleRequisicionAgrupada,
						DB_13,
						anio,
						anio,
						idalmacen,
						mes,
						tipoAlmacen, 
						tiposubrequisicion,
						utilitiesRepository.getDb13()),
						DetalleRequisicionAgrupada.class);

		return (List<DetalleRequisicionAgrupada>) query.getResultList();
	}
	
	public List<DetalleRequisicionAgrupada> getGridDetalleRequisicionAgrupadaSocio(int anio, int idalmacen, int mes,int tipoAlmacen, int tiposubrequisicion, int idsocio) {

		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGridDetalleRequisicionAgrupadaSocio,
						DB_13,
						anio,
						anio,
						idalmacen,
						mes,
						tipoAlmacen, 
						tiposubrequisicion,
						idsocio,
						utilitiesRepository.getDb13()),
						DetalleRequisicionAgrupada.class);

		return (List<DetalleRequisicionAgrupada>) query.getResultList();
	}
	
	/**
	 * getFolioAgrupada: obtiene el folio siat para agrupadas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-10
	 */
	public List<Folio> getFolioAgrupada(int tipofolio) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetFolioAgrupada,
						tipofolio,
						utilitiesRepository.getDb13()),
						Folio.class);

		return (List<Folio>) query.getResultList();
	}
	
	/**
	 * insertFolioAgrupada:inserta registro en folios para las requisiciones agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-12
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertFolioAgrupada(Folio folio) {
		
		String stringInsert = String.format(queryInsertFolio,
				DB_13,
				folio.getTipofolio(),
				folio.getIdfolio(),
				folio.getClavefolio(),
				folio.getDescripcion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertRequisicionAgrupada:inserta registro en requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-10
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionAgrupada(InsertRequisicionesAgrupadas iReqAg, int anio) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisicionAgrupada,
				DB_13,
				anio,
				iReqAg.getIdrequisicion(),
				iReqAg.getClave(),
				iReqAg.getIdsolicita(),
				iReqAg.getObservaciones(),
				iReqAg.getIdurgencia(),
				iReqAg.getIdestatus(),
				iReqAg.getIdalmacen(),
				iReqAg.getIdautoriza(),
				iReqAg.getIdreviso(),
				iReqAg.getEsnueva(),
				iReqAg.getIdpersonal(),
				fecha,
				hora,
				iReqAg.getTabla(),
				iReqAg.getIdtiposubrequisicion(),
				iReqAg.getTipoAlmacen(),
				iReqAg.getIdtiporequisicion(),
				iReqAg.getEstatusrequisicion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertRequisicionAgrupadaExt:inserta registro en requisicion agrupada extension
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-10
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionAgrupadaExt(InsertRequisicionAgrupadaExt iReqAgExt, int anio) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisicionAgrupadaExt,
				DB_13,
				anio,
				iReqAgExt.getIdrequisicion(),
				iReqAgExt.getIdrefaccion(),
				iReqAgExt.getCantsolicitada(),
				iReqAgExt.getCantrequisicion(),
				iReqAgExt.getCantordenada(),
				iReqAgExt.getCantfacturada(),
				iReqAgExt.getCantentrada(),
				iReqAgExt.getIdclasificacion(),
				iReqAgExt.getIdalmacendestino(),
				iReqAgExt.getNombrealmacendestino(),
				iReqAgExt.getIdsocio(),
				iReqAgExt.getIdunidad(),
				iReqAgExt.getNoeconomico(),
				iReqAgExt.getSerie(),
				iReqAgExt.getIdmedida(),
				iReqAgExt.getTiposolicitud(),
				fecha,
				hora,
				0,
				1
				);
		System.out.println(stringInsert);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertRequisicionClasificacion :inserta registro en requisicion clasificacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-12
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionClasificacion(RequisicionClasificacion ReqClaf) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisicionClasificacion,
				DB_13,
				ReqClaf.getIdrequisicion(),
				ReqClaf.getTipoalmacen(),
				ReqClaf.getIdtiporequisicion(),
				ReqClaf.getIdsubtiporequisicion()
				);
		System.out.println(stringInsert);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getListadoRequisicionAgrupada: obtiene el listado de requisiciones agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-25
	 */
	public List<ListadoRequisicion> queryGetListadoRequisicionesAgrupadas(int anio, int idrefaccion, int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetListadoRequisicionAgrupada,
						DB_13,
						anio,
						anio,
						idrefaccion,
						idrequisicion,
						utilitiesRepository.getDb13()),
						ListadoRequisicion.class);

		return (List<ListadoRequisicion>) query.getResultList();
	}
	
	/**
	 * getCantidadListadoAgrupada: obtiene la cantidad del listado de requisiciones agrupadas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-25
	 */
	public List<CantidadReq> queryGetCantidadListadoAgrupadas(int anio, int idrefaccion, int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCantidadListadoAgrupada,
						DB_13,
						anio,
						anio,
						idrefaccion,
						idrequisicion,
						utilitiesRepository.getDb13()),
						CantidadReq.class);

		return (List<CantidadReq>) query.getResultList();
	}
	
	/**
	 * getCantidadReqAgrupada: obtiene la cantidad de la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-25
	 */
	public List<CantidadReq> queryGetCantidadReqAgrupadas(int anio, String idrequisicion,int idalmacen, int idrefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCantidadReqAgrupada,
						DB_13,
						anio,
						anio,
						idrequisicion,
						idalmacen,
						idrefaccion,
						utilitiesRepository.getDb13()),
						CantidadReq.class);

		return (List<CantidadReq>) query.getResultList();
	}
	
	/**
	 * deleteRequisicionAgrupada :delete registro en requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteRequisicionAgrupada(int anio, int idrequisicion) {
		
		String stringInsert = String.format(queryDeleteRequisicionAgrupada,
				DB_13,
				anio,
				idrequisicion
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * deleteAgrupadaExtension :delete registro en requisicion agrupada extension
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteAgrupadaExtension(int anio, int idrequisicion) {
		
		String stringInsert = String.format(queryDeleteAgrupadaExtension,
				DB_13,
				anio,
				idrequisicion
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getModRequisicionesAgrupadas: obtiene la información para la modificacion de requisicion agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	public List<GetModRequisicionAgrupada> getModRequisicionAgrupada(int anio, int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetModRequisicionAgrupada,
						DB_13,
						anio,
						anio,
						idrequisicion,
						utilitiesRepository.getDb13()),
						GetModRequisicionAgrupada.class);

		return (List<GetModRequisicionAgrupada>) query.getResultList();
	}
	
	/**
	 * getModSociosAgrupada: obtiene la información para la modificacion de socios agrupada.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	public List<GetModSociosAgrupada> getModSociosAgrupada(int anio, int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetModSociosAgrupada,
						DB_13,
						anio,
						anio,
						idrequisicion,
						utilitiesRepository.getDb13()),
						GetModSociosAgrupada.class);

		return (List<GetModSociosAgrupada>) query.getResultList();
	}
	
	/**
	 * cancelarRequisicionAgrupada: cancela la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	public Boolean cancelarRequisicionAgrupada(int anio,int idrequisicion) {
		
		String stringInsert = String.format(queryCancelarRequisicionAgrupada,
						DB_13,
						anio, 
						idrequisicion
						);

		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateRequisicionAgrupada: hace un update en las observaciones la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	public Boolean updateRequisicionAgrupada(UpdateObservaciones ra, int anio,int idrequisicion) {
		
		String stringInsert = String.format(queryUpdateRequisicionAgrupada,
						DB_13,
						anio, 
						idrequisicion,
						ra.getObservaciones()
						);

		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateCantidadSolicitadaAgrupda:update registro en requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateCantidadSolicitadaAgrupada(UpdateCantidadRequerida updateCantidadRequerida, int anio, int idrequisicion, int idrefaccion) {
		
		String stringInsert = String.format(queryUpdateCantidadSolicitadaAgrupada,
				DB_13,
				anio, 
				idrequisicion,
				idrefaccion,
				updateCantidadRequerida.getCantsolicitada()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateRequisicionSociosAgrupada:update registro en requisicion socios agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateRequisicionSociosAgrupada(RequisicionSocios socios, int idrequisicion, int idrefaccion) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryUpdateRequisicionSociosAgrupada,
				DB_13,
				idrequisicion,
				idrefaccion,
				socios.getIdrequisicion(),
				socios.getIdsocio(),
				socios.getNoeconomico(),
				socios.getSerie(),
				fecha,
				hora,
				socios.getIdrefaccion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateRequisicionHerramientaDestinoAgrupada:update registro en requisicion herramienta destino agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateRequisicionHerramientaDestinoAgrupada(HerramientaDestinoAgrupada herramienta, int idrequisicion, int idrefaccion) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryUpdateRequisicionHerramientaDestinoAgrupada,
				DB_13,
				idrequisicion,
				idrefaccion,
				herramienta.getIdrequisicion(),
				herramienta.getIdalmacendestino(),
				herramienta.getNombrealmacendestino(),
				fecha,
				hora
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * createRequisicionHistoricoAgrupadas: Servicio insertar para Requisicion Historico Agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-11-02
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionHistoricoAgrupadas(RequisicionHistorico requisicionHistorico) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisicionHistoricoAgrupadas,
				requisicionHistorico.getIdrequisicion(),
				requisicionHistorico.getIdestatus(),
				fecha,
				hora,
				requisicionHistorico.getIdpersonal(),
				requisicionHistorico.getObservaciones(),
				DB_13
				);
		System.out.println(stringInsert);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getModRequisicionesHistorico: obtiene la información para la modificacion de requisicio historico.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	public List<GetModRequisicionesHistorico> getModRequisicionesHistoricoAgrupadas(int idrequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetModRequisicionesHistoricoAgrupada,
						DB_13,
						idrequisicion,
						utilitiesRepository.getDb13()),
						GetModRequisicionesHistorico.class);

		return (List<GetModRequisicionesHistorico>) query.getResultList();
	}
	
	/**
	 * updateClaveAutorizada:update registro en la refaccion con clave autorizada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateClaveAutorizada(int anio, int idrefaccion, int tiposolicitud, int claveautorizada) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryUpdateClaveAutorizada,
				DB_13,
				anio,
				idrefaccion,
				tiposolicitud,
				claveautorizada
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateEstatusRefaccion:update estatus en la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateEstatusRefaccion(int anio, int idrefaccion, int tiposolicitud, int idsocio, int idestatusrefaccion) {
		String stringInsert = String.format(queryUpdateEstatusRefaccion,
				DB_13,
				anio,
				idrefaccion,
				tiposolicitud,
				idsocio,
				idestatusrefaccion
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertRequisicionAgrupadaAutoriza:inserta registro en requisicion agrupada autoriza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionAgrupadaAutoriza(InsertRequisicionAgrupadaAutorizada iReqAg) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisicionAgrupadaAutoriza,
				DB_13,
				iReqAg.getClaveautorizada(),
				iReqAg.getObservaciones(),
				iReqAg.getIdautoriza(),
				fecha,
				hora
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	public List<ListadoRequisicionAutorizada> getListObtenerIdRequisicion(int anio, int idalmacen, int mes,int tipoAlmacen, int tiposubrequisicion, int idrefaccion ) {

		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetListObtenerIdRequisicion,
						DB_13,
						anio,
						anio,
						idalmacen,
						mes,
						tipoAlmacen, 
						tiposubrequisicion,
						idrefaccion,
						utilitiesRepository.getDb13()),
						ListadoRequisicionAutorizada.class);

		return (List<ListadoRequisicionAutorizada>) query.getResultList();
	}
	
	public List<ObtenerRefaccionesCanceladas> getListObtenerRefaccionesCanceladas(int anio, int idrequisicion ) {

		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetListObtenerRefaccionesCanceladas,
						DB_13,
						anio,
						anio,
						idrequisicion,
						utilitiesRepository.getDb13()),
						ObtenerRefaccionesCanceladas.class);

		return (List<ObtenerRefaccionesCanceladas>) query.getResultList();
	}
	
	/**
	 * updateEstatusRequisicion:update estatus en la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateEstatusRequisicion(int anio, int idrequisicion, int idestatus) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryUpdateEstatusRequisicion,
				DB_13,
				anio,
				idrequisicion,
				idestatus
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateEstatusRequisicion:update estatus en la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateEstatusRequisicionProgramada() {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		Calendar fechaactual = new GregorianCalendar();
		int anio = fechaactual.get(Calendar.YEAR);
		String stringInsert = String.format(queryUpdateEstatusRequisicionProgramada,
				DB_13,
				anio
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateEstatusRefaccionProgramada:update estatus en la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateEstatusRefaccionProgramada() {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		Calendar fechaactual = new GregorianCalendar();
		int anio = fechaactual.get(Calendar.YEAR);
		String stringInsert = String.format(queryUpdateEstatusRefaccionProgramada,
				DB_13,
				anio
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	public List<ObtenerInformacionRequisicion> getListInformacionRequisicion(int anio, int idrequisicion ) {

		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetListInformacionRequisicion,
						DB_13,
						anio,
						idrequisicion,
						utilitiesRepository.getDb13()),
						ObtenerInformacionRequisicion.class);

		return (List<ObtenerInformacionRequisicion>) query.getResultList();
	}
	
	public List<RequisicionAutorizada> getRequisicionSeguimiento(int anio, int tipoAlmacen, int mes) {

		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGridRequisicionSeguimiento,
						DB_13,
						anio,
						anio,
						tipoAlmacen,
						mes,
						utilitiesRepository.getDb13()),
						RequisicionAutorizada.class);

		return (List<RequisicionAutorizada>) query.getResultList();
	}
}
