package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Refaccion por almacen", description = "mapea tabla de siat.idrefaccion")
@Entity
@Table(name = "siat.idrefaccion")
public class RefaccionPorAlmacen {
	
	@Id
	@Column(name="idrefaccion")
	private int idrefaccion;
	@Column(name = "clave")
	private String clave;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "idmedida")
	private int idmedida;
	@Column(name = "estatus")
	private int estatus;
	@Column(name = "nombrePieza")
	private String nombrePieza;
	@Column(name = "tipo_medida")
	private Integer tipo_medida;
	@Column(name = "presentacion")
	private String presentacion;
}
