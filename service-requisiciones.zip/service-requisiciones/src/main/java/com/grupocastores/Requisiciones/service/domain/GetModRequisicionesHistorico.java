package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion para la modificacion de historico requisicion", description = "mapea tabla de siat.requisicionhistorico")
@Entity
@Table(name = "siat.requisicionhistorico")
public class GetModRequisicionesHistorico {
	
	@Id
	@Column(name = "hora")
	private LocalTime hora;
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "idpersonal")
	private int idpersonal;
	@Column(name = "nombreEstatus")
	private String nombreEstatus;
	@Column(name = "idestatus")
	private int idestatus;
	@Column(name = "observaciones")
	private String observaciones;
	@Column(name = "personal")
	private String personal;
}
