package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de requisicionherramientadestino", description = "mapea tabla de siat.requisicionherramientadestino")
@Entity
@Table(name = "siat.requisicionherramientadestino")
public class HerramientaDestino {
	
	@Id
	@Column(name="idrequisicionherramienta")
	private int idrequisicionherramienta;
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name="idalmacen")
	private int idalmacen;
	@Column(name = "nombrealmacen")
	private String nombrealmacen;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
	
}
