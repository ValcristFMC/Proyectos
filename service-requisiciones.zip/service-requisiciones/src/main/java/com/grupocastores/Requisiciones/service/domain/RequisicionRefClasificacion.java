package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Requisición Refaccion Clasificacion", description = "mapea tabla de siat.requisicionrefaccionclasificacion")
@Entity
@Table(name = "siat.requisicionrefaccionclasificacion")
public class RequisicionRefClasificacion {
	
	@Id
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name = "idrefaccion")
	private int idrefaccion;
	@Column(name = "idclasificacion")
	private int idclasificacion;

	
}
