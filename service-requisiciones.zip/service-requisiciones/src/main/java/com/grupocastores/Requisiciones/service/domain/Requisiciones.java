package com.grupocastores.Requisiciones.service.domain;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.grupocastores.Requisiciones.dto.RequisicionesDTO;

/**
 * Clase Requisiciones del dominio tiene su correspondiente {@link RequisicionesDTO}
 *
 * @author Castores - Desarrollo TI
 */
@Data
@Entity
@Table(name = "requisiciones")
@EntityListeners(Requisiciones.class)
public class Requisiciones 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idrequisicion;
	
	@Column(name = "clave") 
	private String clave;
	
	@Column(name = "idsolicita") 
	private int idsolicita;
	
	@Column(name = "observaciones") 
	private String observaciones;
	
	@Column(name = "idurgencia") 
	private int idurgencia;

	@Column(name = "idestatus") 
	private int idestatus;

	@Column(name = "idalmacen") 
	private int idalmacen;

	@Column(name = "idautoriza") 
	private int idautoriza;

	@Column(name = "idreviso") 
	private int idreviso;

	@Column(name = "esnueva") 
	private int esnueva;

	@Column(name = "idpersonal") 
	private int idpersonal;
	
	@CreatedDate
	@Column(name = "fecha", nullable = false, updatable = false)
	private Date fecha;
	
	@LastModifiedDate
	@Column(name = "hora", nullable = false, updatable = true)
	private Time hora;
	
	
	/**
	 * Metodo estatico para obtener un Requisiciones a partir de un RequisicionesDTO origen
	 * 
	 * @param requisiciones RequisicionesDTO origen
	 * 
	 * @return Requisiciones
	 */
	public static Requisiciones fromRequisicionesDTO(RequisicionesDTO requisiciones) {
		Requisiciones rest = new Requisiciones();
		rest.setIdrequisicion(requisiciones.getIdrequisicion());
		rest.setClave(requisiciones.getClave());
		rest.setIdsolicita(requisiciones.getIdsolicita());
		rest.setObservaciones(requisiciones.getObservaciones());
		rest.setIdurgencia(requisiciones.getIdurgencia());
		rest.setIdestatus(requisiciones.getIdestatus());
		rest.setIdalmacen(requisiciones.getIdalmacen());
		rest.setIdautoriza(requisiciones.getIdautoriza());
		rest.setIdreviso(requisiciones.getIdreviso());
		rest.setEsnueva(requisiciones.getEsnueva());
		rest.setIdpersonal(requisiciones.getIdpersonal());
		rest.setFecha(requisiciones.getFecha());		
		rest.setHora(requisiciones.getHora());
		return rest;
	}
	
	/**
	 * Metodo para obtener un RequisicionesDTO a partir de un Requisiciones origen
	 * 
	 * @return RequisicionesDTO
	 */
	public RequisicionesDTO toRequisicionesDTO() {
		 RequisicionesDTO dto = new  RequisicionesDTO();
		 dto.setIdrequisicion(this.getIdrequisicion());
		 dto.setClave(this.getClave());
		 dto.setIdsolicita(this.getIdsolicita());
		 dto.setObservaciones(this.getObservaciones());
		 dto.setIdurgencia(this.getIdurgencia());
		 dto.setIdestatus(this.getIdestatus());
		 dto.setIdalmacen(this.getIdalmacen());
		 dto.setIdautoriza(this.getIdautoriza());
		 dto.setIdreviso(this.getIdreviso());
		 dto.setEsnueva(this.getEsnueva());
		 dto.setIdpersonal(this.getIdpersonal());
		 dto.setFecha(this.getFecha());		
		 dto.setHora(this.getHora());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Requisiciones [idrequisicion=").append(idrequisicion)
		.append(",clave").append(clave)
		.append(",idsolicita").append(idsolicita)
		.append(",observaciones").append(observaciones)
		.append(",idurgencia").append(idurgencia)
		.append(",idestatus").append(idestatus)
		.append(",idalmacen").append(idalmacen)
		.append(",idautoriza").append(idautoriza)
		.append(",idreviso").append(idreviso)
		.append(", esnueva=").append(esnueva)
		.append(",idpersonal=").append(idpersonal)
		.append(",fecha=").append(fecha)
		.append(",hora=").append(hora);		
		return strBuilder.toString();
	}
}
