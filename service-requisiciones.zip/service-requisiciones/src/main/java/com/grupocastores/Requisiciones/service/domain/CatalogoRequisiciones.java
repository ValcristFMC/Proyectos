package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de CatalogoRequisiciones", description = "mapea tabla de siat.requisiciones")
@Entity
@Table(name = "siat.requisiciones2023")
public class CatalogoRequisiciones {
	
	@Id
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name = "clave")
	private String clave;
	@Column(name = "nomUrgencias")
	private String nomUrgencias;
	@Column(name = "fechaReq")
	private LocalDate fechaReq;
	@Column(name = "estatusReq")
	private String estatusReq;
	@Column(name = "nomAlmacen")
	private String nomAlmacen;
	@Column(name = "Autoriza")
	private String autoriza;
	@Column(name = "revisa")
	private String revisa;
	@Column(name="tipoalmacen")
	private int tipoalmacen;
	@Column(name="idtiporequisicion")
	private int idtiporequisicion;
	@Column(name="idsubtiporequisicion")
	private int idsubtiporequisicion;
}
