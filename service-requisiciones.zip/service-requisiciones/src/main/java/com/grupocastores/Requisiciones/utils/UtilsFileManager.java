package com.grupocastores.Requisiciones.utils;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;

import com.grupocastores.Requisiciones.dto.Image;

/**
 * UtilsFileManager - Clase para concentrar algunas funcionalidades de gestion de archivos y formatos.  
 *
 * @author Oscar Edaurdo guerra Salcedo - Desarrollo TI
 *
 */

@Component
public class UtilsFileManager {
	
	 /**
     * getCurrentYearYY: obtiene el año actual en formato de dos digitos ejemplo: 23
     * @param String yyyy-MM-dd or yyyy-MM-dd HH:mm:ss
     * @return String 
     * */
    public Image imageBase64ToByte(String imagenBase64) {
    	String resp = imagenBase64.replace("data:image/jpeg;base64,", "");
        byte[] imagenBytes = Base64.decodeBase64(resp);
    	Image imagen = new Image();
    	imagen.setContenido(imagenBytes);   	
    	return imagen;
    }

}
