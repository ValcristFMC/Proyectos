package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion para la requisicion socio", description = "mapea tabla de siat.requisicionsocio")
@Entity
@Table(name = "siat.requisicionsocio")
public class GetModSociosAgrupada {
	
	@Id
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name = "idsocio")
	private int idsocio;
	@Column(name = "idunidad")
	private int idunidad;
	@Column(name = "noeconomico")
	private int noeconomico;
	@Column(name = "serie")
	private String serie;
	@Column(name = "nombreSocio")
	private String nombreSocio;
	@Column(name = "idrefaccion")
	private int idrefaccion;
}
