package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Autorizaciones", description = "mapea tabla de siat.autorizaciones")
@Entity
@Table(name = "siat.autorizaciones")
public class Autorizaciones {
	
	@Id
	@Column(name="tipomovimiento")
	private int tipomovimiento;
	@Column(name = "nomovimiento")
	private int nomovimiento;
	@Column(name = "idautorizo")
	private int idautorizo;
	@Column(name = "idtipoautorizacion")
	private int idtipoautorizacion;
	@Column(name = "idpersonal")
	private int idpersonal;
	@Column(name = "observaciones")
	private String observaciones;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
	@Column(name = "idautsistema")
	private int idautsistema;
}
