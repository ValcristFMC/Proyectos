package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion para la modificacion de historico orden de compra", description = "mapea tabla de siat.requisicionhistorico")
@Entity
@Table(name = "siat.ordenes")
public class GetModHistoricoOrdenCompra {
	
	@Id
	@Column(name="idordencompra")
	private int idordencompra;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "nombre")
	private String nombre;
}
