package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Cuerpo requisicion anio", description = "mapea tabla de siat.cuerporequisicionanio")
@Entity
@Table(name = "siat.cuerporequisicionanio")
public class CuerpoRequisicionAnio {
	
	@Id
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name = "idrefaccion")
	private int idrefaccion;
	@Column(name = "idmedida")
	private int idmedida;
	@Column(name = "cantsolicitada")
	private double cantsolicitada;
	@Column(name = "tiposolicitud")
	private int tiposolicitud;
	@Column(name = "idestatus")
	private int idestatus;
	
}
