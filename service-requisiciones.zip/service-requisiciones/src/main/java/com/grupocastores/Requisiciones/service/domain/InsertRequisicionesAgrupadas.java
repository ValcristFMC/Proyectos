package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de CatalogoRequisiciones", description = "mapea tabla de siat.requisiciones")
@Entity
@Table(name = "siat.requisiciones2023")
public class InsertRequisicionesAgrupadas {
	
	@Id
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name = "clave")
	private String clave;
	@Column(name="idsolicita")
	private int idsolicita;
	@Column(name = "observaciones")
	private String observaciones;
	@Column(name = "idurgencia")
	private String idurgencia;
	@Column(name = "idestatus")
	private int idestatus;
	@Column(name = "idalmacen")
	private int idalmacen;
	@Column(name = "idautoriza")
	private int idautoriza;
	@Column(name = "idreviso")
	private int idreviso;
	@Column(name = "esnueva")
	private int esnueva;
	@Column(name = "idpersonal")
	private int idpersonal;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
	@Column(name="tabla")
	private int tabla;
	@Column(name="idtiposubrequisicion")
	private int idtiposubrequisicion;
	@Column(name = "tipoAlmacen")
	private int tipoAlmacen;
	@Column(name="idtiporequisicion")
	private int idtiporequisicion;
	@Column(name = "estatusrequisicion")
	private String estatusrequisicion;
	
}
