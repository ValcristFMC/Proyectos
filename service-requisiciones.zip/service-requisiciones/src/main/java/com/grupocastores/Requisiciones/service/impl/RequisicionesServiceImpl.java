package com.grupocastores.Requisiciones.service.impl;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.Requisiciones.service.domain.CatalogoRequisiciones;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisicionesAgrupadas;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisicionesPorAutorizar;
import com.grupocastores.Requisiciones.service.domain.Requisiciones;
import com.grupocastores.Requisiciones.service.repository.RequisicionesRepository;
import com.grupocastores.Requisiciones.utils.UtilitiesRepository;
import com.grupocastores.Requisiciones.service.domain.CuerpoDetalle;
import com.grupocastores.Requisiciones.service.domain.RequisicionAnio;
import com.grupocastores.Requisiciones.service.domain.RequisicionAutorizada;
import com.grupocastores.Requisiciones.service.domain.RequisicionClasificacion;
import com.grupocastores.Requisiciones.service.domain.CuerpoRequisicionAnio;
import com.grupocastores.Requisiciones.service.domain.DetalleRequisicionAgrupada;
import com.grupocastores.Requisiciones.service.domain.RequisicionAnio;
import com.grupocastores.Requisiciones.service.domain.RequisicionHistorico;
import com.grupocastores.Requisiciones.service.domain.RequisicionRefClasificacion;
import com.grupocastores.Requisiciones.service.domain.Personal;
import com.grupocastores.Requisiciones.service.domain.ProveedorRefaccion;
import com.grupocastores.Requisiciones.service.domain.Folio;
import com.grupocastores.Requisiciones.service.domain.GetModHerrDestino;
import com.grupocastores.Requisiciones.service.domain.GetModHistoricoOrdenCompra;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicion;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicionAgrupada;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicionesHistorico;
import com.grupocastores.Requisiciones.service.domain.GetModSocios;
import com.grupocastores.Requisiciones.service.domain.GetModSociosAgrupada;
import com.grupocastores.Requisiciones.service.domain.GetModUrgencia;
import com.grupocastores.Requisiciones.service.domain.ListadoRequisicion;
import com.grupocastores.Requisiciones.service.domain.ListadoRequisicionAutorizada;
import com.grupocastores.Requisiciones.service.domain.ObtenerInformacionRequisicion;
import com.grupocastores.Requisiciones.service.domain.ObtenerRefaccionesCanceladas;
import com.grupocastores.Requisiciones.service.domain.RefaccionPorAlmacen;
import com.grupocastores.Requisiciones.service.domain.RefaccionesConvenio;
import com.grupocastores.Requisiciones.service.domain.Autorizaciones;
import com.grupocastores.Requisiciones.service.domain.CantidadNoConv;
import com.grupocastores.Requisiciones.service.domain.CantidadReq;
import com.grupocastores.Requisiciones.service.domain.CatalogoAlmacen;
import com.grupocastores.Requisiciones.dto.ResponseDTO;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisiciones;
import com.grupocastores.Requisiciones.service.domain.CatalogoSocios;
import com.grupocastores.Requisiciones.service.domain.ClasificacionRef;
import com.grupocastores.Requisiciones.service.domain.SemaforoSiat;
import com.grupocastores.Requisiciones.service.domain.SiatRequisiciones;
import com.grupocastores.Requisiciones.service.domain.TipoAutorizacion;
import com.grupocastores.Requisiciones.service.domain.UpdateCantidadRequerida;
import com.grupocastores.Requisiciones.service.domain.UpdateObservaciones;
import com.grupocastores.Requisiciones.service.domain.ValidaUnidades;
import com.grupocastores.Requisiciones.service.domain.RefaccionesRev;
import com.grupocastores.Requisiciones.service.domain.RefaccionConsignacion;
import com.grupocastores.Requisiciones.service.domain.RequisicionSocios;
import com.grupocastores.Requisiciones.service.domain.HerramientaDestino;
import com.grupocastores.Requisiciones.service.domain.HerramientaDestinoAgrupada;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionAgrupadaAutorizada;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionAgrupadaExt;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionesAgrupadas;
import com.grupocastores.Requisiciones.service.IRequisicionesService;

/**
 * Implementacion interna de 
 * {@link com.grupocastores.Requisiciones.service.IRequisicionesService}.
 *  Esta clase no se debe acceder directamente
 *
 * @author Castores - Desarrollo TI
 */
@Service
public class RequisicionesServiceImpl implements IRequisicionesService 
{
	Logger logger = LoggerFactory.getLogger(RequisicionesServiceImpl.class);
	
	@Autowired
	private RequisicionesRepository requisicionesRepository;

	@Autowired
	private UtilitiesRepository utilitiesRepository;
	
	
	@Override
	public ResponseDTO<List<CatalogoRequisiciones>> getGridRequisiciones(int anio, int almacen, int tipoalmacen) {
		ResponseDTO<List<CatalogoRequisiciones>> response = new ResponseDTO<List<CatalogoRequisiciones>>();
		List<CatalogoRequisiciones> gridRequisiciones = requisicionesRepository.getGridRequisiciones(anio, almacen, tipoalmacen);
	 	if(gridRequisiciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grid de requisiciones ");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequisiciones);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CatalogoRequisiciones>> getGridRequiPorAlmacen(int anio, int idAlmacen) {
		ResponseDTO<List<CatalogoRequisiciones>> response = new ResponseDTO<List<CatalogoRequisiciones>>();
		List<CatalogoRequisiciones> gridRequiPorAlmacen = requisicionesRepository.getGridRequiPorAlmacen(anio, idAlmacen);
	 	if(gridRequiPorAlmacen.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grid de requisiciones ");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequiPorAlmacen);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CatalogoRequisiciones>> getGridRequiPorAnio(int anio, int idAlmacen, int mes, int tipoalmacen) {
		ResponseDTO<List<CatalogoRequisiciones>> response = new ResponseDTO<List<CatalogoRequisiciones>>();
		List<CatalogoRequisiciones> gridRequiPorAnio = requisicionesRepository.getGridRequiPorAnio(anio, idAlmacen, mes, tipoalmacen);
	 	if(gridRequiPorAnio.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grid de requisiciones por año ");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequiPorAnio);
		return response;
	}
	
	@Override
	public ResponseDTO<List<SemaforoSiat>> getSemaforoSiat(int estatus) {
		ResponseDTO<List<SemaforoSiat>> response = new ResponseDTO<List<SemaforoSiat>>();
		List<SemaforoSiat> semaforo = requisicionesRepository.getSemaforo(estatus);
	 	if(semaforo.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de semaforo siat");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(semaforo);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CatalogoAlmacen>> getAlmacen(int tipoAlmacen, String nomAlmacen) {
		ResponseDTO<List<CatalogoAlmacen>> response = new ResponseDTO<List<CatalogoAlmacen>>();
		List<CatalogoAlmacen> almacen = requisicionesRepository.getAlmacen(tipoAlmacen, nomAlmacen);
	 	if(almacen.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(almacen);
		return response;
	}
	
	/**
	 * createCuerpoDetalle: inserta registro en cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-07-24
	 */
	@Override
	public ResponseDTO<Boolean> createCuerpoDetalle (CuerpoDetalle cuerpoDetalle) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.insertCuerpoDetalle(cuerpoDetalle);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Cuerpo detalle de requisicion insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del cuerpo detalle de la requisicion");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * createCuerpoDetalle: inserta registro en cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-07-24
	 */
	@Override
	public ResponseDTO<Boolean> createRequisicionRefClasificacion (RequisicionRefClasificacion requiRefClas) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = requisicionesRepository.insertRequisicionRefClasificacion(requiRefClas);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Requisicion de refaccion clasificacion insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la Requisicion de refaccion clasificacion ");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertRequisicionHistorico: inserta registro en requisicion historico
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-07-24
	 */
	@Override
	public ResponseDTO<Boolean> createRequisicionHistorico (RequisicionHistorico requisicionHistorico) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = requisicionesRepository.insertRequisicionHistorico(requisicionHistorico);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Requisicion historico insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la Requisicion historico ");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertRequisicionHistorico: inserta registro en requisicion anio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-07-24
	 */
	@Override
	public ResponseDTO<Boolean> createRequisicionAnio (RequisicionAnio requisicionAnio, int anio) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = requisicionesRepository.insertRequisicionAnio(requisicionAnio,anio);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Requisicion Año insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la Requisicion Año ");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<Folio>> getFolio(int tipofolio) {
		ResponseDTO<List<Folio>> response = new ResponseDTO<List<Folio>>();
		List<Folio> folio = requisicionesRepository.getFolio(tipofolio);
	 	if(folio.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el folio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(folio);
		return response;
	}
	
	@Override
	public ResponseDTO<List<RefaccionPorAlmacen>> getRefPorAlmacen(int idalmacen, int tiporef) {
		ResponseDTO<List<RefaccionPorAlmacen>> response = new ResponseDTO<List<RefaccionPorAlmacen>>();
		List<RefaccionPorAlmacen> refPorAlm = requisicionesRepository.getRefPorAlmacen(idalmacen,tiporef);
	 	if(refPorAlm.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener las refacciones por almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(refPorAlm);
		return response;
	}
	
	@Override
	public ResponseDTO<List<ProveedorRefaccion>> getProveedorRef(int idrefaccion) {
		ResponseDTO<List<ProveedorRefaccion>> response = new ResponseDTO<List<ProveedorRefaccion>>();
		List<ProveedorRefaccion> proveedorRefaccion = requisicionesRepository.getProveedorRef(idrefaccion);
	 	if(proveedorRefaccion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener los proveedores de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(proveedorRefaccion);
		logger.info("resultado " + proveedorRefaccion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<RefaccionesRev>> getArrRefaccionesRev(String refaccionesRev) {
		ResponseDTO<List<RefaccionesRev>> response = new ResponseDTO<List<RefaccionesRev>>();
		List<RefaccionesRev> refRev = requisicionesRepository.getArrRefaccionesRev(refaccionesRev);
	 	if(refaccionesRev.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener las refacciones");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(refRev);
		return response;
	}
	
	/**
	 * createAutorizaciones: inserta registro en autorizaciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-08-21
	 */
	@Override
	public ResponseDTO<Boolean> createAutorizaciones (Autorizaciones autorizaciones) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.insertAutorizaciones(autorizaciones);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Autorizacion insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la autorizacion");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<TipoAutorizacion>> getTipoAutorizacion(int idtipoautorizacion) {
		ResponseDTO<List<TipoAutorizacion>> response = new ResponseDTO<List<TipoAutorizacion>>();
		List<TipoAutorizacion> tipoAutorizacion = requisicionesRepository.getTipoAutorizacion(idtipoautorizacion);
	 	if(tipoAutorizacion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el tipo de autorizacion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(tipoAutorizacion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<RefaccionesConvenio>> getRefaccionesEnConvenio(int idrefaccion) {
		ResponseDTO<List<RefaccionesConvenio>> response = new ResponseDTO<List<RefaccionesConvenio>>();
		List<RefaccionesConvenio> refaConv = requisicionesRepository.queryGetRefaccionesEnConvenio(idrefaccion);
	 	if(refaConv.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener refacciones en convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(refaConv);
		return response;
	}
	
	@Override
	public ResponseDTO<List<RefaccionesConvenio>> getRefaccionesEnConvenioProv(int idrefaccion, int idproveedor) {
		ResponseDTO<List<RefaccionesConvenio>> response = new ResponseDTO<List<RefaccionesConvenio>>();
		List<RefaccionesConvenio> refaConvProv = requisicionesRepository.queryGetRefaccionesEnConvenioProv(idrefaccion, idproveedor);
	 	if(refaConvProv.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener refacciones en convenio y proveedor");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(refaConvProv);
		return response;
	}
	
	@Override
	public ResponseDTO<List<ListadoRequisicion>> getListadoRequisiciones(int idrefaccion, int idrequisicion) {
		ResponseDTO<List<ListadoRequisicion>> response = new ResponseDTO<List<ListadoRequisicion>>();
		List<ListadoRequisicion> listadoReq = requisicionesRepository.queryGetListadoRequisiciones(idrefaccion, idrequisicion);
	 	if(listadoReq.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el listado requisicion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(listadoReq);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CantidadReq>> getCantidadListado(int idrefaccion, int idrequisicion) {
		ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
		List<CantidadReq> listadoReq = requisicionesRepository.queryGetCantidadListado(idrefaccion, idrequisicion);
	 	if(listadoReq.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el listado requisicion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(listadoReq);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CantidadReq>> getCantidadReq(int anio, String idrequisicion, int almacen,int idrefaccion) {
		ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
		List<CantidadReq> cantidadReq = requisicionesRepository.queryGetCantidadReq(anio,idrequisicion,almacen,idrefaccion);
	 	if(cantidadReq.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener cantidad requerida");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(cantidadReq);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CantidadReq>> getCantidadConvenio(int idrefaccion) {
		ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
		List<CantidadReq> cantidadConv = requisicionesRepository.queryGetCantidadConvenio(idrefaccion);
	 	if(cantidadConv.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener cantidad convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(cantidadConv);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CantidadNoConv>> getCantidadNoConvenio(int idrefaccion, int almacen) {
		ResponseDTO<List<CantidadNoConv>> response = new ResponseDTO<List<CantidadNoConv>>();
		List<CantidadNoConv> tipoAutorizacion = requisicionesRepository.queryGetCantidadNoConvenio(idrefaccion, almacen);
	 	if(tipoAutorizacion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener cantidad no convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(tipoAutorizacion);
		return response;
	}
	
	/**
	 * createFolio: inserta registro en folios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-09-12
	 */
	@Override
	public ResponseDTO<Boolean> createFolio (Folio folio, int tipofolio) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.insertFolio(folio, tipofolio);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("folio de requisicion insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del folio de la requisicion");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<CatalogoSocios>> getSocios(String nombre) {
		ResponseDTO<List<CatalogoSocios>> response = new ResponseDTO<List<CatalogoSocios>>();
		List<CatalogoSocios> socios = requisicionesRepository.getSocios(nombre);
	 	if(socios.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de socios");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(socios);
		return response;
	}

	@Override
	public ResponseDTO<List<ValidaUnidades>> getUnidadEco(int socio, int noeconomico) {
		ResponseDTO<List<ValidaUnidades>> response = new ResponseDTO<List<ValidaUnidades>>();
		List<ValidaUnidades> unidades = requisicionesRepository.getUnidadEco(socio,noeconomico);
	 	if(unidades.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de unidades");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(unidades);
		return response;
	}
	
	@Override
	public ResponseDTO<List<ValidaUnidades>> getUnidadSerie(int socio, String serie) {
		ResponseDTO<List<ValidaUnidades>> response = new ResponseDTO<List<ValidaUnidades>>();
		List<ValidaUnidades> unidades = requisicionesRepository.getUnidadSerie(socio,serie);
	 	if(unidades.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de unidades");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(unidades);
		return response;
	}
	
	@Override
	public ResponseDTO<List<RefaccionConsignacion>> getRelacionConsig(int idrefaccion) {
		ResponseDTO<List<RefaccionConsignacion>> response = new ResponseDTO<List<RefaccionConsignacion>>();
		List<RefaccionConsignacion> refaccion = requisicionesRepository.getRelacionConsig(idrefaccion);
	 	if(refaccion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la relacion consignacion de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(refaccion);
		return response;
	}
	
	/**
	 * createHerramientaDestino: inserta registro en herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-09-14
	 */
	@Override
	public ResponseDTO<Boolean> createHerramientaDestino (HerramientaDestino herramienta) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.insertHeramientaDestino(herramienta);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("herramienta destino insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del destino de herramienta");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * createRequisicionSocios: inserta registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-09-14
	 */
	@Override
	public ResponseDTO<Boolean> createRequisicionSocios (RequisicionSocios socios) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.insertRequisicionSocios(socios);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("requisicion socios insertado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la requisicion socios");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertCuerpoRequisicionHistorico: inserta registro en cuerpo requisicion anio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-09-15
	 */
	@Override
	public ResponseDTO<Boolean> createCuerpoRequisicionAnio (CuerpoRequisicionAnio cuerpoRequisicionAnio, int anio) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = requisicionesRepository.insertCuerpoRequisicionAnio(cuerpoRequisicionAnio, anio);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Cuerpo Requisicion Año insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del Cuerpo Requisicion Año ");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * createRequisiciones: inserta registro en requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-09-15
	 */
	@Override
	public ResponseDTO<Boolean> createRequisiciones (SiatRequisiciones siatRequisiciones) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.insertRequisiciones(siatRequisiciones);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("requisicion insertado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la requisicion");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<ClasificacionRef>> getClasificacionRef(int idrefaccion) {
		ResponseDTO<List<ClasificacionRef>> response = new ResponseDTO<List<ClasificacionRef>>();
		List<ClasificacionRef> refaccion = requisicionesRepository.getClasificacionRef(idrefaccion);
	 	if(refaccion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la relacion consignacion de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(refaccion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetModRequisicion>>getModRequisicion(int anio, int idrequisicion) {
		ResponseDTO<List<GetModRequisicion>> response = new ResponseDTO<List<GetModRequisicion>>();
		List<GetModRequisicion> requisicion = requisicionesRepository.getModRequisicion(anio,idrequisicion);
	 	if(requisicion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la relacion consignacion de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(requisicion);
		return response;
	}
	
	
	@Override
	public ResponseDTO<List<GetModRequisicionesHistorico>>getModRequisicionesHistorico(int idrequisicion) {
		ResponseDTO<List<GetModRequisicionesHistorico>> response = new ResponseDTO<List<GetModRequisicionesHistorico>>();
		List<GetModRequisicionesHistorico> requisicion = requisicionesRepository.getModRequisicionesHistorico(idrequisicion);
	 	if(requisicion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la relacion consignacion de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(requisicion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetModHistoricoOrdenCompra>> getModHistoricoOrdenCompra(int idrequisicion) {
		ResponseDTO<List<GetModHistoricoOrdenCompra>> response = new ResponseDTO<List<GetModHistoricoOrdenCompra>>();
		List<GetModHistoricoOrdenCompra> requisicion = requisicionesRepository.getModHistoricoOrdenCompra(idrequisicion);
	 	if(requisicion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la relacion consignacion de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(requisicion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetModUrgencia>> getModUrgencia(int anio,int idrequisicion) {
		ResponseDTO<List<GetModUrgencia>> response = new ResponseDTO<List<GetModUrgencia>>();
		List<GetModUrgencia> requisicion = requisicionesRepository.getModUrgencia(anio,idrequisicion);
	 	if(requisicion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la relacion consignacion de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(requisicion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetModHerrDestino>> getModHerrDestino(int idrequisicion) {
		ResponseDTO<List<GetModHerrDestino>> response = new ResponseDTO<List<GetModHerrDestino>>();
		List<GetModHerrDestino> requisicion = requisicionesRepository.getModHerrDestino(idrequisicion);
	 	if(requisicion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la herramienta destino de la requisicion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(requisicion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetModSocios>> getModSocios(int idrequisicion) {
		ResponseDTO<List<GetModSocios>> response = new ResponseDTO<List<GetModSocios>>();
		List<GetModSocios> requisicion = requisicionesRepository.getModSocios(idrequisicion);
	 	if(requisicion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la sociedad de la requisicion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(requisicion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CantidadReq>> queryGetAcomuladoCuerpoDet(int idrequisicion) {
		ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
		List<CantidadReq> cantidadReq = requisicionesRepository.queryGetAcomuladoCuerpoDet(idrequisicion);
	 	if(cantidadReq.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener cantidad requerida");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(cantidadReq);
		return response;
	}
	
	/**
	 * updateCantidadRequi:update registro en requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@Override
	public ResponseDTO<Boolean> updateCantidadRequerida (UpdateCantidadRequerida updateCantidadRequerida, int anio, int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateCantidadRequerida(updateCantidadRequerida, anio, idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion de cantidad de la requisicion correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de la cantidad de la requisicion");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateRequisicionSocios:update registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@Override
	public ResponseDTO<Boolean> updateRequisicionSocios (RequisicionSocios socios, int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateRequisicionSocios(socios, idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion de requisicion socios correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de requisicion socios");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateRequisicionHerramientaDestino:update registro en requisicion herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@Override
	public ResponseDTO<Boolean> updateRequisicionHerramientaDestino (HerramientaDestino herramienta, int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateRequisicionHerramientaDestino(herramienta, idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion de requisicion herramienta destino correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de requisicion herramienta destino");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * deleteCuerpoDetalle:delete registro en cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@Override
	public ResponseDTO<Boolean> deleteCuerpoDetalle (int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.deleteCuerpoDetalle( idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("eliminacion de cuerpo detalle de la requisicion correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar el cuerpo detalle de la requisicion");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * deleteCuerpoRequisicionAnio :delete registro en cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@Override
	public ResponseDTO<Boolean> deleteCuerpoRequisicionAnio (int anio, int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.deleteCuerpoRequisicionAnio(anio, idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("eliminacion de cuerpo requisicion año correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar el cuerpo requisicion año");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * deleteRequisicionSocios :delete registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@Override
	public ResponseDTO<Boolean> deleteRequisicionSocios (int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.deleteRequisicionSocios( idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("eliminacion de la requisicion socios correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar la requisicion socios");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * deleteRequisicionHerramientaDestino :delete registro en requisicion herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@Override
	public ResponseDTO<Boolean> deleteRequisicionHerramientaDestino (int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.deleteRequisicionHerramientaDestino( idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("eliminacion de la requisicion herramienta destino correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar la requisicion herramienta destino");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * deleteRequisicionRefClas :delete registro en requisicion refaccion clasificacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@Override
	public ResponseDTO<Boolean> deleteRequisicionRefClas (int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.deleteRequisicionRefClas( idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("eliminacion de la requisicion refaccion clasificacion correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar la requisicion refaccion clasificacion destino");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * cancelarRequisicionAnio: cancela la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	@Override
	public ResponseDTO<Boolean> cancelarRequisicionAnio(int anio,int idrequisicion){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.cancelarRequisicionAnio(anio, idrequisicion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("cancelacion de la requisicion año correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar la requisicion año");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * cancelarRequisiciones: cancela la requisicion en la tabla requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	@Override
	public ResponseDTO<Boolean> cancelarRequisiciones(int idrequisicion){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.cancelarRequisiciones(idrequisicion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("cancelacion de la requisicion correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar la requisicion");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * cancelarCuerpoRequisicionAnio: cancela el cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-27
	 */
	@Override
	public ResponseDTO<Boolean> cancelarCuerpoRequisicionAnio(int anio,int idrequisicion){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.cancelarCuerpoRequisicionAnio(anio, idrequisicion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("cancelacion de la requisicion año correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar la requisicion año");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateRequisicionAnio: hace un update en las observaciones la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	@Override
	public ResponseDTO<Boolean> updateRequisicionAnio(UpdateObservaciones ra, int anio,int idrequisicion){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateRequisicionAnio(ra, anio, idrequisicion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("modificacion de la requisicion año correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible modificar la observacion la requisicion año");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateRequisiciones: update en la tabla requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-28
	 */
	@Override
	public ResponseDTO<Boolean> updateRequisiciones(int idrequisicion, int idestatus){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateRequisiciones(idrequisicion, idestatus);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("cancelacion de la requisicion correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar la requisicion");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateEstadoRequisicionAnio: hace un update idestatus en las observaciones la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-28
	 */
	@Override
	public ResponseDTO<Boolean> updateEstatusRequisicionAnio(int anio,int idrequisicion, int idestatus){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateEstatusRequisicionAnio(anio, idrequisicion, idestatus);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("modificacion de la requisicion año correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible modificar la observacion la requisicion año");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<CatalogoRequisicionesAgrupadas>> getGridRequisicionesAgrupada(int anio, int almacen, int mes, int tipoAlmacen) {
		ResponseDTO<List<CatalogoRequisicionesAgrupadas>> response = new ResponseDTO<List<CatalogoRequisicionesAgrupadas>>();
		List<CatalogoRequisicionesAgrupadas> gridRequisiciones = requisicionesRepository.getGridRequisicionesAgrupadas(anio, almacen, mes, tipoAlmacen);
	 	if(gridRequisiciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grid de requisiciones ");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequisiciones);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CatalogoRequisicionesPorAutorizar>> getGridRequisicionesPorAutorizar(int anio, int almacen, int mes, int tipoAlmacen) {
		ResponseDTO<List<CatalogoRequisicionesPorAutorizar>> response = new ResponseDTO<List<CatalogoRequisicionesPorAutorizar>>();
		List<CatalogoRequisicionesPorAutorizar> gridRequisiciones = requisicionesRepository.getGridRequisicionesPorAutorizar(anio, almacen, mes, tipoAlmacen);
	 	if(gridRequisiciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grid de requisiciones ");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequisiciones);
		return response;
	}
	
	@Override
	public ResponseDTO<List<DetalleRequisicionAgrupada>> getGridDetalleRequisicionAgrupada(int anio, int idalmacen, int mes,int tipoAlmacen, int tiposubrequisicion ) {
		ResponseDTO<List<DetalleRequisicionAgrupada>> response = new ResponseDTO<List<DetalleRequisicionAgrupada>>();
		List<DetalleRequisicionAgrupada> gridRequisiciones = requisicionesRepository.getGridDetalleRequisicionAgrupada(anio,idalmacen,mes,tipoAlmacen, tiposubrequisicion);
	 	if(gridRequisiciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el detalle grid de requisicion agrupada");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequisiciones);
		return response;
	}
	
	@Override
	public ResponseDTO<List<DetalleRequisicionAgrupada>> getGridDetalleRequisicionAgrupadaSocio(int anio, int idalmacen, int mes,int tipoAlmacen, int tiposubrequisicion, int idsocio) {
		ResponseDTO<List<DetalleRequisicionAgrupada>> response = new ResponseDTO<List<DetalleRequisicionAgrupada>>();
		List<DetalleRequisicionAgrupada> gridRequisiciones = requisicionesRepository.getGridDetalleRequisicionAgrupadaSocio(anio,idalmacen,mes,tipoAlmacen, tiposubrequisicion, idsocio);
	 	if(gridRequisiciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el detalle grid de requisicion agrupada");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequisiciones);
		return response;
	}
	
	/**
	 * insertRequisicionesAgrupadas: inserta registro en requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-10-10
	 */
	@Override
	public ResponseDTO<Boolean> createRequisicionAgrupada (InsertRequisicionesAgrupadas iReqAg, int anio) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = requisicionesRepository.insertRequisicionAgrupada(iReqAg, anio);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Requisicion agrupada insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la requisicion agrupada ");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertRequisicionesAgrupadasExt: inserta registro en requisicion agrupada extension
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2023-10-10
	 */
	@Override
	public ResponseDTO<Boolean> createRequisicionAgrupadaExt (InsertRequisicionAgrupadaExt iReqAgExt, int anio) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = requisicionesRepository.insertRequisicionAgrupadaExt(iReqAgExt, anio);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Requisicion agrupada extension insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la requisicion agrupada extension ");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertRequisicionClasificacion :inserta registro en requisicion clasificacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-12
	 */
	@Override
	public ResponseDTO<Boolean> createRequisicionClasificacion (RequisicionClasificacion ReqClaf) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = requisicionesRepository.insertRequisicionClasificacion(ReqClaf);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Requisicion clasificacion insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la requisicion clasificacion");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<ListadoRequisicion>> getListadoRequisicionesAgrupadas(int anio, int idrefaccion, int idrequisicion) {
		ResponseDTO<List<ListadoRequisicion>> response = new ResponseDTO<List<ListadoRequisicion>>();
		List<ListadoRequisicion> listadoReq = requisicionesRepository.queryGetListadoRequisicionesAgrupadas(anio, idrefaccion, idrequisicion);
	 	if(listadoReq.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el listado requisicion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(listadoReq);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CantidadReq>> getCantidadListadoAgrupadas(int anio, int idrefaccion, int idrequisicion) {
		ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
		List<CantidadReq> listadoReq = requisicionesRepository.queryGetCantidadListadoAgrupadas(anio, idrefaccion, idrequisicion);
	 	if(listadoReq.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el listado requisicion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(listadoReq);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CantidadReq>> getCantidadReqAgrupadas(int anio, String idrequisicion, int almacen,int idrefaccion) {
		ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
		List<CantidadReq> cantidadReq = requisicionesRepository.queryGetCantidadReqAgrupadas(anio,idrequisicion,almacen,idrefaccion);
	 	if(cantidadReq.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener cantidad requerida");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(cantidadReq);
		return response;
	}
	
	/**
	 * deleteRequisicionAgrupada :delete registro en requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@Override
	public ResponseDTO<Boolean> deleteRequisicionAgrupada(int anio, int idrequisicion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.deleteRequisicionAgrupada(anio,idrequisicion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("eliminacion de la requisicion agrupada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar la requisicion agrupada");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * deleteAgrupadaExtension :delete registro en requisicion agrupada extension
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@Override
	public ResponseDTO<Boolean> deleteAgrupadaExtension(int anio, int idrequisicion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.deleteAgrupadaExtension(anio,idrequisicion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("eliminacion de requisicion agrupada extension correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar la requisicion agrupada extension");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<GetModRequisicionAgrupada>>getModRequisicionAgrupada(int anio, int idrequisicion) {
		ResponseDTO<List<GetModRequisicionAgrupada>> response = new ResponseDTO<List<GetModRequisicionAgrupada>>();
		List<GetModRequisicionAgrupada> requisicion = requisicionesRepository.getModRequisicionAgrupada(anio,idrequisicion);
	 	if(requisicion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de la requisicion agrupada");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(requisicion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetModSociosAgrupada>> getModSociosAgrupada(int anio,int idrequisicion) {
		ResponseDTO<List<GetModSociosAgrupada>> response = new ResponseDTO<List<GetModSociosAgrupada>>();
		List<GetModSociosAgrupada> requisicion = requisicionesRepository.getModSociosAgrupada(anio,idrequisicion);
	 	if(requisicion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la sociedad de la requisicion agrupada");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(requisicion);
		return response;
	}
	
	/**
	 * cancelarRequisicionAgrupada: cancela la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	@Override
	public ResponseDTO<Boolean> cancelarRequisicionAgrupada(int anio,int idrequisicion){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.cancelarRequisicionAgrupada(anio, idrequisicion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("cancelacion de la requisicion agrupada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar la requisicion agrupada");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateRequisicionAgrupada: hace un update en las observaciones la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	@Override
	public ResponseDTO<Boolean> updateRequisicionAgrupada(UpdateObservaciones ra, int anio, int idrequisicion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateRequisicionAgrupada(ra, anio, idrequisicion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion de observaciones de la requisicion agrupada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de la observacion de la requisicion agrupada");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateCantidadSolicitadaAgrupda:update registro en requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@Override
	public ResponseDTO<Boolean> updateCantidadSolicitadaAgrupada (UpdateCantidadRequerida updateCantidadRequerida, int anio, int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateCantidadSolicitadaAgrupada(updateCantidadRequerida, anio, idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion de cantidad de la requisicion agrupada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de la cantidad de la requisicion agrupada");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateRequisicionSociosAgrupada:update registro en requisicion socios agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@Override
	public ResponseDTO<Boolean> updateRequisicionSociosAgrupada(RequisicionSocios socios, int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateRequisicionSociosAgrupada(socios, idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion de requisicion socios agrupada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de requisicion socios agrupada");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateRequisicionHerramientaDestinoAgrupada:update registro en requisicion herramienta destino agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@Override
	public ResponseDTO<Boolean> updateRequisicionHerramientaDestinoAgrupada(HerramientaDestinoAgrupada herramienta, int idrequisicion, int idrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateRequisicionHerramientaDestinoAgrupada(herramienta, idrequisicion, idrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion de requisicion herramienta destino agrupada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de requisicion herramienta destino agrupada");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * createRequisicionHistoricoAgrupadas: Servicio insertar para Requisicion Historico Agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-11-02
	 */
	@Override
	public ResponseDTO<Boolean> createRequisicionHistoricoAgrupadas (RequisicionHistorico requisicionHistorico) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = requisicionesRepository.insertRequisicionHistoricoAgrupadas(requisicionHistorico);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Requisicion historico Agrupadas insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la Requisicion historico Agrupadas");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<GetModRequisicionesHistorico>>getModRequisicionesHistoricoAgrupadas(int idrequisicion) {
		ResponseDTO<List<GetModRequisicionesHistorico>> response = new ResponseDTO<List<GetModRequisicionesHistorico>>();
		List<GetModRequisicionesHistorico> requisicion = requisicionesRepository.getModRequisicionesHistoricoAgrupadas(idrequisicion);
	 	if(requisicion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la relacion consignacion de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(requisicion);
		return response;
	}
	
	/**
	 * updateClaveAutorizada:update registro en la refaccion con clave autorizada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@Override
	public ResponseDTO<Boolean> updateClaveAutorizada(int anio, int idrefaccion, int tiposolicitud, int claveautorizada) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateClaveAutorizada(anio, idrefaccion, tiposolicitud, claveautorizada);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion de clave autorizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de la clave autorizada");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateEstatusRefaccion:update estatus en la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@Override
	public ResponseDTO<Boolean> updateEstatusRefaccion(int anio, int idrefaccion, int tiposolicitud, int idsocio, int idestatusrefaccion) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateEstatusRefaccion(anio, idrefaccion,tiposolicitud, idsocio, idestatusrefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion  estatus refaccion correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información del estatus refaccion");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertRequisicionAgrupadaAutoriza:inserta registro en requisicion agrupada autoriza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@Override
	public ResponseDTO<Boolean> createRequisicionAgrupadaAutoriza (InsertRequisicionAgrupadaAutorizada iReqAg) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = requisicionesRepository.insertRequisicionAgrupadaAutoriza(iReqAg);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Requisicion agrupada autoriza insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la requisicion agrupada autoriza ");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<ListadoRequisicionAutorizada>> getListObtenerIdRequisicion(int anio, int idalmacen, int mes,int tipoAlmacen, int tiposubrequisicion, int idrefaccion ) {
		ResponseDTO<List<ListadoRequisicionAutorizada>> response = new ResponseDTO<List<ListadoRequisicionAutorizada>>();
		List<ListadoRequisicionAutorizada> gridRequisiciones = requisicionesRepository.getListObtenerIdRequisicion(anio,idalmacen,mes,tipoAlmacen, tiposubrequisicion, idrefaccion);
	 	if(gridRequisiciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el detalle grid de requisicion agrupada");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequisiciones);
		return response;
	}
	
	@Override
	public ResponseDTO<List<ObtenerRefaccionesCanceladas>> getListObtenerRefaccionesCanceladas(int anio, int idrequisicion ) {
		ResponseDTO<List<ObtenerRefaccionesCanceladas>> response = new ResponseDTO<List<ObtenerRefaccionesCanceladas>>();
		List<ObtenerRefaccionesCanceladas> gridRequisiciones = requisicionesRepository.getListObtenerRefaccionesCanceladas(anio, idrequisicion);
	 	if(gridRequisiciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener refacciones canceladas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequisiciones);
		return response;
	}
	
	/**
	 * updateEstatusRequisicion:update estatus en la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@Override
	public ResponseDTO<Boolean> updateEstatusRequisicion(int anio, int idrequisicion, int idestatus) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateEstatusRequisicion(anio, idrequisicion, idestatus);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion  estatus idrequisicion correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información del estatus idrequisicion");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateEstatusRequisicionProgramada:update estatus en la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@Override
	public ResponseDTO<Boolean> updateEstatusRequisicionProgramada() {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateEstatusRequisicionProgramada();
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion  estatus idrequisicion correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información del estatus idrequisicion");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateEstatusRefaccionProgramada:update estatus en la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@Override
	public ResponseDTO<Boolean> updateEstatusRefaccionProgramada() {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = requisicionesRepository.updateEstatusRefaccionProgramada();
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("actualizacion  estatus idrefaccion correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información del estatus idrefaccion");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<ObtenerInformacionRequisicion>> getListInformacionRequisicion(int anio, int idrequisicion ) {
		ResponseDTO<List<ObtenerInformacionRequisicion>> response = new ResponseDTO<List<ObtenerInformacionRequisicion>>();
		List<ObtenerInformacionRequisicion> gridRequisiciones = requisicionesRepository.getListInformacionRequisicion(anio, idrequisicion);
	 	if(gridRequisiciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de la requisicion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequisiciones);
		return response;
	}
	
	@Override
	public ResponseDTO<List<RequisicionAutorizada>> getRequisicionSeguimiento(int anio, int tipoAlmacen, int mes ) {
		ResponseDTO<List<RequisicionAutorizada>> response = new ResponseDTO<List<RequisicionAutorizada>>();
		List<RequisicionAutorizada> gridRequisiciones = requisicionesRepository.getRequisicionSeguimiento(anio, tipoAlmacen, mes);
	 	if(gridRequisiciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la requisicion seguimiento");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(gridRequisiciones);
		return response;
	}
	
	@Override
	public List<Requisiciones> getAll() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Requisiciones save(Requisiciones requisiciones) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Requisiciones update(Requisiciones requisiciones) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Requisiciones delete(Integer idrequisicion) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Requisiciones getById(Integer idrequisicion) {
		// TODO Auto-generated method stub
		return null;
	}
}
