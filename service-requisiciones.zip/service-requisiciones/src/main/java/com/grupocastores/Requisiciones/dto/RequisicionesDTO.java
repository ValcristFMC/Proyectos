package com.grupocastores.Requisiciones.dto;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import io.swagger.annotations.ApiModel;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.Requisiciones.service.domain.Requisiciones} del modelo de dominio
 *
 * @author Castores - Desarrollo TI
 */
@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un Requisiciones", description = "Datos del Requisiciones")
public class RequisicionesDTO 
{
	private int idrequisicion;
	private String clave;
	private int idsolicita;
	private String observaciones;
	private int idurgencia;
	private int idestatus;
	private int idalmacen;
	private int idautoriza;
	private int idreviso;
	private int esnueva;
	private int idpersonal;
	private Date fecha;
	private Time hora;
	
	/**
	 * @param idrequisicion
	 * @param clave
	 * @param idsolicita
	 * @param observaciones
	 * @param idurgencia
	 * @param idestatus
	 * @param idalmacen
	 * @param idautoriza
	 * @param idreviso
	 * @param esnueva
	 * @param idpersonal
	 * @param fecha
	 * @param hora
	 */
	public RequisicionesDTO(int idrequisicion, String clave, int idsolicita, String observaciones, int idurgencia,
			int idestatus, int idalmacen, int idautoriza, int idreviso, int esnueva, int idpersonal, Date fecha,
			Time hora) {
		super();
		this.idrequisicion = idrequisicion;
		this.clave = clave;
		this.idsolicita = idsolicita;
		this.observaciones = observaciones;
		this.idurgencia = idurgencia;
		this.idestatus = idestatus;
		this.idalmacen = idalmacen;
		this.idautoriza = idautoriza;
		this.idreviso = idreviso;
		this.esnueva = esnueva;
		this.idpersonal = idpersonal;
		this.fecha = fecha;
		this.hora = hora;
	}

	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Requisiciones [idrequisicion=").append(idrequisicion)
		.append(",clave").append(clave)
		.append(",idsolicita").append(idsolicita)
		.append(",observaciones").append(observaciones)
		.append(",idurgencia").append(idurgencia)
		.append(",idestatus").append(idestatus)
		.append(",idalmacen").append(idalmacen)
		.append(",idautoriza").append(idautoriza)
		.append(",idreviso").append(idreviso)
		.append(", esnueva=").append(esnueva)
		.append(",idpersonal=").append(idpersonal)
		.append(",fecha=").append(fecha)
		.append(",hora=").append(hora);		
		return strBuilder.toString();
	}
}
