package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de SociosSiat", description = "mapea tabla de siat.sociosiat")
@Entity
@Table(name = "siat.sociossiat")
public class RequisicionSocios {
	
	@Id
	@Column(name="idrequisicionsocios")
	private int idrequisicionsocios;
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name="idsocio")
	private int idsocio;
	@Column(name="idunidad")
	private int idunidad;
	@Column(name = "noeconomico")
	private int noeconomico;
	@Column(name = "serie")
	private String serie;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
	@Column(name="idrefaccion")
	private int idrefaccion;
}
