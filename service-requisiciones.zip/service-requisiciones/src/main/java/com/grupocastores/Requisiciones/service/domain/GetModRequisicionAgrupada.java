package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion para la modificacion de requisicion", description = "mapea tabla de siat.requisicionAnio")
@Entity
@Table(name = "siat.requisicionAnio")
public class GetModRequisicionAgrupada {
	
	@Id
	@Column(name = "idrefaccion")
	private int idrefaccion;
	@Column(name="idrequisicion")
	private int idrequisicion;
	@Column(name = "clave")
	private String clave;
	@Column(name = "cantsolicitada")
	private Double cantsolicitada;
	@Column(name="idmedida")
	private int idmedida;
	@Column(name = "nombrePieza")
	private String nombrePieza;
	@Column(name = "tipo_medida")
	private int tipo_medida;
	@Column(name = "observaciones")
	private String observaciones;
	@Column(name="idestatus")
	private int idestatus;
	@Column(name = "nomAlmacen")
	private String nomAlmacen;
	@Column(name = "estatus")
	private String estatus;
	@Column(name = "nomRefaccion")
	private String nomRefaccion;
	@Column(name = "tipoRef")
	private String tipoRef;
	@Column(name = "idalmacen")
	private int idalmacen;
	@Column(name = "idpersonal")
	private int idpersonal;
	@Column(name = "autoriza")
	private String autoriza;
	@Column(name = "urgencia")
	private String urgencia;
	@Column(name = "idalmacendestino")
	private int idalmacendestino;
	@Column(name = "nombrealmacendestino")
	private String nombrealmacendestino;
	@Column(name = "presentacion")
	private String presentacion;
}
