package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Almacenes", description = "mapea tabla de siat.almacen")
@Entity
@Table(name = "siat.almacen")
public class CatalogoAlmacen {
	
	@Id
	@Column(name="idalmacen")
	private int idalmacen;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "estatus")
	private int estatus;
	@Column(name = "idpersonal")
	private int idpersonal;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
	
}
