package com.grupocastores.Requisiciones.dto;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import io.swagger.annotations.ApiModel;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.Requisiciones.service.domain.Requisiciones} del modelo de dominio
 *
 * @author Castores - Desarrollo TI
 */
@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un Requisiciones", description = "Datos del Requisiciones")
public class AlmacenDTO 
{
	private int idalmacen;
	private String nombre;
	private int estatus;
	private int idpersonal;
	private Date fecha;
	private Time hora;
	
	/**
	 * @param idlamacen
	 * @param nombre
	 * @param estatus
	 * @param idpersonal
	 * @param fecha
	 * @param hora
	 */
	public AlmacenDTO(int idrequisicion, String clave, int idsolicita, String observaciones, int idurgencia,
			int idestatus, int idalmacen, int idautoriza, int idreviso, int esnueva, int idpersonal, Date fecha,
			Time hora) {
		super();
		this.idalmacen = idalmacen;
		this.nombre = nombre;
		this.estatus = estatus;
		this.idpersonal = idpersonal;
		this.fecha = fecha;
		this.hora = hora;
	}

	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Almacen [idalmacen=").append(idalmacen)
		.append(",nombre").append(nombre)
		.append(",estatus").append(estatus)
		.append(",idpersonal").append(idpersonal)
		.append(",fecha=").append(fecha)
		.append(",hora=").append(hora);		
		return strBuilder.toString();
	}
}
