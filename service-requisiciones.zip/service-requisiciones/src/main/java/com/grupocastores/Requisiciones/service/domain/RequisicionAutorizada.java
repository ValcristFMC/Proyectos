package com.grupocastores.Requisiciones.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de CatalogoRequisiciones", description = "mapea tabla de siat.requisiciones")
@Entity
@Table(name = "siat.requisiciones2023")
public class RequisicionAutorizada {
	
	@Id
	@Column(name="claveautorizada")
	private int claveautorizada;
	@Column(name = "idtiporequisicion")
	private int idtiporequisicion;
	@Column(name="idtiposubrequisicion")
	private int idtiposubrequisicion;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "fechaautorizada")
	private LocalDate fechaautorizada;
	@Column(name = "idestatus")
	private int idestatus;
	@Column(name = "estatus")
	private String estatus;
	@Column(name = "idalmacen")
	private int idalmacen;
	@Column(name = "nomAlmacen")
	private String nomAlmacen;
	@Column(name = "tipoAlmacen")
	private String tipoAlmacen;
	@Column(name = "razonsocial")
	private String razonsocial;
	@Column(name = "nombreSocio")
	private String nombreSocio;
}
