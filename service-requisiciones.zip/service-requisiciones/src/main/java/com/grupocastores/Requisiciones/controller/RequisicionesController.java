package com.grupocastores.Requisiciones.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.grupocastores.Requisiciones.service.domain.Requisiciones;
import com.grupocastores.Requisiciones.service.domain.SemaforoSiat;
import com.grupocastores.Requisiciones.service.domain.SiatRequisiciones;
import com.grupocastores.Requisiciones.service.domain.TipoAutorizacion;
import com.grupocastores.Requisiciones.service.domain.UpdateCantidadRequerida;
import com.grupocastores.Requisiciones.service.domain.UpdateObservaciones;
import com.grupocastores.Requisiciones.service.domain.ValidaUnidades;
import com.grupocastores.Requisiciones.service.domain.CuerpoDetalle;
import com.grupocastores.Requisiciones.service.domain.CuerpoRequisicionAnio;
import com.grupocastores.Requisiciones.service.domain.DetalleRequisicionAgrupada;
import com.grupocastores.Requisiciones.service.domain.RequisicionAnio;
import com.grupocastores.Requisiciones.service.domain.RequisicionAutorizada;
import com.grupocastores.Requisiciones.service.domain.RequisicionClasificacion;
import com.grupocastores.Requisiciones.service.domain.RequisicionHistorico;
import com.grupocastores.Requisiciones.service.domain.RequisicionRefClasificacion;
import com.grupocastores.Requisiciones.dto.ResponseDTO;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisiciones;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisicionesAgrupadas;
import com.grupocastores.Requisiciones.service.domain.CatalogoRequisicionesPorAutorizar;
import com.grupocastores.Requisiciones.service.domain.CantidadNoConv;
import com.grupocastores.Requisiciones.service.domain.CantidadReq;
import com.grupocastores.Requisiciones.service.domain.CatalogoAlmacen;
import com.grupocastores.Requisiciones.service.domain.Folio;
import com.grupocastores.Requisiciones.service.domain.GetModHerrDestino;
import com.grupocastores.Requisiciones.service.domain.GetModHistoricoOrdenCompra;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicion;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicionAgrupada;
import com.grupocastores.Requisiciones.service.domain.GetModRequisicionesHistorico;
import com.grupocastores.Requisiciones.service.domain.GetModSocios;
import com.grupocastores.Requisiciones.service.domain.GetModSociosAgrupada;
import com.grupocastores.Requisiciones.service.domain.GetModUrgencia;
import com.grupocastores.Requisiciones.service.domain.ListadoRequisicion;
import com.grupocastores.Requisiciones.service.domain.ListadoRequisicionAutorizada;
import com.grupocastores.Requisiciones.service.domain.ObtenerInformacionRequisicion;
import com.grupocastores.Requisiciones.service.domain.ObtenerRefaccionesCanceladas;
import com.grupocastores.Requisiciones.service.domain.RefaccionPorAlmacen;
import com.grupocastores.Requisiciones.service.domain.RefaccionesConvenio;
import com.grupocastores.Requisiciones.service.domain.RefaccionesRev;
import com.grupocastores.Requisiciones.service.domain.ProveedorRefaccion;
import com.grupocastores.Requisiciones.service.domain.CatalogoSocios;
import com.grupocastores.Requisiciones.service.domain.ClasificacionRef;
import com.grupocastores.Requisiciones.service.domain.RefaccionConsignacion;
import com.grupocastores.Requisiciones.service.IRequisicionesService;
import com.grupocastores.Requisiciones.service.domain.RequisicionSocios;
import com.grupocastores.Requisiciones.service.domain.HerramientaDestino;
import com.grupocastores.Requisiciones.service.domain.HerramientaDestinoAgrupada;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionAgrupadaAutorizada;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionAgrupadaExt;
import com.grupocastores.Requisiciones.service.domain.InsertRequisicionesAgrupadas;
import com.grupocastores.Requisiciones.dto.RequisicionesDTO;
import com.grupocastores.Requisiciones.dto.AlmacenDTO;

@RestController
@RequestMapping(value = "/requisiciones")
@Api(value = "RequisicionesController", produces = "application/json")
@CrossOrigin(origins = "*")
/**
 * Controlador de commands 
 *
 * @author Castores - Desarrollo TI
 */
public class  RequisicionesController {

	Logger logger = LoggerFactory.getLogger(RequisicionesController.class);
	
	@Autowired
	private IRequisicionesService requisicionesService;
	static final String HEADERBACK = "/Requisiciones/{id}";

    /**
     * Crea registro Requisiciones.
     *
     * @param requisiciones RequisicionesDTO
     * @param builder UriComponentsBuilder
     * @return RequisicionesDTO
     */
	@ApiOperation(value = "Crea un registro Requisiciones", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Registro de Requisiciones creado", response = RequisicionesDTO.class), @ApiResponse(code = 404, message = "No creado") })
	@PostMapping("/create")
	public ResponseEntity<RequisicionesDTO> create(@ApiParam(value = "Registro de Requisiciones que se va a crear", required = true) @RequestBody @Valid RequisicionesDTO requisicionesDto, UriComponentsBuilder builder) {
		try {
			Requisiciones requisicionesCreated = requisicionesService.save(Requisiciones.fromRequisicionesDTO(requisicionesDto));
	
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(requisicionesCreated.getIdrequisicion())).toUri());
	
			RequisicionesDTO output = requisicionesCreated.toRequisicionesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

    /**
     * Actualiza Requisiciones.
     *
     * @param requisiciones RequisicionesDTO
     * @param builder UriComponentsBuilder
     * @return RequisicionesDTO
     */
	@ApiOperation(value = "Actualiza un Requisiciones", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Requisiciones actualiza", response = RequisicionesDTO.class), @ApiResponse(code = 404, message = "No actualizado") })
	@PutMapping("/update")
	public ResponseEntity<RequisicionesDTO> update(@ApiParam(value = "Registro Requisiciones que se va a actualizar", required = true) @RequestBody @Valid RequisicionesDTO requisicionesDto, UriComponentsBuilder builder) {
		try {
			Requisiciones requisicionesCreated = requisicionesService.update(Requisiciones.fromRequisicionesDTO(requisicionesDto));
	
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(requisicionesCreated.getIdrequisicion())).toUri());
	
			RequisicionesDTO output = requisicionesCreated.toRequisicionesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.ACCEPTED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

    /**
     * Elimina registro Requisiciones.
     *
     * @param id Integer
     * @return RequisicionesDTO
     */
	@ApiOperation(value = "Elimina un Requisiciones", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Registro eliminado", response = RequisicionesDTO.class), @ApiResponse(code = 404, message = "Registro no eliminado") })
	@DeleteMapping(value = "{id}")
	public ResponseEntity<RequisicionesDTO> delete(@ApiParam(value = "Id del Requisiciones que se va a crear", required = true) @PathVariable String id) {
		try {
			Requisiciones requisicionesDeleted = requisicionesService.delete(new Integer(id));
	
			HttpHeaders headers = new HttpHeaders();
			
			RequisicionesDTO output = requisicionesDeleted.toRequisicionesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.ACCEPTED);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	/**
	 * Pide todos los Requisicioness.
	 *
	 * @return los Requisicioness
	 */
	@ApiOperation(value = "Recupera Requisicioness", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Requisicioness obtenidos", response = RequisicionesDTO.class), @ApiResponse(code = 404, message = "No encontrados") })
	@GetMapping("/getAll")
	@ResponseBody
	public Collection<RequisicionesDTO> getAll() {
		List<RequisicionesDTO> requisicioness = new ArrayList<>();
		for (Requisiciones requisiciones : requisicionesService.getAll()) {
			requisicioness.add(requisiciones.toRequisicionesDTO());
		}
		return requisicioness;
	}

	/**
	 * Pide un Requisiciones por id.
	 *
	 * @param id int id del Requisiciones
	 * @return el Requisiciones
	 */
	@ApiOperation(value = "Recupera Requisicioness", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Requisiciones recuperado", response = RequisicionesDTO.class), @ApiResponse(code = 404, message = "No encontrado") })
	@GetMapping(value = "{id}")
	@ResponseBody
	public RequisicionesDTO getById(@ApiParam(value = "Id del Requisiciones que se pide", required = true) @PathVariable String id) {
		Requisiciones requisiciones = requisicionesService.getById(Integer.valueOf(id));
		return requisiciones.toRequisicionesDTO();
	}
	
	/**
	 * getRequisiciones: obtiene las requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-18
	 */
	@ApiOperation(value = " Servicio para grid Requisiciones", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el grid requisiciones", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridRequisiciones/{anio}/{almacen}/{tipoalmacen}")
	@ResponseBody
	public ResponseDTO<List<CatalogoRequisiciones>> getGridRequisiciones(
			@PathVariable("anio") int anio,
			@PathVariable("almacen") int almacen,
			@PathVariable("tipoalmacen") int tipoalmacen) {
		
		try {	
			
			return requisicionesService.getGridRequisiciones(anio, almacen, tipoalmacen);
		} catch (Exception e) {
			ResponseDTO<List<CatalogoRequisiciones>> response = new ResponseDTO<List<CatalogoRequisiciones>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de requisiciones");
			response.setData(null);
			return response;
		}
	}
	

	/**
	 * getRequisiciones: obtiene las requisiciones por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-18
	 */
	@ApiOperation(value = " Servicio para grid Requisiciones por almacen", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el grid requisiciones", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridRequiPorAlmacen/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<List<CatalogoRequisiciones>> getGridRequiPorAlmacen(
			@PathVariable("anio") int anio,
			@PathVariable("idAlmacen") int idAlmacen) {
		try {	
			
			return requisicionesService.getGridRequiPorAlmacen(anio,idAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<CatalogoRequisiciones>> response = new ResponseDTO<List<CatalogoRequisiciones>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de requisiciones por almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRequisiciones: obtiene las requisiciones por mes, anio y almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-18
	 */
	@ApiOperation(value = " Servicio para grid Requisiciones por almaceny mes", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el grid requisiciones", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridRequiPorAnio/{anio}/{idAlmacen}/{mes}/{tipoalmacen}")
	@ResponseBody
	public ResponseDTO<List<CatalogoRequisiciones>> getGridRequiPorAnio(
		@PathVariable("anio") int anio,
		@PathVariable("idAlmacen") int idAlmacen,
		@PathVariable("mes") int mes,
		@PathVariable("tipoalmacen") int tipoalmacen) {
		
		try {	
			
			return requisicionesService.getGridRequiPorAnio(anio, idAlmacen,mes, tipoalmacen);
		} catch (Exception e) {
			ResponseDTO<List<CatalogoRequisiciones>> response = new ResponseDTO<List<CatalogoRequisiciones>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de requisiciones por almacen y mes");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getAlmacenes: obtiene los almacenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-18
	 */
	@ApiOperation(value = " Servicio para grid de almacen", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para los almacenes", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getAlmacen/{tipoAlmacen}/{nomAlmacen}")
	@ResponseBody
	public ResponseDTO<List<CatalogoAlmacen>> getAlmacen(
			@PathVariable("tipoAlmacen") int tipoAlmacen,
			@PathVariable("nomAlmacen") String nomAlmacen) {
		
		try {
			return requisicionesService.getAlmacen(tipoAlmacen, nomAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<CatalogoAlmacen>> response = new ResponseDTO<List<CatalogoAlmacen>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el catalogo de almacenes");
			response.setData(null);
			return response;
		}
	}
	

	/**
	 * getSemaforoSiat: obtiene semaforo siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-08
	 */
	@ApiOperation(value = " Servicio semaforo siat", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el semaforo siat", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getSemaforoSiat/{estatus}")
	@ResponseBody
	public ResponseDTO<List<SemaforoSiat>> getSemaforoSiat(
			@PathVariable("estatus") int estatus) {
		
		try {	
			
			return requisicionesService.getSemaforoSiat(estatus);
		} catch (Exception e) {
			ResponseDTO<List<SemaforoSiat>> response = new ResponseDTO<List<SemaforoSiat>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el semaforo siat");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createCuerpoDetalle: Servicio insertar para cuerpo detalle.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-28
	 */
	@ApiOperation(value = "Servicio insertar para insertar cuerpo detalle", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Cuerpo detalle insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar cuerpo detalle") 
			})
	@PostMapping("/createCuerpoDetalle")
	@ResponseBody
	public ResponseDTO<Boolean> createCuerpoDetalle(
			@RequestBody CuerpoDetalle cuerpoDetalle) {
		
		try {	
			return requisicionesService.createCuerpoDetalle(cuerpoDetalle);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar cuerpo detalle");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createRequisicionRefClasificacion: Servicio insertar para RequisicionRefClasificacion.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-28
	 */
	@ApiOperation(value = "Servicio insertar para insertar RequisicionRefClasificacion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "refaccion clasificacion insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar requisicion refaccion clasificacion") 
			})
	@PostMapping("/createRequisicionRefClasificacion")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicionRefClasificacion(
			@RequestBody RequisicionRefClasificacion requisicionRefClasificacion) {
		
		try {	
			return requisicionesService.createRequisicionRefClasificacion(requisicionRefClasificacion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar requisicion refaccion clasificacion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createRequisicionHistorico: Servicio insertar para Requisicion Historico.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-28
	 */
	@ApiOperation(value = "Servicio insertar para insertar RequisicionHistorico", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "RequisicionHistorico insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar RequisicionHistorico") 
			})
	@PostMapping("/createRequisicionHistorico")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicionHistorico(
			@RequestBody RequisicionHistorico requisicionHistorico) {
		
		try {	
			return requisicionesService.createRequisicionHistorico(requisicionHistorico);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar RequisicionHistorico");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createRequisicionAnio: Servicio insertar para RequisicionAnio.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-07-28
	 */
	@ApiOperation(value = "Servicio insertar para insertar RequisicionAnio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "RequisicionAnio insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar RequisicionAnio") 
			})
	@PostMapping("/createRequisicionAnio/{anio}")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicionAnio(
			@RequestBody RequisicionAnio requisicionAnio,
			@PathVariable("anio") int anio) {
		
		try {	
			return requisicionesService.createRequisicionAnio(requisicionAnio,anio);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar RequisicionAnio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getFolio: obtiene folio siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-10
	 */
	@ApiOperation(value = " Servicio folio siat", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para los folios", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getFolio/{tipofolio}")
	@ResponseBody
	public ResponseDTO<List<Folio>> getFolio(
			@PathVariable("tipofolio") int tipofolio) {
		
		try {	
			
			return requisicionesService.getFolio(tipofolio);
		} catch (Exception e) {
			ResponseDTO<List<Folio>> response = new ResponseDTO<List<Folio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el folio siat");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRefaccionPorAlmacen: obtiene refacciones por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-10
	 */
	@ApiOperation(value = " Servicio refaccion por almacen", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para los almacenes", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRefPorAlmacen/{idalmacen}/{tiporef}")
	@ResponseBody
	public ResponseDTO<List<RefaccionPorAlmacen>> getRefPorAlmacen(
			@PathVariable("idalmacen") int idalmacen,
			@PathVariable("tiporef") int tiporef) {
		
		try {	
			
			return requisicionesService.getRefPorAlmacen(idalmacen, tiporef);
		} catch (Exception e) {
			ResponseDTO<List<RefaccionPorAlmacen>> response = new ResponseDTO<List<RefaccionPorAlmacen>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener las refacciones por almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getProveedorRef: obtiene los proveedores de las refacciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-10
	 */
	@ApiOperation(value = " Servicio proveedores de la refaccion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para los proveedor", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getProveedorRef/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<List<ProveedorRefaccion>> getProveedorRef(
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			
			return requisicionesService.getProveedorRef(idrefaccion);

		} catch (Exception e) {
			ResponseDTO<List<ProveedorRefaccion>> response = new ResponseDTO<List<ProveedorRefaccion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener las refacciones por almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getArrRefaccionesRev: obtiene las refacciones si tienen convenios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-21
	 */
	@ApiOperation(value = " Servicio para convenios de la refacciones", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para los convenios", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getArrRefaccionesRev/{refaccionesRev}")
	@ResponseBody
	public ResponseDTO<List<RefaccionesRev>> getArrRefaccionesRev(
			@PathVariable("refaccionesRev") String refaccionesRev) {
		
		try {	
			
			return requisicionesService.getArrRefaccionesRev(refaccionesRev);
		} catch (Exception e) {
			ResponseDTO<List<RefaccionesRev>> response = new ResponseDTO<List<RefaccionesRev>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener los convenios de las refacciones");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTipoAutorizacion: obtiene el tipo de autorizacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-21
	 */
	@ApiOperation(value = " Servicio tipo de autorizacion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el tipo de autorizacion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTipoAutorizacion/{idtipoautorizacion}")
	@ResponseBody
	public ResponseDTO<List<TipoAutorizacion>> getTipoAutorizacion(
			@PathVariable("idtipoautorizacion") int idtipoautorizacion) {
		
		try {	
			
			return requisicionesService.getTipoAutorizacion(idtipoautorizacion);
		} catch (Exception e) {
			ResponseDTO<List<TipoAutorizacion>> response = new ResponseDTO<List<TipoAutorizacion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio refacciones convenio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las refacciones convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRefaccionesEnConvenio/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<List<RefaccionesConvenio>> getRefaccionesEnConvenio(
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			
			return requisicionesService.getRefaccionesEnConvenio(idrefaccion);
		} catch (Exception e) {
			ResponseDTO<List<RefaccionesConvenio>> response = new ResponseDTO<List<RefaccionesConvenio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio refacciones convenio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las refacciones convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRefaccionesEnConvenioProv/{idrefaccion}/{idproveedor}")
	@ResponseBody
	public ResponseDTO<List<RefaccionesConvenio>> getRefaccionesEnConvenioProv(
			@PathVariable("idrefaccion") int idrefaccion,
			@PathVariable("idproveedor") int idproveedor) {
		
		try {	
			
			return requisicionesService.getRefaccionesEnConvenioProv(idrefaccion,idproveedor);
		} catch (Exception e) {
			ResponseDTO<List<RefaccionesConvenio>> response = new ResponseDTO<List<RefaccionesConvenio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio refacciones convenio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las refacciones convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getListadoRequisiciones/{idrefaccion}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<ListadoRequisicion>> getListadoRequisiciones(
			@PathVariable("idrefaccion") int idrefaccion,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getListadoRequisiciones(idrefaccion,idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<ListadoRequisicion>> response = new ResponseDTO<List<ListadoRequisicion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio cantidad listado", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las cantidad listado requisicion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCantidadListado/{idrefaccion}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<CantidadReq>> queryGetCantidadListado(
			@PathVariable("idrefaccion") int idrefaccion,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getCantidadListado(idrefaccion,idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio refacciones convenio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las refacciones convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCantidadReq/{anio}/{idrequisicion}/{almacen}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<List<CantidadReq>> getCantidadReq(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") String idrequisicion,
			@PathVariable("almacen") int almacen,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			
			return requisicionesService.getCantidadReq(anio,idrequisicion,almacen, idrefaccion);
		} catch (Exception e) {
			ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio refacciones convenio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las refacciones convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCantidadConvenio/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<List<CantidadReq>> getCantidadConvenio(
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			
			return requisicionesService.getCantidadConvenio(idrefaccion);
		} catch (Exception e) {
			ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio refacciones convenio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las refacciones convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCantidadNoConvenio/{idrefaccion}/{almacen}")
	@ResponseBody
	public ResponseDTO<List<CantidadNoConv>> getCantidadNoConvenio(
			@PathVariable("idrefaccion") int idrefaccion,
			@PathVariable("almacen") int almacen) {
		
		try {	
			
			return requisicionesService.getCantidadNoConvenio(idrefaccion,almacen);
		} catch (Exception e) {
			ResponseDTO<List<CantidadNoConv>> response = new ResponseDTO<List<CantidadNoConv>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createFolio: Servicio insertar para folios.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	@ApiOperation(value = "Servicio insertar para insertar folio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Folio insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar Folio") 
			})
	@PostMapping("/createFolio/{tipofolio}")
	@ResponseBody
	public ResponseDTO<Boolean> createFolio(
			@RequestBody Folio folio,
			@PathVariable("tipofolio") int tipofolio) {
		
		try {	
			return requisicionesService.createFolio(folio, tipofolio);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar Folio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getSocios: obtiene socios siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	@ApiOperation(value = " Servicio socios siat", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para los socios siat", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getSocios/{nombre}")
	@ResponseBody
	public ResponseDTO<List<CatalogoSocios>> getSocios(
			@PathVariable("nombre") String nombre) {
		
		try {	
			
			return requisicionesService.getSocios(nombre);
		} catch (Exception e) {
			ResponseDTO<List<CatalogoSocios>> response = new ResponseDTO<List<CatalogoSocios>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener los socios siat");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getUnidades: obtiene unidad siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	@ApiOperation(value = " Servicio unidad siat", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la unidad siat", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getUnidadEco/{socio}/{noeconomico}")
	@ResponseBody
	public ResponseDTO<List<ValidaUnidades>> getUnidadEco(
			@PathVariable("socio") int socio,
			@PathVariable("noeconomico") int noeconomico) {
		
		try {	
			
			return requisicionesService.getUnidadEco(socio,noeconomico);
		} catch (Exception e) {
			ResponseDTO<List<ValidaUnidades>> response = new ResponseDTO<List<ValidaUnidades>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la unidad siat");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getUnidades: obtiene unidad siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-12
	 */
	@ApiOperation(value = " Servicio unidad siat", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la unidad siat", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getUnidadSerie/{socio}/{serie}")
	@ResponseBody
	public ResponseDTO<List<ValidaUnidades>> getUnidadSerie(
			@PathVariable("socio") int socio,
			@PathVariable("serie") String serie) {
		
		try {	
			
			return requisicionesService.getUnidadSerie(socio,serie);
		} catch (Exception e) {
			ResponseDTO<List<ValidaUnidades>> response = new ResponseDTO<List<ValidaUnidades>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la unidad siat");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRelacionConsig: obtiene la relacion consignacion de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-14
	 */
	@ApiOperation(value = " Servicio relacion consignacion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la relacion consignacion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRelacionConsig/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<List<RefaccionConsignacion>> getRelacionConsig(
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			
			return requisicionesService.getRelacionConsig(idrefaccion);
		} catch (Exception e) {
			ResponseDTO<List<RefaccionConsignacion>> response = new ResponseDTO<List<RefaccionConsignacion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la relacion consignacion ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createHerramientaDestino: Servicio insertar para herramienta destino.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-14
	 */
	@ApiOperation(value = "Servicio insertar para insertar herramienta destino", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "herramienta destino insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar herramienta destino") 
			})
	@PostMapping("/createHerramientaDestino")
	@ResponseBody
	public ResponseDTO<Boolean> createHerramientaDestino(
			@RequestBody HerramientaDestino herramienta) {
		
		try {	
			return requisicionesService.createHerramientaDestino(herramienta);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar herramienta destino");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createRequisicionSocios: Servicio insertar para requisicion socios.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-14
	 */
	@ApiOperation(value = "Servicio insertar para insertar requisicionsocios", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "requisicion socios insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar requisicion socios") 
			})
	@PostMapping("/createRequisicionSocios")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicionSocios(
			@RequestBody RequisicionSocios socios) {
		
		try {	
			return requisicionesService.createRequisicionSocios(socios);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar requisicion socios");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createCuerpoRequisicionAnio: Servicio insertar para CuerpoRequisicionAnio.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-15
	 */
	@ApiOperation(value = "Servicio insertar para insertar CuerpoRequisicionAnio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "RequisicionAnio insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar CuerpoRequisicionAnio") 
			})
	@PostMapping("/createCuerpoRequisicionAnio/{anio}")
	@ResponseBody
	public ResponseDTO<Boolean> createCuerpoRequisicionAnio(
			@RequestBody CuerpoRequisicionAnio cuerpoRequisicionAnio,
			@PathVariable("anio") int anio) {
		
		try {	
			return requisicionesService.createCuerpoRequisicionAnio(cuerpoRequisicionAnio,anio);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar CuerpoRequisicionAnio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createRequisiciones: Servicio insertar para requisiciones.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-15
	 */
	@ApiOperation(value = "Servicio insertar para insertar requisicion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "requisicion insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar requisicion") 
			})
	@PostMapping("/createRequisicion")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicion(
			@RequestBody SiatRequisiciones siatRequisiciones) {
		
		try {	
			return requisicionesService.createRequisiciones(siatRequisiciones);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar requisicion socios");
			response.setData(null);
			return response;
		}
	}
	
	
	/**
	 * getClasificacionRef: obtiene la clasificacion de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-18
	 */
	@ApiOperation(value = " Servicio clasificacion refaccion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la clasificacion de la refaccion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getClasificacionRef/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<List<ClasificacionRef>> getClasificacionRef(
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			
			return requisicionesService.getClasificacionRef(idrefaccion);
		} catch (Exception e) {
			ResponseDTO<List<ClasificacionRef>> response = new ResponseDTO<List<ClasificacionRef>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la clasificacion de la refaccion ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getModRequisiciones: obtiene la información para la modificacion de requisicion.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	@ApiOperation(value = " Servicio para la modificacion de requisicion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la modificacion de requisicion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getModRequisicion/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<GetModRequisicion>> getModRequisicion(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getModRequisicion(anio,idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<GetModRequisicion>> response = new ResponseDTO<List<GetModRequisicion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la clasificacion de la refaccion ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getModRequisicionesHistorico: obtiene la información para la modificacion de requisicio historico.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	@ApiOperation(value = " Servicio para la  modificacion de historico requisicion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la modificacion de historico requisicion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getModRequisicionesHistorico/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<GetModRequisicionesHistorico>> getModRequisicionesHistorico(
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getModRequisicionesHistorico(idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<GetModRequisicionesHistorico>> response = new ResponseDTO<List<GetModRequisicionesHistorico>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el historico requisicion ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getModHistoricoOrdenCompra: obtiene la información para la modificacion de orden compra.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	@ApiOperation(value = " Servicio para la  modificacion de  historico orden de compra", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la modificacion de historico orden compra", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getModHistoricoOrdenCompra/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<GetModHistoricoOrdenCompra>> getModHistoricoOrdenCompra(
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getModHistoricoOrdenCompra(idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<GetModHistoricoOrdenCompra>> response = new ResponseDTO<List<GetModHistoricoOrdenCompra>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el historico de orden de compra ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getModUrgencia: obtiene la información para la modificacion de urgencia y almacen.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	@ApiOperation(value = " Servicio para la  modificacion de  historico con la urgencia y almacen", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la modificacion de historico con la urgencia y almacen", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getModUrgencia/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<GetModUrgencia>> getModUrgencia(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getModUrgencia(anio,idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<GetModUrgencia>> response = new ResponseDTO<List<GetModUrgencia>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el historico con la urgencia y almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getModHerrDestino: obtiene la información para la modificacion de herramienta destino.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-22
	 */
	@ApiOperation(value = " Servicio para la  obtencion de la informacion de la herramienta destino", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la obtencion de la informacion de la herramienta destino", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getModHerrDestino/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<GetModHerrDestino>> getModHerrDestino(
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getModHerrDestino(idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<GetModHerrDestino>> response = new ResponseDTO<List<GetModHerrDestino>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el destino de la herramienta");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getModSocios: obtiene la información para la modificacion de socios.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-22
	 */
	@ApiOperation(value = " Servicio para la obtencion de la sociedad", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la obtencion de la sociedad", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getModSocios/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<GetModSocios>> getModSocios(
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getModSocios(idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<GetModSocios>> response = new ResponseDTO<List<GetModSocios>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la sociedad");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getAcomuladoCuerpoDet: obtiene la cantidad del cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-25
	 */
	@ApiOperation(value = " Servicio refacciones acomulado cuerpo detalle", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el acomulado cuerpo detalle", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getAcomuladoCuerpoDet/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<CantidadReq>> getAcomuladoCuerpoDet(
			@PathVariable("idrequisicion") int idrequisicion){
		
		try {	
			
			return requisicionesService.queryGetAcomuladoCuerpoDet(idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el  acomulado cuerpo detalle");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateCantidadRequi:update registro en requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@ApiOperation(value = "Servicio para la actualizacion de cantidad de la requisicion ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de cantidad de la requisicion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar la cantidad de la requisicion") 
			})
	@PostMapping("/updateCantidadRequerida/{anio}/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateCantidadRequerida(
			@RequestBody UpdateCantidadRequerida updateCantidadRequerida,
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.updateCantidadRequerida(updateCantidadRequerida, anio, idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar la cantidad de la idrefaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRequisicionSocios:update registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@ApiOperation(value = "Servicio para la actualizacion de requisicion socios ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de requisicion socios correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar requisicion socios") 
			})
	@PostMapping("/updateRequisicionSocios/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRequisicionSocios(
			@RequestBody RequisicionSocios socios,
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.updateRequisicionSocios(socios, idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar requisicion socios");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRequisicionHerramientaDestino:update registro en requisicion herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@ApiOperation(value = "Servicio para la actualizacion de requisicion socios ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de requisicion herramienta destino correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar requisicion herramienta destino") 
			})
	@PostMapping("/updateRequisicionHerramientaDestino/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRequisicionHerramientaDestino(
			@RequestBody HerramientaDestino herramienta,
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.updateRequisicionHerramientaDestino(herramienta, idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar requisicion herramienta destino");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteCuerpoDetalle:delete registro en cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@ApiOperation(value = "Servicio para la eliminacion del cuerpo detalle de la requisicion correctamente", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminacion del cuerpo detalle de la requisicion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar el cuerpo detalle de la requisicion") 
			})
	@PostMapping("/deleteCuerpoDetalle/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> deleteCuerpoDetalle(
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.deleteCuerpoDetalle(idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible elimianr el cuerpo detalle de la requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteCuerpoRequisicionAnio :delete registro en cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@ApiOperation(value = "Servicio para la eliminacion del cuerpo requisicion año correctamente", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminacion del cuerpo requisicion año correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar el cuerpo requisicion año") 
			})
	@PostMapping("/deleteCuerpoRequisicionAnio/{anio}/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> deleteCuerpoRequisicionAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.deleteCuerpoRequisicionAnio(anio, idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible elimianr el cuerpo requisicion año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteRequisicionSocios :delete registro en requisicion socios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@ApiOperation(value = "Servicio para la eliminacion requisicion socios correctamente", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminacion de la requisicion socios correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar la requisicion socios") 
			})
	@PostMapping("/deleteRequisicionSocios/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> deleteRequisicionSocios(
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.deleteRequisicionSocios(idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible elimianr la requisicion socios");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteRequisicionHerramientaDestino :delete registro en requisicion herramienta destino
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@ApiOperation(value = "Servicio para la eliminacion requisicion herramienta destino correctamente", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminacion de la requisicion herramienta destino correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar la requisicion herramienta destino") 
			})
	@PostMapping("/deleteRequisicionHerramientaDestino/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> deleteRequisicionHerramientaDestino(
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.deleteRequisicionHerramientaDestino(idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible elimianr la requisicion herramienta destino");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteRequisicionRefClas :delete registro en requisicion refaccion clasificacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@ApiOperation(value = "Servicio para la eliminacion requisicion refaccion clasificacion correctamente", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminacion de la requisicion refaccion clasificacion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar la requisicion refaccion clasificacion") 
			})
	@PostMapping("/deleteRequisicionRefClas/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> deleteRequisicionRefClas(
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.deleteRequisicionRefClas(idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible elimianr la requisicion refaccion clasificacion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * cancelarRequisicionAnio: cancela la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	@ApiOperation(value = "Servicio para la cancelacion requisicion año", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cancelacion de la requisicion año correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible cancelar la requisicion año") 
			})
	@PostMapping("/cancelarRequisicionAnio/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<Boolean> cancelarRequisicionAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion)
			 {
		
		try {	
			return requisicionesService.cancelarRequisicionAnio(anio,idrequisicion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar la requisicion año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * cancelarRequisiciones: cancela la requisicion en la tabla requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	@ApiOperation(value = "Servicio para la cancelacion requisicion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cancelacion de la requisicion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible cancelar la requisicion") 
			})
	@PostMapping("/cancelarRequisiciones/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<Boolean> cancelarRequisiciones(
			@PathVariable("idrequisicion") int idrequisicion)
			 {
		
		try {	
			return requisicionesService.cancelarRequisiciones(idrequisicion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar la requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * cancelarCuerpoRequisicionAnio: cancela el cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-27
	 */
	@ApiOperation(value = "Servicio para la cancelacion cuerpo requisicion año", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cancelacion del cuerpo requisicion año correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible cancelar el cuerpo requisicion año") 
			})
	@PostMapping("/cancelarCuerpoRequisicionAnio/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<Boolean> cancelarCuerpoRequisicionAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion)
			 {
		
		try {	
			return requisicionesService.cancelarCuerpoRequisicionAnio(anio,idrequisicion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar el cuerpo requisicion año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRequisicionAnio: hace un update en las observaciones la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-26
	 */
	@ApiOperation(value = "Servicio para la modificacion de requisicion año", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cancelacion de la requisicion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible cancelar la requisicion") 
			})
	@PostMapping("/updateRequisicionAnio/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRequisicionAnio(
			@RequestBody UpdateObservaciones ra,
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion)
			 {
		
		try {	
			return requisicionesService.updateRequisicionAnio(ra,anio,idrequisicion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible modificar la observacion de la requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRequisiciones: update en la tabla requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-28
	 */
	@ApiOperation(value = "Servicio para la cancelacion requisicion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cancelacion de la requisicion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible cancelar la requisicion") 
			})
	@PostMapping("/updateRequisiciones/{idrequisicion}/{idestatus}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRequisiciones(
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idestatus") int idestatus)
			 {
		
		try {	
			return requisicionesService.updateRequisiciones(idrequisicion, idestatus);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar la requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateEstatusRequisicionAnio: hace un update idestatus en las observaciones la requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-28
	 */
	@ApiOperation(value = "Servicio para la modificacion idestatus de requisicion año", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "update idestatus de la requisicion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible modificar el estatus la requisicion") 
			})
	@PostMapping("/updateEstatusRequisicionAnio/{anio}/{idrequisicion}/{idestatus}")
	@ResponseBody
	public ResponseDTO<Boolean> updateEstatusRequisicionAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idestatus") int idestatus)
			 {
		
		try {	
			return requisicionesService.updateEstatusRequisicionAnio(anio,idrequisicion, idestatus);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible modificar el idestatus de la requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRequisiciones: obtiene las requisiciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-04
	 */
	@ApiOperation(value = " Servicio para grid Requisiciones", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el grid requisiciones de agrupada", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridRequisicionesAgrupada/{anio}/{almacen}/{mes}/{tipoAlmacen}")
	@ResponseBody
	public ResponseDTO<List<CatalogoRequisicionesAgrupadas>> getGridRequisicionesAgrupada(
			@PathVariable("anio") int anio,
			@PathVariable("almacen") int almacen,
			@PathVariable("mes") int mes,
			@PathVariable("tipoAlmacen") int tipoAlmacen) {
		
		try {	
			
			return requisicionesService.getGridRequisicionesAgrupada(anio, almacen, mes, tipoAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<CatalogoRequisicionesAgrupadas>> response = new ResponseDTO<List<CatalogoRequisicionesAgrupadas>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de requisiciones agrupada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGridRequisicionesPorAutorizar: obtiene grid de requisiciones por autorizar.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-10-05
	 */
	@ApiOperation(value = " Servicio para grid Requisiciones por autorizar", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el grid requisiciones por autorizar", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridRequisicionesPorAutorizar/{anio}/{almacen}/{mes}/{tipoAlmacen}")
	@ResponseBody
	public ResponseDTO<List<CatalogoRequisicionesPorAutorizar>> getGridRequisicionesPorAutorizar(
			@PathVariable("anio") int anio,
			@PathVariable("almacen") int almacen,
			@PathVariable("mes") int mes,
			@PathVariable("tipoAlmacen") int tipoAlmacen) {
		
		try {	
			
			return requisicionesService.getGridRequisicionesPorAutorizar(anio, almacen, mes, tipoAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<CatalogoRequisicionesPorAutorizar>> response = new ResponseDTO<List<CatalogoRequisicionesPorAutorizar>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de requisiciones por autorizar");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGridDetalleRequisicionAgrupada: obtiene grid del detalle de requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-10-05
	 */
	@ApiOperation(value = " Servicio para grid Detalle Requisiciones agrupadas", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el grid del detalle de requisiciones agrupadas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridDetalleRequisicionAgrupada/{anio}/{idalmacen}/{mes}/{tipoAlmacen}/{tiposubrequisicion}")
	@ResponseBody
	public ResponseDTO<List<DetalleRequisicionAgrupada>> getGridDetalleRequisicionAgrupada(
			@PathVariable("anio") int anio,
			@PathVariable("idalmacen") int idalmacen,
			@PathVariable("mes") int mes,
			@PathVariable("tipoAlmacen") int tipoAlmacen,
			@PathVariable("tiposubrequisicion") int tiposubrequisicion) {
		
		try {	
			
			return requisicionesService.getGridDetalleRequisicionAgrupada(anio,idalmacen,mes,tipoAlmacen,tiposubrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<DetalleRequisicionAgrupada>> response = new ResponseDTO<List<DetalleRequisicionAgrupada>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de requisiciones por autorizar");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGridDetalleRequisicionAgrupadaSocio: obtiene grid del detalle de requisiciones agrupadas socio.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-10-05
	 */
	@ApiOperation(value = " Servicio para grid Detalle Requisiciones agrupadas", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el grid del detalle de requisiciones agrupadas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridDetalleRequisicionAgrupadaSocio/{anio}/{idalmacen}/{mes}/{tipoAlmacen}/{tiposubrequisicion}/{idsocio}")
	@ResponseBody
	public ResponseDTO<List<DetalleRequisicionAgrupada>> getGridDetalleRequisicionAgrupadaSocio(
			@PathVariable("anio") int anio,
			@PathVariable("idalmacen") int idalmacen,
			@PathVariable("mes") int mes,
			@PathVariable("tipoAlmacen") int tipoAlmacen,
			@PathVariable("tiposubrequisicion") int tiposubrequisicion,
			@PathVariable("idsocio") int idsocio) {
		
		try {	
			
			return requisicionesService.getGridDetalleRequisicionAgrupadaSocio(anio,idalmacen,mes,tipoAlmacen,tiposubrequisicion, idsocio);
		} catch (Exception e) {
			ResponseDTO<List<DetalleRequisicionAgrupada>> response = new ResponseDTO<List<DetalleRequisicionAgrupada>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de requisiciones por autorizar");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertRequisicionAgrupada:inserta registro en requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-10
	 */
	@ApiOperation(value = "Servicio insertar para insertar requisicion agrupada", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Requisicion agrupada insertada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar requisicion agrupada") 
			})
	@PostMapping("/createRequisicionAgrupada/{anio}")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicionAgrupada(
			@RequestBody InsertRequisicionesAgrupadas iReqAg,
			@PathVariable("anio") int anio) {
		
		try {	
			return requisicionesService.createRequisicionAgrupada(iReqAg,anio);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar la requisicion agrupada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertRequisicionAgrupada:inserta registro en requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-10
	 */
	@ApiOperation(value = "Servicio insertar para insertar requisicion agrupada", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Requisicion agrupada extension insertada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar requisicion agrupada extension") 
			})
	@PostMapping("/createRequisicionAgrupadaExt/{anio}")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicionAgrupadaExt(
			@RequestBody InsertRequisicionAgrupadaExt iReqAgExt,
			@PathVariable("anio") int anio) {
		
		try {	
			return requisicionesService.createRequisicionAgrupadaExt(iReqAgExt,anio);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar la requisicion agrupada extension");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertRequisicionClasificacion :inserta registro en requisicion clasificacion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-12
	 */
	@ApiOperation(value = "Servicio insertar para insertar requisicion clasificacion", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Requisicion clasificacion insertada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar requisicion clasificacion") 
			})
	@PostMapping("/createRequisicionClasificacion")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicionClasificacion(
			@RequestBody RequisicionClasificacion ReqClaf) {
		
		try {	
			return requisicionesService.createRequisicionClasificacion(ReqClaf);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar la requisicion agrupada extension");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio refacciones agrupadas", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las refacciones convenio agrupadas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getListadoRequisicionesAgrupadas/{anio}/{idrefaccion}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<ListadoRequisicion>> getListadoRequisicionesAgrupadas(
			@PathVariable("anio") int anio,
			@PathVariable("idrefaccion") int idrefaccion,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getListadoRequisicionesAgrupadas(anio,idrefaccion,idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<ListadoRequisicion>> response = new ResponseDTO<List<ListadoRequisicion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio cantidad listado agrupadas", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las cantidad listado requisicion agrupadas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCantidadListadoAgrupadas/{anio}/{idrefaccion}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<CantidadReq>> queryGetCantidadListado(
			@PathVariable("anio") int anio,
			@PathVariable("idrefaccion") int idrefaccion,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getCantidadListadoAgrupadas(anio,idrefaccion,idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	@ApiOperation(value = " Servicio refacciones convenio", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las refacciones convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCantidadReqAgrupadas/{anio}/{idrequisicion}/{almacen}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<List<CantidadReq>> getCantidadReqAgrupadas(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") String idrequisicion,
			@PathVariable("almacen") int almacen,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			
			return requisicionesService.getCantidadReqAgrupadas(anio,idrequisicion,almacen, idrefaccion);
		} catch (Exception e) {
			ResponseDTO<List<CantidadReq>> response = new ResponseDTO<List<CantidadReq>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo de autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteRequisicionAgrupada :delete registro en requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@ApiOperation(value = "Servicio para la eliminacion la requisicion agrupada correctamente", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminacion de la requisicion agrupada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar la requisicion agrupada") 
			})
	@PostMapping("/deleteRequisicionAgrupada/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<Boolean> deleteRequisicionAgrupada(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			return requisicionesService.deleteRequisicionAgrupada(anio, idrequisicion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar la requisicion agrupada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteAgrupadaExtension :delete registro en requisicion agrupada extension
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@ApiOperation(value = "Servicio para la eliminacion la requisicion agrupada extension correctamente", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminacion de la requisicion agrupada extension correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar la requisicion agrupada extension") 
			})
	@PostMapping("/deleteAgrupadaExtension/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<Boolean> deleteAgrupadaExtension(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			return requisicionesService.deleteAgrupadaExtension(anio, idrequisicion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar la requisicion agrupada extension");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getModRequisicionesAgrupadas: obtiene la información para la modificacion de requisicion agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	@ApiOperation(value = " Servicio para la modificacion de requisicion agrupada", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la modificacion de requisicion agrupada", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getModRequisicionAgrupada/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<GetModRequisicionAgrupada>> getModRequisicionAgrupada(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getModRequisicionAgrupada(anio,idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<GetModRequisicionAgrupada>> response = new ResponseDTO<List<GetModRequisicionAgrupada>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la clasificacion de la refaccion ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getModSociosAgrupada: obtiene la información para la modificacion de socios agrupada.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	@ApiOperation(value = " Servicio para la obtencion de la sociedad", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la obtencion de la sociedad en las requisiciones agrupada", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getModSocios/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<GetModSociosAgrupada>> getModSociosAgrupada(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getModSociosAgrupada(anio,idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<GetModSociosAgrupada>> response = new ResponseDTO<List<GetModSociosAgrupada>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la sociedad");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * cancelarRequisicionAgrupada: cancela la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	@ApiOperation(value = "Servicio para la cancelacion requisicion agrupada", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cancelacion de la requisicion agrupada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible cancelar la requisicion agrupada") 
			})
	@PostMapping("/cancelarRequisicionAgrupada/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<Boolean> cancelarRequisicionAgrupada(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion)
			 {
		
		try {	
			return requisicionesService.cancelarRequisicionAgrupada(anio,idrequisicion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible cancelar la requisicion año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRequisicionAgrupada: hace un update en las observaciones la requisicion agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-10-31
	 */
	@ApiOperation(value = "Servicio para la actualizacion de la observacion de la requisicion ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de observacion de la requisicion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar la observacion de la requisicion") 
			})
	@PostMapping("/updateRequisicionAgrupada/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRequisicionAgrupada(
			@RequestBody UpdateObservaciones ra,
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			return requisicionesService.updateRequisicionAgrupada(ra, anio, idrequisicion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar la observacion de la idrefaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateCantidadSolicitadaAgrupda:update registro en requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@ApiOperation(value = "Servicio para la actualizacion de cantidad de la requisicion ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de cantidad de la requisicion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar la cantidad de la requisicion") 
			})
	@PostMapping("/updateCantidadSolicitadaAgrupada/{anio}/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateCantidadSolicitadaAgrupada(
			@RequestBody UpdateCantidadRequerida updateCantidadRequerida,
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.updateCantidadSolicitadaAgrupada(updateCantidadRequerida, anio, idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar la cantidad de la idrefaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRequisicionSociosAgrupada:update registro en requisicion socios agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@ApiOperation(value = "Servicio para la actualizacion de requisicion socios ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de requisicion socios agrupada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar requisicion socios agrupada") 
			})
	@PostMapping("/updateRequisicionSociosAgrupada/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRequisicionSociosAgrupada(
			@RequestBody RequisicionSocios socios,
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.updateRequisicionSociosAgrupada(socios, idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar requisicion socios agrupada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRequisicionHerramientaDestinoAgrupada:update registro en requisicion herramienta destino agrupada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-10-31
	 */
	@ApiOperation(value = "Servicio para la actualizacion de requisicion herramienta destino agrupada ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de requisicion herramienta destino agrupada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar requisicion herramienta destino agrupada") 
			})
	@PostMapping("/updateRequisicionHerramientaDestinoAgrupada/{idrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRequisicionHerramientaDestinoAgrupada(
			@RequestBody HerramientaDestinoAgrupada herramienta,
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			return requisicionesService.updateRequisicionHerramientaDestinoAgrupada(herramienta, idrequisicion, idrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar requisicion herramienta destino agrupada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createRequisicionHistoricoAgrupadas: Servicio insertar para Requisicion Historico Agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-11-02
	 */
	@ApiOperation(value = "Servicio insertar para insertar RequisicionHistorico Agrupadas", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "RequisicionHistorico Agrupadas insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar RequisicionHistorico Agrupadas") 
			})
	@PostMapping("/createRequisicionHistoricoAgrupadas")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicionHistoricoAgrupadas(
			@RequestBody RequisicionHistorico requisicionHistorico) {
		
		try {	
			return requisicionesService.createRequisicionHistoricoAgrupadas(requisicionHistorico);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar RequisicionHistorico");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getModRequisicionesHistoricoAgrupadas: obtiene la información para la modificacion de requisicio historico agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-09-21
	 */
	@ApiOperation(value = " Servicio para la  modificacion de historico requisicion agrupada", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para la modificacion de historico requisicion agrupada", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getModRequisicionesHistoricoAgrupada/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<GetModRequisicionesHistorico>> getModRequisicionesHistoricoAgrupada(
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getModRequisicionesHistoricoAgrupadas(idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<GetModRequisicionesHistorico>> response = new ResponseDTO<List<GetModRequisicionesHistorico>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el historico requisicion ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateClaveAutorizada:update registro en la refaccion con clave autorizada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@ApiOperation(value = "Servicio para la actualizacion de clave autorizada ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de clave autorizada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar la clave autorizada") 
			})
	@PostMapping("/updateClaveAutorizada/{anio}/{idrefaccion}/{tiposolicitud}/{claveautorizada}")
	@ResponseBody
	public ResponseDTO<Boolean> updateClaveAutorizada(
			@PathVariable("anio") int anio,
			@PathVariable("idrefaccion") int idrefaccion,
			@PathVariable("tiposolicitud") int tiposolicitud,
			@PathVariable("claveautorizada") int claveautorizada) {
		
		try {	
			return requisicionesService.updateClaveAutorizada(anio, idrefaccion, tiposolicitud,claveautorizada);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar la clave autorizada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateEstatusRefaccion:update estatus en la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@ApiOperation(value = "Servicio para la actualizacion de estatus refaccion ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de la estatus refaccion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar la estatus refaccion") 
			})
	@PostMapping("/updateEstatusRefaccion/{anio}/{idrefaccion}/{tiposolicitud}/{idsocio}/{idestatusrefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateEstatusRefaccion(
			@PathVariable("anio") int anio,
			@PathVariable("idrefaccion") int idrefaccion,
			@PathVariable("tiposolicitud") int tiposolicitud,
			@PathVariable("idsocio") int idsocio,
			@PathVariable("idestatusrefaccion") int idestatusrefaccion) {
		
		try {	
			return requisicionesService.updateEstatusRefaccion(anio, idrefaccion,tiposolicitud, idsocio, idestatusrefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar el estatus refaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertRequisicionAgrupadaAutoriza:inserta registro en requisicion agrupada autoriza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@ApiOperation(value = "Servicio insertar para insertar requisicion agrupada autoriza", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Requisicion agrupada autoriza insertada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar requisicion agrupada autoriza") 
			})
	@PostMapping("/createRequisicionAgrupadaAutoriza")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicionAgrupadaAutoriza(
			@RequestBody InsertRequisicionAgrupadaAutorizada iReqAg) {
		
		try {	
			return requisicionesService.createRequisicionAgrupadaAutoriza(iReqAg);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar la requisicion agrupada autoriza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getListObtenerIdRequisicion: obtiene liestado de la id requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-11-08
	 */
	@ApiOperation(value = " Servicio para listado de id Requisiciones agrupadas", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el listado de id requisiciones agrupadas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getListObtenerIdRequisicion/{anio}/{idalmacen}/{mes}/{tipoAlmacen}/{tiposubrequisicion}/{idrefaccion}")
	@ResponseBody
	public ResponseDTO<List<ListadoRequisicionAutorizada>> getListObtenerIdRequisicion(
			@PathVariable("anio") int anio,
			@PathVariable("idalmacen") int idalmacen,
			@PathVariable("mes") int mes,
			@PathVariable("tipoAlmacen") int tipoAlmacen,
			@PathVariable("tiposubrequisicion") int tiposubrequisicion,
			@PathVariable("idrefaccion") int idrefaccion) {
		
		try {	
			
			return requisicionesService.getListObtenerIdRequisicion(anio,idalmacen,mes,tipoAlmacen,tiposubrequisicion, idrefaccion);
		} catch (Exception e) {
			ResponseDTO<List<ListadoRequisicionAutorizada>> response = new ResponseDTO<List<ListadoRequisicionAutorizada>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de requisiciones por autorizar");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getListObtenerRefaccionesCanceladas: obtiene liestado de la id requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<GridRequisiciones>>
	 * @throws Exception 
	 * @date 2023-11-08
	 */
	@ApiOperation(value = " Servicio para listado de id Requisiciones agrupadas", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para obtener refacciones canceladas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getListObtenerRefaccionesCanceladas/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<ObtenerRefaccionesCanceladas>> getListObtenerRefaccionesCanceladas(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getListObtenerRefaccionesCanceladas(anio, idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<ObtenerRefaccionesCanceladas>> response = new ResponseDTO<List<ObtenerRefaccionesCanceladas>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la lista de refacciones canceladas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateEstatusRequisicion:update estatus en la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@ApiOperation(value = "Servicio para la actualizacion de estatus refaccion ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de la estatus refaccion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar la estatus refaccion") 
			})
	@PostMapping("/updateEstatusRequisicion/{anio}/{idrequisicion}/{idestatus}")
	@ResponseBody
	public ResponseDTO<Boolean> updateEstatusRequisicion(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion,
			@PathVariable("idestatus") int idestatus) {
		
		try {	
			return requisicionesService.updateEstatusRequisicion(anio, idrequisicion,idestatus);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar el estatus refaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateEstatusRequisicion:update estatus en la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@ApiOperation(value = "Servicio para la actualizacion de requisicion refaccion ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de la estatus requisicion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar la estatus requisicion") 
			})
	@Scheduled(cron = "0 0 4 ? * 1 ")
	public ResponseDTO<Boolean> updateEstatusRequisicionProgramada() {
		
		try {	
			return requisicionesService.updateEstatusRequisicionProgramada();
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar el estatus requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateEstatusRefaccionProgramada:update estatus en la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2023-11-08
	 */
	@ApiOperation(value = "Servicio para la actualizacion de estatus refaccion ", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "actualizacion de la estatus refaccion correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar la estatus refaccion") 
			})
	@Scheduled(cron = "0 0 4 ? * 1 ")
	public ResponseDTO<Boolean> updateEstatusRefaccionProgramada() {
		
		try {	
			return requisicionesService.updateEstatusRefaccionProgramada();
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar el estatus refaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getListInformacionRequisicion: obtiene la informacion de la requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<ObtenerInformacionRequisicion>>
	 * @throws Exception 
	 * @date 2023-11-10
	 */
	@ApiOperation(value = " Servicio para listado de id Requisiciones agrupadas", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para obtener la informacion de la requisicion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getListInformacionRequisicion/{anio}/{idrequisicion}")
	@ResponseBody
	public ResponseDTO<List<ObtenerInformacionRequisicion>> getListInformacionRequisicion(
			@PathVariable("anio") int anio,
			@PathVariable("idrequisicion") int idrequisicion) {
		
		try {	
			
			return requisicionesService.getListInformacionRequisicion(anio, idrequisicion);
		} catch (Exception e) {
			ResponseDTO<List<ObtenerInformacionRequisicion>> response = new ResponseDTO<List<ObtenerInformacionRequisicion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de la requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getListInformacionRequisicion: obtiene la informacion de la requisiciones agrupadas.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<ObtenerInformacionRequisicion>>
	 * @throws Exception 
	 * @date 2023-11-10
	 */
	@ApiOperation(value = " Servicio para listado de id Requisiciones agrupadas", tags = { "Controlador requisicionesController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para obtener la informacion de la requisicion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRequisicionSeguimiento/{anio}/{tipoAlmacen}/{mes}")
	@ResponseBody
	public ResponseDTO<List<RequisicionAutorizada>> getRequisicionSeguimiento(
			@PathVariable("anio") int anio,
			@PathVariable("tipoAlmacen") int tipoAlmacen,
			@PathVariable("mes") int mes) {
		
		try {	
			
			return requisicionesService.getRequisicionSeguimiento(anio, tipoAlmacen, mes);
		} catch (Exception e) {
			ResponseDTO<List<RequisicionAutorizada>> response = new ResponseDTO<List<RequisicionAutorizada>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de la requisicion autorizada");
			response.setData(null);
			return response;
		}
	}
}
