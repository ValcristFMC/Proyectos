# castores-service-siat-entradas

## Versión: 0.0.0.0
- __Ticket/Proyecto:__ N/A
- __Author:__ Castores
- __Fecha:__ 
- __Descripción:__ 
	- Se crea servicio base.
--------

## Configuración técnica
- __IDE:__ Spring Tools Suite 4
- __Lenguaje:__ Java 8 Sping Boot


## Librerías
### Internas
-

### Externas
-
-------------
## Documentación
- Generar peticiones en swagger
