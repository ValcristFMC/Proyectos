# castores-service-siat-entradas

## Versión: 0.0.0.0
- __Ticket/Proyecto:__ N/A
- __Author:__ Castores
- __Fecha:__ 
- __Descripción:__ 
	- Se crea servicio base.
