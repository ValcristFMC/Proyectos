package com.grupocastores.SiatEntradas.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.SiatEntradas.dto.ConvenioDTO;
import com.grupocastores.SiatEntradas.dto.ConvenioHistoricoDTO;
import com.grupocastores.SiatEntradas.dto.ResponseDTO;
import com.grupocastores.SiatEntradas.service.ISiatConveniosService;
import com.grupocastores.SiatEntradas.service.repository.SiatConvenioRespository;

@Service
public class ISiatConveniosServiceImpl implements ISiatConveniosService{
    
    private Logger logger = LoggerFactory.getLogger(ISiatConveniosServiceImpl.class);
    
    @Autowired
    SiatConvenioRespository siatConvenioRespository;

    @Override
    public List<ConvenioDTO> getLstConvenios(int estatus) {
        try {
            return siatConvenioRespository.lstConvenios(estatus);
        }catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
            return new ArrayList<ConvenioDTO>();
        }
    }

    @Override
    public ConvenioDTO getConvenioById(int id) {
    	
        try {
            return siatConvenioRespository.getConvenioById(id);
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
            return null;
        }
    }

    public ResponseDTO<Void> insertConvenio(ConvenioDTO convenio) {
        ResponseDTO<Void> response = new ResponseDTO<>();

        try {
           if( siatConvenioRespository.insertConvenio(convenio)) {
            response.setCode(1);
            response.setDescription("success");
            response.setMessage("Convenio insertado correctamente");
              } else {
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al insertar convenio");

        	   
           }
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al insertar convenio");
        }
        return response;
    }

    @Override
    public ResponseDTO<Void> updateConvenio(ConvenioDTO convenio) {
        ResponseDTO<Void> response = new ResponseDTO<>();

        try {
            if(siatConvenioRespository.updateConvenio(convenio)) {
            response.setCode(1);
            response.setDescription("success");
            response.setMessage("Convenio actualizado correctamente");
            } else {
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al actualizar convenio");
            }

        } catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al actualizar convenio");
        }
        return response;
    }

    @Override
    public ResponseDTO<Void> updateConvenioEstatus(int estatus, int id) {
        ResponseDTO<Void> response = new ResponseDTO<>();

        try {
            if(siatConvenioRespository.updateConvenioEstatus(estatus, id)) {
            response.setCode(1);
            response.setDescription("success");
            response.setMessage("Estatus de convenio actualizado correctamente");
            return response;
            } else {
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al actualizar estatus de convenio");
        
            }
            
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al actualizar estatus de convenio");
        }
        return response;
    }
    
    @Override
    public Long getLastId() {
        try {
            return (long) siatConvenioRespository.getLastId();
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
            return (long) 0;
        }
    }
}
