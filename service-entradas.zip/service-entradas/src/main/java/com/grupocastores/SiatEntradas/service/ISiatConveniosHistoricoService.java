
package com.grupocastores.SiatEntradas.service;

import java.util.List;

import com.grupocastores.SiatEntradas.dto.ConvenioHistoricoDTO;
import com.grupocastores.SiatEntradas.dto.ResponseDTO;

public interface ISiatConveniosHistoricoService {
    
    public ResponseDTO<List<ConvenioHistoricoDTO>> getHistoricoConvenioById(int idConvenio, int idModificacion, int idRefaccion, int numCampo);
    
    public ResponseDTO<Void> insertHistoricoConvenio(ConvenioHistoricoDTO historico);
    
    public ResponseDTO<Void> updateHistoricoConvenio(ConvenioHistoricoDTO historico);
    
}
