package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de contrarecibo", description = "mapea tabla de siat.contrarecibo")
@Entity
@Table(name = "siat.contrarecibo")
public class RptContraRecibo {
	
	@Id
	@Column(name="numero")
	private Integer numero;
	@Column(name="remision")
	private String remision;
	@Column(name = "fecha2", nullable = true)
	private String fecha2;
	@Column(name = "subtotal")
	private Double subTotal;
	@Column(name = "iva")
	private Double iva;
	@Column(name = "retencion")
	private Double retencion;
	@Column(name = "total" , nullable = true)
	private Double total;
	@Column(name = "idproveedor")
	private Integer idProveedor;
	@Column(name="moneda", nullable = true)
	private Integer moneda;
	@Column(name = "impresion")
	private Integer impresion;
	@Column(name = "idfacturaorden")
	private Integer idFacturaOrden;
	@Column(name = "razonsocial")
	private String razonSocial;
}
