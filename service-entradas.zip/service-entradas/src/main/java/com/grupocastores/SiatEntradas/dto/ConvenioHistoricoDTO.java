package com.grupocastores.SiatEntradas.dto;

import java.sql.Time;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity(name = "ConvenioHistoricoDTO") 
public class ConvenioHistoricoDTO{

	 @Id
	 private Long idConvenio;
	 
	 private Long idModificacion;
	 
	 private Long idRefaccion;
	    
	 private double numCampo;
	 
	 private String nomCampo;
	 
	 private double valorAnterior;
	 
	 private double valorNuevo;
	    
	 private String motivo;
	    
	 private Long idPersonal;
	    
	 private Date fecha;
	    
	 private Time hora;
	    
}

