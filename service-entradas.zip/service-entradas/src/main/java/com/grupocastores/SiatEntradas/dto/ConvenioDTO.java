package com.grupocastores.SiatEntradas.dto;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity(name = "ConvenioDTO") 
public class ConvenioDTO{

	@Id
    private Long idConvenio;

    private int tipoConvenio;

    private String proveedorNombre;

    private Date fechaInicio;

    private Date fechaFin;

    private int estatus;

    private double total;

    private String observaciones;

    private int idProveedor;
    
    private int idpersonal;
       
}

