package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de poliza", description = "mapea tabla de siat.poliza")
@Entity
@Table(name = "siat.poliza")
public class PolizasAnio {
	
	@Id
	@Column(name="idpoliza")
	private int idPoliza;
	@Column(name="numpoliza")
	private int numPoliza;
	@Column(name = "idtipopol")
	private int idTipoPol;
	@Column(name = "concepto")
	private String concepto;
	@Column(name = "fechapol")
	private LocalDate fechaPol;
	@Column(name = "fechaalta")
	private LocalDate fechaAlta;
	@Column(name="altapor")
	private int altaPor;
	@Column(name = "elaboradopor")
	private int elaboradoPor;
	@Column(name = "autoriza")
	private int autoriza;
	@Column(name = "horaalta")
	private LocalTime horaAlta;
	@Column(name = "depto")
	private String depto;
	@Column(name = "oficinaenvia")
	private String oficinaEnvia;
	@Column(name = "status")
	private int status;
	@Column(name = "referencia")
	private String referencia;
	@Column(name = "auditada")
	private int auditada;
	@Column(name = "auditadapor")
	private int auditadaPor;
	@Column(name = "fechaauditada", nullable = true)
	private String fechaAuditada;
	@Column(name="idbanco")
	private int idBanco;
}
