package com.grupocastores.SiatEntradas.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.SiatEntradas.service.domain.SiatEntradas;
import com.grupocastores.SiatEntradas.service.domain.TablaSumTemporal;
import com.grupocastores.SiatEntradas.service.domain.TablaTemporal;
import com.grupocastores.SiatEntradas.service.domain.Tempoliza;
import com.grupocastores.SiatEntradas.service.domain.TempolizaRefaccion;
import com.grupocastores.SiatEntradas.service.domain.TipoAutorizaciones;
import com.grupocastores.SiatEntradas.service.domain.TipoCambio;
import com.grupocastores.SiatEntradas.service.domain.TipoSolicitud;
import com.grupocastores.SiatEntradas.service.domain.TotalGrid;
import com.grupocastores.SiatEntradas.service.domain.TraspasosGrupos;
import com.grupocastores.SiatEntradas.service.domain.UpdateRefacciones;
import com.grupocastores.SiatEntradas.service.domain.ValidacionEntrada;
import com.grupocastores.SiatEntradas.service.repository.SiatEntradasRepository;
import com.grupocastores.SiatEntradas.service.domain.Almacen;
import com.grupocastores.SiatEntradas.service.domain.AlmacenTranspasosPlazo;
import com.grupocastores.SiatEntradas.service.domain.Autorizaciones;
import com.grupocastores.SiatEntradas.service.domain.BancoProveedor;
import com.grupocastores.SiatEntradas.service.domain.CantidadesEntradas;
import com.grupocastores.SiatEntradas.service.domain.CatalogoAlmacen;
import com.grupocastores.SiatEntradas.service.domain.CatCuentas;
import com.grupocastores.SiatEntradas.service.domain.CatCuentasAnio;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibos;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibosInfo;
import com.grupocastores.SiatEntradas.service.domain.ControlCambio;
import com.grupocastores.SiatEntradas.service.domain.ControlEntrada;
import com.grupocastores.SiatEntradas.service.domain.ConvenioInf;
import com.grupocastores.SiatEntradas.service.domain.ConvenioProveedor;
import com.grupocastores.SiatEntradas.service.domain.ConvenioRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Convenios;
import com.grupocastores.SiatEntradas.service.domain.CuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.CuerpoDetalle;
import com.grupocastores.SiatEntradas.service.domain.CuerpoFactura;
import com.grupocastores.SiatEntradas.service.domain.CuerpoOrden;
import com.grupocastores.SiatEntradas.service.domain.CuerpoRequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.DetalleEntrada;
import com.grupocastores.SiatEntradas.service.domain.DetalleEntradaConsignacion;
import com.grupocastores.SiatEntradas.service.domain.Entradas;
import com.grupocastores.SiatEntradas.service.domain.EntradasAnio;
import com.grupocastores.SiatEntradas.service.domain.EntradasFechapol;
import com.grupocastores.SiatEntradas.service.domain.EntradasInfo;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrden;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrdenAnticipo;
import com.grupocastores.SiatEntradas.service.domain.FolioAlmacen;
import com.grupocastores.SiatEntradas.service.domain.GetDataEntrada;
import com.grupocastores.SiatEntradas.service.domain.GetDataEntradaNormal;
import com.grupocastores.SiatEntradas.service.domain.GetMotivo;
import com.grupocastores.SiatEntradas.service.domain.GetProveedor;
import com.grupocastores.SiatEntradas.service.domain.Folio;
import com.grupocastores.SiatEntradas.dto.ResponseDTO;
import com.grupocastores.SiatEntradas.service.domain.GridEntradas;
import com.grupocastores.SiatEntradas.service.domain.GridFacturas;
import com.grupocastores.SiatEntradas.service.domain.Grupos;
import com.grupocastores.SiatEntradas.service.domain.HistoricoConvenio;
import com.grupocastores.SiatEntradas.service.domain.HistoricoCuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.IdRefaccionGrid;
import com.grupocastores.SiatEntradas.service.domain.Importe;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradas;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradasFactura;
import com.grupocastores.SiatEntradas.service.domain.ImprimirGeneral;
import com.grupocastores.SiatEntradas.service.domain.KardexInformacion;
import com.grupocastores.SiatEntradas.service.domain.InformacionRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Iva;
import com.grupocastores.SiatEntradas.service.domain.Kardex;
import com.grupocastores.SiatEntradas.service.domain.KardexMovimiento;
import com.grupocastores.SiatEntradas.service.domain.KardexRefacciones;
import com.grupocastores.SiatEntradas.service.domain.ListaCuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.Lotes;
import com.grupocastores.SiatEntradas.service.domain.Movimientos;
import com.grupocastores.SiatEntradas.service.domain.Ordenes;
import com.grupocastores.SiatEntradas.service.domain.OrdenesAnio;
import com.grupocastores.SiatEntradas.service.domain.Polizas;
import com.grupocastores.SiatEntradas.service.domain.PolizasAnio;
import com.grupocastores.SiatEntradas.service.domain.RefPorAlmacen;
import com.grupocastores.SiatEntradas.service.domain.RefaccionesPorSurtir;
import com.grupocastores.SiatEntradas.service.domain.Refaproveedor;
import com.grupocastores.SiatEntradas.service.domain.RequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.RequisicionHistorico;
import com.grupocastores.SiatEntradas.service.domain.ResumenCompra;
import com.grupocastores.SiatEntradas.service.domain.RptContraRecibo;
import com.grupocastores.SiatEntradas.service.domain.SemaforoSiat;
import com.grupocastores.SiatEntradas.utils.UtilitiesRepository;
import com.grupocastores.SiatEntradas.service.ISiatEntradasService;

/**
 * Implementacion interna de {@link com.grupocastores.SiatEntradas.service.ISiatEntradasService}. Esta clase no se debe acceder directamente
 *
 * @author Castores - Desarrollo TI
 */
@Service
public class SiatEntradasServiceImpl implements ISiatEntradasService 
{
	Logger logger = LoggerFactory.getLogger(SiatEntradasServiceImpl.class);
	
	@Autowired
	private UtilitiesRepository utilitiesRepository;
	
	@Autowired
	private SiatEntradasRepository siatEntradasRepository;

	@Override
	public ResponseDTO<List<SemaforoSiat>> getSemaforoSiat(int estatus) {
		ResponseDTO<List<SemaforoSiat>> response = new ResponseDTO<List<SemaforoSiat>>();
		List<SemaforoSiat> semaforo = siatEntradasRepository.getSemaforo(estatus);
	 	if(semaforo.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de semaforo siat");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(semaforo);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GridEntradas>> getGridEntradas(int anio, int mes, int idTaller, int almacen) {
		ResponseDTO<List<GridEntradas>> response = new ResponseDTO<List<GridEntradas>>();
		List<GridEntradas> entradas = siatEntradasRepository.getGridEntradas(anio, mes, idTaller, almacen);
	 	if(entradas.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de semaforo siat");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(entradas);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GridEntradas>> getGridEntradasPorAlmacen(int anio, int mes, int tipoAlmacen) {
		ResponseDTO<List<GridEntradas>> response = new ResponseDTO<List<GridEntradas>>();
		List<GridEntradas> entradas = siatEntradasRepository.getGridEntradasPorAlmacen(anio, mes, tipoAlmacen);
	 	if(entradas.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de semaforo siat");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(entradas);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CatalogoAlmacen>> getAlmacen(int tipoAlmacen, String nomAlmacen) {
		ResponseDTO<List<CatalogoAlmacen>> response = new ResponseDTO<List<CatalogoAlmacen>>();
		List<CatalogoAlmacen> almacen = siatEntradasRepository.getAlmacen(tipoAlmacen, nomAlmacen);
	 	if(almacen.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(almacen);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GridFacturas>> getGridFacturas(int anio,int mes) {
		ResponseDTO<List<GridFacturas>> response = new ResponseDTO<List<GridFacturas>>();
		List<GridFacturas> facuras = siatEntradasRepository.getGridFacturas(anio, mes);
	 	if(facuras.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grid facturas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(facuras);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GridFacturas>> getGridFacturasAgrupadas(int anio,int mes) {
		ResponseDTO<List<GridFacturas>> response = new ResponseDTO<List<GridFacturas>>();
		List<GridFacturas> facuras = siatEntradasRepository.getGridFacturasAgrupadas(anio, mes);
	 	if(facuras.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grid facturas agrupadas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(facuras);
		return response;
	}
	
	@Override
	public ResponseDTO<List<ValidacionEntrada>> getValidacionEntrada(int anio, int idFacturaOrden) {
		ResponseDTO<List<ValidacionEntrada>> response = new ResponseDTO<List<ValidacionEntrada>>();
		List<ValidacionEntrada> almacen = siatEntradasRepository.getValidacionEntrada(anio, idFacturaOrden);
	 	if(almacen.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(almacen);
		return response;
	}
	
	@Override
	public ResponseDTO<List<TotalGrid>> getTotalGrid(int noMovimiento,int tipo)  {
		ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
		List<TotalGrid> total = siatEntradasRepository.getTotalGrid(noMovimiento, tipo);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<TotalGrid>> getTotalOpcionGrid(int noMovimiento,int tipo)  {
		ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
		List<TotalGrid> total = siatEntradasRepository.getTotalOpcionGrid(noMovimiento, tipo);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<IdRefaccionGrid>> getRefaccionGrid(int noMovimiento,int tipo)  {
		ResponseDTO<List<IdRefaccionGrid>> response = new ResponseDTO<List<IdRefaccionGrid>>();
		List<IdRefaccionGrid> refaccion = siatEntradasRepository.getRefaccionGrid(noMovimiento, tipo);
	 	if(refaccion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(refaccion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<IdRefaccionGrid>> getCarroceriaGrid(String idRefaccion)  {
		ResponseDTO<List<IdRefaccionGrid>> response = new ResponseDTO<List<IdRefaccionGrid>>();
		List<IdRefaccionGrid> refaccion = siatEntradasRepository.getCarroceriaGrid(idRefaccion);
	 	if(refaccion.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(refaccion);
		return response;
	}
	
	@Override
	public ResponseDTO<List<TipoCambio>> getTipoCambio(String fecha)  {
		ResponseDTO<List<TipoCambio>> response = new ResponseDTO<List<TipoCambio>>();
		List<TipoCambio> total = siatEntradasRepository.getTipoCambio(fecha);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetMotivo>> getMotivo(int idMotivo)  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> total = siatEntradasRepository.getMotivo(idMotivo);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener motivo");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<TipoCambio>> getTipoCambioCarroceria()  {
		ResponseDTO<List<TipoCambio>> response = new ResponseDTO<List<TipoCambio>>();
		List<TipoCambio> total = siatEntradasRepository.getTipoCambioCarroceria();
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<AlmacenTranspasosPlazo>> getAlmacenTraspaso(int idAlmacen)  {
		ResponseDTO<List<AlmacenTranspasosPlazo>> response = new ResponseDTO<List<AlmacenTranspasosPlazo>>();
		List<AlmacenTranspasosPlazo> total = siatEntradasRepository.getAlmacenTraspaso(idAlmacen);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el catalogo de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<Ordenes>> getOrdenes(int idOrdenCompra)  {
		ResponseDTO<List<Ordenes>> response = new ResponseDTO<List<Ordenes>>();
		List<Ordenes> total = siatEntradasRepository.getOrdenes(idOrdenCompra);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener las ordenes");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<OrdenesAnio>> getOrdenesAnio(int anio, int idOrdenCompra, int idRequisicion)  {
		ResponseDTO<List<OrdenesAnio>> response = new ResponseDTO<List<OrdenesAnio>>();
		List<OrdenesAnio> total = siatEntradasRepository.getOrdenesAnio(anio, idOrdenCompra, idRequisicion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener las ordenes anio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<OrdenesAnio>> getOrdenesAnioMoneda(int anio,int idOrdenCompra){
		ResponseDTO<List<OrdenesAnio>> response = new ResponseDTO<List<OrdenesAnio>>();
		List<OrdenesAnio> total = siatEntradasRepository.getOrdenesAnioMoneda(anio, idOrdenCompra);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener las ordenes anio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<RequisicionAnio>> getRequisicionAnio(int anio, int idRequisicion)  {
		ResponseDTO<List<RequisicionAnio>> response = new ResponseDTO<List<RequisicionAnio>>();
		List<RequisicionAnio> total = siatEntradasRepository.getRequisicionAnio(anio, idRequisicion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la requisicion anio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CuerpoDetalle>> getCuerpoDetalle( int idRequisicion)  {
		ResponseDTO<List<CuerpoDetalle>> response = new ResponseDTO<List<CuerpoDetalle>>();
		List<CuerpoDetalle> total = siatEntradasRepository.getCuerpoDetalle(idRequisicion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el cuerpo detalle");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * getCuerpoDetalleRefaccion: obtiene el cuerpo detalle de la idrequisicion e idrefaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	@Override
	public ResponseDTO<List<CuerpoDetalle>> getCuerpoDetalleRefaccion( int idRequisicion, int idRefaccion)  {
		ResponseDTO<List<CuerpoDetalle>> response = new ResponseDTO<List<CuerpoDetalle>>();
		List<CuerpoDetalle> total = siatEntradasRepository.getCuerpoDetalleRefaccion(idRequisicion, idRefaccion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el cuerpo detalle");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<TotalGrid>> getCantidadCuerpoOrden(int anio, int idOrdenCompra, int idRefaccion)  {
		ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
		List<TotalGrid> total = siatEntradasRepository.getCantidadCuerpoOrden(anio, idOrdenCompra, idRefaccion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la cantidad cuerpo orden");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<TipoCambio>> getTipoCambioDiaCurso(int idMoneda)  {
		ResponseDTO<List<TipoCambio>> response = new ResponseDTO<List<TipoCambio>>();
		List<TipoCambio> total = siatEntradasRepository.getTipoCambioDiaCurso(idMoneda);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el doficial del dia");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<FacturaOrden>> getFacturaOrden( int idFacturaOrden)  {
		ResponseDTO<List<FacturaOrden>> response = new ResponseDTO<List<FacturaOrden>>();
		List<FacturaOrden> total = siatEntradasRepository.getFacturaOrden(idFacturaOrden);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la factura orden");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<FolioAlmacen>> getFolioAlmacen(int tipoFolio, int idAlmacen)  {
		ResponseDTO<List<FolioAlmacen>> response = new ResponseDTO<List<FolioAlmacen>>();
		List<FolioAlmacen> total = siatEntradasRepository.getFolioAlmacen(tipoFolio, idAlmacen);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la factura orden");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<ControlCambio>> getControlTipoCambio( int idProveedor)  {
		ResponseDTO<List<ControlCambio>> response = new ResponseDTO<List<ControlCambio>>();
		List<ControlCambio> total = siatEntradasRepository.getControlTipoCambio(idProveedor);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la factura orden");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CuerpoFactura>> getCuerpoFactura( int idFacturaOrden)  {
		ResponseDTO<List<CuerpoFactura>> response = new ResponseDTO<List<CuerpoFactura>>();
		List<CuerpoFactura> total = siatEntradasRepository.getCuerpoFactura(idFacturaOrden);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el cuerpo factura");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<InformacionRefaccion>> getInformacionRefaccion( int idRefaccion)  {
		ResponseDTO<List<InformacionRefaccion>> response = new ResponseDTO<List<InformacionRefaccion>>();
		List<InformacionRefaccion> total = siatEntradasRepository.getInformacionRefaccion(idRefaccion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * insertControlEntrada:inserta registro en control entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-03
	 */
	@Override
	public ResponseDTO<Boolean> insertControlEntrada (ControlEntrada ce) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
		Boolean inserted = siatEntradasRepository.insertControlEntrada(ce);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Control entrada insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del control entrada ");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<Folio>> getFolio(int tipoFolio) {
		ResponseDTO<List<Folio>> response = new ResponseDTO<List<Folio>>();
		List<Folio> folio = siatEntradasRepository.getFolio(tipoFolio);
	 	if(folio.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el folio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(folio);
		return response;
	}
	
	/**
	 * createFolio: inserta registro en folios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return ResponseDTO<Boolean>
	 * @date 2024-01-03
	 */
	@Override
	public ResponseDTO<Boolean> createFolio(Folio folio, int tipoFolio) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertFolio(folio, tipoFolio);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("folio de requisicion insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del folio de la entrada");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertFolioAlmacen:inserta registro en folios almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	@Override
	public ResponseDTO<Boolean> createFolioAlmacen(FolioAlmacen folio, int tipoFolio, int idAlmacen) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertFolioAlmacen(folio, tipoFolio, idAlmacen);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("folio almacen de requisicion insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del folio almacen de la entrada");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<TotalGrid>> getRefaProveedor(int idProveedor, int idRefaccion)  {
		ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
		List<TotalGrid> total = siatEntradasRepository.getRefaProveedor(idProveedor, idRefaccion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion del proveedor de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetMotivo>> getValorParamGen(int idParametro)  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> total = siatEntradasRepository.getValorParamGen(idParametro);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el valor de la variable global");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetMotivo>> getValorParametros(int idParametro)  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> total = siatEntradasRepository.getValorParametros(idParametro);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el valor de la variable siat");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetMotivo>> getValorParametrosNombre(int idParametro)  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> total = siatEntradasRepository.getValorParametrosNombre(idParametro);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el valor de la variable siat");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<TipoSolicitud>> getTipoSolicitud(int idRequisicion)  {
		ResponseDTO<List<TipoSolicitud>> response = new ResponseDTO<List<TipoSolicitud>>();
		List<TipoSolicitud> total = siatEntradasRepository.getTipoSolicitud(idRequisicion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el valor del tipo solicitud de la requisicion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetMotivo>> getNombreMoneda(int idMoneda)  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> total = siatEntradasRepository.getNombreMoneda(idMoneda);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el nombre de a moneda");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<CantidadesEntradas>> getCantidadesEntradas(int anio, int idOrdenCompra)  {
		ResponseDTO<List<CantidadesEntradas>> response = new ResponseDTO<List<CantidadesEntradas>>();
		List<CantidadesEntradas> total = siatEntradasRepository.getCantidadesEntradas(anio, idOrdenCompra);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener cantidades entradas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetProveedor>> getProveedor(int idProveedor)  {
		ResponseDTO<List<GetProveedor>> response = new ResponseDTO<List<GetProveedor>>();
		List<GetProveedor> total = siatEntradasRepository.getProveedor(idProveedor);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener motivo");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * deleteCuerpoDetalle:delete registro en tabla controlentrada
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-01-12
	 */
	@Override
	public ResponseDTO<Boolean> deleteControlEntrada (String folioControl, int idPersonal) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.deleteControlEntrada(folioControl, idPersonal);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("eliminacion del registro en controlentrada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar el registro de la tabla de controlentrada");
			response.setData(false);
			return response;
		}
	}
	
	@Override
	public ResponseDTO<List<TipoAutorizaciones>> getTipoAutorizacion(int idTipoAutorizacion)  {
		ResponseDTO<List<TipoAutorizaciones>> response = new ResponseDTO<List<TipoAutorizaciones>>();
		List<TipoAutorizaciones> autorizaciones = siatEntradasRepository.getTipoAutorizacion(idTipoAutorizacion);
	 	if(autorizaciones.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el tipo autorizaciones");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(autorizaciones);
		return response;
	}
	
	/**
	 * insertEntradas:inserta registro en entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	@Override
	public ResponseDTO<Boolean> createEntradas (Entradas entradas) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.createEntradas(entradas);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("entradas insertado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la entrada");
			response.setData(false);
			return response;
		}
	}

	@Override
	public ResponseDTO<List<GetMotivo>> getControlIncrementoMaquila()  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> total = siatEntradasRepository.getControlIncrementoMaquila();
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el incremento de maquila");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<GetMotivo>> getConvenioRefaccion(int idRefaccion)  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> total = siatEntradasRepository.getConvenioRefaccion(idRefaccion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el convenio de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	@Override
	public ResponseDTO<List<ConvenioRefaccion>> getConvenioRefaccionDetallado(int idRefaccion)  {
		ResponseDTO<List<ConvenioRefaccion>> response = new ResponseDTO<List<ConvenioRefaccion>>();
		List<ConvenioRefaccion> total = siatEntradasRepository.getConvenioRefaccionDetallado(idRefaccion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el convenio de la refaccion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * insertEntradasAño:inserta registro en entradas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	@Override
	public ResponseDTO<Boolean> createEntradasAnio(int anio, EntradasAnio entradas) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.createEntradasAnio(anio, entradas);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("entradas insertado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de la entrada año");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * createLotes:inserta registro en lotes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	@Override
	public ResponseDTO<Boolean> createLotes (Lotes lotes) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.createLotes(lotes);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("lotes insertado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del lote");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * createKardex:inserta registro en kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	@Override
	public ResponseDTO<Boolean> createKardex(Kardex kardex) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.createKardex(kardex);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("lotes insertado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del lote");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getEsFactura: obtiene informacion si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getEsFactura(int idFacturaOrden)  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> esfactura = siatEntradasRepository.getEsFactura(idFacturaOrden);
	 	if(esfactura.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener si es factura");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(esfactura);
		return response;
	}
	
	/**
	 * getImporteFactura: obtiene informacion del importe si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<List<Importe>> getImporteFactura(int anio, int idEntrada, int idAlmacen) {
		ResponseDTO<List<Importe>> response = new ResponseDTO<List<Importe>>();
		List<Importe> esfactura = siatEntradasRepository.getImporteFactura(anio, idEntrada, idAlmacen);
	 	if(esfactura.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el importe de la factura");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(esfactura);
		return response;
	}
	
	/**
	 * getImporteRemision: obtiene informacion del importe si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<List<Importe>> getImporteRemision(int anio, int idEntrada, int idAlmacen) {
		ResponseDTO<List<Importe>> response = new ResponseDTO<List<Importe>>();
		List<Importe> esfactura = siatEntradasRepository.getImporteRemision(anio, idEntrada, idAlmacen);
	 	if(esfactura.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el importe de la remision");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(esfactura);
		return response;
	}
	
	@Override
	public ResponseDTO<List<ValidacionEntrada>> getMaxLotes()  {
		ResponseDTO<List<ValidacionEntrada>> response = new ResponseDTO<List<ValidacionEntrada>>();
		List<ValidacionEntrada> total = siatEntradasRepository.getMaxLotes();
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el max de lotes");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * createDetalleEntrada:inserta registro en detalle entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<Boolean> createDetalleEntrada(DetalleEntrada de) {
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.createDetalleEntrada(de);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Detalle entrada insertado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información del detalle entrada");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getInfRefaproveedor: obtiene informacion de Refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<List<Refaproveedor>> getInfRefaproveedor(int idRefaccion, int idProveedor){
		ResponseDTO<List<Refaproveedor>> response = new ResponseDTO<List<Refaproveedor>>();
		List<Refaproveedor> esfactura = siatEntradasRepository.getInfRefaproveedor(idRefaccion, idProveedor);
	 	if(esfactura.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de refaproveedor");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(esfactura);
		return response;
	}
	
	/**
	 * getRefPorAlmacen: obtiene informacion de refaccion por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<List<RefPorAlmacen>> getRefPorAlmacen(int idRefaccion, int idAlmacen){
		ResponseDTO<List<RefPorAlmacen>> response = new ResponseDTO<List<RefPorAlmacen>>();
		List<RefPorAlmacen> esfactura = siatEntradasRepository.getRefPorAlmacen(idRefaccion, idAlmacen);
	 	if(esfactura.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de refaccion por almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(esfactura);
		return response;
	}
	
	/**
	 * getConvenioInf: obtiene informacion de convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<List<ConvenioInf>> getConvenioInf(int idRefaccion){
		ResponseDTO<List<ConvenioInf>> response = new ResponseDTO<List<ConvenioInf>>();
		List<ConvenioInf> esfactura = siatEntradasRepository.getConvenioInf(idRefaccion);
	 	if(esfactura.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion del convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(esfactura);
		return response;
	}
	
	/**
	 * updateRefaProveedor:actualiza registro en refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<Boolean> updateRefaProveedor(Refaproveedor rp, int idRefaccion, int idProveedor){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateRefaProveedor(rp, idRefaccion, idProveedor);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("refaproveedor actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de refaproveedor");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateRefaPorAlmacen:actualiza registro en refaccion_por_almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@Override
	public ResponseDTO<Boolean> updateRefaPorAlmacen(RefPorAlmacen rp, int idRefaccion, int idAlmacen){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateRefaPorAlmacen(rp, idRefaccion, idAlmacen);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("refaccion_por_almacen actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de refaccion_por_almacen");
			response.setData(false);
			return response;
		}
	}
	

	/**
	 * updateRefacciones:actualiza registro en refacciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@Override
	public ResponseDTO<Boolean> updateRefacciones(UpdateRefacciones ur,int idRefaccion){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateRefacciones(ur, idRefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("refacciones actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de refacciones");
			response.setData(false);
			return response;
		}
	}

	/**
	 * updateCuerpoConvenio:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@Override
	public ResponseDTO<Boolean> updateCuerpoConvenio(int idRefaccion, int idConvenio, Double pcmn){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateCuerpoConvenio(idRefaccion,idConvenio, pcmn);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("cuerpo convenio actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de cuerpo convenio");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateFacturasOrden:actualiza registro en facturas orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@Override
	public ResponseDTO<Boolean> updateFacturasOrden( int idFacturaOrden, int idEstatus){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateFacturasOrden(idFacturaOrden,idEstatus);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("facturas orden actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de facturas orden");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getCuerpoOrdenAnio: obtiene informacion de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-24
	 */
	@Override
	public ResponseDTO<List<CuerpoOrden>> getCuerpoOrdenAnio(int anio, int idRefaccion, int idOrdenCompra){
		ResponseDTO<List<CuerpoOrden>> response = new ResponseDTO<List<CuerpoOrden>>();
		List<CuerpoOrden> cuerpoorden = siatEntradasRepository.getCuerpoOrdenAnio( anio, idRefaccion, idOrdenCompra);
	 	if(cuerpoorden.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de cuerpo orden");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(cuerpoorden);
		return response;
	}
	
	/**
	 * getCuerpoOrden: obtiene informacion de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-24
	 */
	@Override
	public ResponseDTO<List<CuerpoOrden>> getCuerpoOrden(int anio, int idOrdenCompra){
		ResponseDTO<List<CuerpoOrden>> response = new ResponseDTO<List<CuerpoOrden>>();
		List<CuerpoOrden> cuerpoorden = siatEntradasRepository.getCuerpoOrden( anio, idOrdenCompra);
	 	if(cuerpoorden.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de cuerpo orden");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(cuerpoorden);
		return response;
	}
	
	/**
	 * updateCuerpoOrdenAnio:actualiza registro de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	@Override
	public ResponseDTO<Boolean> updateCuerpoOrdenAnio(CuerpoOrden co,int anio, int idRefaccion, int idOrdenCompra){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateCuerpoOrdenAnio(co,anio,idRefaccion,idOrdenCompra);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Cuerpo orden actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de Cuerpo orden");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateCuerpoOrdenAnio:actualiza registro de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	@Override
	public ResponseDTO<Boolean> updateOrdenCompraAnio(OrdenesAnio co,int anio, int idRequisicion, int idOrdenCompra){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateOrdenCompraAnio(co,anio,idRequisicion,idOrdenCompra);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Cuerpo orden actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de Cuerpo orden");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateOrdenes:actualiza registro de ordenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	@Override
	public ResponseDTO<Boolean> updateOrdenes(int idOrdenCompra, int idEstatus){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateOrdenes(idOrdenCompra, idEstatus);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Orden actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de Orden");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateCuerpoRequisicionAnio:actualiza registro de cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@Override
	public ResponseDTO<Boolean> updateCuerpoRequisicionAnio(CuerpoRequisicionAnio cr,int anio, int idRequisicion, int idRefaccion){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateCuerpoRequisicionAnio(cr, anio, idRequisicion, idRefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("cuerpo requisicion actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de cuerpo requisicion");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getCuerpoRequisicionAnio: obtiene informacion de cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-25
	 */
	@Override
	public ResponseDTO<List<CuerpoRequisicionAnio>> getCuerpoRequisicionAnio(int anio,int idRequisicion, int idRefaccion){
		ResponseDTO<List<CuerpoRequisicionAnio>> response = new ResponseDTO<List<CuerpoRequisicionAnio>>();
		List<CuerpoRequisicionAnio> cuerpoorden = siatEntradasRepository.getCuerpoRequisicionAnio( anio,idRequisicion, idRefaccion);
	 	if(cuerpoorden.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de cuerpo requisicion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(cuerpoorden);
		return response;
	}
	
	/**
	 * updateRequisicionAnio:actualiza registro de requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@Override
	public ResponseDTO<Boolean> updateRequisicionAnio(RequisicionAnio ra,int anio, int idRequisicion){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateRequisicionAnio(ra, anio, idRequisicion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("requisicion año actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de requisicion año");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertRequisicionHistorico:inserta registro de requisicion historico
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@Override
	public ResponseDTO<Boolean> insertRequisicionHistorico(RequisicionHistorico requisicionhistorico){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertRequisicionHistorico(requisicionhistorico);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("requisicion historico insertado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar la información de requisicion historico");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateCuerpoDetalle:actualiza registro de cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@Override
	public ResponseDTO<Boolean> updateCuerpoDetalle(CuerpoDetalle cd, int idRequisicion, int idRefaccion){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateCuerpoDetalle(cd, idRequisicion, idRefaccion);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Cuerpo detalle actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de cuerpo detalle");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertAutorizaciones:inserta registro en autorizaciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	@Override
	public ResponseDTO<Boolean> insertAutorizaciones(Autorizaciones autorizaciones){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertAutorizaciones(autorizaciones);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Autorizacion insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de autorizaciones");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateCuerpoConvenioSaldo:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	@Override
	public ResponseDTO<Boolean> updateCuerpoConvenioSaldo(int idRefaccion, int idConvenio, Double saldo){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateCuerpoConvenioSaldo(idRefaccion,idConvenio, saldo);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("cuerpo convenio actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de cuerpo convenio");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getInfoconvenio: obtiene informacion de convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-25
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getInfoconvenio( int idRefaccion){
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> motivo = siatEntradasRepository.getInfoconvenio(idRefaccion);
	 	if(motivo.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(motivo);
		return response;
	}
	
	/**
	 * getBancoProveedor: obtiene informacion de banco proveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	@Override
	public ResponseDTO<List<BancoProveedor>> getBancoProveedor(int idProveedor){
		ResponseDTO<List<BancoProveedor>> response = new ResponseDTO<List<BancoProveedor>>();
		List<BancoProveedor> banco = siatEntradasRepository.getBancoProveedor(idProveedor);
	 	if(banco.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de banco proveedor");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(banco);
		return response;
	}
	
	/**
	 * getContraRecibo: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	@Override
	public ResponseDTO<List<ContraRecibos>> getContraRecibo(){
		ResponseDTO<List<ContraRecibos>> response = new ResponseDTO<List<ContraRecibos>>();
		List<ContraRecibos> contrarecibos = siatEntradasRepository.getContraRecibo();
	 	if(contrarecibos.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de contrarecibos");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(contrarecibos);
		return response;
	}
	
	/**
	 * insertContraRecibo:inserta registro en contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	@Override
	public ResponseDTO<Boolean> insertContraRecibo(ContraRecibosInfo contraRecibo){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertContraRecibo(contraRecibo);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Autorizacion insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de autorizaciones");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getContraReciboInfo: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@Override
	public ResponseDTO<List<ContraRecibosInfo>> getContraReciboInfo(int idContraRecibo){
		ResponseDTO<List<ContraRecibosInfo>> response = new ResponseDTO<List<ContraRecibosInfo>>();
		List<ContraRecibosInfo> contrarecibos = siatEntradasRepository.getContraReciboInfo(idContraRecibo);
	 	if(contrarecibos.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de contrarecibos");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(contrarecibos);
		return response;
	}
	
	/**
	 * getContraReciboFact: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@Override
	public ResponseDTO<List<ContraRecibosInfo>> getContraReciboFact(int idFacturaOrden){
		ResponseDTO<List<ContraRecibosInfo>> response = new ResponseDTO<List<ContraRecibosInfo>>();
		List<ContraRecibosInfo> contrarecibos = siatEntradasRepository.getContraReciboFact(idFacturaOrden);
	 	if(contrarecibos.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de contrarecibos");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(contrarecibos);
		return response;
	}
	
	/**
	 * getRptContraReciboFact : obtiene reporte de contra recibo con factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@Override
	public ResponseDTO<List<RptContraRecibo>> getRptContraReciboFact(int coidFacturaOrden){
		ResponseDTO<List<RptContraRecibo>> response = new ResponseDTO<List<RptContraRecibo>>();
		List<RptContraRecibo> contrarecibos = siatEntradasRepository.getRptContraReciboFact(coidFacturaOrden);
	 	if(contrarecibos.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el reporte de contrarecibos");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(contrarecibos);
		return response;
	}
	
	/**
	 * getRptContraRecibo: obtiene reporte de contra recibo con factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@Override
	public ResponseDTO<List<RptContraRecibo>> getRptContraRecibo(int idContraRecibo){
		ResponseDTO<List<RptContraRecibo>> response = new ResponseDTO<List<RptContraRecibo>>();
		List<RptContraRecibo> contrarecibos = siatEntradasRepository.getRptContraRecibo(idContraRecibo);
	 	if(contrarecibos.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el reporte de contrarecibos");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(contrarecibos);
		return response;
	}
	
	/**
	 * getEntradas : obtiene informacion de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@Override
	public ResponseDTO<List<Entradas>> getEntradas(int idEntrada, int tipoEntrada){
		ResponseDTO<List<Entradas>> response = new ResponseDTO<List<Entradas>>();
		List<Entradas> entradas = siatEntradasRepository.getEntradas(idEntrada, tipoEntrada);
	 	if(entradas.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de entradas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(entradas);
		return response;
	}
	
	/**
	 * getValoresEntradas : obtiene valores de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@Override
	public ResponseDTO<List<EntradasInfo>> getValoresEntradas(int anio, int idEntrada, int tipoEntrada){
		ResponseDTO<List<EntradasInfo>> response = new ResponseDTO<List<EntradasInfo>>();
		List<EntradasInfo> entradas = siatEntradasRepository.getValoresEntradas(anio, idEntrada, tipoEntrada);
	 	if(entradas.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de entradas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(entradas);
		return response;
	}
	
	/**
	 * getFacturasOrdenInfo: obtiene valores de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@Override
	public ResponseDTO<List<FacturaOrden>> getFacturasOrdenInfo(int idOrdenCompra, int idFacturaOrden){
		ResponseDTO<List<FacturaOrden>> response = new ResponseDTO<List<FacturaOrden>>();
		List<FacturaOrden> entradas = siatEntradasRepository.getFacturasOrdenInfo(idOrdenCompra, idFacturaOrden);
	 	if(entradas.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de facturas orden");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(entradas);
		return response;
	}
	
	/**
	 * getEntradasAnio: obtiene informacion de entradas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@Override
	public ResponseDTO<List<EntradasAnio>> getEntradasAnio(int anio, int idEntrada, int tipo){
		ResponseDTO<List<EntradasAnio>> response = new ResponseDTO<List<EntradasAnio>>();
		List<EntradasAnio> entradas = siatEntradasRepository.getEntradasAnio(anio, idEntrada, tipo);
	 	if(entradas.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de entradas año");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(entradas);
		return response;
	}
	
	/**
	 * getKardex:  obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@Override
	public ResponseDTO<List<Kardex>> getKardex(int tipoMovimiento, int noMovimiento, int tipo){
		ResponseDTO<List<Kardex>> response = new ResponseDTO<List<Kardex>>();
		List<Kardex> entradas = siatEntradasRepository.getKardex(tipoMovimiento, noMovimiento, tipo);
	 	if(entradas.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de kardex");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(entradas);
		return response;
	}
	
	/**
	 * getKardexPrecio: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@Override
	public ResponseDTO<List<Kardex>> getKardexPrecio(int idRefaccion, int noMovimiento){
		ResponseDTO<List<Kardex>> response = new ResponseDTO<List<Kardex>>();
		List<Kardex> entradas = siatEntradasRepository.getKardexPrecio(idRefaccion, noMovimiento);
	 	if(entradas.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de kardex");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(entradas);
		return response;
	}
	
	/**
	 * deleteTempoliza: Elimina informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@Override
	public ResponseDTO<Boolean> deleteTempoliza(){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.deleteTempoliza();
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Tempoliza eliminada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar información de Tempoliza");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getTempolizaInsert: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@Override
	public ResponseDTO<List<Tempoliza>> getTempolizaInsert(String param1, String param2, int tipoMovimiento, int noMovimiento, int tipo){
		ResponseDTO<List<Tempoliza>> response = new ResponseDTO<List<Tempoliza>>();
		List<Tempoliza> tempoliza = siatEntradasRepository.getTempolizaInsert(param1, param2, tipoMovimiento, noMovimiento, tipo);
	 	if(tempoliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de tempoliza");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(tempoliza);
		return response;
	}
	
	/**
	 * getTempolizaInsert2: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@Override
	public ResponseDTO<List<Tempoliza>> getTempolizaInsert2(int idEntrada, int tipo){
		ResponseDTO<List<Tempoliza>> response = new ResponseDTO<List<Tempoliza>>();
		List<Tempoliza> tempoliza = siatEntradasRepository.getTempolizaInsert2(idEntrada, tipo);
	 	if(tempoliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de tempoliza");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(tempoliza);
		return response;
	}
	
	/**
	 * insertTempoliza:inserta registro en tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-02
	 */
	@Override
	public ResponseDTO<Boolean> insertTempoliza(Tempoliza tempoliza){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertTempoliza(tempoliza);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Tempoliza insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de Tempoliza");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getIva: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@Override
	public ResponseDTO<List<Iva>> getIva(int idIva)  {
		ResponseDTO<List<Iva>> response = new ResponseDTO<List<Iva>>();
		List<Iva> total = siatEntradasRepository.getIva(idIva);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de iva");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * getTempoliza: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@Override
	public ResponseDTO<List<Tempoliza>> getTempoliza(){
		ResponseDTO<List<Tempoliza>> response = new ResponseDTO<List<Tempoliza>>();
		List<Tempoliza> tempoliza = siatEntradasRepository.getTempoliza();
	 	if(tempoliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de tempoliza");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(tempoliza);
		return response;
	}
	
	/**
	 * getTempolizaRefaccion: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@Override
	public ResponseDTO<List<TempolizaRefaccion>> getTempolizaRefaccion(){
		ResponseDTO<List<TempolizaRefaccion>> response = new ResponseDTO<List<TempolizaRefaccion>>();
		List<TempolizaRefaccion> tempoliza = siatEntradasRepository.getTempolizaRefaccion();
	 	if(tempoliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de tempoliza");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(tempoliza);
		return response;
	}
	
	/**
	 * getTraspasosGrupos: obtiene informacion de traspasos grupos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	@Override
	public ResponseDTO<List<TraspasosGrupos>> getTraspasosGrupos(int idRefaccion, String fecha, String hora){
		ResponseDTO<List<TraspasosGrupos>> response = new ResponseDTO<List<TraspasosGrupos>>();
		List<TraspasosGrupos> traspasos = siatEntradasRepository.getTraspasosGrupos(idRefaccion,fecha,hora);
	 	if(traspasos.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de tempoliza");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(traspasos);
		return response;
	}
	
	/**
	 * getGruposAlmacen: obtiene informacion de grupos almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getGruposAlmacen(int idGrupo, int idAlmacen){
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> traspasos = siatEntradasRepository.getGruposAlmacen(idGrupo,idAlmacen);
	 	if(traspasos.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de grupos almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(traspasos);
		return response;
	}
	
	/**
	 * updateTempoliza :actualiza registro de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-02
	 */
	@Override
	public ResponseDTO<Boolean> updateTempoliza(Tempoliza tempoliza, int idRefaccion, String fecha, String hora){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateTempoliza(tempoliza, idRefaccion, fecha, hora);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Tempoliza actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de Tempoliza");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getGruposAlmacen: obtiene informacion de kardex y refacciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	@Override
	public ResponseDTO<List<KardexRefacciones>> getKardexRefacciones(String noMovimiento,int tipo, int idGrupo){
		ResponseDTO<List<KardexRefacciones>> response = new ResponseDTO<List<KardexRefacciones>>();
		List<KardexRefacciones> kardex = siatEntradasRepository.getKardexRefacciones(noMovimiento,tipo,idGrupo);
	 	if(kardex.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de kardex");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(kardex);
		return response;
	}
	
	/**
	 * getKardexMovimiento: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	@Override
	public ResponseDTO<List<KardexMovimiento>> getKardexMovimiento(int idRefaccion, String fecha, String hora){
		ResponseDTO<List<KardexMovimiento>> response = new ResponseDTO<List<KardexMovimiento>>();
		List<KardexMovimiento> kardex = siatEntradasRepository.getKardexMovimiento(idRefaccion,fecha, hora);
	 	if(kardex.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de kardex");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(kardex);
		return response;
	}
	
	/**
	 * getAlmacenes: obtiene informacion de almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	@Override
	public ResponseDTO<List<Almacen>> getAlmacenes(){
		ResponseDTO<List<Almacen>> response = new ResponseDTO<List<Almacen>>();
		List<Almacen> almacen = siatEntradasRepository.getAlmacenes();
	 	if(almacen.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de almacen");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(almacen);
		return response;
	}
	
	/**
	 * getSumCantKardex: obtiene suma de la cantidad de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	@Override
	public ResponseDTO<List<TotalGrid>> getSumCantKardex(int idRefaccion, String fecha, String hora, int idAlmacen){
		ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
		List<TotalGrid> kardex = siatEntradasRepository.getSumCantKardex(idRefaccion,fecha, hora, idAlmacen);
	 	if(kardex.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de la suma de kardex");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(kardex);
		return response;
	}
	
	/**
	 * getFacturaOrdenAnticipo: obtiene informacion de la tabla factura orden anticipo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	@Override
	public ResponseDTO<List<FacturaOrdenAnticipo>> getFacturaOrdenAnticipo(int idFacturaOrden)  {
		ResponseDTO<List<FacturaOrdenAnticipo>> response = new ResponseDTO<List<FacturaOrdenAnticipo>>();
		List<FacturaOrdenAnticipo> total = siatEntradasRepository.getFacturaOrdenAnticipo(idFacturaOrden);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la factura orden anticipo");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * getIdPoliza: obtiene informacion de la tabla poliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-07
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getIdPoliza(int tabla, int numPoliza, int idTipoPol){
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> poliza = siatEntradasRepository.getIdPoliza(tabla, numPoliza, idTipoPol);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la id poliza");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getMaxPoliza: obtiene informacion de la tabla poliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-07
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getMaxPoliza(int tabla){
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> poliza = siatEntradasRepository.getMaxPoliza(tabla);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el max poliza");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * insertPolizaAnio:inserta registro en poliza año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@Override
	public ResponseDTO<Boolean> insertPolizaAnio(int anio, PolizasAnio poliza){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertPolizaAnio(anio, poliza);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Poliza insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de Poliza");
			response.setData(false);
			return response;
		}
	}
	
	
	/**
	 * insertPoliza:inserta registro en polizas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@Override
	public ResponseDTO<Boolean> insertPoliza(Polizas poliza){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertPoliza(poliza);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Poliza insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de Poliza");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertMovimientos:inserta registro en movimientos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@Override
	public ResponseDTO<Boolean> insertMovimientos(int anio, Movimientos movimiento){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertMovimientos(anio, movimiento);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Movimientos insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de Movimientos");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateCatcuentasAnio:actualiza registro en catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@Override
	public ResponseDTO<Boolean> updateCatcuentasAnio(int anio, int mes, String idCuenta, int importe){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateCatcuentasAnio(anio,mes,idCuenta, importe);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("catcuentas actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de catcuentas");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateCatcuentasAbono:actualiza registro en catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@Override
	public ResponseDTO<Boolean> updateCatcuentasAbonos(int anio, int mes, String idCuenta, String importe){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateCatcuentasAbonos(anio,mes,idCuenta, importe);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("catcuentas actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de catcuentas");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getCatCuentas: obtiene informacion de la catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-11
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getCatCuentas(int cargo, int anio, String idCuenta){
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> Cargo = siatEntradasRepository.getCatCuentas(cargo, anio, idCuenta);
	 	if(Cargo.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el cargo de la cat cuenta");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(Cargo);
		return response;
	}
	
	/**
	 * getCatCuentasAbonos: obtiene informacion de la catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-11
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getCatCuentasAbonos(int abono, int anio, String idCuenta){
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> Abono = siatEntradasRepository.getCatCuentasAbonos(abono, anio, idCuenta);
	 	if(Abono.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el abono de la catcuenta");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(Abono);
		return response;
	}
	
	/**
	 * updateResumenCompra:actualiza registro en resumen compra
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-09
	 */
	@Override
	public ResponseDTO<Boolean> updateResumenCompra(int idRefaccion, ResumenCompra resumen){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateResumenCompra(idRefaccion,resumen);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("resumen cuenta actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de resumen cuenta");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getResumenCompra: obtiene informacion de resumen compra
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-12
	 */
	@Override
	public ResponseDTO<List<ResumenCompra>> getResumenCompra(int idRefaccion){
		ResponseDTO<List<ResumenCompra>> response = new ResponseDTO<List<ResumenCompra>>();
		List<ResumenCompra> poliza = siatEntradasRepository.getResumenCompra(idRefaccion);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el resumen compra");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getResumenImpresion: obtiene informacion de resumen impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-15
	 */
	@Override
	public ResponseDTO<List<ImprimirGeneral>> getResumenImpresion(int anio, String fechaIni, String fechaFin, int tipo,int permisoTaller, int idTaller){
		ResponseDTO<List<ImprimirGeneral>> response = new ResponseDTO<List<ImprimirGeneral>>();
		List<ImprimirGeneral> poliza = siatEntradasRepository.getResumenImpresion(anio, fechaIni, fechaFin,tipo, permisoTaller, idTaller);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el resumen impresion");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getKardexInformacion: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-15
	 */
	@Override
	public ResponseDTO<List<KardexInformacion>> getKardexInformacion(int noMovimiento, int tipoMovimiento, int tipo){
		ResponseDTO<List<KardexInformacion>> response = new ResponseDTO<List<KardexInformacion>>();
		List<KardexInformacion> poliza = siatEntradasRepository.getKardexInformacion(noMovimiento, tipoMovimiento,tipo);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la kardex");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getEntradaFechapol: obtiene informacion de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@Override
	public ResponseDTO<List<EntradasFechapol>> getEntradaFechapol(int anio, int idEntrada, int tipo){
		ResponseDTO<List<EntradasFechapol>> response = new ResponseDTO<List<EntradasFechapol>>();
		List<EntradasFechapol> poliza = siatEntradasRepository.getEntradaFechapol(anio, idEntrada,tipo);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de entradas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getTotalMovimientos: obtiene informacion de movimientos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getTotalMovimientos(int anio, int idPoliza){
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> poliza = siatEntradasRepository.getTotalMovimientos(anio, idPoliza);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la informacion de movimientos");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * deletePoliza : Elimina informacion de polizas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@Override
	public ResponseDTO<Boolean> deletePoliza(int idPoliza, int tabla, int idTipoPol){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.deletePoliza(idPoliza, tabla, idTipoPol);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Poliza eliminada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar información de poliza");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * deletePolizaAnio : Elimina informacion de polizas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@Override
	public ResponseDTO<Boolean> deletePolizaAnio(int anio, int idPoliza, int idTipoPol){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.deletePolizaAnio(anio, idPoliza, idTipoPol);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Poliza año eliminada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar información de poliza año");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * deleteMovimientosAnio : Elimina informacion de movimientos año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@Override
	public ResponseDTO<Boolean> deleteMovimientosAnio(int anio, int idPoliza){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.deleteMovimientosAnio(anio, idPoliza);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Movimientos año eliminada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar información de movimientos año");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 *getRptEntradaConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	@Override
	public ResponseDTO<List<ImprimirEntradas>> getRptEntradaConsultar(int anio, int idEntrada, int tipo){
		ResponseDTO<List<ImprimirEntradas>> response = new ResponseDTO<List<ImprimirEntradas>>();
		List<ImprimirEntradas> poliza = siatEntradasRepository.getRptEntradaConsultar(anio, idEntrada,tipo);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la impresion de entradas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 *getRptEntradaFacturaConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	@Override
	public ResponseDTO<List<ImprimirEntradasFactura>> getRptEntradaFacturaConsultar(int anio, int idEntrada, int idAlmacen, int tipo){
		ResponseDTO<List<ImprimirEntradasFactura>> response = new ResponseDTO<List<ImprimirEntradasFactura>>();
		List<ImprimirEntradasFactura> poliza = siatEntradasRepository.getRptEntradaFacturaConsultar(anio, idEntrada,idAlmacen, tipo);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la impresion de entradas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 *getRptEntradaRemisionConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	@Override
	public ResponseDTO<List<ImprimirEntradasFactura>> getRptEntradaRemisionConsultar(int anio, int idEntrada, int idAlmacen, int tipo){
		ResponseDTO<List<ImprimirEntradasFactura>> response = new ResponseDTO<List<ImprimirEntradasFactura>>();
		List<ImprimirEntradasFactura> poliza = siatEntradasRepository.getRptEntradaRemisionConsultar(anio, idEntrada,idAlmacen, tipo);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la impresion de entradas");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getConvenios: obtiene informacion de la tabla convenios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	@Override
	public ResponseDTO<List<Convenios>> getConvenios(int idConvenio){
		ResponseDTO<List<Convenios>> response = new ResponseDTO<List<Convenios>>();
		List<Convenios> poliza = siatEntradasRepository.getConvenios(idConvenio);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getGridEntDevolucion: obtiene informacion para generar el grid de entrada por devolucion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	@Override
	public ResponseDTO<List<ConvenioProveedor>> getGridEntDevolucion(){
		ResponseDTO<List<ConvenioProveedor>> response = new ResponseDTO<List<ConvenioProveedor>>();
		List<ConvenioProveedor> convenio = siatEntradasRepository.getGridEntDevolucion();
	 	if(convenio.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el convenio proveedor");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(convenio);
		return response;
	}
	
	/**
	 * getRefaccionesPorSurtir: obtiene informacion para generar obtener las refacciones por surtir
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	@Override
	public ResponseDTO<List<RefaccionesPorSurtir>> getRefaccionesPorSurtir(int idConvenio){
		ResponseDTO<List<RefaccionesPorSurtir>> response = new ResponseDTO<List<RefaccionesPorSurtir>>();
		List<RefaccionesPorSurtir> poliza = siatEntradasRepository.getRefaccionesPorSurtir(idConvenio);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getGrupos: obtiene informacion para los grupos.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-07
	 */
	@Override
	public ResponseDTO<List<Grupos>> getGrupos(int clave){
		ResponseDTO<List<Grupos>> response = new ResponseDTO<List<Grupos>>();
		List<Grupos> poliza = siatEntradasRepository.getGrupos(clave);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grupo");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getGruposIdentificador: obtiene informacion para los grupos.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-07
	 */
	@Override
	public ResponseDTO<List<Grupos>> getGruposIdentificador(int idGrupo){
		ResponseDTO<List<Grupos>> response = new ResponseDTO<List<Grupos>>();
		List<Grupos> poliza = siatEntradasRepository.getGruposIdentificador(idGrupo);
	 	if(poliza.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grupo");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(poliza);
		return response;
	}
	
	/**
	 * getCuerpoDetalleRefaccion: obtiene el cuerpo del convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	@Override
	public ResponseDTO<List<CuerpoConvenio>> getCuerpoConvenio( int idConvenio, int idRefaccion)  {
		ResponseDTO<List<CuerpoConvenio>> response = new ResponseDTO<List<CuerpoConvenio>>();
		List<CuerpoConvenio> total = siatEntradasRepository.getCuerpoConvenio(idConvenio, idRefaccion);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el cuerpo convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * getCatCuentasAnio: obtiene informacion de cat cuentas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-15-13
	 */
	@Override
	public ResponseDTO<List<CatCuentasAnio>> getCatCuentasAnio( int anio, String idCuentas)  {
		ResponseDTO<List<CatCuentasAnio>> response = new ResponseDTO<List<CatCuentasAnio>>();
		List<CatCuentasAnio> total = siatEntradasRepository.getCatCuentasAnio(anio, idCuentas);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el cuerpo convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	

	/**
	 * deleteTablaTemporal: eliminar una tabla temporal
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-03-19
	 */
	@Override
	public ResponseDTO<Boolean> deleteTablaTemporal(){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.deleteTablaTemporal();
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("tabla temporada eliminar correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar información de tabla temporal");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertTemporal: inserta registro en tabla temporal
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-03-19
	 */
	@Override
	public ResponseDTO<Boolean> insertTemporal(TablaTemporal temp){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertTemporal(temp);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("tabla temporal insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de tabla temporal");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getGrupoTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getGrupoTemporal()  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> total = siatEntradasRepository.getGrupoTemporal();
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el grupo temporal");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * getImporteTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	@Override
	public ResponseDTO<List<TablaSumTemporal>> getImporteTemporal()  {
		ResponseDTO<List<TablaSumTemporal>> response = new ResponseDTO<List<TablaSumTemporal>>();
		List<TablaSumTemporal> total = siatEntradasRepository.getImporteTemporal();
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la suma temporal");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * getSumPmnTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	@Override
	public ResponseDTO<List<GetMotivo>> getSumPmnTemporal()  {
		ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
		List<GetMotivo> total = siatEntradasRepository.getSumPmnTemporal();
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener el suma pmn ");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * updateFacturasOrden:actualiza registro en facturas orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@Override
	public ResponseDTO<Boolean> updatePrecioRefaccionLlanta( int idRefaccion, Double precio ){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updatePrecioRefaccionLlanta(idRefaccion, precio);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Precio de la refacción en llantas actualizado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar el precio de la refacción en llantas");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getEsFactura: obtiene informacion si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<List<DetalleEntradaConsignacion>> getDetalleEntradaConsignacion(int anio, int idEntrada, int idAlmacen)  {
		ResponseDTO<List<DetalleEntradaConsignacion>> response = new ResponseDTO<List<DetalleEntradaConsignacion>>();
		List<DetalleEntradaConsignacion> esfactura = siatEntradasRepository.getDetalleEntradaConsignacion(anio, idEntrada, idAlmacen);
	 	if(esfactura.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener si es factura");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(esfactura);
		return response;
	}
	
	/**
	 * updateFacturasOrden:actualiza saldo total en convenios
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-24
	 */
	@Override
	public ResponseDTO<Boolean> updateSaldoConvenio( int idConvenio, Double saldoTotal ){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateSaldoConvenio(idConvenio, saldoTotal);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("Saldo total del convenio actualizado correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar el saldo total del convenio");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertTemporal: inserta registro en tabla historicodetaconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-25
	 */
	@Override
	public ResponseDTO<Boolean> insertHistoricoConvenio(HistoricoConvenio temp){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertHistoricoConvenio(temp);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("tabla historicodetaconvenio insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de tabla historicodetaconvenio");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getListCuerpoConvenio: obtiene las refacciones del cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-26
	 */
	@Override
	public ResponseDTO<List<ListaCuerpoConvenio>> getListCuerpoConvenio(int idConvenio)  {
		ResponseDTO<List<ListaCuerpoConvenio>> response = new ResponseDTO<List<ListaCuerpoConvenio>>();
		List<ListaCuerpoConvenio> total = siatEntradasRepository.getListCuerpoConvenio(idConvenio);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener la lista del cuerpo convenio");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * updateRefaProveedor:actualiza registro en refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	@Override
	public ResponseDTO<Boolean> updateExistenciaRefaProveedor(int idRefaccion, int idProveedor, Double existencia){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateExistenciaRefaProveedor(idRefaccion, idProveedor, existencia);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("refaproveedor actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de refaproveedor");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * updateDataCuerpoConvenio:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia Alor
	 * @return Boolean
	 * @date 2024-03-27
	 */
	@Override
	public ResponseDTO<Boolean> updateDataCuerpoConvenio(int idRefaccion, int idConvenio, Double pcmn, Double cantidadSurtida){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.updateDataCuerpoConvenio(idRefaccion,idConvenio, pcmn, cantidadSurtida);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("cuerpo convenio actualizada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar información de cuerpo convenio");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * insertTemporal: inserta registro en tabla histcuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-27
	 */
	@Override
	public ResponseDTO<Boolean> insertHistoricoCuerpoConvenio(HistoricoCuerpoConvenio temp){
		ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();

		Boolean inserted = siatEntradasRepository.insertHistoricoCuerpoConvenio(temp);
		if (inserted) {
			response.setCode(1);
			response.setDescription("success");
			response.setMessage("tabla histcuerpoconvenio insertada correctamente");
			response.setData(true);
			return response;
		} else {
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar información de tabla histcuerpoconvenio");
			response.setData(false);
			return response;
		}
	}
	
	/**
	 * getDataEntradaNormal: obtiene los datos de la entrada normal
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-27
	 */
	@Override
	public ResponseDTO<List<GetDataEntradaNormal>> getDataEntradaNormal(int anio, int idEntrada, int tipoEntrada)  {
		ResponseDTO<List<GetDataEntradaNormal>> response = new ResponseDTO<List<GetDataEntradaNormal>>();
		List<GetDataEntradaNormal> total = siatEntradasRepository.getDataEntradaNormal(anio, idEntrada, tipoEntrada);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener los datos de la entrada para la poliza");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
	/**
	 * getDataEntrada: obtiene los datos de las entradas
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-27
	 */
	@Override
	public ResponseDTO<List<GetDataEntrada>> getDataEntrada(int anio, int idEntrada, int tipoEntrada)  {
		ResponseDTO<List<GetDataEntrada>> response = new ResponseDTO<List<GetDataEntrada>>();
		List<GetDataEntrada> total = siatEntradasRepository.getDataEntrada(anio, idEntrada, tipoEntrada);
	 	if(total.isEmpty()) {
	 		response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible obtener los datos de la entrada para la poliza");
			response.setData(null);
			return response;
	 	}	
		response.setCode(1);
		response.setDescription("success");
		response.setMessage("Registros obtenidos correctamente");
		response.setData(total);
		return response;
	}
	
}
