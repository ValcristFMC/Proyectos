package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de poliza", description = "mapea tabla de siat.poliza")
@Entity
@Table(name = "siat.poliza")
public class CatCuentasAnio {
	
	@Id
	@Column(name="idcuenta")
	private String idCuenta;
	@Column(name="idoficina")
	private int idOficina;
	@Column(name = "nivelcuenta")
	private int nivelCuenta;
	@Column(name = "tipocuenta")
	private String tipoCuenta;
	@Column(name = "nombrecuenta")
	private String nombreCuenta;
	@Column(name = "fechaalta")
	private LocalDate fechaAlta;
	@Column(name = "horaalta")
	private LocalTime horaAlta;
	@Column(name="idusuario")
	private int idUsuario;
	@Column(name = "tamnivdet")
	private int tamnivdet;
	@Column(name = "saldoinicial1")
	private Double saldoInicial1;
	@Column(name = "saldoinicial2")
	private Double saldoInicial2;
	@Column(name = "saldoinicial3")
	private Double saldoInicial3;
	@Column(name = "saldoinicial4")
	private Double saldoInicial4;
	@Column(name = "saldoinicial5")
	private Double saldoInicial5;
	@Column(name = "saldoinicial6")
	private Double saldoInicial6;
	@Column(name = "saldoinicial7")
	private Double saldoInicial7;
	@Column(name = "saldoinicial8")
	private Double saldoInicial8;
	@Column(name = "saldoinicial9")
	private Double saldoInicial9;
	@Column(name = "saldoinicial10")
	private Double saldoInicial10;
	@Column(name = "saldoinicial11")
	private Double saldoInicial11;
	@Column(name = "saldoinicial12")
	private Double saldoInicial12;
	@Column(name = "saldoinicial13")
	private Double saldoInicial13;
	@Column(name = "cargos1")
	private Double cargos1;
	@Column(name = "abonos1")
	private Double abonos1;
	@Column(name = "cargos2")
	private Double cargos2;
	@Column(name = "abonos2")
	private Double abonos2;
	@Column(name = "cargos3")
	private Double cargos3;
	@Column(name = "abonos3")
	private Double abonos3;
	@Column(name = "cargos4")
	private Double cargos4;
	@Column(name = "abonos4")
	private Double abonos4;
	@Column(name = "cargos5")
	private Double cargos5;
	@Column(name = "abonos5")
	private Double abonos5;
	@Column(name = "cargos6")
	private Double cargos6;
	@Column(name = "abonos6")
	private Double abonos6;
	@Column(name = "cargos7")
	private Double cargos7;
	@Column(name = "abonos7")
	private Double abonos7;
	@Column(name = "cargos8")
	private Double cargos8;
	@Column(name = "abonos8")
	private Double abonos8;
	@Column(name = "cargos9")
	private Double cargos9;
	@Column(name = "abonos9")
	private Double abonos9;
	@Column(name = "cargos10")
	private Double cargos10;
	@Column(name = "abonos10")
	private Double abonos10;
	@Column(name = "cargos11")
	private Double cargos11;
	@Column(name = "abonos11")
	private Double abonos11;
	@Column(name = "cargos12")
	private Double cargos12;
	@Column(name = "abonos12")
	private Double abonos12;
	@Column(name = "cargos13")
	private Double cargos13;
	@Column(name = "abonos13")
	private Double abonos13;
	@Column(name = "presupuesto1")
	private Double presupuesto1;
	@Column(name = "presupuesto2")
	private Double presupuesto2;
	@Column(name = "presupuesto3")
	private Double presupuesto3;
	@Column(name = "presupuesto4")
	private Double presupuesto4;
	@Column(name = "presupuesto5")
	private Double presupuesto5;
	@Column(name = "presupuesto6")
	private Double presupuesto6;
	@Column(name = "presupuesto7")
	private Double presupuesto7;
	@Column(name = "presupuesto8")
	private Double presupuesto8;
	@Column(name = "presupuesto9")
	private Double presupuesto9;
	@Column(name = "presupuesto10")
	private Double presupuesto10;
	@Column(name = "presupuesto11")
	private Double presupuesto11;
	@Column(name = "presupuesto12")
	private Double presupuesto12;
	@Column(name = "presupuesto13")
	private Double presupuesto13;
	@Column(name = "preanual")
	private Double preAnual;
}
