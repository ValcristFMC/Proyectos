package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Almacenes", description = "mapea tabla de siat.almacen")
@Entity
@Table(name = "siat.almacen")
public class ContraRecibosInfo {
	
	@Id
	@Column(name="idcontrarecibo", nullable = true)
	private int idContraRecibo;
	@Column(name = "idfacturaorden" , nullable = true)
	private String idFacturaOrden;
	@Column(name="folio", nullable = true)
	private int folio;
	@Column(name = "fechaemision", nullable = true)
	private LocalDate fechaEmision;
	@Column(name = "idproveedor" , nullable = true)
	private String idProveedor;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
	@Column(name="idpersonal", nullable = true)
	private int idPersonal;
	@Column(name = "subtotal" , nullable = true)
	private Double subTotal;
	@Column(name = "iva" , nullable = true)
	private Double iva;
	@Column(name = "retencion" , nullable = true)
	private Double retencion;
	@Column(name = "descuento" , nullable = true)
	private Double descuento;
	@Column(name = "total" , nullable = true)
	private Double total;
	@Column(name="idestatus", nullable = true)
	private int idEstatus;
	@Column(name = "fechaparapago")
	private LocalDate fechaParaPago;
	@Column(name="pagoanticipado", nullable = true)
	private int pagoAnticipado;
	@Column(name="tipo", nullable = true)
	private int tipo;
	@Column(name="idmoneda", nullable = true)
	private int idMoneda;
	@Column(name="impresion", nullable = true)
	private int impresion;	
}
