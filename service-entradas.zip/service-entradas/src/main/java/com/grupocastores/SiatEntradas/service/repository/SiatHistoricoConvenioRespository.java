package com.grupocastores.SiatEntradas.service.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.grupocastores.SiatEntradas.dto.ConvenioHistoricoDTO;
import com.grupocastores.SiatEntradas.utils.UtilitiesRepository;
import com.grupocastores.SiatEntradas.utils.UtilsDatetime;


@Repository
public class SiatHistoricoConvenioRespository extends UtilitiesRepository{
	private String dataBaseSelect = DB_13;
    private String comilla = "\"";
    public static final String qryHistoricoConvenioBase = "SELECT idconvenio AS id_convenio, idmodificacion AS id_modificacion, idrefaccion AS id_refaccion, num_campo AS num_campo, nom_campo AS nom_campo, valor_anterior AS valor_anterior, valor_nuevo AS valor_nuevo, motivo, id_personal AS id_personal, fecha, hora FROM siat.historicodetaconvenio_view";
    public static final String qryHistoricoConvenioById = "WHERE idconvenio = %s AND idmodificacion = %s AND idrefaccion = %s AND numcampo = %s";
    public static final String qryInsertHistoricoConvenio = "INSERT INTO siat.historicodetaconvenio(idconvenio, idmodificacion, idrefaccion, numcampo, nomcampo, valoranterior, valornuevo, motivo, idpersonal, fecha, hora) VALUES(\"%s\", \"%s\",\"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\")";
    public static final String qryUpdateHistoricoConvenio = "UPDATE siat.historicodetaconvenio SET nomcampo = \"%s\", valoranterior = \"%s\", valornuevo = \"%s\", motivo = \"%s\", idpersonal = \"%s\", fecha = \"%s\", hora = \"%s\" WHERE idconvenio = %s AND idmodificacion = %s AND idrefaccion = %s AND numcampo = %s";	
	private String lastQuery = "";
	
    @PersistenceContext
    private EntityManager entityManager;

    private String getQueryHistoricoById(int idConvenio, int idModificacion, int idRefaccion, int numCampo) {
    	return formatoMySqlToSqlServer(String.format(qryHistoricoConvenioBase + qryHistoricoConvenioById, "%s", "%s", "%s"), dataBaseSelect);
    }

    private String getQueryInsertHistorico(ConvenioHistoricoDTO historico) {
    	UtilsDatetime util = new UtilsDatetime();
    	return formatoMySqlToSqlServerExec(String.format(qryInsertHistoricoConvenio, historico.getIdConvenio(), historico.getIdModificacion(), historico.getIdRefaccion(), historico.getNumCampo(), historico.getNomCampo(), historico.getValorAnterior(), historico.getValorNuevo(), historico.getMotivo(), historico.getIdPersonal(), util.dateToStringDMY(historico.getFecha()), historico.getHora()), dataBaseSelect);
    }

    private String getQueryUpdateHistorico(ConvenioHistoricoDTO historico) {
    	UtilsDatetime util = new UtilsDatetime();
    	return formatoMySqlToSqlServerExec(String.format(qryUpdateHistoricoConvenio, historico.getNomCampo(), historico.getValorAnterior(), historico.getValorNuevo(), historico.getMotivo(), historico.getIdPersonal(), util.dateToStringDMY(historico.getFecha()), historico.getHora(), historico.getIdConvenio(), historico.getIdModificacion(), historico.getIdRefaccion(), historico.getNumCampo()), dataBaseSelect);
    }

    @SuppressWarnings("unchecked")
    public List<ConvenioHistoricoDTO> getHistoricoConvenioById(int idConvenio, int idModificacion, int idRefaccion, int numCampo) {
    	lastQuery = getQueryHistoricoById(idConvenio, idModificacion, idRefaccion, numCampo);
        Query query = entityManager.createNativeQuery(lastQuery, ConvenioHistoricoDTO.class);
	    return (List<ConvenioHistoricoDTO>) query.getResultList();
    }

    public Boolean insertHistoricoConvenio(ConvenioHistoricoDTO historico) {
    	
    	lastQuery = getQueryInsertHistorico(historico);
        System.out.println("Esta es la qry: " + lastQuery);
       return executeStoredProcedure(lastQuery);
		

    }

    public Boolean updateHistoricoConvenio(ConvenioHistoricoDTO historico) {
    	lastQuery = getQueryUpdateHistorico(historico);
    	System.out.println("Esta es la qry: " + lastQuery);
        return executeStoredProcedure(lastQuery);
    }

	public String getLastQuery() {
		return lastQuery;
	}

	public void setLastQuery(String lastQuery) {
		this.lastQuery = lastQuery;
	}
	
}
