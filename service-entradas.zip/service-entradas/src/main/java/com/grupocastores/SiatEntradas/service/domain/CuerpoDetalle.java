package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Cuerpo detalle", description = "mapea tabla de siat.cuerpodetalle")
@Entity
@Table(name = "siat.cuerpodetalle")
public class CuerpoDetalle {
	
	@Id
	@Column(name = "idrefaccion")
	private int idRefaccion;
	@Column(name="idrequisicion")
	private int idRequisicion;
	@Column(name = "cantrequisicion")
	private String cantRequisicion;
	@Column(name = "cantordenada")
	private String cantOrdenada;
	@Column(name = "cantfacturada")
	private String cantFacturada;
	@Column(name = "cantentrada")
	private String cantEntrada;
	
}
