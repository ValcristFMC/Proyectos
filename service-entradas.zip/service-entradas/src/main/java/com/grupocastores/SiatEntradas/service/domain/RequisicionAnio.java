package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Requisición Anio", description = "mapea tabla de siat.requisicionAnio")
@Entity
@Table(name = "siat.requisicionAnio")
public class RequisicionAnio {
	
	@Id
	@Column(name="idrequisicion")
	private int idRequisicion;
	@Column(name = "clave")
	private String clave;
	@Column(name = "idsolicita")
	private int idSolicita;
	@Column(name = "observaciones")
	private String observaciones;
	@Column(name = "idurgencia")
	private int idUrgencia;
	@Column(name = "idestatus")
	private int idEstatus;
	@Column(name = "idalmacen")
	private int idAlmacen;
	@Column(name = "idautoriza")
	private int idAutoriza;
	@Column(name = "idreviso")
	private int idReviso;
	@Column(name = "esnueva")
	private int esNueva;
	@Column(name = "idpersonal")
	private int idPersonal;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;

}
