package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.Nullable;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Requisición Anio", description = "mapea tabla de siat.requisicionAnio")
@Entity
@Table(name = "siat.requisicionAnio")
public class FacturaOrden {
	
	@Id
	@Column(name="idfacturaorden")
	private int idFacturaOrden;
	@Column(name="idordencompra")
	private int idOrdenCompra;
	@Column(name = "factura")
	private String factura;
	@Column(name = "subtotal")
	private Double subTotal;
	@Column(name = "descuento")
	private Double descuento;
	@Column(name = "iva")
	private Double iva;
	@Column(name = "retencion")
	private Double retencion;
	@Column(name = "total")
	private Double total;
	@Column(name = "idproveedor")
	private int idProveedor;
	@Column(name = "observaciones")
	private String observaciones;
	@Column(name = "idestatus", nullable = true)
	private int idEstatus;
	@Column(name = "idpersonal", nullable = true)
	private int idPersonal;
	@Column(name = "fecha", nullable = true)
	private String fecha;
	@Column(name = "hora", nullable = true)
	private LocalTime hora;
	@Column(name = "esfactura", nullable = true)
	private int esFactura;
	@Column(name = "fechavencimiento", nullable = true)
	private String fechaVencimiento;
	@Column(name = "contrarecibo", nullable = true)
	private int contrarecibo;
	@Column(name = "repuestocon", nullable = true)
	private int repuestoCon;
	@Column(name = "sepagara", nullable = true)
	private int sePagara;
	@Column(name = "idmonedafactura", nullable = true)
	private int idMonedaFactura;
	@Column(name = "idmonedacontrarecibo", nullable = true)
	private int idMonedaContrarecibo;
	@Column(name = "tipocambio", nullable = true)
	private String tipoCambio;
	@Column(name = "fechamod", nullable = true)
	private String fechaMod;
	@Column(name = "razonsocial", nullable = true)
	private String razonSocial;
}
