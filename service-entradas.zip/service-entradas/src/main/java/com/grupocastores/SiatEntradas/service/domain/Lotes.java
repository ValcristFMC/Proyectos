package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class Lotes {
	
	@Id
	@Column(name="idlote")
	private int idLote;
	@Column(name="idrefaccion")
	private int idRefaccion;
	@Column(name="fecha")
	private LocalDate fecha;
	@Column(name="hora")
	private LocalTime hora;
	@Column(name="idproveedor")
	private int idProveedor;
	@Column(name="idalmacen")
	private int idAlmacen;
	@Column(name = "cantentrada")
	private Double cantEntrada;
	@Column(name = "cantsalida")
	private Double cantSalida;
	@Column(name = "precioentrada")
	private Double precioEntrada;
	@Column(name="idmoneda")
	private int idMoneda;
	@Column(name = "esnueva")
	private int	esNueva;	
}
