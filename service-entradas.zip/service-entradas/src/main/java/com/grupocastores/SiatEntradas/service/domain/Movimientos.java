package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de poliza", description = "mapea tabla de siat.poliza")
@Entity
@Table(name = "siat.poliza")
public class Movimientos {
	
	@Id
	@Column(name="idmovim")
	private int idMovim;
	@Column(name="idpoliza")
	private int idPoliza;
	@Column(name="idcuenta")
	private String idCuenta;
	@Column(name = "idoficina")
	private int idOficina;
	@Column(name = "conceptomovim")
	private String conceptoMovim;
	@Column(name = "tipomovim")
	private String tipoMovim;
	@Column(name = "importe")
	private Double importe;
	@Column(name="iddocumento")
	private int idDocumento;
	@Column(name = "referencia")
	private String referencia;
	@Column(name = "tiporef")
	private String tipoRef;
	@Column(name = "anio")
	private int anio;
	@Column(name = "noconci")
	private int noConci;

}
