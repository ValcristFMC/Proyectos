package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class KardexMovimiento {
	
	@Id
	@Column(name="idrefaccion")
	private int idRefaccion;
	@Column(name="nomovimiento")
	private int noMovimiento;
	@Column(name = "precio")
	private Double precio;
	@Column(name = "fecha", nullable = true)
	private LocalDate fecha;
}
