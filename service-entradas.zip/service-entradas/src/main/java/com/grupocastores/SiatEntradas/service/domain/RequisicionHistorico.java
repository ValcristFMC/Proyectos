package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Requisicion Historico", description = "mapea tabla de siat.requisicionhistorico")
@Entity
@Table(name = "siat.requisicionhistorico")
public class RequisicionHistorico {
	
	@Id
	@Column(name="idrequisicion")
	private int idRequisicion;
	@Column(name = "idestatus")
	private int idEstatus;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
	@Column(name = "idpersonal")
	private int idPersonal;
	@Column(name = "observaciones")
	private String observaciones;
}
