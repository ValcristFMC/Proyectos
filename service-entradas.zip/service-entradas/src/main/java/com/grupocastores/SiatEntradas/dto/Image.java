package com.grupocastores.SiatEntradas.dto;

import javax.persistence.Entity;
import javax.persistence.Lob;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Image {

    @Lob
    private byte[] contenido;

    // getters y setters
}