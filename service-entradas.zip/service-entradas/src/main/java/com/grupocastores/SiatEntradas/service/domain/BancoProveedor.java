package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Banco proveedor", description = "mapea tabla de siat.bancoproveedor")
@Entity
@Table(name = "siat.bancoproveedor")
public class BancoProveedor {
	
	@Id
	@Column(name="idbancoproveedor")
	private int idBancoProveedor;
	@Column(name="idproveedor")
	private int idProveedor;
	@Column(name = "cuenta")
	private String cuenta;
	@Column(name = "clabe")
	private String clabe;
	@Column(name = "sucursal")
	private String sucursal;
	@Column(name = "idbanco")
	private int idBanco;
	@Column(name = "tipopago")
	private int tipoPago;
	@Column(name = "pagoanticipado")
	private int pagoAnticipado;
	@Column(name = "referenciatransaccion")
	private String referenciaTransaccion;
	@Column(name = "codigobeneficiario")
	private String codigoBeneficiario;
}
