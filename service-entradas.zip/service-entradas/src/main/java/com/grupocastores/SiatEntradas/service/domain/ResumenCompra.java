package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de resumencompra", description = "mapea tabla de siat.resumencompra")
@Entity
@Table(name = "siat.resumencompra")
public class ResumenCompra {
	
	@Id
	@Column(name="idrefaccion")
	private int idRefaccion;
	@Column(name="idproveedor")
	private int idProveedor;
	@Column(name="nombreproveedor")
	private String nombreProveedor;
	@Column(name="identrada")
	private int idEntrada;
	@Column(name="idordencompra")
	private int idOrdenCompra;
	@Column(name = "fechaultimacompra")
	private LocalDate fechaUltimaCompra;
	@Column(name="pcmn")
	private Double pcmn;
	@Column(name="pcd")
	private Double pcd;
	@Column(name="idcotizacion")
	private int idCotizacion;
	@Column(name = "fechacotizacion")
	private LocalDate fechaCotizacion;
	@Column(name = "idmoneda")
	private int idMoneda;
}
