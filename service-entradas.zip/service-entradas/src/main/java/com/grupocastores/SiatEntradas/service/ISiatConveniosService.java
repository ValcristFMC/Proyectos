package com.grupocastores.SiatEntradas.service;

import java.util.List;

import com.grupocastores.SiatEntradas.dto.ConvenioDTO;
import com.grupocastores.SiatEntradas.dto.ResponseDTO;

public interface ISiatConveniosService {
    
    public List<ConvenioDTO> getLstConvenios(int estatus);
    
    public ConvenioDTO getConvenioById(int id);
    
    public ResponseDTO<Void> insertConvenio(ConvenioDTO convenio);
    
    public ResponseDTO<Void> updateConvenio(ConvenioDTO convenio);
    
    public ResponseDTO<Void> updateConvenioEstatus(int estatus, int id);
    
    public Long getLastId();

}
