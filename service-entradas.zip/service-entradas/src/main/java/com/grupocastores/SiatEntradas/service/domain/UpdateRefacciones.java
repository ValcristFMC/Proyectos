package com.grupocastores.SiatEntradas.service.domain;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class UpdateRefacciones {
	
	@Id
	@Column(name = "existencia")
	private Double existencia;
	@Column(name = "minimo")
	private Double minimo;
	@Column(name = "maximo")
	private Double maximo;
	@Column(name = "pcmn")
	private Double pcmn;
	@Column(name = "pcd")
	private Double pcd;
	@Column(name = "pvmn")
	private Double pvmn;
	@Column(name = "pvd")
	private Double pvd;
}
