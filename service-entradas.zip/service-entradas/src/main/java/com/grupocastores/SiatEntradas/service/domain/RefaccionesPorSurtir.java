package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class RefaccionesPorSurtir {
	
	@Id
	@Column(name="clave")
	private String clave;
	@Column(name="nombre")
	private String nombre;
	@Column(name="nueva")
	private String nueva;
	@Column(name = "cantidad")
	private Double cantidad;
	@Column(name = "pcmn")
	private Double pcmn;
	@Column(name = "idrefaccion")
	private int idRefaccion;
	@Column(name = "existencia")
	private Double existencia;
	@Column(name = "cantidad_surtir")
	private Double cantidadSurtir;
	@Column(name = "pcd")
	private Double pcd;
	@Column(name = "uno")
	private int uno;
	@Column(name="idproveedor")
	private int idProveedor;
	@Column(name="cero")
	private int cero;
	@Column(name="ast")
	private String ast;
	@Column(name = "tipoconvenio")
	private int tipoConvenio;
}
