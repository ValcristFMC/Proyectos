package com.grupocastores.SiatEntradas.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.grupocastores.SiatEntradas.service.domain.SiatEntradas;
import com.grupocastores.SiatEntradas.service.domain.TablaSumTemporal;
import com.grupocastores.SiatEntradas.service.domain.TablaTemporal;
import com.grupocastores.SiatEntradas.service.domain.Tempoliza;
import com.grupocastores.SiatEntradas.service.domain.TempolizaRefaccion;
import com.grupocastores.SiatEntradas.service.domain.TipoAutorizaciones;
import com.grupocastores.SiatEntradas.service.domain.TipoCambio;
import com.grupocastores.SiatEntradas.service.domain.TipoSolicitud;
import com.grupocastores.SiatEntradas.service.domain.TotalGrid;
import com.grupocastores.SiatEntradas.service.domain.TraspasosGrupos;
import com.grupocastores.SiatEntradas.service.domain.UpdateRefacciones;
import com.grupocastores.SiatEntradas.service.domain.ValidacionEntrada;
import com.grupocastores.SiatEntradas.service.ISiatEntradasService;
import com.grupocastores.SiatEntradas.service.domain.Almacen;
import com.grupocastores.SiatEntradas.service.domain.AlmacenTranspasosPlazo;
import com.grupocastores.SiatEntradas.service.domain.Autorizaciones;
import com.grupocastores.SiatEntradas.service.domain.BancoProveedor;
import com.grupocastores.SiatEntradas.service.domain.CantidadesEntradas;
import com.grupocastores.SiatEntradas.service.domain.CatalogoAlmacen;
import com.grupocastores.SiatEntradas.service.domain.CatCuentas;
import com.grupocastores.SiatEntradas.service.domain.CatCuentasAnio;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibos;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibosInfo;
import com.grupocastores.SiatEntradas.service.domain.ControlCambio;
import com.grupocastores.SiatEntradas.service.domain.ControlEntrada;
import com.grupocastores.SiatEntradas.service.domain.ConvenioInf;
import com.grupocastores.SiatEntradas.service.domain.ConvenioProveedor;
import com.grupocastores.SiatEntradas.service.domain.ConvenioRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Convenios;
import com.grupocastores.SiatEntradas.service.domain.CuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.CuerpoDetalle;
import com.grupocastores.SiatEntradas.service.domain.CuerpoFactura;
import com.grupocastores.SiatEntradas.service.domain.CuerpoOrden;
import com.grupocastores.SiatEntradas.service.domain.CuerpoRequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.DetalleEntrada;
import com.grupocastores.SiatEntradas.service.domain.DetalleEntradaConsignacion;
import com.grupocastores.SiatEntradas.service.domain.Entradas;
import com.grupocastores.SiatEntradas.service.domain.EntradasAnio;
import com.grupocastores.SiatEntradas.service.domain.EntradasFechapol;
import com.grupocastores.SiatEntradas.service.domain.EntradasInfo;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrden;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrdenAnticipo;
import com.grupocastores.SiatEntradas.service.domain.FolioAlmacen;
import com.grupocastores.SiatEntradas.service.domain.GetDataEntrada;
import com.grupocastores.SiatEntradas.service.domain.GetDataEntradaNormal;
import com.grupocastores.SiatEntradas.service.domain.GetMotivo;
import com.grupocastores.SiatEntradas.service.domain.GetProveedor;
import com.grupocastores.SiatEntradas.service.domain.Folio;
import com.grupocastores.SiatEntradas.dto.ResponseDTO;
import com.grupocastores.SiatEntradas.service.domain.GridEntradas;
import com.grupocastores.SiatEntradas.service.domain.GridFacturas;
import com.grupocastores.SiatEntradas.service.domain.Grupos;
import com.grupocastores.SiatEntradas.service.domain.HistoricoConvenio;
import com.grupocastores.SiatEntradas.service.domain.HistoricoCuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.IdRefaccionGrid;
import com.grupocastores.SiatEntradas.service.domain.Importe;
import com.grupocastores.SiatEntradas.service.domain.ImprimirGeneral;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradas;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradasFactura;
import com.grupocastores.SiatEntradas.service.domain.KardexInformacion;
import com.grupocastores.SiatEntradas.service.domain.InformacionRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Iva;
import com.grupocastores.SiatEntradas.service.domain.Kardex;
import com.grupocastores.SiatEntradas.service.domain.KardexMovimiento;
import com.grupocastores.SiatEntradas.service.domain.KardexRefacciones;
import com.grupocastores.SiatEntradas.service.domain.ListaCuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.Lotes;
import com.grupocastores.SiatEntradas.service.domain.Movimientos;
import com.grupocastores.SiatEntradas.service.domain.Ordenes;
import com.grupocastores.SiatEntradas.service.domain.OrdenesAnio;
import com.grupocastores.SiatEntradas.service.domain.Polizas;
import com.grupocastores.SiatEntradas.service.domain.PolizasAnio;
import com.grupocastores.SiatEntradas.service.domain.RefPorAlmacen;
import com.grupocastores.SiatEntradas.service.domain.RefaccionesPorSurtir;
import com.grupocastores.SiatEntradas.service.domain.Refaproveedor;
import com.grupocastores.SiatEntradas.service.domain.RequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.RequisicionHistorico;
import com.grupocastores.SiatEntradas.service.domain.ResumenCompra;
import com.grupocastores.SiatEntradas.service.domain.RptContraRecibo;
import com.grupocastores.SiatEntradas.service.domain.SemaforoSiat;
import com.grupocastores.SiatEntradas.dto.SiatEntradasDTO;

@RestController
@RequestMapping(value = "/SiatEntradas")
@Api(value = "SiatEntradasController", produces = "application/json")
@CrossOrigin(origins = "*")
/**
 * Controlador de commands 
 *
 * @author Castores - Desarrollo TI
 */
public class  SiatEntradasController {

	Logger logger = LoggerFactory.getLogger(SiatEntradasController.class);
	
	@Autowired
	private ISiatEntradasService siatEntradasService;
	static final String HEADERBACK = "/SiatEntradas/{id}";

	/**
	 * getSemaforoSiat: obtiene semaforo siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-08
	 */
	@ApiOperation(value = " Servicio semaforo siat", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para el semaforo siat", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getSemaforoSiat/{estatus}")
	@ResponseBody
	public ResponseDTO<List<SemaforoSiat>> getSemaforoSiat(
			@PathVariable("estatus") int estatus) {
		
		try {	
			
			return siatEntradasService.getSemaforoSiat(estatus);
		} catch (Exception e) {
			ResponseDTO<List<SemaforoSiat>> response = new ResponseDTO<List<SemaforoSiat>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el semaforo siat");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGridEntradas: obtiene el grid de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-07
	 */
	@ApiOperation(value = " Servicio grid Entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para grid Entradas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridEntradas/{anio}/{mes}/{idTaller}/{almacen}")
	@ResponseBody
	public ResponseDTO<List<GridEntradas>> getGridEntradas(
			@PathVariable("anio") int anio,
			@PathVariable("mes") int mes,
			@PathVariable("idTaller") int idTaller,
			@PathVariable("almacen") int almacen) {
		
		try {	
			
			return siatEntradasService.getGridEntradas(anio,mes,idTaller,almacen);
		} catch (Exception e) {
			ResponseDTO<List<GridEntradas>> response = new ResponseDTO<List<GridEntradas>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de entradas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGridEntradasPorAlmacen: obtiene el grid de entradas por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	@ApiOperation(value = " Servicio grid Entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para grid Entradas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridEntradasPorAlmacen/{anio}/{mes}/{tipoAlmacen}")
	@ResponseBody
	public ResponseDTO<List<GridEntradas>> getGridEntradasPorAlmacen(
			@PathVariable("anio") int anio,
			@PathVariable("mes") int mes,
			@PathVariable("tipoAlmacen") int tipoAlmacen) {
		
		try {	
			
			return siatEntradasService.getGridEntradasPorAlmacen(anio,mes,tipoAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<GridEntradas>> response = new ResponseDTO<List<GridEntradas>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid de entradas por almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getAlmacenes: obtiene los almacenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-11-12
	 */
	@ApiOperation(value = " Servicio para grid de almacen", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para los almacenes", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getAlmacen/{tipoAlmacen}/{nomAlmacen}")
	@ResponseBody
	public ResponseDTO<List<CatalogoAlmacen>> getAlmacen(
			@PathVariable("tipoAlmacen") int tipoAlmacen,
			@PathVariable("nomAlmacen") String nomAlmacen) {
		
		try {
			return siatEntradasService.getAlmacen(tipoAlmacen, nomAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<CatalogoAlmacen>> response = new ResponseDTO<List<CatalogoAlmacen>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el catalogo de almacenes");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGridFacuras: obtiene las facturas de compras
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	@ApiOperation(value = " Servicio para grid de facturas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las facturas de compras", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridFacturas/{anio}/{mes}")
	@ResponseBody
	public ResponseDTO<List<GridFacturas>> getGridFacturas(
			@PathVariable("anio") int anio,
			@PathVariable("mes") int mes) {
		
		try {
			return siatEntradasService.getGridFacturas(anio, mes);
		} catch (Exception e) {
			ResponseDTO<List<GridFacturas>> response = new ResponseDTO<List<GridFacturas>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grid facturas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGridFacurasAgrupadas: obtiene las facturas de compras agrupadas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	@ApiOperation(value = " Servicio para grid de facturas agrupadas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para las facturas de compras agrupadas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridFacturasAgrupadas/{anio}/{mes}")
	@ResponseBody
	public ResponseDTO<List<GridFacturas>> getGridFacturasAgrupadas(
			@PathVariable("anio") int anio,
			@PathVariable("mes") int mes) {
		
		try {
			return siatEntradasService.getGridFacturasAgrupadas(anio, mes);
		} catch (Exception e) {
			ResponseDTO<List<GridFacturas>> response = new ResponseDTO<List<GridFacturas>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el catalogo de almacenes");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getValidacionEntrada: obtiene la validacion de entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	@ApiOperation(value = " Servicio para grid de almacen", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data validacion de entrada", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getValidacionEntrada/{anio}/{idFacturaOrden}")
	@ResponseBody
	public ResponseDTO<List<ValidacionEntrada>> getValidacionEntrada(
			@PathVariable("anio") int anio,
			@PathVariable("idFacturaOrden") int idFacturaOrden) {
		
		try {
			return siatEntradasService.getValidacionEntrada(anio, idFacturaOrden);
		} catch (Exception e) {
			ResponseDTO<List<ValidacionEntrada>> response = new ResponseDTO<List<ValidacionEntrada>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la validacion de la entrada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * queryGetTotalGrid: obtiene el total para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data total para el grid", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTotalGrid/{noMovimiento}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<TotalGrid>> getTotalGrid(
			@PathVariable("noMovimiento") int noMovimiento,
			@PathVariable("tipo") int tipo) {
		
		try {
			return siatEntradasService.getTotalGrid(noMovimiento, tipo);
		} catch (Exception e) {
			ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la validacion de la entrada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * queryGetTotalGrid: obtiene el total para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data total para el grid", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTotalOpcionGrid/{noMovimiento}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<TotalGrid>> getTotalOpcionGrid(
			@PathVariable("noMovimiento") int noMovimiento,
			@PathVariable("tipo") int tipo) {
		
		try {
			return siatEntradasService.getTotalOpcionGrid(noMovimiento, tipo);
		} catch (Exception e) {
			ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la validacion de la entrada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * queryGetRefaccionGrid: obtiene la idrefaccion para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data total para el grid", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRefaccionGrid/{noMovimiento}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<IdRefaccionGrid>> getRefaccionGrid(
			@PathVariable("noMovimiento") int noMovimiento,
			@PathVariable("tipo") int tipo) {
		
		try {
			return siatEntradasService.getRefaccionGrid(noMovimiento, tipo);
		} catch (Exception e) {
			ResponseDTO<List<IdRefaccionGrid>> response = new ResponseDTO<List<IdRefaccionGrid>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la validacion de la entrada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * queryGetRefaccionGrid: obtiene la idrefaccion para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data total para el grid", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCarroceriaGrid/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<IdRefaccionGrid>> getCarroceriaGrid(
			@PathVariable("idRefaccion") String idRefaccion) {
		
		try {
			return siatEntradasService.getCarroceriaGrid(idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<IdRefaccionGrid>> response = new ResponseDTO<List<IdRefaccionGrid>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la validacion de la entrada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * queryGetTipoCambio obtiene el total tipo cambio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-18
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data total para el grid", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTipoCambio/{fecha}")
	@ResponseBody
	public ResponseDTO<List<TipoCambio>> getTipoCambio(
			@PathVariable("fecha") String fecha) {
		
		try {
			return siatEntradasService.getTipoCambio(fecha);
		} catch (Exception e) {
			ResponseDTO<List<TipoCambio>> response = new ResponseDTO<List<TipoCambio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener tipo cambio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getMotivo: obtiene la idrefaccion si es de carroceria
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-18
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con el motivo para el grid", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getMotivo/{idMotivo}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getMotivo(
			@PathVariable("idMotivo") int idMotivo) {
		
		try {
			return siatEntradasService.getMotivo(idMotivo);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener tipo cambio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTipoCambioCarroceria obtiene el total tipo cambio de carroceria
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data total para el grid", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTipoCambioCarroceria")
	@ResponseBody
	public ResponseDTO<List<TipoCambio>> getTipoCambioCarroceria() {
		
		try {
			return siatEntradasService.getTipoCambioCarroceria();
		} catch (Exception e) {
			ResponseDTO<List<TipoCambio>> response = new ResponseDTO<List<TipoCambio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener tipo cambio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getAlmacenTraspaso: obtiene el almacen traspaso
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-20
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con el motivo para el grid", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getAlmacenTraspaso/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<List<AlmacenTranspasosPlazo>> getAlmacenTraspaso(
			@PathVariable("idAlmacen") int idAlmacen) {
		
		try {
			return siatEntradasService.getAlmacenTraspaso(idAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<AlmacenTranspasosPlazo>> response = new ResponseDTO<List<AlmacenTranspasosPlazo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener tipo cambio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getOrdenes: obtiene las ordenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para las ordenes", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getOrdenes/{idOrdenCompra}")
	@ResponseBody
	public ResponseDTO<List<Ordenes>> getOrdenes(
			@PathVariable("idOrdenCompra") int idOrdenCompra) {
		
		try {
			return siatEntradasService.getOrdenes(idOrdenCompra);
		} catch (Exception e) {
			ResponseDTO<List<Ordenes>> response = new ResponseDTO<List<Ordenes>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener ordenes");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getOrdenesAnio: obtiene las ordenes por anio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para las ordenes", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getOrdenesAnio/{anio}/{idOrdenCompra}/{idRequisicion}")
	@ResponseBody
	public ResponseDTO<List<OrdenesAnio>> getOrdenes(
			@PathVariable("anio") int anio,
			@PathVariable("idOrdenCompra") int idOrdenCompra,
			@PathVariable("idRequisicion") int idRequisicion) {
		
		try {
			return siatEntradasService.getOrdenesAnio(anio,idOrdenCompra,idRequisicion);
		} catch (Exception e) {
			ResponseDTO<List<OrdenesAnio>> response = new ResponseDTO<List<OrdenesAnio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar ordenes anio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getOrdenesAnioMoneda: obtiene las ordenes anio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para las ordenes", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getOrdenesAnioMoneda/{anio}/{idOrdenCompra}")
	@ResponseBody
	public ResponseDTO<List<OrdenesAnio>> getOrdenesAnioMoneda(
			@PathVariable("anio") int anio,
			@PathVariable("idOrdenCompra") int idOrdenCompra) {
		
		try {
			return siatEntradasService.getOrdenesAnioMoneda(anio,idOrdenCompra);
		} catch (Exception e) {
			ResponseDTO<List<OrdenesAnio>> response = new ResponseDTO<List<OrdenesAnio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar ordenes anio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRequisicionAnio: obtiene las requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para las requisicion anio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRequisicionAnio/{anio}/{idRequisicion}")
	@ResponseBody
	public ResponseDTO<List<RequisicionAnio>> getRequisicionAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idRequisicion") int idRequisicion) {
		
		try {
			return siatEntradasService.getRequisicionAnio(anio,idRequisicion);
		} catch (Exception e) {
			ResponseDTO<List<RequisicionAnio>> response = new ResponseDTO<List<RequisicionAnio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar ordenes anio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCuerpoDetalle: obtiene el cuerpo detalle de la idrequisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el cuerpo detalle", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCuerpoDetalle/{idRequisicion}")
	@ResponseBody
	public ResponseDTO<List<CuerpoDetalle>> getCuerpoDetalle(
			@PathVariable("idRequisicion") int idRequisicion) {
		
		try {
			return siatEntradasService.getCuerpoDetalle(idRequisicion);
		} catch (Exception e) {
			ResponseDTO<List<CuerpoDetalle>> response = new ResponseDTO<List<CuerpoDetalle>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar ordenes anio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCuerpoDetalleRefaccion: obtiene el cuerpo detalle de la idrequisicion e idrefaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el cuerpo detalle", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCuerpoDetalleRefaccion/{idRequisicion}/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<CuerpoDetalle>> getCuerpoDetalleRefaccion(
			@PathVariable("idRequisicion") int idRequisicion,
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {
			return siatEntradasService.getCuerpoDetalleRefaccion(idRequisicion, idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<CuerpoDetalle>> response = new ResponseDTO<List<CuerpoDetalle>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar ordenes anio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCantidadCuerpoOrden: obtiene la cantidad solicitada del cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-22
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la cantidad solicitada cuerpo orden", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCantidadCuerpoOrden/{anio}/{idOrdenCompra}/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<TotalGrid>> getCantidadCuerpoOrden(
			@PathVariable("anio") int anio,
			@PathVariable("idOrdenCompra") int idOrdenCompra,
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {
			return siatEntradasService.getCantidadCuerpoOrden(anio,idOrdenCompra,idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar ordenes anio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * queryGetTipoCambioDiaCurso obtiene el total tipo cambio del dia curso
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data total para el grid", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTipoCambioDiaCurso/{idMoneda}")
	@ResponseBody
	public ResponseDTO<List<TipoCambio>> getTipoCambioDiacurso(
			@PathVariable("idMoneda") int idMoneda) {
		
		try {
			return siatEntradasService.getTipoCambioDiaCurso(idMoneda);
		} catch (Exception e) {
			ResponseDTO<List<TipoCambio>> response = new ResponseDTO<List<TipoCambio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener tipo cambio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getFacturaOrden: obtiene informacion de la tabla factura orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la factura orden", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getFacturaOrden/{idFacturaOrden}")
	@ResponseBody
	public ResponseDTO<List<FacturaOrden>> getFacturaOrden(
			@PathVariable("idFacturaOrden") int idFacturaOrden) {
		
		try {
			return siatEntradasService.getFacturaOrden(idFacturaOrden);
		} catch (Exception e) {
			ResponseDTO<List<FacturaOrden>> response = new ResponseDTO<List<FacturaOrden>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la factura orden");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getFolioAlmacen: obtiene informacion de la tabla folio almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la factura orden", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getFolioAlmacen/{tipoFolio}/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<List<FolioAlmacen>> getFolioAlmacen(
			@PathVariable("tipoFolio") int tipoFolio,
			@PathVariable("idAlmacen") int idAlmacen) {
		
		try {
			return siatEntradasService.getFolioAlmacen(tipoFolio,idAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<FolioAlmacen>> response = new ResponseDTO<List<FolioAlmacen>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el folio almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getControlTipoCambio: obtiene informacion de proveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para proveedor", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getControlTipoCambio/{idProveedor}")
	@ResponseBody
	public ResponseDTO<List<ControlCambio>> getControlTipoCambio(
			@PathVariable("idProveedor") int idProveedor) {
		
		try {
			return siatEntradasService.getControlTipoCambio(idProveedor);
		} catch (Exception e) {
			ResponseDTO<List<ControlCambio>> response = new ResponseDTO<List<ControlCambio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la factura orden");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCuerpoFactura: obtiene informacion de cuerpo factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para cuerpo factura", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCuerpoFactura/{idFacturaOrden}")
	@ResponseBody
	public ResponseDTO<List<CuerpoFactura>> getCuerpoFactura(
			@PathVariable("idFacturaOrden") int idFacturaOrden) {
		
		try {
			return siatEntradasService.getCuerpoFactura(idFacturaOrden);
		} catch (Exception e) {
			ResponseDTO<List<CuerpoFactura>> response = new ResponseDTO<List<CuerpoFactura>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el cuerpo factura");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getInformacionRefaccion: obtiene informacion de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informaciond de la refaccion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getInformacionRefaccion/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<InformacionRefaccion>> getInformacionRefaccion(
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {
			return siatEntradasService.getInformacionRefaccion(idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<InformacionRefaccion>> response = new ResponseDTO<List<InformacionRefaccion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de la refaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertControlEntrada:inserta registro en control entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-03
	 */
	@ApiOperation(value = "Servicio insertar para insertar control entrada", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "control entrada insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar control entrada") 
			})
	@PostMapping("/insertControlEntrada")
	@ResponseBody
	public ResponseDTO<Boolean> insertControlEntrada(
			@RequestBody ControlEntrada ce) {
		
		try {	
			return siatEntradasService.insertControlEntrada(ce);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar el control entrada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getFolio: obtiene folios siat.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<Folio>>
	 * @throws Exception 
	 * @date 2024-01-03
	 */
	@ApiOperation(value = " Servicio folio siat", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con data para los folios", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getFolio/{tipoFolio}")
	@ResponseBody
	public ResponseDTO<List<Folio>> getFolio(
			@PathVariable("tipoFolio") int tipoFolio) {
		
		try {	
			
			return siatEntradasService.getFolio(tipoFolio);
		} catch (Exception e) {
			ResponseDTO<List<Folio>> response = new ResponseDTO<List<Folio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el folio siat");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertFolio:inserta registro en folios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-03
	 */
	@ApiOperation(value = "Servicio insertar para insertar folio", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Folio insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar Folio") 
			})
	@PostMapping("/createFolio/{tipoFolio}")
	@ResponseBody
	public ResponseDTO<Boolean> createFolio(
			@RequestBody Folio folio,
			@PathVariable("tipoFolio") int tipoFolio) {
		
		try {	
			return siatEntradasService.createFolio(folio, tipoFolio);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar Folio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertFolioAlmacen:inserta registro en folios almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	@ApiOperation(value = "Servicio insertar para insertar folio almacen", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Folio almacen insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar Folio Almacen") 
			})
	@PostMapping("/createFolioAlmacen/{tipoFolio}/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<Boolean> createFolioAlmacen(
			@RequestBody FolioAlmacen folio,
			@PathVariable("tipoFolio") int tipoFolio,
			@PathVariable("idAlmacen") int idAlmacen) {
		
		try {	
			return siatEntradasService.createFolioAlmacen(folio, tipoFolio, idAlmacen);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar Folio Almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRefaProveedor : obtiene informacion del proveedor de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informaciond de la refaccion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRefaProveedor/{idProveedor}/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<TotalGrid>> getRefaProveedor(
			@PathVariable("idProveedor") int idProveedor,
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {
			return siatEntradasService.getRefaProveedor(idProveedor, idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion del proveedor refaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getValorParamGen : obtiene informacion de la variable general
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informaciond de la refaccion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getValorParamGen/{idParametro}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getValorParamGen(
			@PathVariable("idParametro") int idParametro) {
		
		try {
			return siatEntradasService.getValorParamGen(idParametro);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el valor de la variable global");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getValorParametros : obtiene informacion de la variable 
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de la variable siat", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getValorParametros/{idParametro}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getValorParametros(
			@PathVariable("idParametro") int idParametro) {
		
		try {
			return siatEntradasService.getValorParametros(idParametro);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el valor de la variable siat");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getValorParametrosNombre : obtiene informacion de la variable 
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de la variable siat", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getValorParametrosNombre/{idParametro}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getValorParametrosNombre(
			@PathVariable("idParametro") int idParametro) {
		
		try {
			return siatEntradasService.getValorParametrosNombre(idParametro);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el valor de la variable siat");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTipoSolicitud : obtiene informacion de tipo solicitud de la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-08
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion del tipo solicitud de la requisicion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTipoSolicitud/{idRequisicion}")
	@ResponseBody
	public ResponseDTO<List<TipoSolicitud>> getTipoSolicitud(
			@PathVariable("idRequisicion") int idRequisicion) {
		
		try {
			return siatEntradasService.getTipoSolicitud(idRequisicion);
		} catch (Exception e) {
			ResponseDTO<List<TipoSolicitud>> response = new ResponseDTO<List<TipoSolicitud>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion del tipo solicitud de la requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getNombreMoneda: obtiene informacion del nombre de la moneda
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-08
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion del nombre de la moneda", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getNombreMoneda/{idMoneda}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getNombreMoneda(
			@PathVariable("idMoneda") int idMoneda) {
		
		try {
			return siatEntradasService.getNombreMoneda(idMoneda);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion del nombre de la moneda");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCantidadesEntradas: obtiene informacion de las cantidades entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-08
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de las cantidades entradas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCantidadesEntradas/{anio}/{idOrdenCompra}")
	@ResponseBody
	public ResponseDTO<List<CantidadesEntradas>> getCantidadesEntradas(
			@PathVariable("anio") int anio,
			@PathVariable("idOrdenCompra") int idOrdenCompra) {
		
		try {
			return siatEntradasService.getCantidadesEntradas(anio, idOrdenCompra);
		} catch (Exception e) {
			ResponseDTO<List<CantidadesEntradas>> response = new ResponseDTO<List<CantidadesEntradas>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la cantidad de entradas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getProveedor: obtiene los datos del proveedor
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-18
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con los datos del proveedor", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getProveedor/{idProveedor}")
	@ResponseBody
	public ResponseDTO<List<GetProveedor>> getProveedor(
			@PathVariable("idProveedor") int idProveedor) {
		
		try {
			return siatEntradasService.getProveedor(idProveedor);
		} catch (Exception e) {
			ResponseDTO<List<GetProveedor>> response = new ResponseDTO<List<GetProveedor>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la información del proveedor");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteControlEntrada:delete registro en controlentrada
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2023-09-25
	 */
	@ApiOperation(value = "Servicio para la eliminacion del registro temporal de la tabla controlentrada", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminación del registro de la tabla temporal controlentrada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar el registro de la tabla controlentrada") 
			})
	@PostMapping("/deleteControlEntrada/{folioControl}/{idPersonal}")
	@ResponseBody
	public ResponseDTO<Boolean> deleteCuerpoDetalle(
			@PathVariable("folioControl") String folioControl,
			@PathVariable("idPersonal") int idPersonal) {
		
		try {	
			return siatEntradasService.deleteControlEntrada(folioControl, idPersonal);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar el registro de la tabla controlentrada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTipoAutorizacion: obtiene informacion de las cantidades entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-16
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con los datos del tipo autorizacion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTipoAutorizacion/{idTipoAutorizacion}")
	@ResponseBody
	public ResponseDTO<List<TipoAutorizaciones>> getTipoAutorizacion(
			@PathVariable("idTipoAutorizacion") int idTipoAutorizacion) {
		
		try {
			return siatEntradasService.getTipoAutorizacion(idTipoAutorizacion);
		} catch (Exception e) {
			ResponseDTO<List<TipoAutorizaciones>> response = new ResponseDTO<List<TipoAutorizaciones>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el tipo autorizacion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertEntradas:inserta registro en entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	@ApiOperation(value = "Servicio insertar para insertar entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "entradas insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar entradas") 
			})
	@PostMapping("/createEntradas")
	@ResponseBody
	public ResponseDTO<Boolean> createRequisicion(
			@RequestBody Entradas entradas) {
		
		try {	
			return siatEntradasService.createEntradas(entradas);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar entradas");
			response.setData(null);
			return response;
		}
	}

	/**
	 * getControlIncrementoMaquila: obtiene informacion del incremento maquila
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-16
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion del incremento maquila", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getControlIncrementoMaquila")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getControlIncrementoMaquila() {
		
		try {
			return siatEntradasService.getControlIncrementoMaquila();
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion del incremento de maquila");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getConvenioRefaccion: obtiene informacion del convenio de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-17
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion del convenio de la refaccion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getConvenioRefaccion/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getConvenioRefaccion(
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {
			return siatEntradasService.getConvenioRefaccion(idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion el convenio de la refaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getConvenioRefaccionDetallado: obtiene informacion del convenio de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-17
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion del convenio de la refaccion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getConvenioRefaccionDetallado/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<ConvenioRefaccion>> getConvenioRefaccionDetallado(
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {
			return siatEntradasService.getConvenioRefaccionDetallado(idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<ConvenioRefaccion>> response = new ResponseDTO<List<ConvenioRefaccion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion el convenio de la refaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertEntradasAño:inserta registro en entradas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	@ApiOperation(value = "Servicio insertar para insertar entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "entradas insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar entradas") 
			})
	@PostMapping("/createEntradasAnio/{anio}")
	@ResponseBody
	public ResponseDTO<Boolean> createEntradasAnio(
			@PathVariable("anio") int anio,
			@RequestBody EntradasAnio entradas) {
		
		try {	
			return siatEntradasService.createEntradasAnio(anio, entradas);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar entradas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createLotes:inserta registro en lotes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	@ApiOperation(value = "Servicio insertar para insertar entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "lote insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar lotes") 
			})
	@PostMapping("/createLotes")
	@ResponseBody
	public ResponseDTO<Boolean> createLotes(
			@RequestBody Lotes lotes) {
		
		try {	
			return siatEntradasService.createLotes(lotes);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar lotes");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createKardex:inserta registro en kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	@ApiOperation(value = "Servicio insertar para insertar entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Kardex insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar kardex") 
			})
	@PostMapping("/createKardex")
	@ResponseBody
	public ResponseDTO<Boolean> createKardex(
			@RequestBody Kardex kardex) {
		
		try {	
			return siatEntradasService.createKardex(kardex);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar kardex");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getEsFactura: obtiene informacion si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion si es factura", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getEsFactura/{idFacturaOrden}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getEsFactura(
			@PathVariable("idFacturaOrden") int idFacturaOrden) {
		
		try {
			return siatEntradasService.getEsFactura(idFacturaOrden);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion si es factura");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getImporteFactura: obtiene informacion del importe si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion del importe de la factura", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getImporteFactura/{anio}/{idEntrada}/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<List<Importe>> getImporteFactura(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("idAlmacen") int idAlmacen){
		
		try {
			return siatEntradasService.getImporteFactura(anio, idEntrada, idAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<Importe>> response = new ResponseDTO<List<Importe>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion del importe de la factura");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getImporteRemision: obtiene informacion del importe si es remision
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion del importe de la remision", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getImporteRemision/{anio}/{idEntrada}/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<List<Importe>> getImporteRemision(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("idAlmacen") int idAlmacen){
		
		try {
			return siatEntradasService.getImporteRemision(anio, idEntrada, idAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<Importe>> response = new ResponseDTO<List<Importe>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion del importe de la remision");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getMaxLotes: obtiene informacion del max idlote
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion del convenio de la refaccion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getMaxLotes")
	@ResponseBody
	public ResponseDTO<List<ValidacionEntrada>> getMaxLotes() {
		
		try {
			return siatEntradasService.getMaxLotes();
		} catch (Exception e) {
			ResponseDTO<List<ValidacionEntrada>> response = new ResponseDTO<List<ValidacionEntrada>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion el convenio de la refaccion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * createDetalleEntrada:inserta registro en detalle entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	@ApiOperation(value = "Servicio insertar para insertar entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Kardex insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar detalle entrada") 
			})
	@PostMapping("/createDetalleEntrada")
	@ResponseBody
	public ResponseDTO<Boolean> createDetalleEntrada(
			@RequestBody DetalleEntrada de) {
		
		try {	
			return siatEntradasService.createDetalleEntrada(de);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar detalle entrada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getInfRefaproveedor: obtiene informacion de Refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de refaproveedor", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getInfRefaproveedor/{idRefaccion}/{idProveedor}")
	@ResponseBody
	public ResponseDTO<List<Refaproveedor>> getInfRefaproveedor(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idProveedor") int idProveedor){
		
		try {
			return siatEntradasService.getInfRefaproveedor(idRefaccion, idProveedor);
		} catch (Exception e) {
			ResponseDTO<List<Refaproveedor>> response = new ResponseDTO<List<Refaproveedor>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de refaproveedor");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRefPorAlmacen: obtiene informacion de refaccion por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de refaccion por almacen", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRefPorAlmacen/{idRefaccion}/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<List<RefPorAlmacen>> getRefPorAlmacen(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idAlmacen") int idAlmacen){
		
		try {
			return siatEntradasService.getRefPorAlmacen(idRefaccion, idAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<RefPorAlmacen>> response = new ResponseDTO<List<RefPorAlmacen>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de refaccion por almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getConvenioInf: obtiene informacion de convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de refaccion por almacen", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getConvenioInf/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<ConvenioInf>> getConvenioInf(
			@PathVariable("idRefaccion") int idRefaccion){
		
		try {
			return siatEntradasService.getConvenioInf(idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<ConvenioInf>> response = new ResponseDTO<List<ConvenioInf>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de refaccion por almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRefaProveedor:actualiza registro en refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	@ApiOperation(value = "Servicio insertar para actualizar refaproveedor", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Refaproveedor actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar refaproveedor") 
			})
	@PostMapping("/updateRefaProveedor/{idRefaccion}/{idProveedor}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRefaProveedor(
			@RequestBody Refaproveedor rp,
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idProveedor") int idProveedor) {
		
		try {	
			return siatEntradasService.updateRefaProveedor(rp,idRefaccion, idProveedor);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar refaproveedor");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRefaPorAlmacen:actualiza registro en refaccion_por_almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	
	@ApiOperation(value = "Servicio insertar para actualizar refaccion_por_almacen", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "refaccion_por_almacen actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar refaccion_por_almacen") 
			})
	@PostMapping("/updateRefaPorAlmacen/{idRefaccion}/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRefaPorAlmacen(
			@RequestBody RefPorAlmacen rp,
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idAlmacen") int idAlmacen) {
		
		try {	
			return siatEntradasService.updateRefaPorAlmacen(rp,idRefaccion, idAlmacen);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar refaccion_por_almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRefacciones:actualiza registro en refacciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@ApiOperation(value = "Servicio insertar para actualizar refacciones", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "refacciones actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar refacciones") 
			})
	@PostMapping("/updateRefacciones/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRefacciones(
			@RequestBody UpdateRefacciones ur,
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {	
			return siatEntradasService.updateRefacciones(ur, idRefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar refacciones");
			response.setData(null);
			return response;
		}
	}

	/**
	 * updateCuerpoConvenio:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	
	@ApiOperation(value = "Servicio insertar para actualizar refacciones", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cuerpo convenio actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar cuerpo convenio") 
			})
	@PostMapping("/updateCuerpoConvenio/{idRefaccion}/{idConvenio}/{pcmn}")
	@ResponseBody
	public ResponseDTO<Boolean> updateCuerpoConvenio(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idConvenio") int idConvenio,
			@PathVariable("pcmn") Double pcmn) {
		
		try {	
			return siatEntradasService.updateCuerpoConvenio(idRefaccion, idConvenio, pcmn);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar cuerpo convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateFacturasOrden:actualiza registro en facturas orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@ApiOperation(value = "Servicio insertar para actualizar facturas orden", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "facturas orden actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar facturas orden") 
			})
	@PostMapping("/updateFacturasOrden/{idFacturaOrden}/{idEstatus}")
	@ResponseBody
	public ResponseDTO<Boolean> updateFacturasOrden(
			@PathVariable("idFacturaOrden") int idFacturaOrden,
			@PathVariable("idEstatus") int idEstatus) {
		
		try {	
			return siatEntradasService.updateFacturasOrden(idFacturaOrden, idEstatus);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar facturas orden");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCuerpoOrdenAnio: obtiene informacion de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-24
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de cuerpo orden", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCuerpoOrdenAnio/{anio}/{idRefaccion}/{idOrdenCompra}")
	@ResponseBody
	public ResponseDTO<List<CuerpoOrden>> getCuerpoOrdenAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idOrdenCompra") int idOrdenCompra){
		
		try {
			return siatEntradasService.getCuerpoOrdenAnio(anio, idRefaccion, idOrdenCompra);
		} catch (Exception e) {
			ResponseDTO<List<CuerpoOrden>> response = new ResponseDTO<List<CuerpoOrden>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de cuerpo orden");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCuerpoOrden: obtiene informacion de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-24
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de cuerpo orden", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCuerpoOrden/{anio}/{idOrdenCompra}")
	@ResponseBody
	public ResponseDTO<List<CuerpoOrden>> getCuerpoOrden(
			@PathVariable("anio") int anio,
			@PathVariable("idOrdenCompra") int idOrdenCompra){
		
		try {
			return siatEntradasService.getCuerpoOrden(anio, idOrdenCompra);
		} catch (Exception e) {
			ResponseDTO<List<CuerpoOrden>> response = new ResponseDTO<List<CuerpoOrden>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de cuerpo orden");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateCuerpoOrdenAnio:actualiza registro de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	@ApiOperation(value = "Servicio insertar para actualizar cuerpo orden", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "facturas orden actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar cuerpo orden") 
			})
	@PostMapping("/updateCuerpoOrdenAnio/{anio}/{idRefaccion}/{idOrdenCompra}")
	@ResponseBody
	public ResponseDTO<Boolean> updateCuerpoOrdenAnio(
			@RequestBody CuerpoOrden co,
			@PathVariable("anio") int anio,
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idOrdenCompra") int idOrdenCompra) {
		
		try {	
			return siatEntradasService.updateCuerpoOrdenAnio(co,anio,idRefaccion,idOrdenCompra);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar cuerpo orden");
			response.setData(null);
			return response;
		}
	}
	
	
	/**
	 * updateCuerpoOrdenAnio:actualiza registro de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	@ApiOperation(value = "Servicio insertar para actualizar cuerpo orden", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "orden actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar cuerpo orden") 
			})
	@PostMapping("/updateOrdenCompraAnio/{anio}/{idRequisicion}/{idOrdenCompra}")
	@ResponseBody
	public ResponseDTO<Boolean> updateOrdenCompraAnio(
			@RequestBody OrdenesAnio co,
			@PathVariable("anio") int anio,
			@PathVariable("idRequisicion") int idRequisicion,
			@PathVariable("idOrdenCompra") int idOrdenCompra) {
		
		try {	
			return siatEntradasService.updateOrdenCompraAnio(co, anio,idRequisicion, idOrdenCompra);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar cuerpo orden");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateOrdenes:actualiza registro de ordenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	@ApiOperation(value = "Servicio insertar para actualizar orden", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Orden actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar orden") 
			})
	@PostMapping("/updateOrdenes/{idOrdenCompra}/{idEstatus}")
	@ResponseBody
	public ResponseDTO<Boolean> updateOrdenes(
			@PathVariable("idOrdenCompra") int idOrdenCompra,
			@PathVariable("idEstatus") int idEstatus) {
		
		try {	
			return siatEntradasService.updateOrdenes(idOrdenCompra, idEstatus);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar orden");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateCuerpoRequisicionAnio:actualiza registro de cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@ApiOperation(value = "Servicio insertar para actualizar cuerpo requisicion", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cuerpo requisicion actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar cuerpo requisicion") 
			})
	@PostMapping("/updateCuerpoRequisicionAnio/{anio}/{idRequisicion}/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateCuerpoRequisicionAnio(
			@RequestBody CuerpoRequisicionAnio cr,
			@PathVariable("anio") int anio,
			@PathVariable("idRequisicion") int idRequisicion,
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {	
			return siatEntradasService.updateCuerpoRequisicionAnio(cr, anio,idRequisicion, idRefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar cuerpo requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCuerpoRequisicionAnio: obtiene informacion de cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-25
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de cuerpo requisicion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCuerpoRequisicionAnio/{anio}/{idRequisicion}/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<CuerpoRequisicionAnio>> getCuerpoRequisicionAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idRequisicion") int idRequisicion,
			@PathVariable("idRefaccion") int idRefaccion){
		
		try {
			return siatEntradasService.getCuerpoRequisicionAnio(anio, idRequisicion, idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<CuerpoRequisicionAnio>> response = new ResponseDTO<List<CuerpoRequisicionAnio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de cuerpo requisicion");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRequisicionAnio:actualiza registro de requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@ApiOperation(value = "Servicio insertar para actualizar requisicion año", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Requisicion año actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar requisicion año") 
			})
	@PostMapping("/updateRequisicionAnio/{anio}/{idRequisicion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateRequisicionAnio(
			@RequestBody RequisicionAnio ra,
			@PathVariable("anio") int anio,
			@PathVariable("idRequisicion") int idRequisicion) {
		
		try {	
			return siatEntradasService.updateRequisicionAnio(ra, anio,idRequisicion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar requisicion año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertRequisicionHistorico:inserta registro de requisicion historico
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@ApiOperation(value = "Servicio insertar requisicion historico", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Requisicion historico insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar requisicion historico") 
			})
	@PostMapping("/insertRequisicionHistorico")
	@ResponseBody
	public ResponseDTO<Boolean> insertRequisicionHistorico(
			@RequestBody RequisicionHistorico requisicionHistorico) {
		
		try {	
			return siatEntradasService.insertRequisicionHistorico(requisicionHistorico);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar requisicion historico");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateCuerpoDetalle:actualiza registro de cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@ApiOperation(value = "Servicio insertar para actualizar cuerpo detalle", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cuerpo detalle actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar cuerpo detalle") 
			})
	@PostMapping("/updateCuerpoDetalle/{idRequisicion}/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateCuerpoDetalle(
			@RequestBody CuerpoDetalle cr,
			@PathVariable("idRequisicion") int idRequisicion,
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {	
			return siatEntradasService.updateCuerpoDetalle(cr, idRequisicion, idRefaccion);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar cuerpo detalle");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertAutorizaciones:inserta registro en autorizaciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	@ApiOperation(value = "Servicio insertar para autorizaciones", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Autorizaciones insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar Autorizaciones") 
			})
	@PostMapping("/insertAutorizaciones")
	@ResponseBody
	public ResponseDTO<Boolean> insertAutorizaciones(
			@RequestBody Autorizaciones autorizaciones) {
		
		try {	
			return siatEntradasService.insertAutorizaciones(autorizaciones);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar Autorizaciones");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateCuerpoConvenioSaldo:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	
	@ApiOperation(value = "Servicio insertar para actualizar refacciones", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cuerpo convenio actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar cuerpo convenio") 
			})
	@PostMapping("/updateCuerpoConvenioSaldo/{idRefaccion}/{idConvenio}/{saldo}")
	@ResponseBody
	public ResponseDTO<Boolean> updateCuerpoConvenioSaldo(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idConvenio") int idConvenio,
			@PathVariable("saldo") Double saldo) {
		
		try {	
			return siatEntradasService.updateCuerpoConvenioSaldo(idRefaccion, idConvenio, saldo);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar cuerpo convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getInfoconvenio: obtiene informacion de convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-25
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getInfoconvenio/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getInfoconvenio(
			@PathVariable("idRefaccion") int idRefaccion){
		
		try {
			return siatEntradasService.getInfoconvenio( idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getBancoProveedor: obtiene informacion de banco proveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de banco proveedor", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getBancoProveedor/{idProveedor}")
	@ResponseBody
	public ResponseDTO<List<BancoProveedor>> getBancoProveedor(
			@PathVariable("idProveedor") int idProveedor){
		
		try {
			return siatEntradasService.getBancoProveedor(idProveedor);
		} catch (Exception e) {
			ResponseDTO<List<BancoProveedor>> response = new ResponseDTO<List<BancoProveedor>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de banco proveedor");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getContraRecibo: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de ContraRecibos", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getContraRecibo")
	@ResponseBody
	public ResponseDTO<List<ContraRecibos>> getContraRecibo(){
		
		try {
			return siatEntradasService.getContraRecibo();
		} catch (Exception e) {
			ResponseDTO<List<ContraRecibos>> response = new ResponseDTO<List<ContraRecibos>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de ContraRecibos");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertContraRecibo:inserta registro en contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	@ApiOperation(value = "Servicio insertar para Contra Recibos", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Contra Recibos insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar Contra Recibos") 
			})
	@PostMapping("/insertContraRecibo")
	@ResponseBody
	public ResponseDTO<Boolean> insertContraRecibo(
			@RequestBody ContraRecibosInfo contraRecibo) {
		
		try {	
			return siatEntradasService.insertContraRecibo(contraRecibo);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar Contra Recibos");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getContraReciboInfo: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de ContraRecibos", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getContraReciboInfo/{idContraRecibo}")
	@ResponseBody
	public ResponseDTO<List<ContraRecibosInfo>> getContraReciboInfo(
			@PathVariable("idContraRecibo") int idContraRecibo){
		
		try {
			return siatEntradasService.getContraReciboInfo(idContraRecibo);
		} catch (Exception e) {
			ResponseDTO<List<ContraRecibosInfo>> response = new ResponseDTO<List<ContraRecibosInfo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de ContraRecibos");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getContraReciboFact: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de ContraRecibos", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getContraReciboFact/{idFacturaOrden}")
	@ResponseBody
	public ResponseDTO<List<ContraRecibosInfo>> getContraReciboFact(
			@PathVariable("idFacturaOrden") int idFacturaOrden){
		
		try {
			return siatEntradasService.getContraReciboFact(idFacturaOrden);
		} catch (Exception e) {
			ResponseDTO<List<ContraRecibosInfo>> response = new ResponseDTO<List<ContraRecibosInfo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de ContraRecibos");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRptContraReciboFact : String: obtiene reporte de contra recibo con factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el reporte de ContraRecibos", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRptContraReciboFact/{coidFacturaOrden}")
	@ResponseBody
	public ResponseDTO<List<RptContraRecibo>> getRptContraReciboFact(
			@PathVariable("coidFacturaOrden") int coidFacturaOrden){
		
		try {
			return siatEntradasService.getRptContraReciboFact(coidFacturaOrden);
		} catch (Exception e) {
			ResponseDTO<List<RptContraRecibo>> response = new ResponseDTO<List<RptContraRecibo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el reporte de ContraRecibos");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRptContraReciboFact : String: obtiene reporte de contra recibo con factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el reporte de ContraRecibos", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRptContraRecibo/{idContraRecibo}")
	@ResponseBody
	public ResponseDTO<List<RptContraRecibo>> getRptContraRecibo(
			@PathVariable("idContraRecibo") int idContraRecibo){
		
		try {
			return siatEntradasService.getRptContraRecibo(idContraRecibo);
		} catch (Exception e) {
			ResponseDTO<List<RptContraRecibo>> response = new ResponseDTO<List<RptContraRecibo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el reporte de ContraRecibos");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getEntradas : String: obtiene informacion de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de entradas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getEntradas/{idEntrada}/{tipoEntrada}")
	@ResponseBody
	public ResponseDTO<List<Entradas>> getEntradas(
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("tipoEntrada") int tipoEntrada){
		
		try {
			return siatEntradasService.getEntradas(idEntrada, tipoEntrada);
		} catch (Exception e) {
			ResponseDTO<List<Entradas>> response = new ResponseDTO<List<Entradas>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de entradas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getValoresEntradas : String: obtiene valores de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de entradas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getValoresEntradas/{anio}/{idEntrada}/{tipoEntrada}")
	@ResponseBody
	public ResponseDTO<List<EntradasInfo>> getValoresEntradas(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("tipoEntrada") int tipoEntrada){
		
		try {
			return siatEntradasService.getValoresEntradas(anio, idEntrada, tipoEntrada);
		} catch (Exception e) {
			ResponseDTO<List<EntradasInfo>> response = new ResponseDTO<List<EntradasInfo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de entradas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getFacturasOrdenInfo: String: obtiene valores de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de facturas orden", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getFacturasOrdenInfo/{idOrdenCompra}/{idFacturaOrden}")
	@ResponseBody
	public ResponseDTO<List<FacturaOrden>> getFacturasOrdenInfo(
			@PathVariable("idOrdenCompra") int idOrdenCompra,
			@PathVariable("idFacturaOrden") int idFacturaOrden){
		
		try {
			return siatEntradasService.getFacturasOrdenInfo(idOrdenCompra, idFacturaOrden);
		} catch (Exception e) {
			ResponseDTO<List<FacturaOrden>> response = new ResponseDTO<List<FacturaOrden>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de facturas orden");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getEntradasAnio : String: obtiene informacion de entradas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de entradas año", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getEntradasAnio/{anio}/{idEntrada}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<EntradasAnio>> getEntradasAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("tipo") int tipo){
		
		try {
			return siatEntradasService.getEntradasAnio(anio, idEntrada, tipo);
		} catch (Exception e) {
			ResponseDTO<List<EntradasAnio>> response = new ResponseDTO<List<EntradasAnio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de entradas año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getKardex: String: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de entradas año", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getKardex/{tipoMovimiento}/{noMovimiento}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<Kardex>> getKardex(
			@PathVariable("tipoMovimiento") int tipoMovimiento,
			@PathVariable("noMovimiento") int noMovimiento,
			@PathVariable("tipo") int tipo){
		
		try {
			return siatEntradasService.getKardex(tipoMovimiento, noMovimiento, tipo);
		} catch (Exception e) {
			ResponseDTO<List<Kardex>> response = new ResponseDTO<List<Kardex>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de entradas año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getKardexPrecio: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de entradas año", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getKardexPrecio/{idRefaccion}/{noMovimiento}")
	@ResponseBody
	public ResponseDTO<List<Kardex>> getKardexPrecio(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("noMovimiento") int noMovimiento){
		
		try {
			return siatEntradasService.getKardexPrecio(idRefaccion, noMovimiento);
		} catch (Exception e) {
			ResponseDTO<List<Kardex>> response = new ResponseDTO<List<Kardex>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de entradas año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteTempoliza: Elimina informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@ApiOperation(value = "Servicio eliminar para Tempoliza", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Tempoliza eliminado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar Tempoliza") 
			})
	@PostMapping("/deleteTempoliza")
	@ResponseBody
	public ResponseDTO<Boolean> deleteTempoliza() {
		
		try {	
			return siatEntradasService.deleteTempoliza();
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar Tempoliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTempolizaInser: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de entradas año", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTempolizaInsert/{param1}/{param2}/{tipoMovimiento}/{noMovimiento}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<Tempoliza>> getTempolizaInsert(
			@PathVariable("param1") String param1,
			@PathVariable("param2") String param2,
			@PathVariable("tipoMovimiento") int tipoMovimiento,
			@PathVariable("noMovimiento") int noMovimiento,
			@PathVariable("tipo") int tipo){
		
		try {
			return siatEntradasService.getTempolizaInsert(param1, param2,tipoMovimiento, noMovimiento, tipo);
		} catch (Exception e) {
			ResponseDTO<List<Tempoliza>> response = new ResponseDTO<List<Tempoliza>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de entradas año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTempolizaInser: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de entradas año", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTempolizaInsert2/{idEntrada}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<Tempoliza>> getTempolizaInsert2(
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("tipo") int tipo){
		
		try {
			return siatEntradasService.getTempolizaInsert2(idEntrada,  tipo);
		} catch (Exception e) {
			ResponseDTO<List<Tempoliza>> response = new ResponseDTO<List<Tempoliza>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de entradas año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertTempoliza:inserta registro en tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-02
	 */
	@ApiOperation(value = "Servicio insertar para Tempoliza", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Tempoliza insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar Tempoliza") 
			})
	@PostMapping("/insertTempoliza")
	@ResponseBody
	public ResponseDTO<Boolean> insertTempoliza(
			@RequestBody Tempoliza tempoliza) {
		
		try {	
			return siatEntradasService.insertTempoliza(tempoliza);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar tempoliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getIva: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de iva", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getIva/{idIva}")
	@ResponseBody
	public ResponseDTO<List<Iva>> getIva(
			@PathVariable("idIva") int idIva){
		
		try {
			return siatEntradasService.getIva(idIva);
		} catch (Exception e) {
			ResponseDTO<List<Iva>> response = new ResponseDTO<List<Iva>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de iva");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTempoliza: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de tempoliza", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTempoliza")
	@ResponseBody
	public ResponseDTO<List<Tempoliza>> getTempoliza(){
		
		try {
			return siatEntradasService.getTempoliza();
		} catch (Exception e) {
			ResponseDTO<List<Tempoliza>> response = new ResponseDTO<List<Tempoliza>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de tempoliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTraspasosGrupos: obtiene informacion de traspasos grupos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de traspasos grupos", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTraspasosGrupos/{idRefaccion}/{fecha}/{hora}")
	@ResponseBody
	public ResponseDTO<List<TraspasosGrupos>> getTraspasosGrupos(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("fecha") String fecha,
			@PathVariable("hora") String hora){
		
		try {
			return siatEntradasService.getTraspasosGrupos(idRefaccion,fecha,hora);
		} catch (Exception e) {
			ResponseDTO<List<TraspasosGrupos>> response = new ResponseDTO<List<TraspasosGrupos>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de traspasos grupos");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGruposAlmacen: obtiene informacion de grupos almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de grupos almacen", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGruposAlmacen/{idGrupo}/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getGruposAlmacen(
			@PathVariable("idGrupo") int idGrupo,
			@PathVariable("idAlmacen") int idAlmacen){
		
		try {
			return siatEntradasService.getGruposAlmacen(idGrupo,idAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de grupos almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateTempoliza :actualiza registro de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-02
	 */
	@ApiOperation(value = "Servicio actualizar para Tempoliza", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Tempoliza actualizada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar Tempoliza") 
			})
	@PostMapping("/updateTempoliza/{idRefaccion}/{fecha}/{hora}")
	@ResponseBody
	public ResponseDTO<Boolean> updateTempoliza(
			@RequestBody Tempoliza tempoliza,
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("fecha") String fecha,
			@PathVariable("hora") String hora) {
		
		try {	
			return siatEntradasService.updateTempoliza(tempoliza,idRefaccion,fecha,hora);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar tempoliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTempoliza: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de tempoliza", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTempolizaRefaccion")
	@ResponseBody
	public ResponseDTO<List<TempolizaRefaccion>> getTempolizaRefaccion(){
		
		try {
			return siatEntradasService.getTempolizaRefaccion();
		} catch (Exception e) {
			ResponseDTO<List<TempolizaRefaccion>> response = new ResponseDTO<List<TempolizaRefaccion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de tempoliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGruposAlmacen: obtiene informacion de kardex y refacciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de kardex y refacciones", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getKardexRefacciones/{noMovimiento}/{tipo}/{idGrupo}")
	@ResponseBody
	public ResponseDTO<List<KardexRefacciones>> getKardexRefacciones(
			@PathVariable("noMovimiento") String noMovimiento,
			@PathVariable("tipo") int tipo,
			@PathVariable("idGrupo") int idGrupo){
		
		try {
			return siatEntradasService.getKardexRefacciones(noMovimiento,tipo,idGrupo);
		} catch (Exception e) {
			ResponseDTO<List<KardexRefacciones>> response = new ResponseDTO<List<KardexRefacciones>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de kardex y refacciones");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getKardexMovimiento: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de kardex", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getKardexMovimiento/{idRefaccion}/{fecha}/{hora}")
	@ResponseBody
	public ResponseDTO<List<KardexMovimiento>> getKardexMovimiento(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("fecha") String fecha,
			@PathVariable("hora") String hora){
		
		try {
			return siatEntradasService.getKardexMovimiento(idRefaccion,fecha,hora);
		} catch (Exception e) {
			ResponseDTO<List<KardexMovimiento>> response = new ResponseDTO<List<KardexMovimiento>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de kardex ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getAlmacenes: obtiene informacion de almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de almacen", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getAlmacenes")
	@ResponseBody
	public ResponseDTO<List<Almacen>> getAlmacenes(){
		
		try {
			return siatEntradasService.getAlmacenes();
		} catch (Exception e) {
			ResponseDTO<List<Almacen>> response = new ResponseDTO<List<Almacen>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de almacen");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getSumCantKardex: obtiene suma de la cantidad de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de la suma de kardex", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getSumCantKardex/{idRefaccion}/{fecha}/{hora}/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<List<TotalGrid>> getSumCantKardex(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("fecha") String fecha,
			@PathVariable("hora") String hora,
			@PathVariable("idAlmacen") int idAlmacen){
		
		try {
			return siatEntradasService.getSumCantKardex(idRefaccion,fecha,hora,idAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<TotalGrid>> response = new ResponseDTO<List<TotalGrid>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de la suma de kardex ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getFacturaOrdenAnticipo: obtiene informacion de la tabla factura orden anticipo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la factura orden", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getFacturaOrdenAnticipo/{idFacturaOrden}")
	@ResponseBody
	public ResponseDTO<List<FacturaOrdenAnticipo>> getFacturaOrdenAnticipo(
			@PathVariable("idFacturaOrden") int idFacturaOrden) {
		
		try {
			return siatEntradasService.getFacturaOrdenAnticipo(idFacturaOrden);
		} catch (Exception e) {
			ResponseDTO<List<FacturaOrdenAnticipo>> response = new ResponseDTO<List<FacturaOrdenAnticipo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la factura orden");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getIdPoliza: obtiene informacion de la tabla poliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-07
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la id poliza", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getIdPoliza/{tabla}/{numPoliza}/{idTipoPol}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getIdPoliza(
			@PathVariable("tabla") int tabla,
			@PathVariable("numPoliza") int numPoliza,
			@PathVariable("idTipoPol") int idTipoPol) {
		
		try {
			return siatEntradasService.getIdPoliza(tabla,numPoliza,idTipoPol);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la id poliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getMaxPoliza: obtiene informacion de la tabla poliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-07
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el max polizan", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getMaxPoliza/{tabla}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getMaxPoliza(
			@PathVariable("tabla") int tabla) {
		
		try {
			return siatEntradasService.getMaxPoliza(tabla);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el max poliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertPolizaAnio:inserta registro en poliza año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@ApiOperation(value = "Servicio insertar para Tempoliza", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Tempoliza insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar Tempoliza") 
			})
	@PostMapping("/insertPolizaAnio/{anio}")
	@ResponseBody
	public ResponseDTO<Boolean> insertPolizaAnio(
			@PathVariable("anio") int anio,
			@RequestBody PolizasAnio poliza) {
		
		try {	
			return siatEntradasService.insertPolizaAnio(anio,poliza);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar tempoliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertPoliza:inserta registro en polizas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@ApiOperation(value = "Servicio insertar para Tempoliza", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Tempoliza insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar Tempoliza") 
			})
	@PostMapping("/insertPoliza")
	@ResponseBody
	public ResponseDTO<Boolean> insertPoliza(
			@RequestBody Polizas poliza) {
		
		try {	
			return siatEntradasService.insertPoliza(poliza);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar tempoliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertMovimientos:inserta registro en movimientos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@ApiOperation(value = "Servicio insertar para Movimientos", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Movimientos insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar movimientos") 
			})
	@PostMapping("/insertMovimientos/{anio}")
	@ResponseBody
	public ResponseDTO<Boolean> insertMovimientos(
			@PathVariable("anio") int anio,
			@RequestBody Movimientos movimientos) {
		
		try {	
			return siatEntradasService.insertMovimientos(anio,movimientos);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar Movimientos");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertPoliza:inserta registro en polizas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@ApiOperation(value = "Servicio actualizar para catcuentas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "catcuentas actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar catcuentas") 
			})
	@PostMapping("/updateCatcuentasAnio/{anio}/{mes}/{idCuenta}/{importe}")
	@ResponseBody
	public ResponseDTO<Boolean> updateCatcuentasAnio(
			@PathVariable("anio") int anio,
			@PathVariable("mes") int mes,
			@PathVariable("idCuenta") String idCuenta,
			@PathVariable("importe") int importe) {
		
		try {	
			return siatEntradasService.updateCatcuentasAnio(anio, mes, idCuenta, importe);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar catcuentas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateCatcuentasAbono:actualiza registro en catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@ApiOperation(value = "Servicio actualizar para catcuentas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "catcuentas actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar catcuentas") 
			})
	@PostMapping("/updateCatcuentasAbono/{anio}/{mes}/{idCuenta}/{importe}")
	@ResponseBody
	public ResponseDTO<Boolean> updateCatcuentasAbono(
			@PathVariable("anio") int anio,
			@PathVariable("mes") int mes,
			@PathVariable("idCuenta") String idCuenta,
			@PathVariable("importe") String importe) {
		
		try {	
			return siatEntradasService.updateCatcuentasAbonos(anio, mes, idCuenta, importe);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar catcuentas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCatCuentas: obtiene informacion de la catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-11
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el cargo de cat cuentas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCatCuentas/{cargo}/{anio}/{idCuenta}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getCatCuentas(
			@PathVariable("cargo") int cargo,
			@PathVariable("anio") int anio,
			@PathVariable("idCuenta") String idCuenta) {
		
		try {
			return siatEntradasService.getCatCuentas(cargo,anio,idCuenta);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el cargo de cat cuentas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCatCuentasAbonos: obtiene informacion de la catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-11
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el abono de cat cuentas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCatCuentasAbonos/{abono}/{anio}/{idCuenta}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getCatCuentasAbonos(
			@PathVariable("abono") int abono,
			@PathVariable("anio") int anio,
			@PathVariable("idCuenta") String idCuenta) {
		
		try {
			return siatEntradasService.getCatCuentasAbonos(abono,anio,idCuenta);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el abono de cat cuentas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateResumenCompra:actualiza registro en resumen compra
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-09
	 */
	@ApiOperation(value = "Servicio actualizar para resumen cuenta", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "resumen cuenta actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar resumen cuenta") 
			})
	@PostMapping("/updateResumenCompra/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<Boolean> updateResumenCompra(
			@PathVariable("idRefaccion") int idRefaccion,
			@RequestBody ResumenCompra resumen) {
		
		try {	
			return siatEntradasService.updateResumenCompra(idRefaccion, resumen);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar resumen cuenta");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getResumenCompra: obtiene informacion de resumen compra
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-12
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el resumen compra", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getResumenCompra/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<ResumenCompra>> getResumenCompra(
			@PathVariable("idRefaccion") int idRefaccion) {
		
		try {
			return siatEntradasService.getResumenCompra(idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<ResumenCompra>> response = new ResponseDTO<List<ResumenCompra>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el resumen compra");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getResumenImpresion: obtiene informacion de resumen impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-15
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de impresion", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getResumenImpresion/{anio}/{fechaIni}/{fechaFin}/{tipo}/{permisoTaller}/{idTaller}")
	@ResponseBody
	public ResponseDTO<List<ImprimirGeneral>> getResumenImpresion(
			@PathVariable("anio") int anio,
			@PathVariable("fechaIni") String fechaIni,
			@PathVariable("fechaFin") String fechaFin,
			@PathVariable("tipo") int tipo,
			@PathVariable("permisoTaller") int permisoTaller,
			@PathVariable("idTaller") int idTaller) {
		
		try {
			return siatEntradasService.getResumenImpresion(anio,fechaIni,fechaFin,tipo,permisoTaller,idTaller);
		} catch (Exception e) {
			ResponseDTO<List<ImprimirGeneral>> response = new ResponseDTO<List<ImprimirGeneral>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de impresion ");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getKardexInformacion: obtiene informacion de cantidades impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-15
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de kardex", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getKardexInformacion/{noMovimiento}/{tipoMovimiento}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<KardexInformacion>> getKardexInformacion(
			@PathVariable("noMovimiento") int noMovimiento,
			@PathVariable("tipoMovimiento") int tipoMovimiento,
			@PathVariable("tipo") int tipo) {
		
		try {
			return siatEntradasService.getKardexInformacion(noMovimiento,tipoMovimiento,tipo);
		} catch (Exception e) {
			ResponseDTO<List<KardexInformacion>> response = new ResponseDTO<List<KardexInformacion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de kardex");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getEntradaFechapol: obtiene informacion de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de entradas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getEntradaFechapol/{anio}/{idEntrada}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<EntradasFechapol>> getEntradaFechapol(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("tipo") int tipo) {
		
		try {
			return siatEntradasService.getEntradaFechapol(anio,idEntrada,tipo);
		} catch (Exception e) {
			ResponseDTO<List<EntradasFechapol>> response = new ResponseDTO<List<EntradasFechapol>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de entradas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getTotalMovimientos: obtiene informacion de movimientos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion de movimientos", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getTotalMovimientos/{anio}/{idPoliza}")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getTotalMovimientos(
			@PathVariable("anio") int anio,
			@PathVariable("idPoliza") int idPoliza) {
		
		try {
			return siatEntradasService.getTotalMovimientos(anio,idPoliza);
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion de movimientos");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deletePoliza : Elimina informacion de polizas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@ApiOperation(value = "Servicio para la eliminacion del registro polizaa", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminación del registro de la tabla poliza correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar el registro de la tabla poliza") 
			})
	@PostMapping("/deletePoliza/{idPoliza}/{tabla}/{idTipoPol}")
	@ResponseBody
	public ResponseDTO<Boolean> deletePoliza(
			@PathVariable("idPoliza") int idPoliza,
			@PathVariable("tabla") int tabla,
			@PathVariable("idTipoPol") int idTipoPol) {
		
		try {	
			return siatEntradasService.deletePoliza(idPoliza, tabla,idTipoPol);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar el registro de la tabla poliza");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deletePolizaAnio : Elimina informacion de polizas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@ApiOperation(value = "Servicio para la eliminacion del registro poliza año", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminación del registro de la tabla poliza año correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar el registro de la tabla poliza año") 
			})
	@PostMapping("/deletePolizaAnio/{anio}/{idPoliza}/{idTipoPol}")
	@ResponseBody
	public ResponseDTO<Boolean> deletePolizaAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idPoliza") int idPoliza,
			@PathVariable("idTipoPol") int idTipoPol) {
		
		try {	
			return siatEntradasService.deletePolizaAnio(anio, idPoliza, idTipoPol);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar el registro de la tabla poliza año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteMovimientosAnio : Elimina informacion de movimientos año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@ApiOperation(value = "Servicio para la eliminacion del registro de movimientos año", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "eliminación del registro de la tabla de movimientos año correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminar el registro de la tabla de movimientos año") 
			})
	@PostMapping("/deleteMovimientosAnio/{anio}/{idPoliza}")
	@ResponseBody
	public ResponseDTO<Boolean> deleteMovimientosAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idPoliza") int idPoliza) {
		
		try {	
			return siatEntradasService.deleteMovimientosAnio(anio, idPoliza);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar el registro de la tabla de movimientos año");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 *getRptEntradaConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la impresion de entradas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRptEntradaConsultar/{anio}/{idEntrada}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<ImprimirEntradas>> ImprimirEntradas(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("tipo") int tipo) {
		
		try {
			return siatEntradasService.getRptEntradaConsultar(anio,idEntrada,tipo);
		} catch (Exception e) {
			ResponseDTO<List<ImprimirEntradas>> response = new ResponseDTO<List<ImprimirEntradas>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la impresion de entradas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 *getRptEntradaFacturaConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la impresion de entradas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRptEntradaFacturaConsultar/{anio}/{idEntrada}/{idAlmacen}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<ImprimirEntradasFactura>> getRptEntradaFacturaConsultar(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("idAlmacen") int idAlmacen,
			@PathVariable("tipo") int tipo) {
		
		try {
			return siatEntradasService.getRptEntradaFacturaConsultar(anio,idEntrada,idAlmacen,tipo);
		} catch (Exception e) {
			ResponseDTO<List<ImprimirEntradasFactura>> response = new ResponseDTO<List<ImprimirEntradasFactura>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la impresion de entradas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 *getRptEntradaFacturaConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la impresion de entradas", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRptEntradaRemisionConsultar/{anio}/{idEntrada}/{idAlmacen}/{tipo}")
	@ResponseBody
	public ResponseDTO<List<ImprimirEntradasFactura>> getRptEntradaRemisionConsultar(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("idAlmacen") int idAlmacen,
			@PathVariable("tipo") int tipo) {
		
		try {
			return siatEntradasService.getRptEntradaRemisionConsultar(anio,idEntrada,idAlmacen,tipo);
		} catch (Exception e) {
			ResponseDTO<List<ImprimirEntradasFactura>> response = new ResponseDTO<List<ImprimirEntradasFactura>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la impresion de entradas");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getConvenios: obtiene informacion de la tabla convenios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getConvenios/{idConvenio}")
	@ResponseBody
	public ResponseDTO<List<Convenios>> getConvenios(
			@PathVariable("idConvenio") int idConvenio) {
		
		try {
			return siatEntradasService.getConvenios(idConvenio);
		} catch (Exception e) {
			ResponseDTO<List<Convenios>> response = new ResponseDTO<List<Convenios>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGridEntDevolucion: obtiene informacion para generar el grid de entrada por devolucion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el convenio proveedor", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGridEntDevolucion")
	@ResponseBody
	public ResponseDTO<List<ConvenioProveedor>> getGridEntDevolucion() {
		
		try {
			return siatEntradasService.getGridEntDevolucion();
		} catch (Exception e) {
			ResponseDTO<List<ConvenioProveedor>> response = new ResponseDTO<List<ConvenioProveedor>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el convenio proveedor");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getRefaccionesPorSurtir: obtiene informacion para generar obtener las refacciones por surtir
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getRefaccionesPorSurtir/{idConvenio}")
	@ResponseBody
	public ResponseDTO<List<RefaccionesPorSurtir>> getRefaccionesPorSurtir(
			@PathVariable("idConvenio") int idConvenio) {
		
		try {
			return siatEntradasService.getRefaccionesPorSurtir(idConvenio);
		} catch (Exception e) {
			ResponseDTO<List<RefaccionesPorSurtir>> response = new ResponseDTO<List<RefaccionesPorSurtir>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGrupos: obtiene informacion para los grupos.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-07
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el grupo", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGrupos/{clave}")
	@ResponseBody
	public ResponseDTO<List<Grupos>> getGrupos(
			@PathVariable("clave") int clave) {
		
		try {
			return siatEntradasService.getGrupos(clave);
		} catch (Exception e) {
			ResponseDTO<List<Grupos>> response = new ResponseDTO<List<Grupos>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grupo");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGruposIdentificador: obtiene informacion para los grupos.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-07
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el grupo", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGruposIdentificador/{idGrupo}")
	@ResponseBody
	public ResponseDTO<List<Grupos>> getGruposIdentificador(
			@PathVariable("idGrupo") int idGrupo) {
		
		try {
			return siatEntradasService.getGruposIdentificador(idGrupo);
		} catch (Exception e) {
			ResponseDTO<List<Grupos>> response = new ResponseDTO<List<Grupos>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener el grupo");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCuerpoDetalle: obtiene el cuerpo del convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el cuerpo detalle", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCuerpoConvenio/{idConvenio}/{idRefaccion}")
	@ResponseBody
	public ResponseDTO<List<CuerpoConvenio>> getCuerpoConvenio(
			@PathVariable("idConvenio") int idConvenio,
			@PathVariable("idRefaccion") int idRefaccion
	) {
		
		try {
			return siatEntradasService.getCuerpoConvenio(idConvenio, idRefaccion);
		} catch (Exception e) {
			ResponseDTO<List<CuerpoConvenio>> response = new ResponseDTO<List<CuerpoConvenio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar los datos del cuerpo del convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getCatCuentasAnio: obtiene informacion de cat cuentas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-15-13
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el cuerpo detalle", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getCatCuentasAnio/{anio}/{idCuenta}")
	@ResponseBody
	public ResponseDTO<List<CatCuentasAnio>> getCatCuentasAnio(
			@PathVariable("anio") int anio,
			@PathVariable("idCuenta") String idCuenta
	) {
		
		try {
			return siatEntradasService.getCatCuentasAnio(anio, idCuenta);
		} catch (Exception e) {
			ResponseDTO<List<CatCuentasAnio>> response = new ResponseDTO<List<CatCuentasAnio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar los datos del cuerpo del convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * deleteTablaTemporal: eliminar una tabla temporal
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-03-19
	 */
	@ApiOperation(value = "Servicio insertar para Tempoliza", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "tabla temporal eliminada correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible eliminada tabla personal") 
			})
	@PostMapping("/deleteTablaTemporal")
	@ResponseBody
	public ResponseDTO<Boolean> deleteTablaTemporal() {
		
		try {	
			return siatEntradasService.deleteTablaTemporal();
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible eliminar la tabla temporal");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertTemporal: inserta registro en tabla temporal
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-03-19
	 */
	@ApiOperation(value = "Servicio insertar requisicion historico", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Requisicion historico insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar requisicion historico") 
			})
	@PostMapping("/insertTemporal")
	@ResponseBody
	public ResponseDTO<Boolean> insertTemporal(
			@RequestBody TablaTemporal tablaTemp) {
		
		try {	
			return siatEntradasService.insertTemporal(tablaTemp);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar requisicion historico");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getGrupoTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el grupo temporal", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getGrupoTemporal")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getGrupoTemporal() {
		
		try {
			return siatEntradasService.getGrupoTemporal();
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar los datos del grupo temporal");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getImporteTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el grupo temporal", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getImporteTemporal")
	@ResponseBody
	public ResponseDTO<List<TablaSumTemporal>> getImporteTemporal() {
		
		try {
			return siatEntradasService.getImporteTemporal();
		} catch (Exception e) {
			ResponseDTO<List<TablaSumTemporal>> response = new ResponseDTO<List<TablaSumTemporal>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar los datos del grupo temporal");
			response.setData(null);
			return response;
		}
	}

	/**
	 * getSumPmnTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el grupo temporal", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getSumPmnTemporal")
	@ResponseBody
	public ResponseDTO<List<GetMotivo>> getSumPmnTemporal() {
		
		try {
			return siatEntradasService.getSumPmnTemporal();
		} catch (Exception e) {
			ResponseDTO<List<GetMotivo>> response = new ResponseDTO<List<GetMotivo>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar los datos del grupo temporal");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updatePrecioRefaccion:actualiza el precio de la refacción en llantas
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-22
	 */
	@ApiOperation(value = "Servicio para actualizar el precio de la refacción en llantas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "El precio de la refacción en llantas ha sido actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar el precio de la refacción en llantas") 
			})
	@PostMapping("/updatePrecioRefaccionLlanta/{idRefaccion}/{precio}")
	@ResponseBody
	public ResponseDTO<Boolean> updatePrecioRefaccionLlanta(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("precio") Double precio) {
		
		try {	
			return siatEntradasService.updatePrecioRefaccionLlanta(idRefaccion, precio);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar el precio de la refacción");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getEsFactura: obtiene informacion si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para la informacion si es factura", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getDetalleEntradaConsignacion/{anio}/{idEntrada}/{idAlmacen}")
	@ResponseBody
	public ResponseDTO<List<DetalleEntradaConsignacion>> getDetalleEntradaConsignacion(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("idAlmacen") int idAlmacen) {
		
		try {
			return siatEntradasService.getDetalleEntradaConsignacion(anio, idEntrada, idAlmacen);
		} catch (Exception e) {
			ResponseDTO<List<DetalleEntradaConsignacion>> response = new ResponseDTO<List<DetalleEntradaConsignacion>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la informacion si es factura");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updatePrecioRefaccion:actualiza el saldo total del convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-25
	 */
	@ApiOperation(value = "Servicio para actualizar saldo total del convenio", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "El saldo total del convenio ha sido actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar el precio de la refacción en llantas") 
			})
	@PostMapping("/updateSaldoConvenio/{idConvenio}/{saldoTotal}")
	@ResponseBody
	public ResponseDTO<Boolean> updateSaldoConvenio(
			@PathVariable("idConvenio") int idConvenio,
			@PathVariable("saldoTotal") Double saldoTotal) {
		
		try {	
			return siatEntradasService.updateSaldoConvenio(idConvenio, saldoTotal);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar el saldo total del convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertTemporal: inserta registro en tabla temporal
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-03-19
	 */
	@ApiOperation(value = "Servicio insertar historicodetaconvenio historico", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "historico del convenio insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar el historico del convenio") 
			})
	@PostMapping("/insertHistoricoConvenio")
	@ResponseBody
	public ResponseDTO<Boolean> insertHistoricoConvenio(
			@RequestBody HistoricoConvenio tablaTemp) {
		
		try {	
			return siatEntradasService.insertHistoricoConvenio(tablaTemp);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar el historico del convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getProveedor: obtiene los datos del cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-26
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con los datos del cuerpo convenio", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getListCuerpoConvenio/{idConvenio}")
	@ResponseBody
	public ResponseDTO<List<ListaCuerpoConvenio>> getListCuerpoConvenio(
			@PathVariable("idConvenio") int idConvenio) {
		try {
			return siatEntradasService.getListCuerpoConvenio(idConvenio);
		} catch (Exception e) {
			ResponseDTO<List<ListaCuerpoConvenio>> response = new ResponseDTO<List<ListaCuerpoConvenio>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la información del proveedor");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateRefaProveedor:actualiza registro en refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-25
	 */
	@ApiOperation(value = "Servicio insertar para actualizar refaproveedor", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Refaproveedor actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar refaproveedor") 
			})
	@PostMapping("/updateExistenciaRefaProveedor/{idRefaccion}/{idProveedor}/{existencia}")
	@ResponseBody
	public ResponseDTO<Boolean> updateExistenciaRefaProveedor(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idProveedor") int idProveedor,
			@PathVariable("idRefaccion") Double existencia) {
		try {	
			return siatEntradasService.updateExistenciaRefaProveedor(idRefaccion, idProveedor, existencia);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar refaproveedor");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * updateCuerpoConvenio:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-26
	 */
	
	@ApiOperation(value = "Servicio para actualizar el cuerpo del convenio", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "cuerpo convenio actualizado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible actualizar cuerpo convenio") 
			})
	@PostMapping("/updateDataCuerpoConvenio/{idRefaccion}/{idConvenio}/{pcmn}/{cantidadSurtida}")
	@ResponseBody
	public ResponseDTO<Boolean> updateDataCuerpoConvenio(
			@PathVariable("idRefaccion") int idRefaccion,
			@PathVariable("idConvenio") int idConvenio,
			@PathVariable("pcmn") Double pcmn,
			@PathVariable("cantidadSurtida") Double cantidadSurtida){
		
		try {	
			return siatEntradasService.updateDataCuerpoConvenio(idRefaccion, idConvenio, pcmn, cantidadSurtida);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible actualizar cuerpo convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * insertTemporal: inserta registro en tabla histcuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-27
	 */
	@ApiOperation(value = "Servicio insertar historicodetaconvenio historico", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "historico del convenio insertado correctamente", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No fue posible insertar el historico del convenio") 
			})
	@PostMapping("/insertHistoricoCuerpoConvenio")
	@ResponseBody
	public ResponseDTO<Boolean> insertHistoricoCuerpoConvenio(
			@RequestBody HistoricoCuerpoConvenio tablaTemp) {
		
		try {	
			return siatEntradasService.insertHistoricoCuerpoConvenio(tablaTemp);
		} catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
			ResponseDTO<Boolean> response = new ResponseDTO<Boolean>();
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("No fue posible insertar el historico del cuerpo convenio");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getDataEntrada: obtiene los datos de la entrada
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-27
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con los datos del proveedor", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getDataEntradaNormal/{anio}/{idEntrada}/{tipoEntrada}")
	@ResponseBody
	public ResponseDTO<List<GetDataEntradaNormal>> getDataEntradaNormal(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("tipoEntrada") int tipoEntrada) {
		
		try {
			return siatEntradasService.getDataEntradaNormal(anio, idEntrada, tipoEntrada);
		} catch (Exception e) {
			ResponseDTO<List<GetDataEntradaNormal>> response = new ResponseDTO<List<GetDataEntradaNormal>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la información de la entrada");
			response.setData(null);
			return response;
		}
	}
	
	/**
	 * getDataEntrada: obtiene los datos de la entrada
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-27
	 */
	@ApiOperation(value = " Servicio para grid de entradas", tags = { "Controlador entradasController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success con los datos del proveedor", response = ResponseDTO.class), 
			@ApiResponse(code = 404, message = "No encontrados") 
	})
	@GetMapping("/getDataEntrada/{anio}/{idEntrada}/{tipoEntrada}")
	@ResponseBody
	public ResponseDTO<List<GetDataEntrada>> getDataEntrada(
			@PathVariable("anio") int anio,
			@PathVariable("idEntrada") int idEntrada,
			@PathVariable("tipoEntrada") int tipoEntrada) {
		
		try {
			return siatEntradasService.getDataEntrada(anio, idEntrada, tipoEntrada);
		} catch (Exception e) {
			ResponseDTO<List<GetDataEntrada>> response = new ResponseDTO<List<GetDataEntrada>>();
            logger.error(e.getLocalizedMessage(), e);
			response.setCode(0);
			response.setDescription("error");
			response.setMessage("Surgio un error al intentar obtener la información de la entrada");
			response.setData(null);
			return response;
		}
	}
	
}
