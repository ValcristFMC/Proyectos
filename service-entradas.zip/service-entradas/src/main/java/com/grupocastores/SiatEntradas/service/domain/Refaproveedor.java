package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class Refaproveedor {
	
	@Id
	@Column(name="idrefaccion")
	private int idRefaccion;
	@Column(name="idproveedor")
	private int idProveedor;
	@Column(name = "existencia")
	private Double existencia;
	@Column(name="dias")
	private int dias;
	@Column(name = "pcmn")
	private Double pcmn;
	@Column(name = "pcd")
	private Double pcd;
	@Column(name = "opcion")
	private int opcion;
	@Column(name = "estatus")
	private int estatus;
	@Column(name = "idpersonal")
	private int idPersonal;
	@Column(name = "fecha", nullable = true)
	private LocalDate fecha;
	@Column(name = "hora", nullable = true)
	private LocalTime hora;
}
