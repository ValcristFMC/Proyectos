package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class EntradasFechapol {
	
	@Id
	@Column(name = "claveentrada")
	private String claveEntrada;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "fechapol")
	private String fechaPol;
	@Column(name="tipo")
	private int tipo;
}
