package com.grupocastores.SiatEntradas.dto;

import java.util.Date;
import io.swagger.annotations.ApiModel;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.SiatEntradas.service.domain.SiatEntradas} del modelo de dominio
 *
 * @author Castores - Desarrollo TI
 */
@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un SiatEntradas", description = "Datos del SiatEntradas")
public class SiatEntradasDTO 
{
	private int id;
	private String description;
	private Date createddate;
	private Date lastModifiedTime;
	private Boolean isActive;

	
	/**
	 * Constructor de SiatEntradasDTO con todos los atributos como argumentos
	 * 
	 * @param id the id to set
	 * @param description the description to set
	 * 
	 */
	public SiatEntradasDTO (int id, String description, Date createddate, Date lastModifiedTime, Boolean isActive) {
		this.id = id;
		this.description = description;
		this.isActive = isActive;
		this.createddate = createddate;
		this.lastModifiedTime = lastModifiedTime;		
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("SiatEntradas [id=").append(id)
		.append(", description=").append(description)
		.append(", isActive=").append(isActive)	
		.append(", createddate").append(createddate)
		.append(", lastModifiedTime").append(lastModifiedTime);
		return strBuilder.toString();
	}
}
