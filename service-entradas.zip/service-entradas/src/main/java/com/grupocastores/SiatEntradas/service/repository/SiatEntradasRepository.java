package com.grupocastores.SiatEntradas.service.repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.grupocastores.SiatEntradas.utils.UtilitiesRepository;
import com.grupocastores.SiatEntradas.utils.UtilsFileManager;
import com.grupocastores.SiatEntradas.service.domain.Folio;
import com.grupocastores.SiatEntradas.service.domain.RequisicionHistorico;
import com.grupocastores.SiatEntradas.service.domain.ResumenCompra;
import com.grupocastores.SiatEntradas.service.domain.RptContraRecibo;
import com.grupocastores.SiatEntradas.service.domain.Almacen;
import com.grupocastores.SiatEntradas.service.domain.AlmacenTranspasosPlazo;
import com.grupocastores.SiatEntradas.service.domain.Autorizaciones;
import com.grupocastores.SiatEntradas.service.domain.BancoProveedor;
import com.grupocastores.SiatEntradas.service.domain.CantidadesEntradas;
import com.grupocastores.SiatEntradas.service.domain.CatalogoAlmacen;
import com.grupocastores.SiatEntradas.service.domain.CatCuentas;
import com.grupocastores.SiatEntradas.service.domain.CatCuentasAnio;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibos;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibosInfo;
import com.grupocastores.SiatEntradas.service.domain.ControlCambio;
import com.grupocastores.SiatEntradas.service.domain.ControlEntrada;
import com.grupocastores.SiatEntradas.service.domain.ConvenioInf;
import com.grupocastores.SiatEntradas.service.domain.ConvenioProveedor;
import com.grupocastores.SiatEntradas.service.domain.ConvenioRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Convenios;
import com.grupocastores.SiatEntradas.service.domain.CuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.CuerpoDetalle;
import com.grupocastores.SiatEntradas.service.domain.CuerpoFactura;
import com.grupocastores.SiatEntradas.service.domain.CuerpoOrden;
import com.grupocastores.SiatEntradas.service.domain.CuerpoRequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.DetalleEntrada;
import com.grupocastores.SiatEntradas.service.domain.DetalleEntradaConsignacion;
import com.grupocastores.SiatEntradas.service.domain.Entradas;
import com.grupocastores.SiatEntradas.service.domain.EntradasAnio;
import com.grupocastores.SiatEntradas.service.domain.EntradasFechapol;
import com.grupocastores.SiatEntradas.service.domain.EntradasInfo;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrden;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrdenAnticipo;
import com.grupocastores.SiatEntradas.service.domain.FolioAlmacen;
import com.grupocastores.SiatEntradas.service.domain.GetDataEntrada;
import com.grupocastores.SiatEntradas.service.domain.GetDataEntradaNormal;
import com.grupocastores.SiatEntradas.service.domain.GetMotivo;
import com.grupocastores.SiatEntradas.service.domain.GetProveedor;
import com.grupocastores.SiatEntradas.service.domain.GridEntradas;
import com.grupocastores.SiatEntradas.service.domain.GridFacturas;
import com.grupocastores.SiatEntradas.service.domain.Grupos;
import com.grupocastores.SiatEntradas.service.domain.HistoricoConvenio;
import com.grupocastores.SiatEntradas.service.domain.HistoricoCuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.IdRefaccionGrid;
import com.grupocastores.SiatEntradas.service.domain.Importe;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradas;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradasFactura;
import com.grupocastores.SiatEntradas.service.domain.ImprimirGeneral;
import com.grupocastores.SiatEntradas.service.domain.KardexInformacion;
import com.grupocastores.SiatEntradas.service.domain.InformacionRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Iva;
import com.grupocastores.SiatEntradas.service.domain.Kardex;
import com.grupocastores.SiatEntradas.service.domain.KardexMovimiento;
import com.grupocastores.SiatEntradas.service.domain.KardexRefacciones;
import com.grupocastores.SiatEntradas.service.domain.ListaCuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.Lotes;
import com.grupocastores.SiatEntradas.service.domain.Movimientos;
import com.grupocastores.SiatEntradas.service.domain.Ordenes;
import com.grupocastores.SiatEntradas.service.domain.OrdenesAnio;
import com.grupocastores.SiatEntradas.service.domain.PolizasAnio;
import com.grupocastores.SiatEntradas.service.domain.Polizas;
import com.grupocastores.SiatEntradas.service.domain.RefPorAlmacen;
import com.grupocastores.SiatEntradas.service.domain.RefaccionesPorSurtir;
import com.grupocastores.SiatEntradas.service.domain.Refaproveedor;
import com.grupocastores.SiatEntradas.service.domain.RequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.SemaforoSiat;
import com.grupocastores.SiatEntradas.service.domain.SiatEntradas;
import com.grupocastores.SiatEntradas.service.domain.TablaSumTemporal;
import com.grupocastores.SiatEntradas.service.domain.TablaTemporal;
import com.grupocastores.SiatEntradas.service.domain.Tempoliza;
import com.grupocastores.SiatEntradas.service.domain.TempolizaRefaccion;
import com.grupocastores.SiatEntradas.service.domain.TipoAutorizaciones;
import com.grupocastores.SiatEntradas.service.domain.TipoCambio;
import com.grupocastores.SiatEntradas.service.domain.TipoSolicitud;
import com.grupocastores.SiatEntradas.service.domain.TotalGrid;
import com.grupocastores.SiatEntradas.service.domain.TraspasosGrupos;
import com.grupocastores.SiatEntradas.service.domain.UpdateRefacciones;
import com.grupocastores.SiatEntradas.service.domain.ValidacionEntrada;

/**
 * SiatEntradasRepository Repositorio para el almacenamiento de {@link com.grupocastores.SiatEntradas.service.domain.SiatEntradas} 
 *
 * @author Castores - Desarrollo TI
 *
 */
@Repository
public class SiatEntradasRepository 
{
	public static final String DB_13 = "PRUEBAS13";
	
	@Autowired
	private UtilitiesRepository utilitiesRepository;

	@Autowired
	private UtilsFileManager utilsFileManager;

	@PersistenceContext
	private EntityManager entityManager;
	
	public static final String AlmacenesCorpo = "28,34,21,6,36,4,10,37,9,15,11,1,2,24,8,3"; 
	
	public static final String AlmacenesForaneos = "27,29,19,25,17,7,5,31,18,35,22,13,26,16,32,14,23,33,20,38"; 

	static final String queryGetSemaforo = "SELECT * FROM OPENQUERY ( %s  , 'SELECT s.*, CONCAT_WS(\" \", p.apepaterno, p.apematerno, p.nombre) AS nompersonal FROM siat.semaforosiat s LEFT JOIN  personal.personal p ON p.idpersonal = s.idpersonal WHERE idsemaforosiat = %s;');";	

	static final String queryGridEntradas = "SELECT * FROM OPENQUERY ( %s  , 'SELECT e.identrada, e.tipo, e.idordencompra, f.factura, IF(e.tipo <> 8, (SELECT LTRIM(CONCAT_WS(\" \", pv.apepaterno, pv.apematerno, pv.nombre, pv.razonsocial)) FROM siat.proveedores pv WHERE pv.idproveedor = e.idproveedor),(SELECT plaza FROM  personal.oficinas of WHERE of.idoficina = e.idproveedor)) AS prov, e.idestatus, e.fecha, e.hora, e.idmotivo, e.idfacturaorden, e.claveentrada, IF(u.idtipounidad = 8, u.serie, u.noeconomico) AS tipounidad, tu.nombre, sa.folio, sa.idsalida, fa.idfactura, fa.fecha AS fac, f.contrarecibo, f.iva, f.sepagara, sal.idsalida AS ids, sal.tabla, IF(e.tipo = 3, (ROUND(SUM((fa.cantidad * fa.costo ) * (fa.iva/100)  * (fa.cantidad * fa.costo )),2)), \" \") AS total, oc.idmoneda, oc.iva AS ivaOC, e.observaciones, e.idalmacen, alm.nombre AS nomalmacen, sa.fecha AS fechasalida, rqc.idsubtiporequisicion FROM siat.entradas%s e LEFT JOIN siat.facturasorden f ON e.idfacturaorden = f.idfacturaorden LEFT JOIN siat.devolucion de ON e.identrada =  de.identrada LEFT JOIN siat.salidas%s sa ON de.idsalida = sa.idsalida LEFT JOIN siat.unidades u ON sa.unidad = u.idunidad AND u.idtipounidad = sa.tipounidad LEFT JOIN siat.tipounidad tu ON sa.tipounidad = tu.idtipounidad LEFT JOIN siat.facturacion fa ON e.identrada = fa.nomovimiento AND fa.tipomovimiento = 1 LEFT JOIN siat.salidas sal ON sal.idsalida = sa.idsalida AND e.tipo = 3 LEFT JOIN siat.ordencompra%s oc ON e.idordencompra = oc.idordencompra  LEFT JOIN siat.almacen alm ON e.idalmacen = alm.idalmacen LEFT JOIN siat.administraciones_relacion adm ON LTRIM(adm.tabla_relacion) = \"proveedores\" AND e.idproveedor = adm.id_relacion AND e.tipo <> 8 LEFT JOIN siat.requisicion%s r ON r.idrequisicion = oc.idrequisicion LEFT JOIN siat.requisicionclasificacion rqc ON rqc.idrequisicion = r.idrequisicion WHERE MONTH(e.fecha) = %s AND e.idestatus = 1 AND alm.idtaller = %s AND e.idalmacen = %s GROUP BY e.identrada, e.tipo ORDER BY e.identrada DESC;');";	

	static final String queryGridEntradasPorAlmacen = "SELECT * FROM OPENQUERY ( %s  , 'SELECT e.identrada, e.tipo, e.idordencompra, f.factura, IF(e.tipo <> 8, (SELECT LTRIM(CONCAT_WS(\" \", pv.apepaterno, pv.apematerno, pv.nombre, pv.razonsocial)) FROM siat.proveedores pv WHERE pv.idproveedor = e.idproveedor),(SELECT plaza FROM  personal.oficinas of WHERE of.idoficina = e.idproveedor)) AS prov, e.idestatus, e.fecha, e.hora, e.idmotivo, e.idfacturaorden, e.claveentrada, IF(u.idtipounidad = 8, u.serie, u.noeconomico) AS tipounidad, tu.nombre, sa.folio, sa.idsalida, fa.idfactura, fa.fecha AS fac, f.contrarecibo, f.iva, f.sepagara, sal.idsalida AS ids, sal.tabla, IF(e.tipo = 3, (ROUND(SUM((fa.cantidad * fa.costo ) * (fa.iva/100)  * (fa.cantidad * fa.costo )),2)), \" \") AS total, oc.idmoneda, oc.iva AS ivaOC, e.observaciones, e.idalmacen, alm.nombre AS nomalmacen, sa.fecha AS fechasalida, rqc.idsubtiporequisicion FROM siat.entradas%s e LEFT JOIN siat.facturasorden f ON e.idfacturaorden = f.idfacturaorden LEFT JOIN siat.devolucion de ON e.identrada =  de.identrada LEFT JOIN siat.salidas%s sa ON de.idsalida = sa.idsalida LEFT JOIN siat.unidades u ON sa.unidad = u.idunidad AND u.idtipounidad = sa.tipounidad LEFT JOIN siat.tipounidad tu ON sa.tipounidad = tu.idtipounidad LEFT JOIN siat.facturacion fa ON e.identrada = fa.nomovimiento AND fa.tipomovimiento = 1 LEFT JOIN siat.salidas sal ON sal.idsalida = sa.idsalida AND e.tipo = 3 LEFT JOIN siat.ordencompra%s oc ON e.idordencompra = oc.idordencompra LEFT JOIN siat.almacen alm ON e.idalmacen = alm.idalmacen LEFT JOIN siat.administraciones_relacion adm ON LTRIM(adm.tabla_relacion) = \"proveedores\" AND e.idproveedor = adm.id_relacion AND e.tipo <> 8 LEFT JOIN siat.requisicion%s r ON r.idrequisicion = oc.idrequisicion LEFT JOIN siat.requisicionclasificacion rqc ON rqc.idrequisicion = r.idrequisicion WHERE MONTH(e.fecha) = %s AND e.idestatus = 1 AND e.idalmacen IN (%s) GROUP BY e.identrada, e.tipo ORDER BY e.identrada DESC;');";	
	
	static final String queryGetAlmacen = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.almacen a WHERE  a.idalmacen IN (%s) AND a.nombre LIKE \"%s\" ;');";  

	static final String queryGridFacturas = "SELECT * FROM OPENQUERY (%s, 'SELECT f.idfacturaorden, o.idrequisicion,CONCAT(\"TA\",r.clave) AS clave, o.idordencompra, o.idproveedor, f.factura, f.fechamod, f.hora, r.idalmacen,  p.razonsocial, a.nombre AS nombrealmacen, TIMESTAMPDIFF(DAY, f.fechamod, CURDATE()) AS difdias, f.idestatus, e.nombre FROM siat.ordencompra%s o INNER JOIN siat.facturasorden f ON o.idordencompra = f.idordencompra INNER JOIN siat.requisicion%s r ON o.idrequisicion = r.idrequisicion LEFT JOIN siat.proveedores p ON  o.idproveedor = p.idproveedor LEFT JOIN siat.almacen a ON r.idalmacen = a.idalmacen LEFT JOIN siat.estatus e ON e.idestatus = f.idestatus AND e.tipo=1 WHERE MONTH(o.fecha) = %s AND f.idestatus IN (1,3,11) ORDER BY o.idordencompra, f.factura;');";  

	static final String queryGridFacturasAgrupadas = "SELECT * FROM OPENQUERY (%s, 'SELECT o.idrequisicion, o.idordencompra, o.idproveedor, f.idfacturaorden, f.factura, f.fechamod, f.hora, r.idalmacen FROM siat.ordencompra%s o INNER JOIN siat.facturasorden f ON o.idordencompra = f.idordencompra INNER JOIN siat.requisicionagrupada%s r ON o.idrequisicion = r.idrequisicion WHERE MONTH(o.fecha) = %s AND f.idestatus IN (1,3) ORDER BY o.idordencompra, f.factura;');";  

	static final String queryGetValidacionEntrada = "SELECT * FROM OPENQUERY (%s, ' SELECT identrada FROM siat.entradas%s WHERE idfacturaorden = %s;');";  

	static final String queryGetTotalGrid = "SELECT * FROM OPENQUERY (%s, ' SELECT CAST(SUM(cantidad * precio)as decimal(38,6)) AS total FROM siat.kardex WHERE nomovimiento = %s AND tipo = %s AND tipomovimiento = 1;');";  

	static final String queryGetTotalOpcionGrid = "SELECT * FROM OPENQUERY (%s, ' SELECT CAST(SUM(cantidad * precio) * (16/100) + (cantidad * precio)as decimal(38,6)) as total FROM siat.kardex WHERE nomovimiento = %s AND tipo = %s AND tipomovimiento = 1;');"; 
	
	static final String queryGetRefaccionGrid = "SELECT * FROM OPENQUERY (%s, ' SELECT idrefaccion FROM siat.kardex WHERE nomovimiento = %s AND tipo = %s AND tipomovimiento = 1;');"; 

	static final String queryGetCarroceriaGrid = "SELECT * FROM OPENQUERY (%s, ' SELECT idrefaccion, tipomoneda FROM siat.refcarroceria WHERE idrefaccion IN(%s);');"; 

	static final String queryGetTipoCambio = "SELECT * FROM OPENQUERY (%s, ' SELECT doficial FROM siat.tipocambio WHERE fecha = \" %s \";');"; 
	
	static final String queryGetMotivo = "SELECT * FROM OPENQUERY (%s, ' SELECT descripcion FROM siat.motivosdevolucion WHERE idmotivo = %s;');"; 

	static final String queryGetTipoCambioCarroceria = "SELECT * FROM OPENQUERY (%s, ' SELECT tipocambio AS doficial FROM siat.tipocambiocarroceria WHERE estatus = 1;');"; 

	static final String queryGetAlmacenTraspasos = "SELECT * FROM OPENQUERY (%s, ' SELECT * FROM siat.almacen_traspasos_plazo WHERE idalmacen = %s;');"; 

	static final String queryGetOrdenes = "SELECT * FROM OPENQUERY (%s, ' SELECT * FROM siat.ordenes WHERE idordencompra = %s;');"; 

	static final String queryGetOrdenesAnio = "SELECT * FROM OPENQUERY (%s, ' SELECT * FROM siat.ordencompra%s WHERE idordencompra = %s AND idrequisicion = %s;');"; 
	
	static final String queryGetOrdenesAnioMoneda = "SELECT * FROM OPENQUERY (%s, ' SELECT * FROM siat.ordencompra%s WHERE idordencompra = %s;');"; 
	
	static final String queryGetRequisicionAnio = "SELECT * FROM OPENQUERY (%s, ' SELECT * FROM siat.requisicion%s WHERE idrequisicion = %s;');"; 

	static final String queryGetCuerpoDetalle = "SELECT * FROM OPENQUERY (%s, ' SELECT idrefaccion, idrequisicion, cantrequisicion, cantordenada, cantfacturada, cantentrada FROM siat.cuerpodetalle WHERE idrequisicion = %s;');"; 

	static final String queryGetCuerpoDetalleRefaccion = "SELECT * FROM OPENQUERY (%s, ' SELECT * FROM siat.cuerpodetalle WHERE idrequisicion = %s AND idrefaccion = %s;');"; 

	static final String queryGetCantidadCuerpoOrden = "SELECT * FROM OPENQUERY (%s, ' SELECT cantsolicitada AS total FROM siat.cuerpoorden%s WHERE idordencompra = %s AND idrefaccion = %s;');"; 

	static final String queryGetTipoCambioDiaCurso = "SELECT * FROM OPENQUERY (%s, ' SELECT doficial FROM siat.tipocambio WHERE idmoneda = %s ORDER BY fecha DESC LIMIT 1');"; 
	
	static final String queryGetFacturaOrden = "SELECT * FROM OPENQUERY (%s, ' SELECT f.idfacturaorden,f.idordencompra,f.factura,f.subtotal,f.descuento,f.iva,f.retencion,f.total,f.idproveedor,f.observaciones,f.idestatus,f.idpersonal,f.fecha,f.hora,f.esfactura,IF(DATE(f.fechavencimiento) = \"0000-00-00\",\"1900-02-01\", date_format(f.fechavencimiento,\"%%Y-%%m-%%d\")) AS fechavencimiento,f.contrarecibo,f.repuestocon,f.sepagara,f.idmonedafactura,f.idmonedacontrarecibo,f.tipocambio,IF(DATE(f.fechamod) = \"0000-00-00\", \"1900-02-01\", date_format(f.fechamod,\"%%Y-%%m-%%d\")) AS fechamod, p.razonsocial FROM siat.facturasorden f LEFT JOIN siat.proveedores p ON p.idproveedor = f.idproveedor WHERE f.idfacturaorden = %s;');";

	static final String queryGetFolioAlmacen = "SELECT * FROM OPENQUERY (%s, ' SELECT * FROM siat.foliosalmacen WHERE tipofolio = %s AND idalmacen = %s;');"; 

	static final String queryGetControlTipoCambio = "SELECT * FROM OPENQUERY (%s, ' SELECT idproveedor, controltipocambio, tipocambio FROM siat.proveedores WHERE idproveedor = %s;');"; 

	static final String queryGetCuerpoFactura = "SELECT * FROM OPENQUERY (%s, ' SELECT idrefaccion, idfacturaorden, cantidad,precio, porc_iva, porc_retencion FROM siat.cuerpofactura WHERE idfacturaorden = %s;');"; 

	static final String queryGetInformacioRefaccion = "SELECT * FROM OPENQUERY (%s, ' SELECT idrefaccion, clave, nombre, tiporef, idgrupo,minimo, maximo, pvmn, pvd, existencia, pcmn, pcd, esnueva FROM siat.refacciones WHERE idrefaccion = %s;');"; 

	static final String queryInsertControlEntrada = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.controlentrada' ) VALUES('%s','%s','%s','%s','%s','%s')";

	static final String queryGetFolio = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.folios WHERE tipofolio = %s;');";  

	static final String queryInsertFolio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.folios WHERE tipofolio = %s' ) SET tipofolio = '%s', idfolio = '%s', clavefolio = '%s', descripcion = '%s'   ";

	static final String queryInsertFolioAlmacen = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.foliosalmacen WHERE tipofolio = %s AND idalmacen = %s' ) SET tipofolio = '%s', clavefolio = '%s', descripcion = '%s', idalmacen = '%s'  ";

	static final String queryGetRefaProveedor = "SELECT * FROM OPENQUERY (%s, 'SELECT pcd AS total FROM siat.refaproveedor WHERE idproveedor = %s AND idrefaccion = %s;');";
	
	static final String queryGetValorParamGen = "SELECT * FROM OPENQUERY (%s, 'SELECT valor  AS descripcion FROM siat.parametrosgenerales WHERE idparametro= %s');";

	static final String queryGetValorParametros = "SELECT * FROM OPENQUERY (%s, 'SELECT valor  AS descripcion FROM siat.parametros WHERE idparametro= %s');";
	
	static final String queryGetValorParametrosNombre = "SELECT * FROM OPENQUERY (%s, 'SELECT nombre  AS descripcion FROM siat.parametros WHERE idparametro= %s');";
	
	static final String queryGetTipoSolicitud = "SELECT * FROM OPENQUERY (%s, 'SELECT tiposolicitud, tabla FROM siat.requisiciones WHERE idrequisicion= %s');";

	static final String queryGetNombreMoneda = "SELECT * FROM OPENQUERY (%s, 'SELECT nombre AS descripcion FROM personal.moneda WHERE idmoneda= %s');";

	static final String queryGetCantidadesEntradas = "SELECT * FROM OPENQUERY (%s, 'SELECT k.idrefaccion, SUM(k.cantidad) AS cantidad FROM siat.entradas%s e INNER JOIN siat.kardex k ON e.identrada = k.nomovimiento AND k.tipomovimiento = 1 WHERE e.idestatus = 1 AND e.tipo = 1 AND e.idordencompra = %s GROUP BY k.idrefaccion ORDER BY k.idrefaccion');";

	static final String queryGetTipoAutorizacion = "SELECT * FROM OPENQUERY (%s, 'SELECT idtipoautorizacion, tipoautorizacion, permisopedido FROM siat.tipoautorizacion WHERE idtipoautorizacion = %s;');";

	static final String queryInsertEntradas = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.entradas' ) VALUES('%s','%s','%s','%s','%s')";

	static final String queryGetControlIncrementoMaquila = "SELECT * FROM OPENQUERY (%s, 'SELECT idrefaccion AS descripcion FROM siat.controlincrementomaquila WHERE idpersonalautoriza = 0');";

	static final String queryGetConvenioRefaccion = "SELECT * FROM OPENQUERY (%s, 'SELECT idconvenio AS descripcion FROM siat.cuerpoconvenio WHERE idrefaccion = %s;');";

	static final String queryGetConvenioRefaccionDetallado = "SELECT * FROM OPENQUERY (%s, 'SELECT c.estatus, r.clave, r.nombre, r.existencia, cc.cantidad FROM siat.convenios c, siat.cuerpoconvenio cc, siat.refacciones r WHERE cc.idconvenio=c.idconvenio AND cc.idrefaccion=r.idrefaccion AND c.estatus>0 AND cc.idrefaccion= %s;');";

	static final String queryInsertEntradasAnio = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.entradas%s' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryInsertLotes = "EXEC('INSERT INTO siat.lotes VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\")') AT %s";

	static final String queryInsertKardex = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.kardex' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryGetEsFactura = "SELECT * FROM OPENQUERY (%s, 'SELECT esfactura AS descripcion FROM siat.facturasorden WHERE idfacturaorden = %s;');";
	
	static final String queryGetDetalleEntradaConsignacion = "SELECT * FROM OPENQUERY (%s, 'SELECT ref.idgrupo, (ROUND(kar.cantidad * kar.precio,4)) AS SUBTOTAL, 0 AS IVA, (ROUND(kar.cantidad*kar.precio,4)) AS TOTAL, kar.idrefaccion, kar.fecha, kar.hora, kar.idalmacen FROM siat.refacciones ref, siat.entradas%s ent, siat.kardex kar, siat.proveedores prov, siat.refacciones_por_almacen ra WHERE ent.identrada = %s AND ra.idalmacen = %s AND ref.idrefaccion = ra.idrefaccion AND kar.idrefaccion = ref.idrefaccion AND kar.idproveedor = ent.idproveedor AND prov.idproveedor = ent.idproveedor AND kar.tipomovimiento = 1 AND kar.nomovimiento = ent.identrada AND kar.tipo = 2;');";

	static final String queryGetImporteFactura = "SELECT * FROM OPENQUERY (%s, 'SELECT kar.hora,ref.idgrupo, (ROUND(kar.cantidad * kar.precio,4)) AS subtotal, IF(ref.aplicaiva > 0, (ROUND((ROUND((kar.cantidad*kar.precio),4) * ROUND(0.16,4)),4)), 0) AS iva, IF(ref.aplicaiva > 0, (IF(0.16 > 0, (ROUND((kar.cantidad*kar.precio),4) + ROUND((ROUND((kar.cantidad*kar.precio), 4) * ROUND(0.16,4)),4)), (ROUND(kar.cantidad*kar.precio,4)))), (ROUND(kar.cantidad*kar.precio,4))) AS total, kar.idrefaccion, kar.fecha, kar.idalmacen FROM siat.refacciones ref, siat.entradas%s ent, siat.kardex kar, siat.proveedores prov, siat.refacciones_por_almacen ra WHERE ent.identrada = %s  AND ra.idalmacen = %s AND ref.idrefaccion = ra.idrefaccion AND kar.idrefaccion = ref.idrefaccion AND kar.idproveedor = ent.idproveedor AND prov.idproveedor = ent.idproveedor AND kar.tipomovimiento = 1 AND kar.nomovimiento = ent.identrada AND kar.tipo = 1;');";

	static final String queryGetImporteRemision = "SELECT * FROM OPENQUERY (%s, 'SELECT kar.hora, ref.idgrupo,(ROUND(kar.cantidad * kar.precio,4)) AS subtotal, 0.00 AS iva, (ROUND(kar.cantidad * kar.precio,4)) AS total, kar.idrefaccion, kar.fecha, kar.idalmacen FROM siat.refacciones ref, siat.entradas%s ent, siat.kardex kar, siat.proveedores prov, siat.refacciones_por_almacen ra WHERE ent.identrada = %s AND ra.idalmacen = %s AND ref.idrefaccion = ra.idrefaccion AND kar.idrefaccion = ref.idrefaccion AND kar.idproveedor = ent.idproveedor  AND prov.idproveedor = ent.idproveedor AND kar.tipomovimiento = 1 AND kar.nomovimiento = ent.identrada AND kar.tipo = 1;');";

	static final String queryGetMaxLotes = "SELECT * FROM OPENQUERY (%s, 'SELECT MAX(idlote) AS identrada FROM siat.lotes;');";

	static final String queryInsertDetalleEntrada = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.detalleentrada' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryGetInfRefaproveedor = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.refaproveedor WHERE idrefaccion = %s AND idproveedor = %s;');";

	static final String queryGetRefPorAlmacen = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.refacciones_por_almacen WHERE idrefaccion = %s AND idalmacen = %s;');";

	static final String queryGetConvenioInf = "SELECT * FROM OPENQUERY (%s, 'SELECT c.idconvenio,c.tipoconvenio FROM siat.cuerpoconvenio cp, siat.convenios c WHERE cp.idconvenio = c.idconvenio AND cp.idrefaccion = %s AND c.estatus = 1;');";

	static final String queryUpdateRefaProveedor = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.refaproveedor WHERE idrefaccion = %s AND idproveedor = %s' ) SET idrefaccion = '%s', idproveedor = '%s', existencia = '%s', dias = '%s', pcmn = '%s', pcd = '%s', opcion = '%s', estatus = '%s', idpersonal = '%s', fecha = '%s', hora = '%s'  ";

	static final String queryUpdateRefaPorAlmacen = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.refacciones_por_almacen WHERE idrefaccion = %s AND idalmacen = %s' ) SET idrefaccion = '%s', idalmacen = '%s', existencia = '%s', rack = '%s', fila = '%s', renglon = '%s', idpersonal = '%s', fechahoramod = '%s', minimo = '%s', maximo = '%s', estatus = '%s', puntoreorden = '%s'  ";

	static final String queryUpdateRefacciones = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.refacciones WHERE idrefaccion = %s' ) SET existencia = '%s', minimo = '%s',maximo = '%s',pcmn = '%s', pcd = '%s', pvmn = '%s', pvd = '%s'";
	
	static final String queryUpdatePrecioLlantas = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.llantas WHERE idrefaccion = %s AND idestatus IN (19,20)' ) SET precio = '%s'";
	
	static final String queryUpdateSaldoConvenio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.convenios WHERE idconvenio = %s' ) SET saldo_total = '%s'";

	static final String queryUpdateCuerpoConvenio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.cuerpoconvenio WHERE idrefaccion = %s AND idconvenio = %s' ) SET pcmn = '%s'";

	static final String queryUpdateFactursaOrden = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.facturasorden WHERE idfacturaorden = %s' ) SET idestatus = '%s'";

	static final String queryGetCuerpoOrdenAnio = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.cuerpoorden%s WHERE idrefaccion = %s AND idordencompra = %s;');";
	
	static final String queryGetCuerpoOrden = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.cuerpoorden%s WHERE idordencompra = %s;');";
	
	static final String queryUpdateCuerpoOrdenAnio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.cuerpoorden%s WHERE idrefaccion = %s AND idordencompra = %s' ) SET cantsolicitada = '%s', precio = '%s', idestatus = '%s', porc_iva = '%s', porc_retencion = '%s', idconvenio = '%s'";

	static final String queryUpdateOrdenCompraAnio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.ordencompra%s WHERE idrequisicion = %s AND idordencompra = %s' ) SET idestatus = '%s', observaciones = '%s', subtotal = '%s', iva = '%s', retencion = '%s', total = '%s', idmoneda = '%s', idpersonal = '%s'";

	static final String queryUpdateOrdenes = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.ordenes WHERE idordencompra = %s' ) SET  idestatus = '%s'";

	static final String queryGetCuerpoRequisicionAnio = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.cuerporequisicion%s WHERE idrequisicion = %s AND idrefaccion = %s;');";

	static final String queryUpdateCuerpoRequisicionAnio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.cuerporequisicion%s WHERE idrequisicion = %s AND idrefaccion = %s' ) SET idmedida = '%s', cantsolicitada = '%s', tiposolicitud = '%s', idestatus = '%s'";

	static final String queryUpdateRequisicionAnio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.requisicion%s WHERE idrequisicion = %s' ) SET  observaciones = '%s', idurgencia = '%s', idestatus = '%s', idalmacen = '%s', idautoriza = '%s', idreviso = '%s', esnueva = '%s', idpersonal = '%s'";

	static final String queryInsertRequisicionHistorico = "EXEC('INSERT INTO siat.requisicionhistorico VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\")') AT %s";

	static final String queryUpdateCuerpoDetalle = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.cuerpodetalle WHERE idrequisicion = %s AND idrefaccion = %s' ) SET  cantrequisicion = '%s', cantordenada = '%s', cantfacturada = '%s', cantentrada = '%s'";

	static final String queryInsertAutorizaciones = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.autorizaciones' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryUpdateCuerpoConvenioSaldo = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.cuerpoconvenio WHERE idrefaccion = %s AND idconvenio = %s' ) SET saldo = '%s'";

	static final String queryGetInfoConvenio = "SELECT * FROM OPENQUERY (%s, 'SELECT c.idconvenio AS descripcion FROM siat.convenios c WHERE c.idconvenio = 1 AND c.idconvenio IN (SELECT DISTINCT (cc.idconvenio) FROM siat.cuerpoconvenio cc WHERE cc.idrefaccion = %s AND c.estatus = 1); ');";

	static final String queryGetBancoProveedor = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.bancoproveedor WHERE idproveedor = %s ORDER BY idbancoproveedor DESC LIMIT 1;');";

	static final String queryGetContraRecibo = "SELECT * FROM OPENQUERY (%s, 'SELECT MAX(idcontrarecibo) AS ultimoid,  MAX(CAST(folio AS UNSIGNED INT)) AS ultimofolio FROM siat.contrarecibo;');";

	static final String queryInsertContraRecibo = "INSERT INTO OPENQUERY(" + DB_13 + ", 'SELECT * FROM siat.contrarecibo' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryGetContraReciboInfo = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.contrarecibo WHERE idcontrarecibo = %s;');";

	static final String queryGetContraReciboFact = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.contrarecibo WHERE idfacturaorden = %s;');";
	
	static final String queryGetRptContraReciboFact = "SELECT * FROM OPENQUERY (%s, 'SELECT co.idcontrarecibo AS numero, fo.factura AS remision, co.fechaparapago AS fecha2, co.subtotal AS subtotal, co.iva AS iva, co.retencion AS retencion, co.total AS total, co.idproveedor AS idproveedor, co.idmoneda AS moneda, co.impresion, co.idfacturaorden, p.razonsocial FROM siat.contrarecibo co, siat.facturasorden fo, siat.proveedores p WHERE fo.idfacturaorden = co.idfacturaorden AND co.idproveedor = p.idproveedor AND co.idfacturaorden = %s;');";

	static final String queryGetRptContraRecibo = "SELECT * FROM OPENQUERY (%s, 'SELECT co.idcontrarecibo AS numero ,0 AS remision, \"\" AS fecha2, co.subtotal AS subtotal, co.iva AS iva, co.retencion AS retencion, co.total AS total, co.idproveedor AS idproveedor, co.idmoneda AS moneda, co.impresion, co.idfacturaorden, p.razonsocial FROM siat.contrarecibo co LEFT JOIN siat.proveedores p ON p.idproveedor = co.idproveedor WHERE co.idcontrarecibo =  %s;');";

	static final String queryGetEntradas = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.entradas WHERE identrada = %s AND tipoentrada = %s;');";

	static final String queryGetValoresEntradas = "SELECT * FROM OPENQUERY (%s, 'SELECT fo.total,fo.iva FROM siat.entradas ent, siat.entradas%s ent1,siat.facturasorden fo WHERE ent.identrada=ent1.identrada AND ent.tipoentrada=ent1.tipo AND ent1.idfacturaorden=fo.idfacturaorden AND ent.identrada= %s AND ent.tipoentrada= %s;');";

	static final String queryGetFacturasOrdenInfo = "SELECT * FROM OPENQUERY (%s, 'SELECT f.idfacturaorden, f.idordencompra, f.factura, f.subtotal, f.descuento, f.iva, f.retencion, f.total, f.idproveedor, f.observaciones, f.idestatus, f.idpersonal, IF(DATE(f.fecha) = DATE(\"0000-00-00\"), \"1900-00-00\", date_format(f.fecha,\"%%Y-%%m-%%d\")) AS fecha, f.hora, f.esfactura, IF(DATE(f.fechavencimiento) = DATE(\"0000-00-00\"), \"1900-00-00\", date_format(f.fechavencimiento,\"%%Y-%%m-%%d\")) AS fechavencimiento, f.contrarecibo, f.repuestocon, f.sepagara, f.idmonedafactura, f.idmonedacontrarecibo, IF(f.tipocambio != NULL, CAST(f.tipocambio AS CHAR), \"0\") AS tipocambio, IF(DATE(f.fechamod) = DATE(\"0000-00-00\"), \"1900-00-00\", date_format(f.fechamod,\"%%Y-%%m-%%d\")) AS fechamod, p.razonsocial FROM siat.facturasorden f LEFT JOIN siat.proveedores p ON p.idproveedor = f.idproveedor WHERE f.idordencompra = %s  AND f.idfacturaorden = %s;');";

	static final String queryGetEntradasAnio = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.entradas%s WHERE identrada = %s AND tipo = %s;');";

	static final String queryGetKardex = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.kardex WHERE tipomovimiento = %s AND nomovimiento = %s AND tipo = %s;');";

	static final String queryGetKardexPrecio = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.kardex WHERE idrefaccion = %s AND nomovimiento = %s;');";

	static final String queryDeleteTempoliza = "DELETE OPENQUERY(%s, 'SELECT * FROM siat.tempoliza');";
	
	static final String queryGetTempolizaInsert = "SELECT * FROM OPENQUERY (%s, 'SELECT g.clave, g.idgrupo, ga.cuenta, CAST(SUM(k.cantidad * k.precio)AS DECIMAL(38,6)) AS subtotal, CAST(SUM(k.cantidad * k.precio * %s)AS DECIMAL(38,6)) AS iva, CAST(SUM(k.cantidad * k.precio * %s)AS DECIMAL(38,6)) AS total, k.idrefaccion, k.fecha, k.hora, k.idalmacen FROM siat.kardex AS k, siat.refacciones AS r, siat.grupos AS g, siat.gruposalmacen AS ga  WHERE k.idrefaccion = r.idrefaccion AND g.idgrupo = r.idgrupo  AND k.tipomovimiento = %s AND k.nomovimiento = %s AND tipo = %s AND g.idgrupo = ga.idgrupo AND k.idalmacen = ga.idalmacen  GROUP BY k.idrefaccion;');";

	static final String queryGetTempolizaInsert2 = "SELECT * FROM OPENQUERY (%s, 'SELECT g.clave, g.idgrupo, ga.cuenta, SUM(det.subtotal) AS subtotal, SUM(det.iva) AS iva, SUM(det.total) AS total, det.idrefaccion, det.fecha, det.hora, det.idalmacen FROM  siat.detalleentrada det, siat.grupos g, siat.gruposalmacen ga  WHERE g.idgrupo = det.idgrupo  AND det.identrada =  %s AND det.tipo =  %s AND g.idgrupo = ga.idgrupo AND det.idalmacen = ga.idalmacen  GROUP BY det.idrefaccion;');";

	static final String queryInsertTempoliza = "EXEC('INSERT INTO siat.tempoliza VALUES(\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\")') AT %s";

	static final String queryGetIva = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.iva where idiva= %s');";
	
	static final String queryGetTempoliza = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.tempoliza');";

	static final String queryGetTraspasosGrupos = "SELECT * FROM OPENQUERY (%s, 'SELECT t.idtraspasogrupos, t.idgruposalida, t.idgrupoentrada, t.observaciones, t.idpersonal, t.fecha, t.hora FROM siat.traspasogrupos t, siat.cuerpotraspasogrupos ctg WHERE t.idtraspasogrupos = ctg.idtraspasogrupos AND ctg.idrefaccion =  %s AND CONCAT_WS(\" \", fecha, hora) > CONCAT_WS(\" \", \"%s\", \"%s\") LIMIT 1; ');";
	
	static final String queryGetGruposAlmacen = "SELECT * FROM OPENQUERY (%s, 'SELECT cuenta AS descripcion FROM siat.gruposalmacen WHERE idgrupo = %s AND idalmacen = %s;');";

	static final String queryUpdateTempoliza = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.tempoliza WHERE idrefaccion = %s AND fecha = \"%s\" AND hora = \"%s\"' ) SET clave = '%s',idgrupo = '%s',cuenta = '%s',subtotal = '%s',iva = '%s',total = '%s',idrefaccion = '%s',fecha = '%s',hora = '%s',idalmacen = '%s'";

	static final String queryGetTempolizaRefaccion = "SELECT * FROM OPENQUERY (%s, 'SELECT clave, idgrupo, cuenta, SUM(subtotal) AS subtotal, SUM(iva) AS iva, SUM(total) AS total,idrefaccion FROM siat.tempoliza GROUP BY idgrupo;');";
	
	static final String queryGetKardexRefaccion = "SELECT * FROM OPENQUERY (%s, 'SELECT k.idrefaccion, k.fecha, k.hora, k.precio FROM siat.kardex AS k, siat.refacciones AS r, siat.grupos AS g WHERE k.idrefaccion = r.idrefaccion AND r.idgrupo = g.idgrupo AND k.nomovimiento = %s AND k.tipo = %s AND k.tipomovimiento = 1 AND r.idgrupo = %s;');";

	static final String queryGetKardexMovimiento = "SELECT * FROM OPENQUERY (%s, 'SELECT idrefaccion, nomovimiento, precio, fecha FROM siat.kardex WHERE idrefaccion = %s AND CONCAT_WS(\" \",fecha,hora)< \"%s\" + \"%s\" ORDER BY CONCAT_WS(\" \",fecha,hora) DESC LIMIT 1;');";

	static final String queryGetAlmacenes = "SELECT * FROM OPENQUERY (%s, 'SELECT idalmacen, nombre, estatus, idpersonal, fecha,hora, idtaller, IF(horainicio = NULL,horainicio,  \"01:01:01\") AS horainicio, IF(horafin = NULL, horafin, \"01:01:01\") AS horafin FROM siat.almacen WHERE idalmacen > 0;');";

	static final String queryGetSumCantKardex = "SELECT * FROM OPENQUERY (%s, 'SELECT (CAST(SUM(IF(tipomovimiento = 1, cantidad, 0))AS DECIMAL(36,2)) - CAST(SUM(IF(tipomovimiento = 2, cantidad, 0))AS DECIMAL(36,2))) AS total FROM siat.kardex WHERE idrefaccion = %s AND CONCAT_WS(\" \",fecha,hora)< \"%s\" + \"%s\"  AND idalmacen = %s GROUP BY idrefaccion ORDER BY fecha, hora;');";

	static final String queryGetFacturaOrdenAnticipo = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.facturasordenanticipo WHERE idfacturaorden = %s;');";
	
	static final String queryGetIdPoliza = "SELECT * FROM OPENQUERY (%s, 'SELECT idpoliza AS descripcion FROM conta_taller.polizas%s WHERE numpoliza = %s AND idtipopol =%s;');";

	static final String queryGetMaxPoliza = "SELECT * FROM OPENQUERY (%s, 'SELECT MAX(idpoliza) AS descripcion FROM conta_taller.polizas%s;');";

	static final String queryInsertPolizaAnio = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM conta_taller.polizas%s' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryInsertPoliza = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM conta_taller.polizas' ) VALUES('%s','%s','%s','%s','%s','%s')";

	static final String queryInsertMovimientos = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM conta_taller.movimientos%s' ) VALUES('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryUpdateCatCuentasAnio = "UPDATE OPENQUERY(%s, 'SELECT * FROM conta_taller.catcuentas%s WHERE idcuenta = %s' ) SET cargos%s = cargos%s + '%s'";

	static final String queryUpdateCatCuentasAbono = "UPDATE OPENQUERY(%s, 'SELECT * FROM conta_taller.catcuentas%s WHERE idcuenta = %s' ) SET abonos%s = abonos%s + '%s'";

	static final String queryGetCatCuentas = "SELECT * FROM OPENQUERY (%s, 'SELECT cargos%s AS descripcion FROM conta_taller.catcuentas%s WHERE idcuenta = %s;');";

	static final String queryGetCatCuentasAbonos = "SELECT * FROM OPENQUERY (%s, 'SELECT abonos%s AS descripcion FROM conta_taller.catcuentas%s WHERE idcuenta = %s;');";
	
	static final String queryUpdateResumenCompra = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.resumencompra WHERE idrefaccion = %s' ) SET idproveedor = '%s', nombreproveedor = '%s', identrada = '%s', idordencompra = '%s', idmoneda = '%s', fechaultimacompra = '%s', pcmn = '%s', pcd = '%s'";
	
	static final String queryGetResumenCompra = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.resumencompra WHERE idrefaccion = %s;');";

	static final String queryGetResumeImpresion = "SELECT * FROM OPENQUERY (%s, 'SELECT ent.claveentrada AS noentrada,  ent.fecha AS fechaent,  fo.fecha AS fechafact, est.nombre AS estatus, ent.idordencompra AS noorden,  fo.factura AS factura,  ELT(ent.tipo, \"EAO\",\"EAC\",\"EAD\",\"EAI\",\"\",\"EVR\",\"ESV\", \"EOF\",\"EAU\") AS tipo, req.clave AS norequisicion,  LTRIM(CONCAT_WS(\" \", prov.apepaterno, prov.apematerno, prov.nombre,prov.razonsocial)) AS proveedor,  ent.observaciones AS observaciones, ELT(ent.tipo, \"Entrada por orden de compra \", \"Entrada por convenio\", \"Entrada por devolucion\", \"Entrada por Inventario\") AS tipoentrada, a.impresion, a.identrada,  IF(fo.contrarecibo = 0, IF(fo.sepagara=0,\"ENTRADAS DE ALMACEN CON REMISION\",\"ENTRADAS DE ALMACEN POR FACTURAR\" ),\"ENTRADAS DE ALMACEN\") AS tituloentrada, alm.nombre almacen,ent.idpersonal,ref.clave AS clave, ref.nombre AS producto, CASE WHEN ref.esnueva = 0 THEN \"NO\" WHEN ref.esnueva = 1 THEN  \"SI\" END AS esnueva, ra.existencia AS existencias, kar.cantidad AS cantidad, kar.precio AS precio, ROUND(kar.cantidad * kar.precio,4) AS subtotal, 0.00 AS iva,  ROUND(kar.cantidad * kar.precio,4) AS total FROM siat.entradas%s ent INNER JOIN siat.facturasorden fo ON ent.idfacturaorden = fo.idfacturaorden  INNER JOIN siat.estatus est ON est.idestatus = ent.idestatus AND est.tipo = ent.tipo INNER JOIN siat.ordencompra%s oc ON fo.idordencompra = oc.idordencompra INNER JOIN siat.requisicion%s req ON req.idrequisicion = oc.idrequisicion INNER JOIN siat.proveedores prov ON ent.idproveedor  = prov.idproveedor  INNER JOIN siat.entradas a ON a.identrada  = ent.identrada  INNER JOIN siat.almacen alm  ON ent.idalmacen = alm.idalmacen INNER JOIN siat.refacciones_por_almacen ra ON ent.idalmacen = ra.idalmacen INNER JOIN siat.refacciones ref ON ref.idrefaccion = ra.idrefaccion  INNER JOIN siat.kardex kar ON kar.idrefaccion = ref.idrefaccion AND kar.idproveedor = ent.idproveedor AND kar.tipomovimiento = 1  AND kar.nomovimiento = ent.identrada AND kar.tipo= %s WHERE ent.fecha BETWEEN \"%s\" AND \"%s\"  AND ent.tipo = %s %s;');";

	static final String queryGetKardexInformacion = "SELECT * FROM OPENQUERY (%s, 'SELECT r.clave, r.nombre, k.esnueva, k.cantidad, k.precio, k.idrefaccion, p.nombre AS nombreproveedor, k.idproveedor, k.idlote, k.idalmacen, r.idgrupo FROM siat.kardex k, siat.proveedores p ,siat.refacciones r WHERE r.idrefaccion = k.idrefaccion AND p.idproveedor = k.idproveedor AND k.nomovimiento = %s AND k.tipomovimiento = %s AND k.tipo = %s ORDER BY k.fecha ASC, k.hora ASC');";

	static final String queryGetEntradasFecha = "SELECT  *, CAST(MONTH(fecha) AS VARCHAR(2)) + CAST(YEAR(fecha) AS VARCHAR(4)) AS fechapol FROM OPENQUERY (%s, 'SELECT claveentrada, fecha, tipo FROM siat.entradas%s  WHERE identrada = %s AND tipo = %s;');";

	static final String queryGetTotalMovimientos = "SELECT * FROM OPENQUERY (%s, 'SELECT COUNT(*) AS descripcion FROM conta_taller.movimientos%s WHERE idpoliza = %s AND anio IS NOT NULL');";

	static final String queryDeletePoliza = "DELETE OPENQUERY(%s, 'SELECT * FROM conta_taller.polizas WHERE idpoliza = %s AND tabla = %s AND idtipopol = %s;');";
	
	static final String queryDeletePolizaAnio = "DELETE OPENQUERY(%s, 'SELECT * FROM conta_taller.polizas%s WHERE idpoliza = %s AND idtipopol = %s;');";

	static final String queryDeleteMovimientosAnio = "DELETE OPENQUERY(%s, 'SELECT * FROM conta_taller.movimientos%s WHERE idpoliza = %s;');";

	static final String queryGetRptEntradaConsultar = "SELECT * FROM OPENQUERY (%s,'SELECT ent.claveentrada AS noentrada, ent.fecha AS fechaent, fo.fecha AS fechafact, est.nombre AS estatus, ent.idordencompra AS noorden, fo.factura AS factura, ELT(ent.tipo, \"EAO\",\"EAC\",\"EAD\",\"EAI\",\"\",\"EVR\",\"ESV\",\"EOF\",\"EAU\") AS tipo, req.clave AS norequisicion, LTRIM(CONCAT_WS(\" \", prov.apepaterno, prov.apematerno, prov.nombre,prov.razonsocial)) AS proveedor, ent.observaciones AS observaciones, ELT(ent.tipo, \"Entrada por orden de compra \", \"Entrada por convenio\", \"Entrada por devolucion\", \"Entrada por Inventario\") AS tipoentrada, a.impresion, a.identrada, IF(fo.contrarecibo = 0, IF(fo.sepagara=0,\"ENTRADAS DE ALMACEN CON REMISION\",\"ENTRADAS DE ALMACEN POR FACTURAR\" ), \"ENTRADAS DE ALMACEN\") AS tituloentrada, alm.nombre almacen,ent.hora AS horaent, tc.doficial AS tipocambio FROM siat.entradas%s ent, siat.facturasorden fo, siat.estatus est, siat.requisicion%s req, siat.ordencompra%s oc, siat.proveedores prov, siat.entradas a, siat.almacen alm, siat.tipocambio tc WHERE  ent.identrada = %s AND  ent.tipo = %s AND est.idestatus = ent.idestatus  AND est.tipo = ent.tipo AND ent.idfacturaorden = fo.idfacturaorden AND fo.idordencompra = oc.idordencompra AND req.idrequisicion = oc.idrequisicion AND ent.idproveedor  = prov.idproveedor AND a.identrada  = ent.identrada  AND tc.fecha=ent.fecha AND ent.idalmacen = alm.idalmacen;')";
	
	static final String queryGetRptEntradaFacturaConsultar = "SELECT * FROM OPENQUERY (%s,'SELECT ref.clave AS clave, ref.nombre AS producto, CASE ref.esnueva WHEN 0 THEN \"NO\" WHEN 1 THEN \"SI\" END AS nueva, ra.existencia AS existencias, kar.cantidad AS cantidad, kar.precio  AS precio, ROUND(kar.cantidad * kar.precio,2) AS subtotal,IF (ref.aplicaiva > 0, (CAST(((kar.cantidad*kar.precio)) * ((porc_iva))AS DECIMAL(38,4))),2) AS iva, IF(ref.aplicaiva >0, (IF ((porc_iva) > 0,CAST(CAST((kar.cantidad * kar.precio)AS DECIMAL(38,2)) + CAST((kar.cantidad*kar.precio)*(porc_iva)AS DECIMAL(38,2))AS DECIMAL(38,2)), CAST((kar.cantidad*kar.precio)AS DECIMAL(38,2)))), CAST((kar.cantidad*kar.precio)AS DECIMAL(38,2))) AS total, tc.doficial AS tipocambio FROM siat.refacciones ref, siat.entradas%s ent, siat.kardex kar, siat.proveedores prov, siat.refacciones_por_almacen ra, siat.tipocambio tc WHERE ent.identrada = %s AND ra.idalmacen = %s AND ref.idrefaccion = ra.idrefaccion AND kar.idrefaccion = ref.idrefaccion AND kar.idproveedor = ent.idproveedor AND prov.idproveedor = ent.idproveedor AND kar.tipomovimiento = 1 AND kar.nomovimiento = ent.identrada AND tc.fecha=ent.fecha  AND kar.tipo= %s')";
	
	static final String queryGetRptEntradaRemisionConsultar = "SELECT * FROM OPENQUERY (%s,'SELECT ref.clave AS clave, ref.nombre AS producto, CASE ref.esnueva WHEN 0 THEN \"NO\" WHEN 1 THEN \"SI\" END AS nueva, ra.existencia AS existencias, kar.cantidad AS cantidad, kar.precio AS precio, ROUND(kar.cantidad * kar.precio,4) AS subtotal, 0.00 AS iva, ROUND(kar.cantidad * kar.precio,4) AS total,tc.doficial AS tipocambio FROM siat.refacciones ref, siat.entradas%s ent, siat.kardex kar, siat.proveedores prov, siat.refacciones_por_almacen ra, siat.tipocambio tc WHERE ent.identrada = %s AND ra.idalmacen = %s AND ref.idrefaccion = ra.idrefaccion  AND kar.idrefaccion = ref.idrefaccion AND kar.idproveedor = ent.idproveedor AND prov.idproveedor = ent.idproveedor AND kar.tipomovimiento = 1 AND kar.nomovimiento = ent.identrada AND tc.fecha=ent.fecha AND kar.tipo=%s;')";
	
	static final String queryGetConvenios = "SELECT * FROM OPENQUERY (%s,'SELECT * FROM siat.convenios WHERE idconvenio = %s')";
	
	static final String queryGetGridEntDevolucion = "SELECT * FROM OPENQUERY (%s,'SELECT DISTINCT(c.idconvenio), LTRIM(CONCAT_WS(\" \",p.apepaterno, p.apematerno, p.nombre, p.razonsocial)) AS proveedor FROM siat.convenios c LEFT JOIN siat.proveedores p ON c.idproveedor = p.idproveedor, siat.cuerpoconvenio cc WHERE c.idconvenio = cc.idconvenio AND c.tipoconvenio IN(2,4) AND c.estatus = 1 AND (cc.cantidad - cc.cantidad_surtida) > 0  ORDER BY 1;')";

	static final String queryGetRefaccionesPorSurtir = "SELECT * FROM OPENQUERY (%s,'SELECT r.clave, r.nombre, CASE r.esnueva WHEN 0 THEN \"N\" WHEN 1 THEN \"S\" END AS nueva, cc.cantidad, cc.pcmn, r.idrefaccion, r.existencia, (cc.cantidad - cc.cantidad_surtida) AS cantidad_surtir, cc.pcd, 1 AS uno, c.idproveedor, 0 AS cero, \"*\" AS ast, c.tipoconvenio FROM siat.cuerpoconvenio cc LEFT JOIN siat.refacciones r ON cc.idrefaccion = r.idrefaccion, siat.convenios c WHERE c.idconvenio = cc.idconvenio AND c.idconvenio = %s AND (cc.cantidad - cc.cantidad_surtida) > 0;')";

	static final String queryGetGrupos = "SELECT * FROM OPENQUERY (%s,'SELECT * FROM siat.grupos WHERE clave = %s;')";

	static final String queryGetGruposIdentificador = "SELECT * FROM OPENQUERY (%s,'SELECT * FROM siat.grupos WHERE idgrupo = %s;')";
	
	static final String queryGetCatCuentasAnio = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM conta_taller.catcuentas%s WHERE idcuenta = %s;');";
	
	static final String queryDeleteTemporal = "EXEC('TRUNCATE TABLE siat.tmprefacciones') AT %s";
	
	static final String queryInsertTemporal = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.tmprefacciones') VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s')";

	static final String queryGetGrupoTemporal = "SELECT * FROM OPENQUERY (%s, 'SELECT distinct(idgrupo) AS descripcion FROM siat.tmprefacciones');";
	
	static final String queryGetImporteTemporal = "SELECT * FROM OPENQUERY (%s, 'SELECT idgrupo,sum(pmn) AS pmn, (entrada * pmn) AS importe FROM siat.tmprefacciones GROUP BY (idgrupo)');";
	
	static final String queryGetSumPmnTemporal = "SELECT * FROM OPENQUERY (%s, 'SELECT sum(pmn) AS descripcion FROM siat.tmprefacciones');";

	/** creado por Gabriel Garcia E2024**/
	static final String queryGetProveedor = "SELECT * FROM OPENQUERY (%s, ' SELECT p.apepaterno, p.apematerno, p.nombre, p.razonsocial, p.idproveedor, p.porc_iva, p.porc_retencion, p.cuenta FROM siat.proveedores p WHERE idproveedor = %s;');"; 
	static final String queryGetListCuerpoConvenio = "SELECT * FROM OPENQUERY (%s, ' SELECT r.clave, r.nombre, cc.cantidad, (SELECT pcmn FROM siat.refaproveedor WHERE idproveedor = c.idproveedor AND idrefaccion = rp.idrefaccion) AS pcmn, cc.pcd, cantidad*cc.pcmn AS importe_pesos, cantidad*cc.pcd AS importe_dolares, cc.cantidad_surtida, r.existencia, rp.existencia AS existencia_proveedor, cc.saldo, cc.idrefaccion, rp.dias, rp.idproveedor, IFNULL(EnContrarecibo.piezas,0) AS piezas_en_contrarecibo, CASE WHEN CAST((cc.cantidad_surtida - r.existencia) - IFNULL(EnContrarecibo.piezas,0) AS DECIMAL(38,4)) > 0 THEN CAST((cc.cantidad_surtida - r.existencia) - IFNULL(EnContrarecibo.piezas,0) AS DECIMAL(38,4)) ELSE 0 END AS piezas_sin_contrarecibo, CASE WHEN ((cc.cantidad_surtida - r.existencia) - IFNULL(EnContrarecibo.piezas,0)) > 0 THEN CAST(TRUNCATE(CAST((cc.cantidad_surtida - r.existencia) - IFNULL(EnContrarecibo.piezas,0)AS DECIMAL(38,4)) * cc.pcmn, 4) AS DECIMAL(38,4)) ELSE 0 END AS saldo_mn, CASE WHEN ((cc.cantidad_surtida - r.existencia) - IFNULL(EnContrarecibo.piezas,0)) > 0 THEN CAST(TRUNCATE(CAST((cc.cantidad_surtida - r.existencia) - IFNULL(EnContrarecibo.piezas,0) AS DECIMAL(38,4)) * cc.pcd, 4)AS DECIMAL(38,4)) ELSE 0 END AS saldo_dlls FROM  siat.convenios c INNER JOIN  siat.cuerpoconvenio cc ON c.idconvenio = cc.idconvenio LEFT JOIN  siat.refacciones r ON cc.idrefaccion = r.idrefaccion LEFT JOIN  siat.refaproveedor rp ON c.idproveedor = rp.idproveedor AND cc.idrefaccion = rp.idrefaccion LEFT JOIN (SELECT crcv.idrefaccion, SUM(cf.cantidad) AS piezas FROM  siat.contrarecibo cr INNER JOIN  siat.contrarecibo_convenio crcv ON cr.idcontrarecibo = crcv.idcontrarecibo INNER JOIN  siat.facturasorden fo ON cr.idfacturaorden = fo.idfacturaorden INNER JOIN  siat.cuerpofactura cf ON fo.idfacturaorden = cf.idfacturaorden AND cf.idrefaccion = crcv.idrefaccion WHERE cr.idestatus <> 0 AND cr.tipo = 3 AND crcv.idestatus <> 0 AND fo.idestatus <> 0 AND crcv.idconvenio = %s GROUP BY crcv.idrefaccion) AS EnContrarecibo ON cc.idrefaccion = EnContrarecibo.idrefaccion WHERE c.idconvenio = %s ORDER BY r.nombre;');"; 
	static final String queryDeleteControlEntrada = "DELETE OPENQUERY(%s, 'SELECT * FROM siat.controlentrada ce WHERE ce.foliocontrol = %s AND ce.idpersonal = %s');";
	static final String queryGetCuerpoConvenio = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM siat.cuerpoconvenio WHERE idconvenio = %s AND idrefaccion = %s;');";
	static final String queryInsertHistoricoConvenio = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.historicodetaconvenio') VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";
	static final String queryInsertHistoricoCuerpoConvenio = "INSERT INTO OPENQUERY(%s, 'SELECT * FROM siat.histcuerpoconvenio') VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')";
	static final String queryUpdateExistenciaRefaProveedor = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.refaproveedor WHERE idrefaccion = %s AND idproveedor = %s' ) SET existencia = '%s' ";
	static final String queryUpdateDataCuerpoConvenio = "UPDATE OPENQUERY(%s, 'SELECT * FROM siat.cuerpoconvenio WHERE idrefaccion = %s AND idconvenio = %s' ) SET pcmn = '%s', cantidad_surtida = '%s'";
	static final String queryGetDataEntradaNormal = "SELECT * FROM OPENQUERY (%s, ' SELECT ent.identrada AS id_entrada,ent.clave,ent.tabla,ent.tipoentrada,ent.impresion, ent1.*,fo.total,fo.iva FROM siat.entradas ent, siat.entradas%s ent1,siat.facturasorden fo WHERE ent.identrada=ent1.identrada AND ent.tipoentrada=ent1.tipo AND ent1.idfacturaorden=fo.idfacturaorden AND ent.identrada= %s AND ent.tipoentrada= %s;');"; 
	static final String queryGetDataEntrada = "SELECT * FROM OPENQUERY (%s, ' SELECT ent.identrada AS id_entrada,ent.clave,ent.tabla,ent.tipoentrada,ent.impresion, ent1.* FROM siat.entradas ent, siat.entradas%s ent1 WHERE ent.identrada=ent1.identrada AND ent.tipoentrada=ent1.tipo AND ent.identrada= %s AND ent.tipoentrada= %s;');"; 
	
	/**
	 * getSemaforoSiat: obtiene el semaforo siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-04
	 */
	public List<SemaforoSiat> getSemaforo(int estatus) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetSemaforo,
						DB_13,
						estatus,
						utilitiesRepository.getDb13()),
						SemaforoSiat.class);

		return (List<SemaforoSiat>) query.getResultList();
	}
	
	/**
	 * getGridEntradas: obtiene el grid de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-07
	 */
	public List<GridEntradas> getGridEntradas(int anio, int mes, int idTaller, int almacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGridEntradas,
						DB_13,
						anio,
						anio,
						anio,
						anio,
						mes,
						idTaller,
						almacen,
						utilitiesRepository.getDb13()),
						GridEntradas.class);
		return (List<GridEntradas>) query.getResultList();
	}
	
	/**
	 * getGridEntradasPorAlmacen: obtiene el grid de entradas por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	public List<GridEntradas> getGridEntradasPorAlmacen(int anio, int mes, int tipoAlmacen) {
		String almacenesRef;
		if(tipoAlmacen == 1) {
			almacenesRef = AlmacenesCorpo;
		}else {
			almacenesRef = AlmacenesForaneos;
		}
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGridEntradasPorAlmacen,
						DB_13,
						anio,
						anio,
						anio,
						anio,
						mes, 
						almacenesRef,
						utilitiesRepository.getDb13()),
						GridEntradas.class);
		return (List<GridEntradas>) query.getResultList();
	}
	
	/**
	 * getCatalogoAlmacen: obtiene los almacenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	public List<CatalogoAlmacen> getAlmacen(int tipoAlmacen,String nomAlmacen) {
		String almacenesRef;
		if(tipoAlmacen == 1) {
			almacenesRef = AlmacenesCorpo;
		}else {
			almacenesRef = AlmacenesForaneos;
		}
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetAlmacen,
						DB_13,
						almacenesRef,
						"%"+nomAlmacen+"%",
						utilitiesRepository.getDb13()),
						CatalogoAlmacen.class);
		return (List<CatalogoAlmacen>) query.getResultList();
	}
	
	/**
	 * getGridFacuras: obtiene las facturas de compras
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	public List<GridFacturas> getGridFacturas(int anio,int mes) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGridFacturas,
						DB_13,
						anio,
						anio,
						mes,
						utilitiesRepository.getDb13()),
						GridFacturas.class);
		return (List<GridFacturas>) query.getResultList();
	}
	
	/**
	 * getGridFacurasAgrupadas: obtiene las facturas de compras agrupadas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	public List<GridFacturas> getGridFacturasAgrupadas(int anio,int mes) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGridFacturasAgrupadas,
						DB_13,
						anio,
						anio,
						mes,
						utilitiesRepository.getDb13()),
						GridFacturas.class);

		return (List<GridFacturas>) query.getResultList();
	}
	
	/**
	 * getValidacionEntrada: obtiene la validacion de entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	public List<ValidacionEntrada> getValidacionEntrada(int anio,int idFacturaOrden) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetValidacionEntrada,
						DB_13,
						anio,
						idFacturaOrden,
						utilitiesRepository.getDb13()),
						ValidacionEntrada.class);
		return (List<ValidacionEntrada>) query.getResultList();
	}
	
	/**
	 * queryGetTotalGrid: obtiene el total para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	public List<TotalGrid> getTotalGrid(int noMovimiento,int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTotalGrid,
						DB_13,
						noMovimiento,
						tipo,
						utilitiesRepository.getDb13()),
						TotalGrid.class);
		return (List<TotalGrid>) query.getResultList();
	}
	
	/**
	 * queryGetTotalOpcionGrid: obtiene el total para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	public List<TotalGrid> getTotalOpcionGrid(int noMovimiento,int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTotalOpcionGrid,
						DB_13,
						noMovimiento,
						tipo,
						utilitiesRepository.getDb13()),
						TotalGrid.class);
		return (List<TotalGrid>) query.getResultList();
	}
	
	/**
	 * queryGetRefaccionGrid: obtiene la idrefaccion para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	public List<IdRefaccionGrid> getRefaccionGrid(int noMovimiento,int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRefaccionGrid,
						DB_13,
						noMovimiento,
						tipo,
						utilitiesRepository.getDb13()),
						IdRefaccionGrid.class);
		return (List<IdRefaccionGrid>) query.getResultList();
	}
	
	/**
	 * queryGetCarroceriaGrid: obtiene la idrefaccion si es de carroceria
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	public List<IdRefaccionGrid> getCarroceriaGrid(String idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCarroceriaGrid,
						DB_13,
						idRefaccion,
						utilitiesRepository.getDb13()),
						IdRefaccionGrid.class);
		return (List<IdRefaccionGrid>) query.getResultList();
	}
	
	/**
	 * queryGetCarroceriaGrid: obtiene la idrefaccion si es de carroceria
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	public List<TipoCambio> getTipoCambio(String fecha) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTipoCambio,
						DB_13,
						fecha,
						utilitiesRepository.getDb13()),
						TipoCambio.class);
		return (List<TipoCambio>) query.getResultList();
	}
	
	/**
	 * getMotivo: obtiene la idrefaccion si es de carroceria
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-18
	 */
	public List<GetMotivo> getMotivo(int idMotivo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetMotivo,
						DB_13,
						idMotivo,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getTipoCambioCarroceria: obtiene el tipo cambio de carroceria
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-19
	 */
	public List<TipoCambio> getTipoCambioCarroceria() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTipoCambioCarroceria,
						DB_13,
						utilitiesRepository.getDb13()),
						TipoCambio.class);
		return (List<TipoCambio>) query.getResultList();
	}
	
	/**
	 * getAlmacenTraspaso: obtiene el almacen traspaso
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-20
	 */
	public List<AlmacenTranspasosPlazo> getAlmacenTraspaso(int idAlmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetAlmacenTraspasos,
						DB_13,
						idAlmacen,
						utilitiesRepository.getDb13()),
						AlmacenTranspasosPlazo.class);
		return (List<AlmacenTranspasosPlazo>) query.getResultList();
	}
	
	/**
	 * getOrdenes: obtiene las ordenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-22
	 */
	public List<Ordenes> getOrdenes(int idOrdenCompra ) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetOrdenes,
						DB_13,
						idOrdenCompra,
						utilitiesRepository.getDb13()),
						Ordenes.class);
		return (List<Ordenes>) query.getResultList();
	}
	
	/**
	 * getOrdenesAnio: obtiene las ordenes año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-22
	 */
	public List<OrdenesAnio> getOrdenesAnio(int anio, int idOrdenCompra, int idRequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetOrdenesAnio,
						DB_13,
						anio,
						idOrdenCompra,
						idRequisicion,
						utilitiesRepository.getDb13()),
						OrdenesAnio.class);
		return (List<OrdenesAnio>) query.getResultList();
	}
	
	/**
	 * getOrdenesAnioMoneda: obtiene las ordenes año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-22
	 */
	public List<OrdenesAnio> getOrdenesAnioMoneda(int anio, int idOrdenCompra) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetOrdenesAnioMoneda,
						DB_13,
						anio,
						idOrdenCompra,
						utilitiesRepository.getDb13()),
						OrdenesAnio.class);
		return (List<OrdenesAnio>) query.getResultList();
	}
	
	/**
	 * getRequisicionAnio: obtiene las requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-22
	 */
	public List<RequisicionAnio> getRequisicionAnio(int anio,int idRequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRequisicionAnio,
						DB_13,
						anio,
						idRequisicion,
						utilitiesRepository.getDb13()),
						RequisicionAnio.class);
		return (List<RequisicionAnio>) query.getResultList();
	}
	
	/**
	 * getCuerpoDetalle: obtiene el cuerpo detalle de la idrequisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-22
	 */
	public List<CuerpoDetalle> getCuerpoDetalle(int idRequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCuerpoDetalle,
						DB_13,
						idRequisicion,
						utilitiesRepository.getDb13()),
						CuerpoDetalle.class);
		return (List<CuerpoDetalle>) query.getResultList();
	}
	
	/**
	 * getCuerpoDetalleRefaccion: obtiene el cuerpo detalle de la idrequisicion e idrefaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-22
	 */
	public List<CuerpoDetalle> getCuerpoDetalleRefaccion(int idRequisicion, int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCuerpoDetalleRefaccion,
						DB_13,
						idRequisicion,
						idRefaccion,
						utilitiesRepository.getDb13()),
						CuerpoDetalle.class);
		return (List<CuerpoDetalle>) query.getResultList();
	}
	
	/**
	 * getCantidadCuerpoOrden: obtiene la cantidad solicitada del cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-22
	 */
	public List<TotalGrid> getCantidadCuerpoOrden(int anio, int idOrdenCompra, int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCantidadCuerpoOrden,
						DB_13,
						anio,
						idOrdenCompra,
						idRefaccion,
						utilitiesRepository.getDb13()),
						TotalGrid.class);
		return (List<TotalGrid>) query.getResultList();
	}
	
	/**
	 * getTipoCambioDiaCurso: obtiene el tipo de cambio a la fecha actual
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	public List<TipoCambio> getTipoCambioDiaCurso(int idMoneda) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTipoCambioDiaCurso,
						DB_13,
						idMoneda,
						utilitiesRepository.getDb13()),
						TipoCambio.class);
		return (List<TipoCambio>) query.getResultList();
	}
	
	/**
	 * getFacturaOrden: obtiene informacion de la tabla factura orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	public List<FacturaOrden> getFacturaOrden(int idFacturaOrden) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetFacturaOrden,
						DB_13,
						idFacturaOrden,
						utilitiesRepository.getDb13()),
						FacturaOrden.class);
		return (List<FacturaOrden>) query.getResultList();
	}
	
	/**
	 * getFolioAlmacen: obtiene informacion de la tabla folio almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	public List<FolioAlmacen> getFolioAlmacen(int tipoFolio, int idAlmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetFolioAlmacen,
						DB_13,
						tipoFolio,
						idAlmacen,
						utilitiesRepository.getDb13()),
						FolioAlmacen.class);
		return (List<FolioAlmacen>) query.getResultList();
	}
	
	/**
	 * getControlTipoCambio: obtiene informacion de proveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	public List<ControlCambio> getControlTipoCambio(int idProveedor) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetControlTipoCambio,
						DB_13,
						idProveedor,
						utilitiesRepository.getDb13()),
						ControlCambio.class);
		return (List<ControlCambio>) query.getResultList();
	}
	
	/**
	 * getCuerpoFactura: obtiene informacion de cuerpo factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	public List<CuerpoFactura> getCuerpoFactura(int idFacturaOrden) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCuerpoFactura,
						DB_13,
						idFacturaOrden,
						utilitiesRepository.getDb13()),
						CuerpoFactura.class);
		return (List<CuerpoFactura>) query.getResultList();
	}
	
	/**
	 * getInformacionRefaccion: obtiene informacion de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	public List<InformacionRefaccion> getInformacionRefaccion(int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetInformacioRefaccion,
						DB_13,
						idRefaccion,
						utilitiesRepository.getDb13()),
						InformacionRefaccion.class);
		return (List<InformacionRefaccion>) query.getResultList();
	}
	
	/**
	 * insertControlEntrada:inserta registro en control entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-03
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertControlEntrada(ControlEntrada ce) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertControlEntrada,
				DB_13,
				ce.getIdControl(),
				ce.getFolioControl(),
				ce.getIdRefaccion(),
				ce.getIdPersonal(),
				fecha,
				hora
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getFolio: obtiene el folio siat
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-08-10
	 */
	public List<Folio> getFolio(int tipoFolio) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetFolio,
						DB_13,
						tipoFolio,
						utilitiesRepository.getDb13()),
						Folio.class);

		return (List<Folio>) query.getResultList();
	}
	
	/**
	 * insertFolio:inserta registro en folios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-03
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertFolio(Folio folio, int tipoFolio) {
		
		String stringInsert = String.format(queryInsertFolio,
				DB_13,
				tipoFolio,
				folio.getTipoFolio(),
				folio.getIdFolio(),
				folio.getClaveFolio(),
				folio.getDescripcion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertFolioAlmacen:inserta registro en folios almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertFolioAlmacen(FolioAlmacen folio, int tipoFolio, int idAlmacen) {
		
		String stringInsert = String.format(queryInsertFolioAlmacen,
				DB_13,
				tipoFolio,
				idAlmacen,
				folio.getTipoFolio(),
				folio.getClaveFolio(),
				folio.getDescripcion(),
				folio.getIdAlmacen()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	
	/**
	 * getInformacionRefaccion: obtiene informacion de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	public List<TotalGrid> getRefaProveedor(int idProveedor, int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRefaProveedor,
						DB_13,
						idProveedor,
						idRefaccion,
						utilitiesRepository.getDb13()),
						TotalGrid.class);
		return (List<TotalGrid>) query.getResultList();
	}
	
	
	/**
	 * getValorParamGen : obtiene informacion de la variable general
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	public List<GetMotivo> getValorParamGen(int idParametro) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetValorParamGen,
						DB_13,
						idParametro,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getValorParametros : obtiene informacion de la variable 
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	public List<GetMotivo> getValorParametros(int idParametro) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetValorParametros,
						DB_13,
						idParametro,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getValorParametrosNombre : obtiene informacion de la variable 
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	public List<GetMotivo> getValorParametrosNombre(int idParametro) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetValorParametrosNombre,
						DB_13,
						idParametro,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getTipoSolicitud : obtiene informacion de tipo solicitud de la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-08
	 */
	public List<TipoSolicitud> getTipoSolicitud(int idRequisicion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTipoSolicitud,
						DB_13,
						idRequisicion,
						utilitiesRepository.getDb13()),
						TipoSolicitud.class);
		return (List<TipoSolicitud>) query.getResultList();
	}
	
	/**
	 * getNombreMoneda: obtiene informacion del nombre de la moneda
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-08
	 */
	public List<GetMotivo> getNombreMoneda(int idMoneda) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetNombreMoneda,
						DB_13,
						idMoneda,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getCantidadesEntradas: obtiene informacion de las cantidades entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-08
	 */
	public List<CantidadesEntradas> getCantidadesEntradas(int anio, int idOrdenCompra) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCantidadesEntradas,
						DB_13,
						anio,
						idOrdenCompra,
						utilitiesRepository.getDb13()),
						CantidadesEntradas.class);
		return (List<CantidadesEntradas>) query.getResultList();
	}
	
	/**
	 * getMotivo: obtiene la idrefaccion si es de carroceria
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-12
	 */
	public List<GetProveedor> getProveedor(int idProveedor) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetProveedor,
						DB_13,
						idProveedor,
						utilitiesRepository.getDb13()),
						GetProveedor.class);
		return (List<GetProveedor>) query.getResultList();
	}
	
	
	/**
	 * deleteControlEntrada:delete registro en tabla controlentrada
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-01-12
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteControlEntrada(String folioControl, int idPersonal) {
		
		String stringInsert = String.format(queryDeleteControlEntrada,
				DB_13,
				folioControl,
				idPersonal
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 *getTipoAutorizacion: obtiene informacion de las cantidades entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-16
	 */
	public List<TipoAutorizaciones> getTipoAutorizacion(int idTipoAutorizacion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTipoAutorizacion,
						DB_13,
						idTipoAutorizacion,
						utilitiesRepository.getDb13()),
						TipoAutorizaciones.class);
		return (List<TipoAutorizaciones>) query.getResultList();
	}
	
	/**
	 * insertEntradas:inserta registro en entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	@SuppressWarnings("unchecked")
	public Boolean createEntradas(Entradas entradas) {

		String stringInsert = String.format(queryInsertEntradas,
				entradas.getIdEntrada(),
				entradas.getClave(),
				entradas.getTabla(),
				entradas.getTipoEntrada(),
				entradas.getImpresion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getControlIncrementoMaquila: obtiene informacion del incremento maquila
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-16
	 */
	public List<GetMotivo> getControlIncrementoMaquila() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetControlIncrementoMaquila,
						DB_13,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getConvenioRefaccion: obtiene informacion del convenio de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-17
	 */
	public List<GetMotivo> getConvenioRefaccion(int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetConvenioRefaccion,
						DB_13,
						idRefaccion,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getConvenioRefaccionDetallado: obtiene informacion del convenio de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-17
	 */
	public List<ConvenioRefaccion> getConvenioRefaccionDetallado(int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetConvenioRefaccionDetallado,
						DB_13,
						idRefaccion,
						utilitiesRepository.getDb13()),
						ConvenioRefaccion.class);
		return (List<ConvenioRefaccion>) query.getResultList();
	}
	
	/**
	 * createEntradasAño:inserta registro en entradas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	@SuppressWarnings("unchecked")
	public Boolean createEntradasAnio(int anio, EntradasAnio entradas) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertEntradasAnio,
				anio,
				entradas.getIdEntrada(),
				entradas.getIdOrdenCompra(),
				entradas.getIdFacturaOrden(),
				entradas.getIdProveedor(),
				entradas.getClaveEntrada(),
				entradas.getCantidad(),
				entradas.getIdEstatus(),
				entradas.getIdPersonal(),
				entradas.getObservaciones(),
				entradas.getTipo(),
				fecha,
				hora,
				entradas.getIdMotivo(),
				entradas.getIdAlmacen()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * createLotes:inserta registro en lotes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	@SuppressWarnings("unchecked")
	public Boolean createLotes(Lotes lotes) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertLotes,
				lotes.getIdLote(),
				lotes.getIdRefaccion(),
				fecha,
				hora,
				lotes.getIdProveedor(),
				lotes.getIdAlmacen(),
				lotes.getCantEntrada(),
				lotes.getCantSalida(),
				lotes.getPrecioEntrada(),
				lotes.getIdMoneda(),
				lotes.getEsNueva(),
				DB_13
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * createKardex:inserta registro en kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	@SuppressWarnings("unchecked")
	public Boolean createKardex(Kardex kardex) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertKardex,
				kardex.getIdRefaccion(),
				kardex.getIdProveedor(),
				fecha,
				hora,
				kardex.getTipoMovimiento(),
				kardex.getNoMovimiento(),
				kardex.getIdAlmacen(),
				kardex.getCantidad(),
				kardex.getPrecio(),
				kardex.getEstatus(),
				kardex.getTipo(),
				kardex.getEsNueva(),
				kardex.getIdMoneda(),
				kardex.getIdLote()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getEsFactura: obtiene informacion si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	public List<GetMotivo> getEsFactura(int idFacturaOrden) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetEsFactura,
						DB_13,
						idFacturaOrden,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getImporteFactura: obtiene informacion del importe si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	public List<Importe> getImporteFactura(int anio, int idEntrada, int idAlmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetImporteFactura,
						DB_13,
						anio,
						idEntrada,
						idAlmacen,
						utilitiesRepository.getDb13()),
						Importe.class);
		return (List<Importe>) query.getResultList();
	}
	
	/**
	 * getImporteRemision: obtiene informacion del importe si es remision
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	public List<Importe> getImporteRemision(int anio, int idEntrada, int idAlmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetImporteRemision,
						DB_13,
						anio,
						idEntrada,
						idAlmacen,
						utilitiesRepository.getDb13()),
						Importe.class);
		return (List<Importe>) query.getResultList();
	}
	
	/**
	 * getMaxLotes: obtiene informacion del max idlote
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	public List<ValidacionEntrada> getMaxLotes() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetMaxLotes,
						DB_13,
						utilitiesRepository.getDb13()),
						ValidacionEntrada.class);
		return (List<ValidacionEntrada>) query.getResultList();
	}
	
	/**
	 * createDetalleEntrada:inserta registro en detalle entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	@SuppressWarnings("unchecked")
	public Boolean createDetalleEntrada(DetalleEntrada de) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertDetalleEntrada,
				de.getIdDetalle(),
				de.getIdEntrada(),
				de.getTipo(),
				de.getIdGrupo(),
				de.getIdAlmacen(),
				de.getIdRefaccion(),
				de.getSubTotal(),
				de.getIva(),
				de.getTotal(),
				de.getIdPersonal(),
				fecha,
				hora
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getInfRefaproveedor: obtiene informacion de Refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	public List<Refaproveedor> getInfRefaproveedor(int idRefaccion, int idProveedor) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetInfRefaproveedor,
						DB_13,
						idRefaccion,
						idProveedor,
						utilitiesRepository.getDb13()),
						Refaproveedor.class);
		return (List<Refaproveedor>) query.getResultList();
	}
	
	/**
	 * getRefPorAlmacen: obtiene informacion de refaccion por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	public List<RefPorAlmacen> getRefPorAlmacen(int idRefaccion, int idAlmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRefPorAlmacen,
						DB_13,
						idRefaccion,
						idAlmacen,
						utilitiesRepository.getDb13()),
						RefPorAlmacen.class);
		return (List<RefPorAlmacen>) query.getResultList();
	}
	
	/**
	 * getConvenioInf: obtiene informacion de convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	public List<ConvenioInf> getConvenioInf(int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetConvenioInf,
						DB_13,
						idRefaccion,
						utilitiesRepository.getDb13()),
						ConvenioInf.class);
		return (List<ConvenioInf>) query.getResultList();
	}
	
	/**
	 * updateRefaProveedor:actualiza registro en refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateRefaProveedor(Refaproveedor rp, int idRefaccion, int idProveedor) {
		
		String stringInsert = String.format(queryUpdateRefaProveedor,
				DB_13,
				idRefaccion,
				idProveedor, 
				rp.getIdRefaccion(),
				rp.getIdProveedor(),
				rp.getExistencia(),
				rp.getDias(),
				rp.getPcmn(),
				rp.getPcd(),
				rp.getOpcion(),
				rp.getEstatus(),
				rp.getIdPersonal(),
				rp.getFecha(),
				rp.getHora()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateRefaPorAlmacen:actualiza registro en refaccion_por_almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateRefaPorAlmacen(RefPorAlmacen rp, int idRefaccion, int idAlmacen) {
		
		String stringInsert = String.format(queryUpdateRefaPorAlmacen,
				DB_13,
				idRefaccion,
				idAlmacen, 
				rp.getIdRefaccion(),
				rp.getIdAlmacen(),
				rp.getExistencia(),
				rp.getRack(),
				rp.getFila(),
				rp.getRenglon(),
				rp.getIdPersonal(),
				rp.getFechaHoraMod(),
				rp.getMinimo(),
				rp.getMaximo(),
				rp.getEstatus(),
				rp.getPuntoReorden()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateRefacciones:actualiza registro en refacciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateRefacciones(UpdateRefacciones ur ,int idRefaccion) {
		
		String stringInsert = String.format(queryUpdateRefacciones,
				DB_13,
				idRefaccion,
				ur.getExistencia(),
				ur.getMinimo(),
				ur.getMaximo(),
				ur.getPcmn(),
				ur.getPcd(),
				ur.getPvmn(),
				ur.getPvd()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateCuerpoConvenio:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateCuerpoConvenio( int idRefaccion, int idConvenio, Double pcmn) {
		
		String stringInsert = String.format(queryUpdateCuerpoConvenio,
				DB_13,
				idRefaccion,
				idConvenio,
				pcmn
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateFacturasOrden:actualiza registro en facturas orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateFacturasOrden( int idFacturaOrden, int idEstatus) {
		
		String stringInsert = String.format(queryUpdateFactursaOrden,
				DB_13,
				idFacturaOrden,
				idEstatus
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getCuerpoOrdenAnio: obtiene informacion de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-24
	 */
	public List<CuerpoOrden> getCuerpoOrdenAnio(int anio, int idRefaccion, int idOrdenCompra) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCuerpoOrdenAnio,
						DB_13,
						anio,
						idRefaccion,
						idOrdenCompra,
						utilitiesRepository.getDb13()),
						CuerpoOrden.class);
		return (List<CuerpoOrden>) query.getResultList();
	}
	
	/**
	 * getCuerpoOrden: obtiene informacion de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-24
	 */
	public List<CuerpoOrden> getCuerpoOrden(int anio, int idOrdenCompra) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCuerpoOrden,
						DB_13,
						anio,
						idOrdenCompra,
						utilitiesRepository.getDb13()),
						CuerpoOrden.class);
		return (List<CuerpoOrden>) query.getResultList();
	}
	
	/**
	 * updateCuerpoOrdenAnio:actualiza registro de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateCuerpoOrdenAnio(CuerpoOrden co,int anio, int idRefaccion, int idOrdenCompra) {
		
		String stringInsert = String.format(queryUpdateCuerpoOrdenAnio,
				DB_13,
				anio,
				idRefaccion,
				idOrdenCompra,
				co.getCantSolicitada(),
				co.getPrecio(),
				co.getIdEstatus(),
				co.getPorcIva(),
				co.getPorcRetencion(),
				co.getIdConvenio()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateCuerpoOrdenAnio:actualiza registro de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateOrdenCompraAnio(OrdenesAnio co,int anio, int idRequisicion, int idOrdenCompra) {
		
		String stringInsert = String.format(queryUpdateOrdenCompraAnio,
				DB_13,
				anio,
				idRequisicion,
				idOrdenCompra,
				co.getIdEstatus(),
				co.getObservaciones(),
				co.getSubTotal(),
				co.getIva(),
				co.getRetencion(),
				co.getTotal(),
				co.getIdMoneda(),
				co.getIdPersonal()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateOrdenes:actualiza registro de ordenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateOrdenes(int idOrdenCompra, int idEstatus) {
		
		String stringInsert = String.format(queryUpdateOrdenes,
				DB_13,
				idOrdenCompra,
				idEstatus
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateCuerpoRequisicionAnio:actualiza registro de cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateCuerpoRequisicionAnio(CuerpoRequisicionAnio cr,int anio, int idRequisicion, int idRefaccion) {
		
		String stringInsert = String.format(queryUpdateCuerpoRequisicionAnio,
				DB_13,
				anio,
				idRequisicion,
				idRefaccion,
				cr.getIdMedida(),
				cr.getCantSolicitada(),
				cr.getTipoSolicitud(),
				cr.getIdEstatus()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getCuerpoRequisicionAnio: obtiene informacion de cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-25
	 */
	public List<CuerpoRequisicionAnio> getCuerpoRequisicionAnio(int anio,int idRequisicion, int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCuerpoRequisicionAnio,
						DB_13,
						anio,
						idRequisicion,
						idRefaccion,
						utilitiesRepository.getDb13()),
						CuerpoRequisicionAnio.class);
		return (List<CuerpoRequisicionAnio>) query.getResultList();
	}
	
	/**
	 * updateRequisicionAnio:actualiza registro de requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateRequisicionAnio(RequisicionAnio ra,int anio, int idRequisicion) {
		
		String stringInsert = String.format(queryUpdateRequisicionAnio,
				DB_13,
				anio,
				idRequisicion,
				ra.getObservaciones(),
				ra.getIdUrgencia(),
				ra.getIdEstatus(),
				ra.getIdAlmacen(),
				ra.getIdAutoriza(),
				ra.getIdReviso(),
				ra.getEsNueva(),
				ra.getIdPersonal()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertRequisicionHistorico:inserta registro en requisicion historico
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertRequisicionHistorico(RequisicionHistorico requisicionHistorico) {
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertRequisicionHistorico,
				requisicionHistorico.getIdRequisicion(),
				requisicionHistorico.getIdEstatus(),
				fecha,
				hora,
				requisicionHistorico.getIdPersonal(),
				requisicionHistorico.getObservaciones(),
				DB_13
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateCuerpoDetalle:actualiza registro de cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateCuerpoDetalle(CuerpoDetalle cd, int idRequisicion, int idRefaccion) {
		
		String stringInsert = String.format(queryUpdateCuerpoDetalle,
				DB_13,
				idRequisicion,
				idRefaccion,
				cd.getCantRequisicion(),
				cd.getCantOrdenada(),
				cd.getCantFacturada(),
				cd.getCantEntrada()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertAutorizaciones:inserta registro en autorizaciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertAutorizaciones(Autorizaciones autorizaciones) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertAutorizaciones,
				autorizaciones.getTipoMovimiento(),
				autorizaciones.getNoMovimiento(),
				autorizaciones.getIdAutorizo(),
				autorizaciones.getIdTipoAutorizacion(),
				autorizaciones.getIdPersonal(),
				autorizaciones.getObservaciones(),
				fecha,
				hora,
				autorizaciones.getIdAutSistema()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateCuerpoConvenioSaldo:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateCuerpoConvenioSaldo( int idRefaccion, int idConvenio, Double saldo) {
		
		String stringInsert = String.format(queryUpdateCuerpoConvenioSaldo,
				DB_13,
				idRefaccion,
				idConvenio,
				saldo
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getInfoconvenio: obtiene informacion de convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	public List<GetMotivo> getInfoconvenio( int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetInfoConvenio,
						DB_13,
						idRefaccion,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getBancoProveedor: obtiene informacion de banco proveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	public List<BancoProveedor> getBancoProveedor(int idProveedor) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetBancoProveedor,
						DB_13,
						idProveedor,
						utilitiesRepository.getDb13()),
						BancoProveedor.class);
		return (List<BancoProveedor>) query.getResultList();
	}
	
	/**
	 * getContraRecibo: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	public List<ContraRecibos> getContraRecibo() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetContraRecibo,
						DB_13,
						utilitiesRepository.getDb13()),
						ContraRecibos.class);
		return (List<ContraRecibos>) query.getResultList();
	}
	
	/**
	 * insertContraRecibo:inserta registro en contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertContraRecibo(ContraRecibosInfo contraRecibo) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertContraRecibo,
				contraRecibo.getIdContraRecibo(),
				contraRecibo.getIdFacturaOrden(),
				contraRecibo.getFolio(),
				fecha,
				contraRecibo.getIdProveedor(),
				fecha,
				hora,
				contraRecibo.getIdPersonal(),
				contraRecibo.getSubTotal(),
				contraRecibo.getIva(),
				contraRecibo.getRetencion(),
				contraRecibo.getDescuento(),
				contraRecibo.getTotal(),
				contraRecibo.getIdEstatus(),
				contraRecibo.getFechaParaPago(),
				contraRecibo.getPagoAnticipado(),
				contraRecibo.getTipo(),
				contraRecibo.getIdMoneda(),
				contraRecibo.getImpresion()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getContraReciboInfo: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	public List<ContraRecibosInfo> getContraReciboInfo(int idContraRecibo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetContraReciboInfo,
						DB_13,
						idContraRecibo,
						utilitiesRepository.getDb13()),
						ContraRecibosInfo.class);
		return (List<ContraRecibosInfo>) query.getResultList();
	}
	
	/**
	 * getContraReciboFact: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	public List<ContraRecibosInfo> getContraReciboFact(int idFacturaOrden) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetContraReciboFact,
						DB_13,
						idFacturaOrden,
						utilitiesRepository.getDb13()),
						ContraRecibosInfo.class);
		return (List<ContraRecibosInfo>) query.getResultList();
	}
	
	/**
	 * getRptContraReciboFact : obtiene reporte de contra recibo con factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	public List<RptContraRecibo> getRptContraReciboFact(int coidFacturaOrden) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRptContraReciboFact,
						DB_13,
						coidFacturaOrden,
						utilitiesRepository.getDb13()),
						RptContraRecibo.class);
		return (List<RptContraRecibo>) query.getResultList();
	}
	
	/**
	 * getRptContraRecibo: obtiene reporte de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	public List<RptContraRecibo> getRptContraRecibo(int idContraRecibo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRptContraRecibo,
						DB_13,
						idContraRecibo,
						utilitiesRepository.getDb13()),
						RptContraRecibo.class);
		return (List<RptContraRecibo>) query.getResultList();
	}
	
	/**
	 * getEntradas : obtiene informacion de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	public List<Entradas> getEntradas(int idEntrada, int tipoEntrada) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetEntradas,
						DB_13,
						idEntrada,
						tipoEntrada,
						utilitiesRepository.getDb13()),
						Entradas.class);
		return (List<Entradas>) query.getResultList();
	}
	
	/**
	 * getValoresEntradas :  obtiene valores de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	public List<EntradasInfo> getValoresEntradas(int anio, int idEntrada, int tipoEntrada) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetValoresEntradas,
						DB_13,
						anio,
						idEntrada,
						tipoEntrada,
						utilitiesRepository.getDb13()),
						EntradasInfo.class);
		return (List<EntradasInfo>) query.getResultList();
	}
	
	/**
	 * getFacturasOrdenInfo: obtiene valores de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	public List<FacturaOrden> getFacturasOrdenInfo(int idOrdenCompra, int idFacturaOrden) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetFacturasOrdenInfo,
						DB_13,
						idOrdenCompra,
						idFacturaOrden,
						utilitiesRepository.getDb13()),
						FacturaOrden.class);
		System.out.println(query.getResultList());
		return (List<FacturaOrden>) query.getResultList();
	}
	
	/**
	 * getEntradasAnio: obtiene informacion de entradas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	public List<EntradasAnio> getEntradasAnio(int anio, int idEntrada, int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetEntradasAnio,
						DB_13,
						anio,
						idEntrada,
						tipo,
						utilitiesRepository.getDb13()),
						EntradasAnio.class);
		return (List<EntradasAnio>) query.getResultList();
	}
	
	/**
	 * getKardex: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	public List<Kardex> getKardex(int tipoMovimiento, int noMovimiento, int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetKardex,
						DB_13,
						tipoMovimiento,
						noMovimiento,
						tipo,
						utilitiesRepository.getDb13()),
						Kardex.class);
		return (List<Kardex>) query.getResultList();
	}
	
	/**
	 * getKardexPrecio: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	public List<Kardex> getKardexPrecio(int idRefaccion, int noMovimiento) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetKardexPrecio,
						DB_13,
						idRefaccion,
						noMovimiento,
						utilitiesRepository.getDb13()),
						Kardex.class);
		return (List<Kardex>) query.getResultList();
	}
	
	/**
	 * deleteTempoliza : Elimina informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteTempoliza() {
		
		String stringInsert = String.format(queryDeleteTempoliza,
				DB_13
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getTempolizaInsert: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	public List<Tempoliza> getTempolizaInsert(String param1, String param2, int tipoMovimiento, int noMovimiento, int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTempolizaInsert,
						DB_13,
						param1,
						param2,
						tipoMovimiento,
						noMovimiento,
						tipo,
						utilitiesRepository.getDb13()),
						Tempoliza.class);
		return (List<Tempoliza>) query.getResultList();
	}
	
	/**
	 * getTempolizaInsert2: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	public List<Tempoliza> getTempolizaInsert2(int idEntrada, int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTempolizaInsert2,
						DB_13,
						idEntrada,
						tipo,
						utilitiesRepository.getDb13()),
						Tempoliza.class);
		return (List<Tempoliza>) query.getResultList();
	}
	
	/**
	 * insertTempoliza:inserta registro en tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-02
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertTempoliza(Tempoliza tempoliza) {
		String stringInsert = String.format(queryInsertTempoliza,
				tempoliza.getClave(),
				tempoliza.getIdGrupo(),
				tempoliza.getCuenta(),
				tempoliza.getSubTotal(),
				tempoliza.getIva(),
				tempoliza.getTotal(),
				tempoliza.getIdRefaccion(),
				tempoliza.getFecha(),
				tempoliza.getHora(),
				tempoliza.getIdAlmacen(),
				DB_13
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getIva: obtiene informacion de iva
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	public List<Iva> getIva(int idIva) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetIva,
						DB_13,
						idIva,
						utilitiesRepository.getDb13()),
						Iva.class);
		return (List<Iva>) query.getResultList();
	}
	
	/**
	 * getTempoliza: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	public List<Tempoliza> getTempoliza() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTempoliza,
						DB_13,
						utilitiesRepository.getDb13()),
						Tempoliza.class);
		return (List<Tempoliza>) query.getResultList();
	}
	
	/**
	 * getTempolizaRefaccion: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	public List<TempolizaRefaccion> getTempolizaRefaccion() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTempolizaRefaccion,
						DB_13,
						utilitiesRepository.getDb13()),
						TempolizaRefaccion.class);
		return (List<TempolizaRefaccion>) query.getResultList();
	}
	
	/**
	 * getTraspasosGrupos: obtiene informacion de traspasos grupos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	public List<TraspasosGrupos> getTraspasosGrupos(int idRefaccion, String fecha, String hora) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTraspasosGrupos,
						DB_13,
						idRefaccion,
						fecha,
						hora,
						utilitiesRepository.getDb13()),
						TraspasosGrupos.class);
		return (List<TraspasosGrupos>) query.getResultList();
	}
	
	/**
	 * getGruposAlmacen: obtiene informacion de grupos almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	public List<GetMotivo> getGruposAlmacen(int idGrupo, int idAlmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGruposAlmacen,
						DB_13,
						idGrupo,
						idAlmacen,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * updateTempoliza :actualiza registro de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-02
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateTempoliza(Tempoliza tempoliza, int idRefaccion, String fecha, String hora) {
		
		String stringInsert = String.format(queryUpdateTempoliza,
				DB_13,
				idRefaccion,
				fecha,
				hora,
				tempoliza.getClave(),
				tempoliza.getIdGrupo(),
				tempoliza.getCuenta(),
				tempoliza.getSubTotal(),
				tempoliza.getIva(),
				tempoliza.getTotal(),
				tempoliza.getIdRefaccion(),
				tempoliza.getFecha(),
				tempoliza.getHora(),
				tempoliza.getIdAlmacen()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getKardexRefacciones: obtiene informacion de kardex y refacciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	public List<KardexRefacciones> getKardexRefacciones(String noMovimiento,int tipo, int idGrupo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetKardexRefaccion,
						DB_13,
						noMovimiento,
						tipo,
						idGrupo,
						utilitiesRepository.getDb13()),
						KardexRefacciones.class);
		return (List<KardexRefacciones>) query.getResultList();
	}
	
	/**
	 * getKardexMovimiento: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	public List<KardexMovimiento> getKardexMovimiento(int idRefaccion, String fecha, String hora) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetKardexMovimiento,
						DB_13,
						idRefaccion,
						fecha,
						hora,
						utilitiesRepository.getDb13()),
						KardexMovimiento.class);
		return (List<KardexMovimiento>) query.getResultList();
	}
	
	/**
	 * getAlmacenes: obtiene informacion de almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	public List<Almacen> getAlmacenes() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetAlmacenes,
						DB_13,
						utilitiesRepository.getDb13()),
						Almacen.class);
		return (List<Almacen>) query.getResultList();
	}
	
	/**
	 * getSumCantKardex: obtiene suma de la cantidad de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	public List<TotalGrid> getSumCantKardex(int idRefaccion, String fecha, String hora, int idAlmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetSumCantKardex,
						DB_13,
						idRefaccion,
						fecha,
						hora,
						idAlmacen,
						utilitiesRepository.getDb13()),
						TotalGrid.class);
		return (List<TotalGrid>) query.getResultList();
	}
	
	/**
	 * getFacturaOrdenAnticipo: obtiene informacion de la tabla factura orden anticipo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	public List<FacturaOrdenAnticipo> getFacturaOrdenAnticipo(int idFacturaOrden) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetFacturaOrdenAnticipo,
						DB_13,
						idFacturaOrden,
						utilitiesRepository.getDb13()),
						FacturaOrdenAnticipo.class);
		return (List<FacturaOrdenAnticipo>) query.getResultList();
	}
	
	/**
	 * getIdPoliza: obtiene informacion de la tabla poliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-07
	 */
	public List<GetMotivo> getIdPoliza(int tabla, int numPoliza, int idTipoPol) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetIdPoliza,
						DB_13,
						tabla,
						numPoliza,
						idTipoPol,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getMaxPoliza: obtiene informacion de la tabla poliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-07
	 */
	public List<GetMotivo> getMaxPoliza(int tabla) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetMaxPoliza,
						DB_13,
						tabla,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * insertPolizaAnio:inserta registro en poliza año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertPolizaAnio(int anio, PolizasAnio poliza) {
		LocalDate fechaalta = LocalDate.now();
		LocalTime horaalta = LocalTime.now();
		String stringInsert = String.format(queryInsertPolizaAnio,
				DB_13,
				anio,
				poliza.getIdPoliza(),
				poliza.getNumPoliza(),
				poliza.getIdTipoPol(),
				poliza.getConcepto(),
				poliza.getFechaPol(),
				fechaalta,
				poliza.getAltaPor(),
				poliza.getElaboradoPor(),
				poliza.getAutoriza(),
				horaalta,
				poliza.getDepto(),
				poliza.getOficinaEnvia(),
				poliza.getStatus(),
				poliza.getReferencia(),
				poliza.getAuditada(),
				poliza.getAuditadaPor(),
				"1900-01-01",
				0
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertPoliza:inserta registro en polizas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertPoliza(Polizas poliza) {
		String stringInsert = String.format(queryInsertPoliza,
				DB_13,
				poliza.getIdPoliza(),
				poliza.getNumPoliza(),
				poliza.getTabla(),
				poliza.getIdTipoPol(),
				poliza.getStatus(),
				poliza.getEsAutomatica()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertMovimientos:inserta registro en movimientos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertMovimientos(int anio, Movimientos movimientos) {
		String stringInsert = String.format(queryInsertMovimientos,
				DB_13,
				anio,
				movimientos.getIdMovim(),
				movimientos.getIdPoliza(),
				movimientos.getIdCuenta(),
				movimientos.getIdOficina(),
				movimientos.getConceptoMovim(),
				movimientos.getTipoMovim(),
				movimientos.getImporte(),
				movimientos.getIdDocumento(),
				movimientos.getReferencia(),
				movimientos.getTipoRef(),
				movimientos.getAnio(),
				movimientos.getNoConci()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateCatcuentasAnio:actualiza registro en catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateCatcuentasAnio(int anio, int mes, String idCuenta, int importe) {
		String stringInsert = String.format(queryUpdateCatCuentasAnio,
				DB_13,
				anio,
				idCuenta,
				mes,
				mes,
				importe
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * updateCatcuentasAbonos:actualiza registro en catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateCatcuentasAbonos(int anio, int mes, String idCuenta, String importe) {
		String stringInsert = String.format(queryUpdateCatCuentasAbono,
				DB_13,
				anio,
				idCuenta,
				mes,
				mes,
				importe
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getCatCuentas: obtiene informacion de la catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-11
	 */
	public List<GetMotivo> getCatCuentas(int cargo, int anio, String idCuenta) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCatCuentas,
						DB_13,
						cargo,
						anio,
						idCuenta,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getCatCuentasAbonos: obtiene informacion de la catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-11
	 */
	public List<GetMotivo> getCatCuentasAbonos(int abono, int anio, String idCuenta) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCatCuentasAbonos,
						DB_13,
						abono,
						anio,
						idCuenta,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}

	
	/**
	 * updateResumenCompra:actualiza registro en resumen compra
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-09
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateResumenCompra(int idRefaccion, ResumenCompra resumen) {
		String stringInsert = String.format(queryUpdateResumenCompra,
				DB_13,
				idRefaccion,
				resumen.getIdProveedor(),
				resumen.getNombreProveedor(),
				resumen.getIdEntrada(),
				resumen.getIdOrdenCompra(),
				resumen.getIdMoneda(),
				resumen.getFechaUltimaCompra(),
				resumen.getPcmn(),
				resumen.getPcd()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getResumenCompra: obtiene informacion de resumen compra
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-12
	 */
	public List<ResumenCompra> getResumenCompra(int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetResumenCompra,
						DB_13,
						idRefaccion,
						utilitiesRepository.getDb13()),
						ResumenCompra.class);
		return (List<ResumenCompra>) query.getResultList();
	}
	
	/**
	 * getResumenImpresion: obtiene informacion de resumen impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-15
	 */
	public List<ImprimirGeneral> getResumenImpresion(int anio, String fechaIni, String fechaFin, int tipo,int permisoTaller, int idTaller) {
		String permisoAlmacen;
		if(permisoTaller > 0) {
			permisoAlmacen = "AND alm.idtaller = "+idTaller;
		}else {
			permisoAlmacen = "";
		}
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetResumeImpresion,
						DB_13,
						anio,
						anio,
						anio,
						tipo,
						fechaIni,
						fechaFin,
						tipo,
						permisoAlmacen,
						utilitiesRepository.getDb13()),
						ImprimirGeneral.class);
		return (List<ImprimirGeneral>) query.getResultList();
	}
	
	/**
	 * getKardexInformacion: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-15
	 */
	public List<KardexInformacion> getKardexInformacion(int noMovimiento, int tipoMovimiento, int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetKardexInformacion,
						DB_13,
						noMovimiento,
						tipoMovimiento,
						tipo,
						utilitiesRepository.getDb13()),
						KardexInformacion.class);
		return (List<KardexInformacion>) query.getResultList();
	}
	
	/**
	 * getEntradaFechapol: obtiene informacion de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	public List<EntradasFechapol> getEntradaFechapol(int anio, int idEntrada, int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetEntradasFecha,
						DB_13,
						anio,
						idEntrada,
						tipo,
						utilitiesRepository.getDb13()),
						EntradasFechapol.class);
		return (List<EntradasFechapol>) query.getResultList();
	}
	
	/**
	 * getTotalMovimientos: obtiene informacion de movimientos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	public List<GetMotivo> getTotalMovimientos(int anio, int idPoliza) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetTotalMovimientos,
						DB_13,
						anio,
						idPoliza,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * deletePoliza : Elimina informacion de polizas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@SuppressWarnings("unchecked")
	public Boolean deletePoliza(int idPoliza, int tabla, int idTipoPol) {
		
		String stringInsert = String.format(queryDeletePoliza,
				DB_13,
				idPoliza,
				tabla,
				idTipoPol
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * deletePolizaAnio : Elimina informacion de polizas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@SuppressWarnings("unchecked")
	public Boolean deletePolizaAnio(int anio, int idPoliza, int idTipoPol) {
		
		String stringInsert = String.format(queryDeletePolizaAnio,
				DB_13,
				anio,
				idPoliza,
				idTipoPol
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * deleteMovimientosAnio : Elimina informacion de movimientos año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteMovimientosAnio(int anio, int idPoliza) {
		
		String stringInsert = String.format(queryDeleteMovimientosAnio,
				DB_13,
				anio,
				idPoliza
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 *getRptEntradaConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	public List<ImprimirEntradas> getRptEntradaConsultar(int anio, int idEntrada, int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRptEntradaConsultar,
						DB_13,
						anio,
						anio,
						anio,
						idEntrada,
						tipo,
						utilitiesRepository.getDb13()),
						ImprimirEntradas.class);
		return (List<ImprimirEntradas>) query.getResultList();
	}
	
	/**
	 *getRptEntradaFacturaConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	public List<ImprimirEntradasFactura> getRptEntradaFacturaConsultar(int anio, int idEntrada,int idAlmacen, int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRptEntradaFacturaConsultar,
						DB_13,
						anio,
						idEntrada,
						idAlmacen,
						tipo,
						utilitiesRepository.getDb13()),
						ImprimirEntradasFactura.class);
		return (List<ImprimirEntradasFactura>) query.getResultList();
	}
	
	/**
	 *getRptEntradaRemisionConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	public List<ImprimirEntradasFactura> getRptEntradaRemisionConsultar(int anio, int idEntrada,int idAlmacen, int tipo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRptEntradaRemisionConsultar,
						DB_13,
						anio,
						idEntrada,
						idAlmacen,
						tipo,
						utilitiesRepository.getDb13()),
						ImprimirEntradasFactura.class);
		return (List<ImprimirEntradasFactura>) query.getResultList();
	}
	
	/**
	 * getConvenios: obtiene informacion de la tabla convenios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	public List<Convenios> getConvenios(int idConvenio) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetConvenios,
						DB_13,
						idConvenio,
						utilitiesRepository.getDb13()),
						Convenios.class);
		return (List<Convenios>) query.getResultList();
	}
	
	/**
	 * getGridEntDevolucion: obtiene informacion para generar el grid de entrada por devolucion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	public List<ConvenioProveedor> getGridEntDevolucion() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGridEntDevolucion,
						DB_13,
						utilitiesRepository.getDb13()),
						ConvenioProveedor.class);
		return (List<ConvenioProveedor>) query.getResultList();
	}
	
	/**
	 * getRefaccionesPorSurtir: obtiene informacion para generar obtener las refacciones por surtir
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	public List<RefaccionesPorSurtir> getRefaccionesPorSurtir(int idConvenio) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetRefaccionesPorSurtir,
						DB_13,
						idConvenio,
						utilitiesRepository.getDb13()),
						RefaccionesPorSurtir.class);
		return (List<RefaccionesPorSurtir>) query.getResultList();
	}
	
	/**
	 * getGrupos: obtiene informacion para los grupos.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-07
	 */
	public List<Grupos> getGrupos(int clave) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGrupos,
						DB_13,
						clave,
						utilitiesRepository.getDb13()),
						Grupos.class);
		return (List<Grupos>) query.getResultList();
	}
	
	/**
	 * getGruposIdentificador: obtiene informacion para los grupos.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-07
	 */
	public List<Grupos> getGruposIdentificador(int idGrupo) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGrupos,
						DB_13,
						idGrupo,
						utilitiesRepository.getDb13()),
						Grupos.class);
		return (List<Grupos>) query.getResultList();
	}
	
	/**
	 * getInfCuerpoConvenio: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	public List<CuerpoConvenio> getCuerpoConvenio(int idConvenio, int idRefaccion) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCuerpoConvenio,
						DB_13,
						idConvenio,
						idRefaccion,
						utilitiesRepository.getDb13()),
						CuerpoConvenio.class);
		return (List<CuerpoConvenio>) query.getResultList();
	}
	
	/**
	 * getCatCuentasAnio: obtiene informacion de cat cuentas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-15-13
	 */
	public List<CatCuentasAnio> getCatCuentasAnio(int anio, String idCuenta) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetCatCuentasAnio,
						DB_13,
						anio,
						idCuenta,
						utilitiesRepository.getDb13()),
						CatCuentasAnio.class);
		return (List<CatCuentasAnio>) query.getResultList();
	}
	
	
	/**
	 * deleteTablaTemporal: eliminar una tabla temporal
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-03-19
	 */
	@SuppressWarnings("unchecked")
	public Boolean deleteTablaTemporal() {
		String stringInsert = String.format(queryDeleteTemporal,
				DB_13
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertTemporal: inserta registro en tabla temporal
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-03-19
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertTemporal(TablaTemporal temp) {
		String stringInsert = String.format(queryInsertTemporal,
				DB_13,
				temp.getIdRefaccion(),
				temp.getIdGrupo(),
				temp.getExistencia(),
				temp.getEntrada(),
				temp.getDifPrecio(),
				temp.getPmn(),
				temp.getPd(),
				temp.getPorcentaje(),
				temp.getEsCarroceria()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getGrupoTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	public List<GetMotivo> getGrupoTemporal() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetGrupoTemporal,
						DB_13,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * getImporteTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	public List<TablaSumTemporal> getImporteTemporal() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetImporteTemporal,
						DB_13,
						utilitiesRepository.getDb13()),
						TablaSumTemporal.class);
		return (List<TablaSumTemporal>) query.getResultList();
	}
	
	/**
	 * getSumPmnTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	public List<GetMotivo> getSumPmnTemporal() {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetSumPmnTemporal,
						DB_13,
						utilitiesRepository.getDb13()),
						GetMotivo.class);
		return (List<GetMotivo>) query.getResultList();
	}
	
	/**
	 * updateFacturasOrden:actualiza el precio de la refacción en la tabla de llantas
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-22
	 */
	@SuppressWarnings("unchecked")
	public Boolean updatePrecioRefaccionLlanta( int idRefaccion, Double precio ) {
		
		String stringInsert = String.format(
				queryUpdatePrecioLlantas,
				DB_13,
				idRefaccion,
				precio
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getEsFactura: obtiene informacion si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	public List<DetalleEntradaConsignacion> getDetalleEntradaConsignacion(int anio, int idEntrada, int idAlmacen) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetDetalleEntradaConsignacion,
						DB_13,
						anio,
						idEntrada,
						idAlmacen,
						utilitiesRepository.getDb13()),
						DetalleEntradaConsignacion.class);
		return (List<DetalleEntradaConsignacion>) query.getResultList();
	}
	
	
	/**
	 * updateFacturasOrden:actualiza el saldo total del convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateSaldoConvenio( int idConvenio, Double saldoTotal ) {
		
		String stringInsert = String.format(
				queryUpdateSaldoConvenio,
				DB_13,
				idConvenio,
				saldoTotal
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertTemporal: inserta registro en tabla historicodetaconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertHistoricoConvenio(HistoricoConvenio temp) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertHistoricoConvenio,
				DB_13,
				temp.getIdConvenio(),
				temp.getIdModificacion(),
				temp.getIdRefaccion(),
				temp.getNumCampo(),
				temp.getNomCampo(),
				temp.getValorAnterior(),
				temp.getValorNuevo(),
				temp.getMotivo(),
				temp.getIdPersonal(),
				fecha,
				hora
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getListCuerpoConvenio: obtiene la lista de refacciones del cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-26
	 */
	public List<ListaCuerpoConvenio> getListCuerpoConvenio(int idConvenio) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetListCuerpoConvenio,
						DB_13,
						idConvenio,
						idConvenio,
						utilitiesRepository.getDb13()),
						ListaCuerpoConvenio.class);
		return (List<ListaCuerpoConvenio>) query.getResultList();
	}
	
	
	/**
	 * updateRefaProveedor:actualiza registro en refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateExistenciaRefaProveedor(int idRefaccion, int idProveedor, Double existencia) {
		String stringInsert = String.format(queryUpdateExistenciaRefaProveedor,
				DB_13,
				idRefaccion,
				idProveedor, 
				existencia
				);
		
		StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("PcrExecSQL");
		storedProcedure.registerStoredProcedureParameter("sql", String.class, ParameterMode.IN);
		storedProcedure.registerStoredProcedureParameter("respuesta", String.class, ParameterMode.OUT);
		storedProcedure.setParameter("sql", stringInsert);
		storedProcedure.execute();
		
		boolean registroRepetido = storedProcedure.getSingleResult().toString().contains("El conjunto de filas utiliza simultaneidad optimista y el valor de una columna ha cambiado desde que se capturó o volvió a sincronizar por última vez la fila que la contiene.");
		if(registroRepetido) {
			return true;
		}else {
			String result = storedProcedure.getSingleResult().toString();
			if(result.equals("1")) {
				return true;
			}else {
				return false;
			}
		}
		
	}
	
	/**
	 * updateDataCuerpoConvenio:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	@SuppressWarnings("unchecked")
	public Boolean updateDataCuerpoConvenio( int idRefaccion, int idConvenio, Double pcmn, Double cantidadSurtida) {
		
		String stringInsert = String.format(queryUpdateDataCuerpoConvenio,
				DB_13,
				idRefaccion,
				idConvenio,
				pcmn,
				cantidadSurtida
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * insertTemporal: inserta registro en tabla historicodetaconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-25
	 */
	@SuppressWarnings("unchecked")
	public Boolean insertHistoricoCuerpoConvenio(HistoricoCuerpoConvenio temp) {
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String stringInsert = String.format(queryInsertHistoricoCuerpoConvenio,
				DB_13,
				temp.getIdConvenio(),
				temp.getIdModificacion(),
				temp.getIdRefaccion(),
				temp.getPcmn(),
				temp.getPcd(),
				temp.getCantidad(),
				temp.getIdPersonal(),
				fecha,
				hora,
				temp.getCantidadSurtida(),
				temp.getSaldo()
				);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}
	
	/**
	 * getDataEntradaNormal: obtiene la data de la entrada normal
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-27
	 */
	public List<GetDataEntradaNormal> getDataEntradaNormal(int anio, int idEntrada, int tipoEntrada) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetDataEntradaNormal,
						DB_13,
						anio,
						idEntrada,
						tipoEntrada,
						utilitiesRepository.getDb13()),
						GetDataEntradaNormal.class);
		return (List<GetDataEntradaNormal>) query.getResultList();
	}
	
	/**
	 * getDataEntrada: obtiene la data de los demás tipo de entradas
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-27
	 */
	public List<GetDataEntrada> getDataEntrada(int anio, int idEntrada, int tipoEntrada) {
		Query query = entityManager
				.createNativeQuery(String.format(				
						queryGetDataEntrada,
						DB_13,
						anio,
						idEntrada,
						tipoEntrada,
						utilitiesRepository.getDb13()),
						GetDataEntrada.class);
		return (List<GetDataEntrada>) query.getResultList();
	}
}