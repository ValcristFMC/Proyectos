package com.grupocastores.SiatEntradas.service.domain;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class RefPorAlmacen {
	
	@Id
	@Column(name="idrefaccion")
	private int idRefaccion;
	@Column(name="idalmacen")
	private int idAlmacen;
	@Column(name = "existencia")
	private Double existencia;
	@Column(name="rack")
	private String rack;
	@Column(name="fila")
	private String fila;
	@Column(name="renglon")
	private String renglon;
	@Column(name = "idpersonal")
	private int idPersonal;
	@Column(name = "fechahoramod", nullable = true)
	private Timestamp fechaHoraMod;
	@Column(name = "minimo")
	private Double minimo;
	@Column(name = "maximo")
	private Double maximo;
	@Column(name = "estatus")
	private int estatus;
	@Column(name = "puntoreorden")
	private Double puntoReorden;
}
