package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class Kardex {
	
	@Id
	@Column(name="idrefaccion")
	private int idRefaccion;
	@Column(name="idproveedor")
	private int idProveedor;
	@Column(name = "fecha", nullable = true)
	private LocalDate fecha;
	@Column(name = "hora", nullable = true)
	private LocalTime hora;
	@Column(name="tipomovimiento")
	private int tipoMovimiento;
	@Column(name="nomovimiento")
	private int noMovimiento;
	@Column(name = "idalmacen")
	private int idAlmacen;
	@Column(name = "cantidad")
	private Double cantidad;
	@Column(name = "precio")
	private Double precio;
	@Column(name = "estatus")
	private int estatus;
	@Column(name = "tipo")
	private int tipo;
	@Column(name = "esnueva")
	private int	 esNueva;	
	@Column(name="idmoneda")
	private int idMoneda;
	@Column(name="idlote")
	private int idLote;
}
