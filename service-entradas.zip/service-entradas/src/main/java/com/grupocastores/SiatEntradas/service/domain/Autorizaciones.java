package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Autorizaciones", description = "mapea tabla de siat.autorizaciones")
@Entity
@Table(name = "siat.autorizaciones")
public class Autorizaciones {
	
	@Id
	@Column(name="tipomovimiento")
	private int tipoMovimiento;
	@Column(name="nomovimiento")
	private int noMovimiento;
	@Column(name = "idautorizo")
	private int idAutorizo;
	@Column(name = "idtipoautorizacion")
	private int idTipoAutorizacion;
	@Column(name = "idpersonal")
	private int idPersonal;
	@Column(name = "observaciones")
	private String observaciones;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
	@Column(name = "idautsistema")
	private int idAutSistema;
}
