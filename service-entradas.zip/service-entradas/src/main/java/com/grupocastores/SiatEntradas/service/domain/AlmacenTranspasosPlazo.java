package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de CatalogoRequisiciones", description = "mapea tabla de siat.requisiciones")
@Entity
@Table(name = "siat.almacen_traspasos_plazo")
public class AlmacenTranspasosPlazo {
	
	@Id
	@Column(name="idalmacen", nullable = true)
	private int idAlmacen;
	@Column(name = "recepcion_dias", nullable = true)
	private int recepcionDias;
	@Column(name = "extplazo_dias", nullable = true)
	private int extplazoDias;
	@Column(name = "bloquear_entradas", nullable = true)
	private String bloquearEntradas;
	@Column(name = "bloquear_salidas", nullable = true)
	private String bloquearSalidas;
	@Column(name = "bloquear_traspasos", nullable = true)
	private String bloquearTraspasos;
	@Column(name="idpersonal", nullable = true)
	private int idPersonal;
	@Column(name = "fecha", nullable = true)
	private LocalDate fecha;
	@Column(name = "hora", nullable = true)
	private LocalTime hora;
}
