package com.grupocastores.SiatEntradas.utils;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.grupocastores.SiatEntradas.service.domain.Servidores;


/**
 * UtilitiesRepository: Repositorio base para para usar con servidores vinculados.
 * 
 * @version 0.0.1
 * @author Moises Lopez Arrona [moisesarrona]
 * @date 2022-06-14
 */

@Repository
public class UtilitiesRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public static final String DB_23 = "PRODUCCION23";
	public static final String DB_13 = "PRUEBAS13";
	public static final String DBPRUEBASOFICINA= "TIJUANAPRUEBA";
	public static final String queryGetLinkedServerByIdOficina = 
			"SELECT * FROM syn.dbo.v_Oficinas where Oficina = \'%s\'";

	/**
	 * getLinkedServerByOfice: Obtiene el servidor vinculado por id de oficina
	 * 
	 * @param idOficina (String) consulta a ejecutar
	 * @return Boolean
	 * @author Atzin Moreno
	 * @date 2023-07-20
	 */
    protected String formatoMySqlToSqlServer(String qryMysql, String dataBaseSelect) {
		return "SELECT * FROM OPENQUERY(" + dataBaseSelect + ","
				+ "'" + qryMysql + ";' )";
	}
    
    protected String formatoMySqlToSqlServerExec(String qryMysql, String dataBaseSelect) {
        return "EXEC ('" + qryMysql + ";' ) AT " + dataBaseSelect + ";";
    }
    
	@SuppressWarnings("unchecked")
	public Servidores getLinkedServerByOfice(String idOficina) {
		Query query = entityManager.createNativeQuery(String.format(queryGetLinkedServerByIdOficina,
				idOficina),Servidores.class
			);
		if(query.getResultList().isEmpty()) {
			return null;
		}
		return (Servidores) query.getResultList().get(0);
	}

    public static String getDb23() {
        return DB_23;
    }

    public static String getDb13() {
        return DB_13;
    }
    
    public static String getDbPruebasOficina() {
        return DBPRUEBASOFICINA;
    }

    /**
	 * executeStoredProcedure: Ejecuta un procedimiento alamcenado para Guardar, Editar
	 * 
	 * @param query (String) consulta a ejecutar
	 * @return Boolean
	 * @author Atzin Moreno
	 * @date 2023-07-26
	 */
	public Boolean executeStoredProcedure(String query) {
		int resp = 0;
		StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("PcrExecSQL");
		storedProcedure.registerStoredProcedureParameter("sql", String.class, ParameterMode.IN);
		storedProcedure.registerStoredProcedureParameter("respuesta", String.class, ParameterMode.OUT);
		storedProcedure.setParameter("sql", query);
		storedProcedure.execute();
		resp = Integer.valueOf((String) storedProcedure.getOutputParameterValue("respuesta"));
		return resp > 0 ? true : false;
	}
    
	
}
