package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class Entradas {
	
	@Id
	@Column(name="identrada")
	private int idEntrada;
	@Column(name = "clave")
	private String clave;
	@Column(name = "tabla")
	private int tabla;
	@Column(name = "tipoentrada")
	private int	 tipoEntrada;
	@Column(name = "impresion")
	private int impresion;
	
}
