
package com.grupocastores.SiatEntradas.service.impl;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.grupocastores.SiatEntradas.service.domain.SiatEntradas;
import com.grupocastores.SiatEntradas.service.domain.Tempoliza;
import com.grupocastores.SiatEntradas.service.domain.TempolizaRefaccion;
import com.grupocastores.SiatEntradas.service.domain.TipoAutorizaciones;
import com.grupocastores.SiatEntradas.service.domain.TipoCambio;
import com.grupocastores.SiatEntradas.service.domain.TipoSolicitud;
import com.grupocastores.SiatEntradas.service.domain.TotalGrid;
import com.grupocastores.SiatEntradas.service.domain.TraspasosGrupos;
import com.grupocastores.SiatEntradas.service.domain.UpdateRefacciones;
import com.grupocastores.SiatEntradas.service.domain.ValidacionEntrada;
import com.grupocastores.SiatEntradas.service.repository.SiatHistoricoConvenioRespository;
import com.grupocastores.SiatEntradas.service.domain.Almacen;
import com.grupocastores.SiatEntradas.service.domain.AlmacenTranspasosPlazo;
import com.grupocastores.SiatEntradas.service.domain.Autorizaciones;
import com.grupocastores.SiatEntradas.service.domain.BancoProveedor;
import com.grupocastores.SiatEntradas.service.domain.CantidadesEntradas;
import com.grupocastores.SiatEntradas.service.domain.CatalogoAlmacen;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibos;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibosInfo;
import com.grupocastores.SiatEntradas.service.domain.ControlCambio;
import com.grupocastores.SiatEntradas.service.domain.ControlEntrada;
import com.grupocastores.SiatEntradas.service.domain.ConvenioInf;
import com.grupocastores.SiatEntradas.service.domain.ConvenioProveedor;
import com.grupocastores.SiatEntradas.service.domain.ConvenioRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Convenios;
import com.grupocastores.SiatEntradas.service.domain.CuerpoDetalle;
import com.grupocastores.SiatEntradas.service.domain.CuerpoFactura;
import com.grupocastores.SiatEntradas.service.domain.CuerpoOrden;
import com.grupocastores.SiatEntradas.service.domain.CuerpoRequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.DetalleEntrada;
import com.grupocastores.SiatEntradas.service.domain.Entradas;
import com.grupocastores.SiatEntradas.service.domain.EntradasAnio;
import com.grupocastores.SiatEntradas.service.domain.EntradasFechapol;
import com.grupocastores.SiatEntradas.service.domain.EntradasInfo;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrden;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrdenAnticipo;
import com.grupocastores.SiatEntradas.service.domain.FolioAlmacen;
import com.grupocastores.SiatEntradas.service.domain.GetMotivo;
import com.grupocastores.SiatEntradas.service.domain.GetProveedor;
import com.grupocastores.SiatEntradas.service.domain.Folio;
import com.grupocastores.SiatEntradas.dto.ConvenioHistoricoDTO;
import com.grupocastores.SiatEntradas.dto.ResponseDTO;
import com.grupocastores.SiatEntradas.service.domain.GridEntradas;
import com.grupocastores.SiatEntradas.service.domain.GridFacturas;
import com.grupocastores.SiatEntradas.service.domain.Grupos;
import com.grupocastores.SiatEntradas.service.domain.IdRefaccionGrid;
import com.grupocastores.SiatEntradas.service.domain.Importe;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradas;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradasFactura;
import com.grupocastores.SiatEntradas.service.domain.ImprimirGeneral;
import com.grupocastores.SiatEntradas.service.domain.KardexInformacion;
import com.grupocastores.SiatEntradas.service.domain.InformacionRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Iva;
import com.grupocastores.SiatEntradas.service.domain.Kardex;
import com.grupocastores.SiatEntradas.service.domain.KardexMovimiento;
import com.grupocastores.SiatEntradas.service.domain.KardexRefacciones;
import com.grupocastores.SiatEntradas.service.domain.Lotes;
import com.grupocastores.SiatEntradas.service.domain.Movimientos;
import com.grupocastores.SiatEntradas.service.domain.Ordenes;
import com.grupocastores.SiatEntradas.service.domain.OrdenesAnio;
import com.grupocastores.SiatEntradas.service.domain.Polizas;
import com.grupocastores.SiatEntradas.service.domain.PolizasAnio;
import com.grupocastores.SiatEntradas.service.domain.RefPorAlmacen;
import com.grupocastores.SiatEntradas.service.domain.RefaccionesPorSurtir;
import com.grupocastores.SiatEntradas.service.domain.Refaproveedor;
import com.grupocastores.SiatEntradas.service.domain.RequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.RequisicionHistorico;
import com.grupocastores.SiatEntradas.service.domain.ResumenCompra;
import com.grupocastores.SiatEntradas.service.domain.RptContraRecibo;
import com.grupocastores.SiatEntradas.service.domain.SemaforoSiat;
import com.grupocastores.SiatEntradas.utils.UtilitiesRepository;
import com.grupocastores.SiatEntradas.service.ISiatConveniosHistoricoService;
import com.grupocastores.SiatEntradas.service.ISiatEntradasService;


@Service
public class ISiatConveniosHistoricoServiceImpl implements ISiatConveniosHistoricoService {

    Logger logger = LoggerFactory.getLogger(ISiatConveniosHistoricoService.class);

    @Autowired
    private SiatHistoricoConvenioRespository siatHistoricoConvenioRespository;

    @Override
    public ResponseDTO<List<ConvenioHistoricoDTO>> getHistoricoConvenioById(int idConvenio, int idModificacion, int idRefaccion, int numCampo) {
        ResponseDTO<List<ConvenioHistoricoDTO>> response = new ResponseDTO<>();
        List<ConvenioHistoricoDTO> historicoConvenio = siatHistoricoConvenioRespository.getHistoricoConvenioById(idConvenio, idModificacion, idRefaccion, numCampo);

        if(historicoConvenio.isEmpty()) {
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("No fue posible obtener el historico de convenio");
            response.setData(null);
            return response;
        	}
	        response.setCode(1);
	        response.setDescription("success");
	        response.setMessage("Registros obtenidos correctamente");
	        response.setData(historicoConvenio);
	        return response;
    		}

    @Override
    public ResponseDTO<Void> insertHistoricoConvenio(ConvenioHistoricoDTO historico) {
        ResponseDTO<Void> response = new ResponseDTO<>();
        try {
        	if(siatHistoricoConvenioRespository.insertHistoricoConvenio(historico)) {
            response.setCode(1);
            response.setDescription("success");
            response.setMessage("Historico de convenio insertado correctamente");
        	} else { 
        	response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al insertar historico de convenio");
            }
        	
        } catch (Exception e) {
            logger.error("Error al insertar historico de convenio", e);
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al insertar historico de convenio");
        }
        return response;
    }

    @Override
    public ResponseDTO<Void> updateHistoricoConvenio(ConvenioHistoricoDTO historico) {
        ResponseDTO<Void> response = new ResponseDTO<>();
        try {
            if(siatHistoricoConvenioRespository.updateHistoricoConvenio(historico)) {
            response.setCode(1);
            response.setDescription("success");
            response.setMessage("Historico de convenio actualizado correctamente");
            } else {
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al actualizar historico de convenio");
            }
        } catch (Exception e) {
            logger.error("Error al actualizar historico de convenio", e);
            response.setCode(0);
            response.setDescription("error");
            response.setMessage("Error al actualizar historico de convenio");
        }
        return response;
    }
}
