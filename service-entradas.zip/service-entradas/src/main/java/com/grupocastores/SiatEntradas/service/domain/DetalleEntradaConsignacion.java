package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Requisición Anio", description = "mapea tabla de siat.entradasAnio")
@Entity
@Table(name = "siat.entradasAnio")
public class DetalleEntradaConsignacion {
	
	@Id
	@Column(name="idgrupo")
	private int idGrupo;
	@Column(name="SUBTOTAL")
	private Double subtotal;
	@Column(name = "IVA")
	private Double iva;
	@Column(name = "TOTAL", nullable = true)
	private Double total;
	@Column(name = "idrefaccion", nullable = true)
	private int idRefaccion;
	@Column(name = "fecha", nullable = true)
	private LocalDate fecha;
	@Column(name = "hora", nullable = true)
	private LocalTime hora;
	@Column(name = "idalmacen", nullable = true)
	private Double idAlmacen;
}
