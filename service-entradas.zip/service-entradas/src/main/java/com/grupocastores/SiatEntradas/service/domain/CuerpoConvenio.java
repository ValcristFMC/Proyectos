package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Gabriel Garcia - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion del cuerpo del convenio", description = "mapea tabla de siat.cuerpoconvenio")
@Entity
@Table(name = "siat.cuerpoconvenio")
public class CuerpoConvenio {
	
	@Id
	@Column(name="idconvenio", nullable = true)
	private int idConvenio;
	@Column(name = "idrefaccion" , nullable = true)
	private String idRefaccion;
	@Column(name = "pcmn" , nullable = true)
	private int pcmn;
	@Column(name = "pcd" , nullable = true)
	private int pcd;
	@Column(name = "cantidad" , nullable = true)
	private int cantidad;
	@Column(name = "idpersonal" , nullable = true)
	private int idPersonal;
	@Column(name = "fecha" , nullable = true)
	private LocalDate fecha;
	@Column(name = "hora" , nullable = true)
	private LocalTime hora;
	@Column(name = "cantidad_surtida" , nullable = true)
	private String cantidadSurtida;
	@Column(name = "saldo" , nullable = true)
	private int saldo;
}
