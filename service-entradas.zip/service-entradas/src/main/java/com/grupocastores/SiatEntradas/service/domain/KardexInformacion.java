package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class KardexInformacion {
	
	@Id
	@Column(name="clave")
	private String clave;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "esnueva")
	private int esNueva;
	@Column(name = "cantidad")
	private double cantidad;
	@Column(name = "precio")
	private double	 precio;
	@Column(name = "idrefaccion")
	private int idRefaccion;
	@Column(name = "nombreproveedor")
	private String nombreProveedor;
	@Column(name = "idproveedor")
	private int idProveedor;
	@Column(name = "idlote")
	private int idLote;
	@Column(name = "idalmacen")
	private int idAlmacen;
	@Column(name = "idgrupo")
	private int idGrupo;	
}
