package com.grupocastores.SiatEntradas.service.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.grupocastores.SiatEntradas.dto.SiatEntradasDTO;

/**
 * Clase SiatEntradas del dominio tiene su correspondiente {@link SiatEntradasDTO}
 *
 * @author Castores - Desarrollo TI
 */
@Data
@Entity
@Table(name = "siatEntradas")
@EntityListeners(SiatEntradas.class)
public class SiatEntradas 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "description") 
	private String description;
	
	@CreatedDate
	@Column(name = "created_date", nullable = false, updatable = false)
	private Date createddate;
	
	@LastModifiedDate
	@Column(name = "last_modified_date", nullable = false, updatable = true)
	private Date lastModifiedTime;
	
	@Column(name = "is_active")
	private Boolean isActive;
	
	
	/**
	 * Metodo estatico para obtener un SiatEntradas a partir de un SiatEntradasDTO origen
	 * 
	 * @param siatEntradas SiatEntradasDTO origen
	 * 
	 * @return SiatEntradas
	 */
	public static SiatEntradas fromSiatEntradasDTO(SiatEntradasDTO siatEntradas) {
		SiatEntradas rest = new SiatEntradas();
		rest.setId(siatEntradas.getId());
		rest.setDescription(siatEntradas.getDescription());
		rest.setCreateddate(siatEntradas.getCreateddate());		
		rest.setLastModifiedTime(siatEntradas.getLastModifiedTime());
		rest.setIsActive(siatEntradas.getIsActive());
		return rest;
	}
	
	/**
	 * Metodo para obtener un SiatEntradasDTO a partir de un SiatEntradas origen
	 * 
	 * @return SiatEntradasDTO
	 */
	public SiatEntradasDTO toSiatEntradasDTO() {
		 SiatEntradasDTO dto = new  SiatEntradasDTO();
		 dto.setId(this.getId());
		 dto.setDescription(this.getDescription());
		 dto.setCreateddate(this.getCreateddate());
		 dto.setLastModifiedTime(this.getLastModifiedTime());
		 dto.setIsActive(this.getIsActive());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("SiatEntradas [id=").append(id)
		.append(", description=").append(description)
		.append(",IsActive=").append(isActive)
		.append(",CreatedDate=").append(createddate)
		.append(",LastModifiedTime=").append(lastModifiedTime);		
		return strBuilder.toString();
	}
}
