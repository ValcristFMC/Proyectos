package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de poliza", description = "mapea tabla de siat.poliza")
@Entity
@Table(name = "siat.poliza")
public class Polizas {
	
	@Id
	@Column(name="idpoliza")
	private int idPoliza;
	@Column(name="numpoliza")
	private int numPoliza;
	@Column(name = "tabla")
	private int tabla;
	@Column(name="idtipopol")
	private int idTipoPol;
	@Column(name = "STATUS")
	private int status;
	@Column(name="esautomatica")
	private int esAutomatica;
}
