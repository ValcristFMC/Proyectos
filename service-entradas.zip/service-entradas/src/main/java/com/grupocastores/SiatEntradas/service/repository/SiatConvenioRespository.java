package com.grupocastores.SiatEntradas.service.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.grupocastores.SiatEntradas.dto.ConvenioDTO;
import com.grupocastores.SiatEntradas.utils.UtilitiesRepository;
import com.grupocastores.SiatEntradas.utils.UtilsDatetime;

@Repository
public class SiatConvenioRespository extends UtilitiesRepository{
	private String dataBaseSelect = DB_13;
				
	public static final String qryConvenioBase = "SELECT idconvenio AS id_convenio , tipoconvenio AS tipo_convenio , proveedornombre AS proveedor_nombre, fechainicio AS fecha_inicio, fechafin AS fecha_fin, estatus, cast(total as decimal(16,8)) as total, observaciones, idproveedor as id_proveedor FROM siat.convenio_view";
	public static final String condicionalMayorIgualCero = "WHERE estatus >= 0 AND idconvenio = idconvenio  GROUP BY idconvenio  ORDER BY idproveedor";
	public static final String condicionalIgualEstatus = "WHERE estatus = %s GROUP BY idconvenio ORDER BY idproveedor";
    public static final String qryConvenioById = "SELECT idconvenio AS id_convenio , tipoconvenio AS tipo_convenio , proveedornombre AS proveedor_nombre, fechainicio AS fecha_inicio, fechafin AS fecha_fin, estatus, cast(total as decimal(16,8)) as total, observaciones, idproveedor as id_proveedor FROM siat.convenio_view WHERE idconvenio = %s";
    public static final String qryInsertConvenio = "INSERT INTO siat.convenios(idconvenio,tipoconvenio, idproveedor, fechainicio, fechafin, saldo_total, observaciones, estatus,idpersonal) VALUES(%s,\"%s\", %s, \"%s\", \"%s\", %s, \"%s\", %s,%s)";
    public static final String qryUpdateConvenio = "UPDATE siat.convenios SET tipoconvenio = \"%s\", idproveedor = %s, fechainicio = \"%s\", fechafin = \"%s\", total = %s, observaciones = \"%s\", estatus = %s WHERE idconvenio = %s";
    public static final String qryUpdateConvenioEstatus = "UPDATE siat.convenios SET estatus = %s WHERE idconvenio = %s";
    public static final String qryLastId = "SELECT MAX(idconvenio) FROM siat.convenios";

	
	private String lastQuery = "";
	
	@PersistenceContext
	private EntityManager entityManager;
	
	private String makeQryConvenioByEstatus(int estatus) {
		if(estatus != 2) {
            return formatoMySqlToSqlServer(String.format(qryConvenioBase + " " + condicionalIgualEstatus, estatus), dataBaseSelect);
		}else {
			return formatoMySqlToSqlServer(qryConvenioBase + " " + condicionalMayorIgualCero, dataBaseSelect);
		}
	}

    private String makeQryConvenioById(int id) {
        return formatoMySqlToSqlServer(String.format(qryConvenioById, id), dataBaseSelect);
    }

    private String makeQryInsertConvenio(ConvenioDTO convenio) {
    	UtilsDatetime util = new UtilsDatetime();
        return formatoMySqlToSqlServerExec(String.format(qryInsertConvenio,convenio.getIdConvenio(), convenio.getTipoConvenio(), convenio.getIdProveedor(), util.dateToStringDMY(convenio.getFechaInicio()), util.dateToStringDMY(convenio.getFechaFin()), convenio.getTotal(), convenio.getObservaciones(), convenio.getEstatus(), convenio.getIdpersonal()), dataBaseSelect);
    }

    private String makeQryUpdateConvenio(ConvenioDTO convenio) {
    	UtilsDatetime util = new UtilsDatetime();
        return formatoMySqlToSqlServerExec(String.format(qryUpdateConvenio, convenio.getTipoConvenio(), convenio.getIdProveedor(), util.dateToStringDMY(convenio.getFechaInicio()), util.dateToStringDMY(convenio.getFechaFin()), convenio.getTotal(), convenio.getObservaciones(), convenio.getEstatus(), convenio.getIdConvenio()), dataBaseSelect);
    }

    private String makeQryUpdateConvenioEstatus(int estatus, int id) {
        return formatoMySqlToSqlServerExec(String.format(qryUpdateConvenioEstatus, estatus, id), dataBaseSelect);
    }


	@SuppressWarnings("unchecked")
	public List<ConvenioDTO> lstConvenios(int estatus) throws Exception {
	    lastQuery = makeQryConvenioByEstatus(estatus);
	    Query query = entityManager.createNativeQuery(lastQuery, ConvenioDTO.class);
	    return (List<ConvenioDTO>) query.getResultList();
	}

    public ConvenioDTO getConvenioById(int id) throws Exception {
        lastQuery = makeQryConvenioById(id);
        Query query = entityManager.createNativeQuery(lastQuery, ConvenioDTO.class);
        return (ConvenioDTO) query.getSingleResult();
    }


    private String makeQryLastId() {
        return formatoMySqlToSqlServer(qryLastId, dataBaseSelect);
    }

    public Boolean insertConvenio(ConvenioDTO convenio) throws Exception {
        lastQuery = makeQryInsertConvenio(convenio);
        System.out.println("Esta es la qry: " + lastQuery);
        return executeStoredProcedure(lastQuery);
        
    }

    public Boolean updateConvenio(ConvenioDTO convenio) throws Exception {
        lastQuery = makeQryUpdateConvenio(convenio);
        System.out.println("Esta es la qry: " + lastQuery);
        return executeStoredProcedure(lastQuery);
    }

    public Boolean updateConvenioEstatus(int estatus, int id) throws Exception {
        lastQuery = makeQryUpdateConvenioEstatus(estatus, id);
        System.out.println("Esta es la qry: " + lastQuery);
        return executeStoredProcedure(lastQuery);
    }
    
    public int getLastId() throws Exception {
        lastQuery = makeQryLastId();
        Query query = entityManager.createNativeQuery(lastQuery);
        return (int) query.getSingleResult();
    }
    
    

	public String getLastQuery() {
		return lastQuery;
	}

	public void setLastQuery(String lastQuery) {
		this.lastQuery = lastQuery;
	}
	
}
