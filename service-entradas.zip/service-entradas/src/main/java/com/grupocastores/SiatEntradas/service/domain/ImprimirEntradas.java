package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class ImprimirEntradas {
	
	@Id
	@Column(name="horaent")
	private LocalTime horaEnt;
	@Column(name="noentrada")
	private int noEntrada;
	@Column(name="fechaent")
	private LocalDate fechaEnt;
	@Column(name = "fechafact", nullable = true)
	private LocalDate fechaFact;
	@Column(name = "estatus", nullable = true)
	private String estatus;
	@Column(name="noorden")
	private String noOrden;
	@Column(name="factura")
	private String factura;
	@Column(name = "tipo")
	private String tipo;
	@Column(name = "norequisicion")
	private String noRequisicion;
	@Column(name = "proveedor")
	private String proveedor;
	@Column(name = "observaciones")
	private String observaciones;
	@Column(name = "tipoentrada")
	private String tipoEntrada;
	@Column(name = "impresion")
	private int impresion;
	@Column(name = "identrada")
	private int	 idEntrada;	
	@Column(name="tituloentrada")
	private String tituloEntrada;
	@Column(name="almacen")
	private String almacen;
	@Column(name="tipocambio")
	private Double tipoCambio;
}
