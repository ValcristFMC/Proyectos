package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de CatalogoRequisiciones", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.almacen")
public class Grupos {
	
	@Id
	@Column(name="idgrupo", nullable = true)
	private int idGrupo;
	@Column(name = "clave", nullable = true)
	private int clave;
	@Column(name = "nombre", nullable = true)
	private String nombre;
	@Column(name = "cuenta", nullable = true)
	private String cuenta;
	@Column(name="estatus", nullable = true)
	private int estatus;
	@Column(name = "idpersonal", nullable = true)
	private int idPersonal;
	@Column(name = "fecha", nullable = true)
	private LocalDate fecha;
	@Column(name = "hora", nullable = true)
	private LocalTime hora;
	@Column(name = "cuenta_consignacion", nullable = true)
	private String cuentaConsignacion;
	@Column(name = "seriar", nullable = true)
	private int seriar;
}
