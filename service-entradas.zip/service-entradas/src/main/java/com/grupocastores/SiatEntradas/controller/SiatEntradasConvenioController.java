package com.grupocastores.SiatEntradas.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.grupocastores.SiatEntradas.dto.ConvenioDTO;
import com.grupocastores.SiatEntradas.dto.ResponseDTO;
import com.grupocastores.SiatEntradas.service.ISiatConveniosService;

import io.swagger.annotations.Api;

@RestController
@RequestMapping(value = "/SiatEntradasConvenio")
@Api(value = "SiatEntradasConvenioController", produces = "application/json")
@CrossOrigin(origins = "*")
public class SiatEntradasConvenioController {
	
	private static final Logger logger = LoggerFactory.getLogger(SiatEntradasConvenioController.class);
	
	@Autowired
	private ISiatConveniosService iSiatConveniosService;
	
	@GetMapping("/getConveniosByEstatus/{estatus}")
	@ResponseBody
	public ResponseEntity<?> getLstConvenios(@PathVariable("estatus") int estatus) {
		try {
			List<ConvenioDTO> lstConvenios = iSiatConveniosService.getLstConvenios(estatus);	
			return ResponseEntity.ok(lstConvenios);
		} catch (Exception e) {
			logger.error("Error en getLstConvenios()", e);
			Map<String, Object> response = new HashMap<>();
			response.put("error", "Error en getLstConvenios()"); 	
			response.put("message", e.getLocalizedMessage());
			response.put("class", this.getClass().getSimpleName());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/getConvenioById/{id}")
	@ResponseBody
	public ResponseEntity<?> getConvenioById(@PathVariable("id") int id) {
		try {
			ConvenioDTO convenio = iSiatConveniosService.getConvenioById(id);	
			return ResponseEntity.ok(convenio);
		} catch (Exception e) {
			logger.error("Error en getConvenioById()", e);
			Map<String, Object> response = new HashMap<>();
			response.put("error", "Error en getConvenioById()"); 	
			response.put("message", e.getLocalizedMessage());
			response.put("class", this.getClass().getSimpleName());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/insertConvenio")
	@ResponseBody
	public ResponseEntity<?> insertConvenio(@RequestBody ConvenioDTO convenio) {
		try {
            convenio.setIdConvenio(iSiatConveniosService.getLastId() + 1);
			ResponseDTO<Void> response = iSiatConveniosService.insertConvenio(convenio);
			return new ResponseEntity<>(response, HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error en insertConvenio()", e);
			Map<String, Object> response = new HashMap<>();
			response.put("error", "Error en insertConvenio()"); 	
			response.put("message", e.getLocalizedMessage());
			response.put("class", this.getClass().getSimpleName());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/updateConvenio")
	@ResponseBody
	public ResponseEntity<?> updateConvenio(@RequestBody ConvenioDTO convenio) {
		try {
			ResponseDTO<Void> response = iSiatConveniosService.updateConvenio(convenio);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error en updateConvenio()", e);
			Map<String, Object> response = new HashMap<>();
			response.put("error", "Error en updateConvenio()"); 	
			response.put("message", e.getLocalizedMessage());
			response.put("class", this.getClass().getSimpleName());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/updateConvenioEstatus/{estatus}/{id}")
	@ResponseBody
	public ResponseEntity<?> updateConvenioEstatus(@PathVariable("estatus") int estatus, @PathVariable("id") int id) {
		try {
			ResponseDTO<Void> response = iSiatConveniosService.updateConvenioEstatus(estatus, id);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error en updateConvenioEstatus()", e);
			Map<String, Object> response = new HashMap<>();
			response.put("error", "Error en updateConvenioEstatus()"); 	
			response.put("message", e.getLocalizedMessage());
			response.put("class", this.getClass().getSimpleName());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
