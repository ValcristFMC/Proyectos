package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class ListaCuerpoConvenio {
	
	@Id
	@Column(name="clave")
	private String clave;
	@Column(name = "nombre")
	private String nombre;
	@Column(name = "cantidad")
	private Double cantidad;
	@Column(name = "pcmn")
	private Float pcmn;
	@Column(name = "pcd")
	private Float pcd;
	@Column(name = "importe_pesos")
	private Float	importePesos;
	@Column(name = "importe_dolares")
	private Float importeDolares;
	@Column(name = "cantidad_surtida")
	private Float cantidadSurtida;
	@Column(name = "existencia")
	private Double existencia;
	@Column(name = "existencia_proveedor")
	private Double existenciaProveedor;
	@Column(name = "saldo")
	private Double saldo;
	@Column(name = "idrefaccion")
	private int idRefaccion;
	@Column(name = "dias")
	private int dias;
	@Column(name = "idproveedor")
	private int idProveedor;
	@Column(name = "piezas_en_contrarecibo")
	private Float piezasEnContrarecibo;
	@Column(name = "piezas_sin_contrarecibo")
	private Float piezasSinContrarecibo;
	@Column(name = "saldo_mn")
	private Float saldoMn;
	@Column(name = "saldo_dlls")
	private Float saldoDlls;
}
