package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Grid Facturas", description = "mapea tabla de siat.requisiciones")
@Entity
@Table(name = "siat.ordencompra")
public class GridFacturas {
	
	@Id
	@Column(name = "hora", nullable = true)
	private LocalTime hora;
	@Column(name = "idfacturaorden", nullable = true)
	private int idFacturaOrden;
	@Column(name="idrequisicion", nullable = true)
	private int idRequisicion;
	@Column(name="clave", nullable = true)
	private String clave;
	@Column(name = "idordencompra", nullable = true)
	private int idOrdenCompra;
	@Column(name = "idproveedor", nullable = true)
	private int idProveedor;
	@Column(name = "factura", nullable = true)
	private String factura;
	@Column(name = "fechamod", nullable = true)
	private LocalDate fechaMod;
	@Column(name="idalmacen", nullable = true)
	private int idAlmacen;
	@Column(name="razonsocial", nullable = true)
	private String razonSocial;
	@Column(name="nombrealmacen", nullable = true)
	private String nombreAlmacen;
	@Column(name="difdias", nullable = true)
	private int difDias;
	@Column(name="idestatus", nullable = true)
	private int idEstatus;
	@Column(name="nombre", nullable = true)
	private String nombre;
}
