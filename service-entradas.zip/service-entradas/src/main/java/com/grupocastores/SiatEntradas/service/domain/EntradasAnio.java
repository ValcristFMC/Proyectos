package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class EntradasAnio {
	
	@Id
	@Column(name="identrada")
	private int idEntrada;
	@Column(name="idordencompra")
	private int idOrdenCompra;
	@Column(name="idfacturaorden")
	private int idFacturaOrden;
	@Column(name="idproveedor")
	private int idProveedor;
	@Column(name = "claveentrada")
	private String claveEntrada;
	@Column(name = "cantidad")
	private Double cantidad;
	@Column(name = "idestatus")
	private int	 idEstatus;
	@Column(name = "idpersonal")
	private int idPersonal;
	@Column(name="observaciones")
	private String observaciones;
	@Column(name="tipo")
	private int tipo;
	@Column(name="fecha")
	private LocalDate fecha;
	@Column(name="hora")
	private LocalTime hora;
	@Column(name="idmotivo")
	private int idMotivo;
	@Column(name="idalmacen")
	private int idAlmacen;
	
}
