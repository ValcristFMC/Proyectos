package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de CatalogoRequisiciones", description = "mapea tabla de siat.requisiciones")
@Entity
@Table(name = "siat.requisiciones2023")
public class GridEntradas {
	
	@Id
	@Column(name="identrada", nullable = true)
	private int idEntrada;
	@Column(name = "tipo", nullable = true)
	private int tipo;
	@Column(name = "idordencompra", nullable = true)
	private int idOrdenCompra;
	@Column(name = "factura", nullable = true)
	private String factura;
	@Column(name = "prov", nullable = true)
	private String prov;
	@Column(name = "idestatus", nullable = true)
	private String idEstatus;
	@Column(name = "fecha", nullable = true)
	private LocalDate fecha;
	@Column(name = "hora", nullable = true)
	private LocalTime hora;
	@Column(name="idmotivo", nullable = true)
	private int idMotivo;
	@Column(name="idfacturaorden", nullable = true)
	private int idFacturaOrden;
	@Column(name="claveentrada", nullable = true)
	private String claveEntrada;
	@Column(name="tipounidad", nullable = true)
	private String tipoUnidad;
	@Column(name="nombre", nullable = true)
	private String nombre;
	@Column(name="folio", nullable = true)
	private String folio;
	@Column(name="idsalida", nullable = true)
	private String idSalida;
	@Column(name="idfactura", nullable = true)
	private String idFactura;
	@Column(name = "fac", nullable = true)
	private String fac;
	@Column(name = "contrarecibo", nullable = true)
	private int contraRecibo;
	@Column(name="iva", nullable = true)
	private Double iva;
	@Column(name="sepagara", nullable = true)
	private int sePagara;
	@Column(name="ids", nullable = true)
	private Integer ids;
	@Column(name="tabla", nullable = true)
	private Integer tabla;
	@Column(name="total", nullable = true)
	private String total;
	@Column(name="idmoneda", nullable = true)
	private Integer idMoneda;
	@Column(name="ivaOC", nullable = true)
	private String ivaOC;
	@Column(name="observaciones", nullable = true)
	private String observaciones;
	@Column(name="idalmacen", nullable = true)
	private int idAlmacen;
	@Column(name="nomalmacen", nullable = true)
	private String nomAlmacen;
	@Column(name = "fechasalida", nullable = true)
	private LocalDate fechaSalida;
	@Column(name="idsubtiporequisicion", nullable = true)
	private Integer idSubtipoRequisicion;
}
