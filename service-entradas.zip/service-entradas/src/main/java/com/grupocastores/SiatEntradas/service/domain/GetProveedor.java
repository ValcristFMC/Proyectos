package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de Grid", description = "")
@Entity
@Table(name = "")
public class GetProveedor {
	@Id
	@Column(name="idproveedor")
	private Integer idProveedor;
	@Column(name="apepaterno")
	private String apePaterno;
	@Column(name="apematerno")
	private String apeMaterno;
	@Column(name="nombre")
	private String nombre;
	@Column(name="razonsocial")
	private String razonSocial;
	@Column(name="porc_iva")
	private Double porcIva;
	@Column(name="porc_retencion")
	private Double porcRetencion;
	@Column(name="cuenta")
	private String cuenta;
}
