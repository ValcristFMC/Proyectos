package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class HistoricoCuerpoConvenio {
	
	@Id
	@Column(name="idconvenio")
	private int idConvenio;
	@Column(name = "idmodificacion")
	private int idModificacion;
	@Column(name = "idrefaccion")
	private int idRefaccion;
	@Column(name = "pcmn")
	private Double	 pcmn;
	@Column(name = "pcd")
	private Double pcd;
	@Column(name = "cantidad")
	private Double	cantidad;
	@Column(name = "idpersonal")
	private int idPersonal;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
	@Column(name = "cantidad_surtida")
	private Double CantidadSurtida;
	@Column(name = "saldo")
	private Double saldo;
}
