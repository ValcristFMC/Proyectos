package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de entradas", description = "mapea tabla de siat.entradas")
@Entity
@Table(name = "siat.entradas")
public class HistoricoConvenio {
	
	@Id
	@Column(name="idconvenio")
	private int idConvenio;
	@Column(name = "idmodificacion")
	private int idModificacion;
	@Column(name = "idrefaccion")
	private int idRefaccion;
	@Column(name = "numcampo")
	private int	 numCampo;
	@Column(name = "nomcampo")
	private String nomCampo;
	@Column(name = "valoranterior")
	private String	valorAnterior;
	@Column(name = "valornuevo")
	private String valorNuevo;
	@Column(name = "motivo")
	private String motivo;
	@Column(name = "idpersonal")
	private int idPersonal;
	@Column(name = "fecha")
	private LocalDate fecha;
	@Column(name = "hora")
	private LocalTime hora;
}
