package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "", description = "")
@Entity
@Table(name = "")
public class IdRefaccionGrid {
	
	@Id
	@Column(name="idrefaccion")
	private int idRefaccion;
	@Column(name="tipomoneda")
	private int tipoMoneda;
}
