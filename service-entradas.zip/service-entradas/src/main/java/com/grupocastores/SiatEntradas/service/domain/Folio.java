package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de folios Siat", description = "mapea tabla de siat.folios")
@Entity
@Table(name = "siat.folios")
public class Folio {
	
	@Id
	@Column(name="tipofolio")
	private int tipoFolio;
	@Column(name = "idfolio")
	private int idFolio;
	@Column(name = "clavefolio")
	private String claveFolio;
	@Column(name = "descripcion")
	private String descripcion;
	
}
