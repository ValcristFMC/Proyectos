package com.grupocastores.SiatEntradas.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.grupocastores.SiatEntradas.dto.ConvenioHistoricoDTO;
import com.grupocastores.SiatEntradas.dto.ResponseDTO;
import com.grupocastores.SiatEntradas.service.ISiatConveniosHistoricoService;
import com.grupocastores.SiatEntradas.service.domain.Polizas;

import io.swagger.annotations.Api;

@RestController
@RequestMapping(value = "/SiatEntradasHistoricoConvenio")
@Api(value = "SiatEntradasHistoricoConvenioController", produces = "application/json")
@CrossOrigin(origins = "*")
public class SiatHistoricoConvenioController {
	
	private static final Logger logger = LoggerFactory.getLogger(SiatHistoricoConvenioController.class);
	
	@Autowired
	private ISiatConveniosHistoricoService iSiatHistoricoConvenioService;
	
	@GetMapping("/SiatEntradasHistoricoConvenio/{idConvenio}/{idModificacion}/{idRefaccion}/{numCampo}")
	@ResponseBody
	public ResponseEntity<?> getHistoricoConvenioById(@PathVariable("idConvenio") int idConvenio, 
	                                                  @PathVariable("idModificacion") int idModificacion, 
	                                                  @PathVariable("idRefaccion") int idRefaccion,
	                                                  @PathVariable("numCampo") int numCampo) {
		try {
			ResponseDTO<List<ConvenioHistoricoDTO>> response = iSiatHistoricoConvenioService.getHistoricoConvenioById(idConvenio, idModificacion, idRefaccion, numCampo);
			return ResponseEntity.ok(response);
		} catch (Exception e) {
			logger.error("Error en getHistoricoConvenioById()", e);
			Map<String, Object> response = new HashMap<>();
			response.put("error", "Error en getHistoricoConvenioById()"); 	
			response.put("message", e.getLocalizedMessage());
			response.put("class", this.getClass().getSimpleName());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/insertHistoricoConvenio")
	@ResponseBody

		
	public ResponseEntity<?> insertHistoricoConvenio(@RequestBody ConvenioHistoricoDTO historico) {
		try {
			ResponseDTO<Void> response = iSiatHistoricoConvenioService.insertHistoricoConvenio(historico);
			return new ResponseEntity<>(response, HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error en insertHistoricoConvenio()", e);
			Map<String, Object> response = new HashMap<>();
			response.put("error", "Error en insertHistoricoConvenio()"); 	
			response.put("message", e.getLocalizedMessage());
			response.put("class", this.getClass().getSimpleName());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/updateHistoricoConvenio")
	@ResponseBody
	public ResponseEntity<?> updateHistoricoConvenio(@RequestBody ConvenioHistoricoDTO historico) {
		try {
			ResponseDTO<Void> response = iSiatHistoricoConvenioService.updateHistoricoConvenio(historico);
			return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error en updateHistoricoConvenio()", e);
			Map<String, Object> response = new HashMap<>();
			response.put("error", "Error en updateHistoricoConvenio()"); 	
			response.put("message", e.getLocalizedMessage());
			response.put("class", this.getClass().getSimpleName());
			return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
