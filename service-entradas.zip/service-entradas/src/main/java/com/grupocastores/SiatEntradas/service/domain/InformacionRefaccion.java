package com.grupocastores.SiatEntradas.service.domain;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Object para el {@link com.grupocastores.CatalogoRequisiciones.service.domain.CatalogoRequisiciones} del modelo de dominio
 *
 * @author Atzin Moreno - Desarrollo TI
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(value = "Informacion de las refacciones", description = "mapea tabla de siat.refacciones")
@Entity
@Table(name = "")
public class InformacionRefaccion {

	@Id
	@Column(name = "idrefaccion", nullable = true)
	private int idRefaccion;
	@Column(name="clave", nullable = true)
	private String clave;
	@Column(name = "nombre", nullable = true)
	private String nombre;
	@Column(name = "tiporef", nullable = true)
	private int tipoRef;
	@Column(name = "idgrupo", nullable = true)
	private int idGrupo;
	@Column(name="minimo", nullable = true)
	private Double minimo;
	@Column(name = "maximo", nullable = true)
	private Double maximo;
	@Column(name="pvmn", nullable = true)
	private Double pvmn;
	@Column(name = "pvd", nullable = true)
	private Double pvd;
	@Column(name="existencia", nullable = true)
	private Double existencia;
	@Column(name = "pcmn", nullable = true)
	private Double pcmn;
	@Column(name = "pcd", nullable = true)
	private Double pcd;
	@Column(name = "esnueva", nullable = true)
	private int esNueva;
}
