package com.grupocastores.SiatEntradas.service;

import java.util.List;

import com.grupocastores.SiatEntradas.service.domain.Almacen;
import com.grupocastores.SiatEntradas.service.domain.AlmacenTranspasosPlazo;
import com.grupocastores.SiatEntradas.service.domain.Autorizaciones;
import com.grupocastores.SiatEntradas.service.domain.BancoProveedor;
import com.grupocastores.SiatEntradas.service.domain.CantidadesEntradas;
import com.grupocastores.SiatEntradas.service.domain.CatalogoAlmacen;
import com.grupocastores.SiatEntradas.service.domain.CatCuentas;
import com.grupocastores.SiatEntradas.service.domain.CatCuentasAnio;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibos;
import com.grupocastores.SiatEntradas.service.domain.ContraRecibosInfo;
import com.grupocastores.SiatEntradas.service.domain.ControlCambio;
import com.grupocastores.SiatEntradas.service.domain.ControlEntrada;
import com.grupocastores.SiatEntradas.service.domain.ConvenioInf;
import com.grupocastores.SiatEntradas.service.domain.ConvenioProveedor;
import com.grupocastores.SiatEntradas.service.domain.ConvenioRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Convenios;
import com.grupocastores.SiatEntradas.service.domain.CuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.CuerpoDetalle;
import com.grupocastores.SiatEntradas.service.domain.CuerpoFactura;
import com.grupocastores.SiatEntradas.service.domain.CuerpoOrden;
import com.grupocastores.SiatEntradas.service.domain.CuerpoRequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.DetalleEntrada;
import com.grupocastores.SiatEntradas.service.domain.DetalleEntradaConsignacion;
import com.grupocastores.SiatEntradas.service.domain.Entradas;
import com.grupocastores.SiatEntradas.service.domain.EntradasAnio;
import com.grupocastores.SiatEntradas.service.domain.EntradasFechapol;
import com.grupocastores.SiatEntradas.service.domain.EntradasInfo;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrden;
import com.grupocastores.SiatEntradas.service.domain.FacturaOrdenAnticipo;
import com.grupocastores.SiatEntradas.service.domain.FolioAlmacen;
import com.grupocastores.SiatEntradas.service.domain.GetDataEntrada;
import com.grupocastores.SiatEntradas.service.domain.GetDataEntradaNormal;
import com.grupocastores.SiatEntradas.service.domain.GetMotivo;
import com.grupocastores.SiatEntradas.service.domain.GetProveedor;
import com.grupocastores.SiatEntradas.service.domain.Folio;
import com.grupocastores.SiatEntradas.dto.ResponseDTO;
import com.grupocastores.SiatEntradas.service.domain.GridEntradas;
import com.grupocastores.SiatEntradas.service.domain.GridFacturas;
import com.grupocastores.SiatEntradas.service.domain.Grupos;
import com.grupocastores.SiatEntradas.service.domain.HistoricoConvenio;
import com.grupocastores.SiatEntradas.service.domain.HistoricoCuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.IdRefaccionGrid;
import com.grupocastores.SiatEntradas.service.domain.Importe;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradas;
import com.grupocastores.SiatEntradas.service.domain.ImprimirEntradasFactura;
import com.grupocastores.SiatEntradas.service.domain.ImprimirGeneral;
import com.grupocastores.SiatEntradas.service.domain.KardexInformacion;
import com.grupocastores.SiatEntradas.service.domain.InformacionRefaccion;
import com.grupocastores.SiatEntradas.service.domain.Iva;
import com.grupocastores.SiatEntradas.service.domain.Kardex;
import com.grupocastores.SiatEntradas.service.domain.KardexMovimiento;
import com.grupocastores.SiatEntradas.service.domain.KardexRefacciones;
import com.grupocastores.SiatEntradas.service.domain.ListaCuerpoConvenio;
import com.grupocastores.SiatEntradas.service.domain.Lotes;
import com.grupocastores.SiatEntradas.service.domain.Movimientos;
import com.grupocastores.SiatEntradas.service.domain.Ordenes;
import com.grupocastores.SiatEntradas.service.domain.OrdenesAnio;
import com.grupocastores.SiatEntradas.service.domain.Polizas;
import com.grupocastores.SiatEntradas.service.domain.PolizasAnio;
import com.grupocastores.SiatEntradas.service.domain.RefPorAlmacen;
import com.grupocastores.SiatEntradas.service.domain.RefaccionesPorSurtir;
import com.grupocastores.SiatEntradas.service.domain.Refaproveedor;
import com.grupocastores.SiatEntradas.service.domain.RequisicionAnio;
import com.grupocastores.SiatEntradas.service.domain.RequisicionHistorico;
import com.grupocastores.SiatEntradas.service.domain.ResumenCompra;
import com.grupocastores.SiatEntradas.service.domain.RptContraRecibo;
import com.grupocastores.SiatEntradas.service.domain.SemaforoSiat;
import com.grupocastores.SiatEntradas.service.domain.SiatEntradas;
import com.grupocastores.SiatEntradas.service.domain.TablaSumTemporal;
import com.grupocastores.SiatEntradas.service.domain.TablaTemporal;
import com.grupocastores.SiatEntradas.service.domain.Tempoliza;
import com.grupocastores.SiatEntradas.service.domain.TempolizaRefaccion;
import com.grupocastores.SiatEntradas.service.domain.TipoAutorizaciones;
import com.grupocastores.SiatEntradas.service.domain.TipoCambio;
import com.grupocastores.SiatEntradas.service.domain.TipoSolicitud;
import com.grupocastores.SiatEntradas.service.domain.TotalGrid;
import com.grupocastores.SiatEntradas.service.domain.TraspasosGrupos;
import com.grupocastores.SiatEntradas.service.domain.UpdateRefacciones;
import com.grupocastores.SiatEntradas.service.domain.ValidacionEntrada;

/**
 * SiatEntradas Service, define el caso de uso del API
 *
 * @author Castores - Desarrollo TI
 *
 */
public interface ISiatEntradasService 
{

	
	/**
	 * getSemaforoSiat: obtiene semaforo siat.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<Almacen>>
	 * @throws Exception 
	 * @date 2023-08-08
	 */
	ResponseDTO<List<SemaforoSiat>> getSemaforoSiat(int estatus);
	
	/**
	 * getGridEntradas: obtiene el grid de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-07
	 */
	ResponseDTO<List<GridEntradas>> getGridEntradas(int anio, int mes, int idTaller, int almacen);
	
	/**
	 * getGridEntradasPorAlmacen: obtiene el grid de entradas por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	ResponseDTO<List<GridEntradas>> getGridEntradasPorAlmacen(int anio, int mes, int tipoAlmacen);

	
	/**
	 * getAlmacenes: obtiene los almacenes.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<Almacen>>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	ResponseDTO<List<CatalogoAlmacen>> getAlmacen(int tipoAlmacen, String nomAlmacen);
	
	/**
	 * getGridFacuras: obtiene las facturas de compras
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	ResponseDTO<List<GridFacturas>> getGridFacturas(int anio,int mes);
	
	/**
	 * getGridFacurasAgrupadas: obtiene las facturas de compras de requisiciones agrupadas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	ResponseDTO<List<GridFacturas>> getGridFacturasAgrupadas(int anio,int mes);
	
	
	/**
	 * getValidacionEntrada: obtiene la validacion de entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-11
	 */
	ResponseDTO<List<ValidacionEntrada>> getValidacionEntrada(int anio, int idFacturaOrden);
	
	/**
	 * queryGetTotalGrid: obtiene el total para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	ResponseDTO<List<TotalGrid>> getTotalGrid (int noMovimiento,int tipo) ;
	
	/**
	 * queryGetTotalOpcionGrid: obtiene el total para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	ResponseDTO<List<TotalGrid>> getTotalOpcionGrid (int noMovimiento,int tipo) ;
	
	/**
	 * queryGetRefaccionGrid: obtiene la idrefaccion para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	ResponseDTO<List<IdRefaccionGrid>> getRefaccionGrid (int noMovimiento,int tipo) ;
	
	/**
	 * queryGetCarroceriaGrid: obtiene la idrefaccion si es carroceria para el grid
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-14
	 */
	ResponseDTO<List<IdRefaccionGrid>> getCarroceriaGrid (String idRefaccion) ;
	
	/**
	 * queryGetTipoCambio obtiene el total tipo cambio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-18
	 */
	ResponseDTO<List<TipoCambio>> getTipoCambio(String fecha);
	
	/**
	 * getMotivo: obtiene la idrefaccion si es de carroceria
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-18
	 */
	ResponseDTO<List<GetMotivo>> getMotivo(int idMotivo);
	
	/**
	 * getTipoCambioCarroceria obtiene el total tipo cambio de carroceria
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-19
	 */
	ResponseDTO<List<TipoCambio>> getTipoCambioCarroceria();
	
	/**
	 * getAlmacenTraspaso: obtiene el almacen traspaso
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-20
	 */
	ResponseDTO<List<AlmacenTranspasosPlazo>> getAlmacenTraspaso(int idAlmacen);
	
	/**
	 * getOrdenes: obtiene las ordenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	ResponseDTO<List<Ordenes>> getOrdenes(int idOrdenCompra);
	
	/**
	 * getOrdenesAnio: obtiene las ordenes anio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	ResponseDTO<List<OrdenesAnio>> getOrdenesAnio(int anio,int idOrdenCompra, int idRequisicion);
	
	/**
	 * getOrdenesAnioMoneda: obtiene las ordenes anio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	ResponseDTO<List<OrdenesAnio>> getOrdenesAnioMoneda(int anio,int idOrdenCompra);
	
	/**
	 * getRequisicionAnio: obtiene las requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	ResponseDTO<List<RequisicionAnio>> getRequisicionAnio(int anio, int idRequisicion);
	
	
	/**
	 * getCuerpoDetalle: obtiene el cuerpo detalle de la idrequisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	ResponseDTO<List<CuerpoDetalle>> getCuerpoDetalle( int idRequisicion);
	
	/**
	 * getCuerpoDetalleRefaccion: obtiene el cuerpo detalle de la idrequisicion e idrefaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-21
	 */
	ResponseDTO<List<CuerpoDetalle>> getCuerpoDetalleRefaccion( int idRequisicion, int idRefaccion);
	
	/**
	 * getCantidadCuerpoOrden: obtiene la cantidad solicitada del cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2023-12-22
	 */
	ResponseDTO<List<TotalGrid>> getCantidadCuerpoOrden(int anio,int idOrdenCompra, int idRefaccion);
	
	/**
	 * queryGetTipoCambioDiaCurso obtiene el total tipo cambio del dia curso
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	ResponseDTO<List<TipoCambio>> getTipoCambioDiaCurso(int idMoneda);
	
	/**
	 * getFacturaOrden: obtiene informacion de la tabla factura orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	ResponseDTO<List<FacturaOrden>> getFacturaOrden( int idFacturaOrden);
	
	/**
	 * getFolioAlmacen: obtiene informacion de la tabla folio almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	ResponseDTO<List<FolioAlmacen>> getFolioAlmacen( int tipoFolio, int idAlmacen);
	
	/**
	 * getControlTipoCambio: obtiene informacion de proveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	ResponseDTO<List<ControlCambio>> getControlTipoCambio( int idProveedor);
	
	/**
	 * getCuerpoFactura: obtiene informacion de cuerpo factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	ResponseDTO<List<CuerpoFactura>> getCuerpoFactura( int idFacturaOrden);
	
	/**
	 * getInformacionRefaccion: obtiene informacion de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-02
	 */
	ResponseDTO<List<InformacionRefaccion>> getInformacionRefaccion( int idRefaccion);
	
	/**
	 * insertControlEntrada:inserta registro en control entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-03
	 */
	public ResponseDTO<Boolean> insertControlEntrada(ControlEntrada ce);
	
	/**
	 * getFolio: obtiene folios siat.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<List<Folio>>
	 * @throws Exception 
	 * @date 2024-01-03
	 */
	ResponseDTO<List<Folio>> getFolio(int tipoFolio);
	
	/**
	 * insertFolio:inserta registro en folios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-03
	 */
	public ResponseDTO<Boolean> createFolio(Folio folio, int tipoFolio);
	
	/**
	 * insertFolioAlmacen:inserta registro en folios almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	public ResponseDTO<Boolean> createFolioAlmacen(FolioAlmacen folio, int tipoFolio, int idAlmacen);
	
	/**
	 * getRefaProveedor : obtiene informacion del proveedor de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	ResponseDTO<List<TotalGrid>> getRefaProveedor(int idProveedor, int idRefaccion);
	
	/**
	 * getValorParamGen : obtiene informacion de la variable general
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	ResponseDTO<List<GetMotivo>> getValorParamGen(int idParametro);
	
	/**
	 * getValorParametros : obtiene informacion de la variable 
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	ResponseDTO<List<GetMotivo>> getValorParametros(int idParametro);
	
	/**
	 * getValorParametrosNombre : obtiene informacion de la variable 
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-04
	 */
	ResponseDTO<List<GetMotivo>> getValorParametrosNombre(int idParametro);
	
	/**
	 * getTipoSolicitud : obtiene informacion de tipo solicitud de la requisicion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-08
	 */
	ResponseDTO<List<TipoSolicitud>> getTipoSolicitud(int idRequisicion);
	
	/**
	 * getNombreMoneda: obtiene informacion del nombre de la moneda
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-08
	 */
	ResponseDTO<List<GetMotivo>> getNombreMoneda(int idMoneda);
	
	/**
	 * getCantidadesEntradas: obtiene informacion de las cantidades entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-08
	 */
	ResponseDTO<List<CantidadesEntradas>> getCantidadesEntradas(int anio, int idOrdenCompra);
	
	ResponseDTO<List<GetProveedor>> getProveedor(int idproveedor);
	
	/**
	 * deleteControlEntrada:delete registro en control entrada
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-01-12
	 */
	public ResponseDTO<Boolean> deleteControlEntrada(String folioControl, int idPersonal);
	
	/**
	 * getTipoAutorizacion: obtiene informacion de las cantidades entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-16
	 */
	ResponseDTO<List<TipoAutorizaciones>> getTipoAutorizacion( int idTipoAutorizacion);
	
	/**
	 * insertEntradas:inserta registro en entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	public ResponseDTO<Boolean> createEntradas(Entradas entradas);
	
	/**
	 * getControlIncrementoMaquila: obtiene informacion del incremento maquila
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-16
	 */
	ResponseDTO<List<GetMotivo>> getControlIncrementoMaquila();
	
	/**
	 * getConvenioRefaccion: obtiene informacion del convenio de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-17
	 */
	ResponseDTO<List<GetMotivo>> getConvenioRefaccion(int idRefaccion);
	
	/**
	 * getConvenioRefaccionDetallado: obtiene informacion del convenio de la refaccion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-17
	 */
	ResponseDTO<List<ConvenioRefaccion>> getConvenioRefaccionDetallado(int idRefaccion);
	
	/**
	 * insertEntradasAño:inserta registro en entradas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-16
	 */
	public ResponseDTO<Boolean> createEntradasAnio(int anio, EntradasAnio entradas);
	
	
	/**
	 * createLotes:inserta registro en lotes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	public ResponseDTO<Boolean> createLotes(Lotes lotes);
	
	/**
	 * createKardex:inserta registro en kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-18
	 */
	public ResponseDTO<Boolean> createKardex(Kardex kardex);
	
	/**
	 * getEsFactura: obtiene informacion si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	ResponseDTO<List<GetMotivo>> getEsFactura(int idFacturaOrden);

	/**
	 * getImporteFactura: obtiene informacion del importe si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	ResponseDTO<List<Importe>> getImporteFactura(int anio, int idEntrada, int idAlmacen);
	
	/**
	 * getImporteRemision: obtiene informacion del importe si es remision
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	ResponseDTO<List<Importe>>  getImporteRemision(int anio, int idEntrada, int idAlmacen);
	
	/**
	 * getMaxLotes: obtiene informacion del max idlote
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	ResponseDTO<List<ValidacionEntrada>> getMaxLotes();
	
	/**
	 * createDetalleEntrada:inserta registro en detalle entrada
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	public ResponseDTO<Boolean> createDetalleEntrada(DetalleEntrada de);
	
	/**
	 * getInfRefaproveedor: obtiene informacion de Refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	ResponseDTO<List<Refaproveedor>>  getInfRefaproveedor(int idRefaccion, int idProveedor);
	
	/**
	 * getRefPorAlmacen: obtiene informacion de refaccion por almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	ResponseDTO<List<RefPorAlmacen>>  getRefPorAlmacen(int idRefaccion, int idAlmacen);
	
	/**
	 * getConvenioInf: obtiene informacion de convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	ResponseDTO<List<ConvenioInf>>  getConvenioInf(int idRefaccion);
	
	/**
	 * updateRefaProveedor:actualiza registro en refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	public ResponseDTO<Boolean> updateRefaProveedor(Refaproveedor rp, int idRefaccion, int idProveedor);
	
	/**
	 * updateRefaPorAlmacen:actualiza registro en refaccion_por_almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	public ResponseDTO<Boolean> updateRefaPorAlmacen(RefPorAlmacen rp, int idRefaccion, int idAlmacen);
	
	/**
	 * updateRefacciones:actualiza registro en refacciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	public ResponseDTO<Boolean> updateRefacciones(UpdateRefacciones ur, int idRefaccion);
	
	/**
	 * updateCuerpoConvenio:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	
	public ResponseDTO<Boolean> updateCuerpoConvenio(int idRefaccion, int idConvenio, Double pcmn);
	
	/**
	 * updateFacturasOrden:actualiza registro en facturas orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	
	public ResponseDTO<Boolean> updateFacturasOrden( int idFacturaOrden, int idEstatus);
	
	/**
	 * getCuerpoOrdenAnio: obtiene informacion de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-24
	 */
	ResponseDTO<List<CuerpoOrden>> getCuerpoOrdenAnio(int anio, int idRefaccion, int idOrdenCompra);
	
	/**
	 * getCuerpoOrden: obtiene informacion de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-24
	 */
	ResponseDTO<List<CuerpoOrden>> getCuerpoOrden(int anio, int idOrdenCompra);
	
	/**
	 * updateCuerpoOrdenAnio:actualiza registro de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	public ResponseDTO<Boolean> updateCuerpoOrdenAnio(CuerpoOrden co,int anio, int idRefaccion, int idOrdenCompra);
	
	/**
	 * updateCuerpoOrdenAnio:actualiza registro de cuerpo orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	public ResponseDTO<Boolean> updateOrdenCompraAnio(OrdenesAnio co,int anio, int idRequisicion, int idOrdenCompra);
	
	/**
	 * updateOrdenes:actualiza registro de ordenes
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-24
	 */
	public ResponseDTO<Boolean> updateOrdenes(int idOrdenCompra, int idEstatus);
	
	/**
	 * updateCuerpoRequisicionAnio:actualiza registro de cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	public ResponseDTO<Boolean> updateCuerpoRequisicionAnio(CuerpoRequisicionAnio cr,int anio, int idRequisicion, int idRefaccion);
	
	/**
	 * getCuerpoRequisicionAnio: obtiene informacion de cuerpo requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-25
	 */
	ResponseDTO<List<CuerpoRequisicionAnio>> getCuerpoRequisicionAnio(int anio, int idRequisicion, int idRefaccion);
	
	/**
	 * updateRequisicionAnio:actualiza registro de requisicion año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	public ResponseDTO<Boolean> updateRequisicionAnio(RequisicionAnio ra,int anio, int idRequisicion);
	
	/**
	 * insertRequisicionHistorico:inserta registro de requisicion historico
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	public ResponseDTO<Boolean> insertRequisicionHistorico(RequisicionHistorico requisicionHistorico);
	
	/**
	 * updateCuerpoDetalle:actualiza registro de cuerpo detalle
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-25
	 */
	public ResponseDTO<Boolean> updateCuerpoDetalle(CuerpoDetalle cd, int idRequisicion, int idRefaccion);
	
	/**
	 * insertAutorizaciones:inserta registro en autorizaciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	public ResponseDTO<Boolean> insertAutorizaciones(Autorizaciones autorizaciones);
	
	/**
	 * updateCuerpoConvenioSaldo:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	
	public ResponseDTO<Boolean> updateCuerpoConvenioSaldo(int idRefaccion, int idConvenio, Double saldo);
	
	/**
	 * getInfoconvenio: obtiene informacion de convenio
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	ResponseDTO<List<GetMotivo>> getInfoconvenio( int idRefaccion);
	
	/**
	 * getBancoProveedor: obtiene informacion de banco proveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	ResponseDTO<List<BancoProveedor>> getBancoProveedor(int idProveedor);
	
	/**
	 * getContraRecibo: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-26
	 */
	ResponseDTO<List<ContraRecibos>> getContraRecibo();
	
	/**
	 * insertContraRecibo:inserta registro en contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-26
	 */
	public ResponseDTO<Boolean> insertContraRecibo(ContraRecibosInfo contraRecibo);
	
	/**
	 * getContraReciboInfo: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	ResponseDTO<List<ContraRecibosInfo>> getContraReciboInfo(int idContraRecibo);
	
	/**
	 * getContraReciboFact: obtiene informacion de contra recibo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	ResponseDTO<List<ContraRecibosInfo>> getContraReciboFact(int idFacturaOrden);

	/**
	 * getRptContraReciboFact : obtiene reporte de contra recibo con factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	ResponseDTO<List<RptContraRecibo>> getRptContraReciboFact(int coidFacturaOrden);
	
	/**
	 * getRptContraReciboFact : obtiene reporte de contra recibo con factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	ResponseDTO<List<RptContraRecibo>> getRptContraRecibo(int idContraRecibo);
	
	/**
	 * getEntradas : String: obtiene informacion de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	ResponseDTO<List<Entradas>> getEntradas(int idEntrada, int tipoEntrada);
	
	/**
	 * getValoresEntradas : obtiene valores de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	ResponseDTO<List<EntradasInfo>> getValoresEntradas(int anio, int idEntrada, int tipoEntrada);
	
	/**
	 * getFacturasOrdenInfo:  obtiene valores de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	ResponseDTO<List<FacturaOrden>> getFacturasOrdenInfo(int idOrdenCompra, int idFacturaOrden);
	
	/**
	 * getEntradasAnio: obtiene informacion de entradas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-29
	 */
	ResponseDTO<List<EntradasAnio>> getEntradasAnio(int anio, int idEntrada, int tipo);
	
	/**
	 * getKardex: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	ResponseDTO<List<Kardex>> getKardex(int tipoMovimiento, int noMovimiento, int tipo);
	
	/**
	 * getKardexPrecio: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	ResponseDTO<List<Kardex>> getKardexPrecio(int idRefaccion, int noMovimiento);
	
	/**
	 * deleteTempoliza: Elimina informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	public ResponseDTO<Boolean> deleteTempoliza();
	
	/**
	 * getTempolizaInsert: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	ResponseDTO<List<Tempoliza>> getTempolizaInsert(String param1, String param2, int tipoMovimiento, int noMovimiento, int tipo);
	
	/**
	 * getTempolizaInsert2: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	ResponseDTO<List<Tempoliza>> getTempolizaInsert2(int idEntrada, int tipo);

	/**
	 * insertTempoliza:inserta registro en tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-02
	 */
	public ResponseDTO<Boolean> insertTempoliza(Tempoliza tempoliza);
	
	/**
	 * getIva: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	ResponseDTO<List<Iva>> getIva(int idIva);
	
	/**
	 * getTempoliza: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	ResponseDTO<List<Tempoliza>> getTempoliza();
	
	/**
	 * getTempolizaRefaccion: obtiene informacion de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-01
	 */
	ResponseDTO<List<TempolizaRefaccion>> getTempolizaRefaccion();
	
	/**
	 * getTraspasosGrupos: obtiene informacion de traspasos grupos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	ResponseDTO<List<TraspasosGrupos>> getTraspasosGrupos(int idRefaccion, String fecha, String hora);
	
	/**
	 * getGruposAlmacen: obtiene informacion de grupos almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-02
	 */
	ResponseDTO<List<GetMotivo>> getGruposAlmacen(int idGrupo, int idAlmacen);

	/**
	 * updateTempoliza :actualiza registro de tempoliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-02
	 */
	public ResponseDTO<Boolean> updateTempoliza(Tempoliza tempoliza, int idRefaccion, String fecha, String hora);
	
	/**
	 * getKardexRefacciones: obtiene informacion de kardex y refacciones
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	ResponseDTO<List<KardexRefacciones>> getKardexRefacciones(String noMovimiento, int tipo, int idGrupo);
	
	/**
	 * getKardexMovimiento: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	ResponseDTO<List<KardexMovimiento>> getKardexMovimiento(int idRefaccion, String fecha, String hora);
	
	/**
	 * getAlmacenes: obtiene informacion de almacen
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	ResponseDTO<List<Almacen>> getAlmacenes();
	
	/**
	 * getSumCantKardex: obtiene suma de la cantidad de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	ResponseDTO<List<TotalGrid>> getSumCantKardex(int idRefaccion, String fecha, String hora,int idAlmacen);
	
	/**
	 * getFacturaOrdenAnticipo: obtiene informacion de la tabla factura orden anticipo
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-06
	 */
	ResponseDTO<List<FacturaOrdenAnticipo>> getFacturaOrdenAnticipo(int idFacturaOrden);
	
	/**
	 * getIdPoliza: obtiene informacion de la tabla poliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-07
	 */
	ResponseDTO<List<GetMotivo>> getIdPoliza(int tabla, int numPoliza, int idTipoPol);
	
	/**
	 * getMaxPoliza: obtiene informacion de la tabla poliza
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-07
	 */
	ResponseDTO<List<GetMotivo>> getMaxPoliza(int tabla);
	
	/**
	 * insertPolizaAnio:inserta registro en poliza año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	public ResponseDTO<Boolean> insertPolizaAnio(int anio, PolizasAnio poliza);
	
	/**
	 * insertPoliza:inserta registro en polizas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	public ResponseDTO<Boolean> insertPoliza(Polizas poliza);
	
	/**
	 * insertMovimientos:inserta registro en movimientos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	public ResponseDTO<Boolean> insertMovimientos(int anio, Movimientos movimientos);
	
	/**
	 * updateCatcuentasAnio:actualiza registro en catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	public ResponseDTO<Boolean> updateCatcuentasAnio(int anio, int mes, String idCuenta, int importe);
	
	/**
	 * updateCatcuentasAbono:actualiza registro en catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-07
	 */
	public ResponseDTO<Boolean> updateCatcuentasAbonos(int anio, int mes, String idCuenta, String importe);
	
	/**
	 * getCatCuentas: obtiene informacion de la catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-11
	 */
	ResponseDTO<List<GetMotivo>> getCatCuentas(int cargo, int anio, String idCuenta);
	
	/**
	 * getCatCuentasAbonos: obtiene informacion de la catcuentas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-11
	 */
	ResponseDTO<List<GetMotivo>> getCatCuentasAbonos(int abono, int anio, String idCuenta);
	
	/**
	 * updateResumenCompra:actualiza registro en resumen compra
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-02-09
	 */
	public ResponseDTO<Boolean> updateResumenCompra(int idRefaccion, ResumenCompra resumen);
	
	/**
	 * getResumenCompra: obtiene informacion de resumen compra
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-12
	 */
	ResponseDTO<List<ResumenCompra>> getResumenCompra(int idRefaccion);
	
	/**
	 * getResumenImpresion: obtiene informacion de resumen impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-15
	 */
	ResponseDTO<List<ImprimirGeneral>> getResumenImpresion(int anio, String fechaIni, String fechaFin, int tipo,int permisoTaller, int idTaller);
	
	/**
	 * getKardexInformacion: obtiene informacion de kardex
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-15
	 */
	ResponseDTO<List<KardexInformacion>> getKardexInformacion(int noMovimiento, int tipoMovimiento, int tipo);
	
	/**
	 * getEntradaFechapol: obtiene informacion de entradas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	ResponseDTO<List<EntradasFechapol>> getEntradaFechapol(int anio, int idEntrada, int tipo);
	
	/**
	 * getTotalMovimientos: obtiene informacion de movimientos
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	ResponseDTO<List<GetMotivo>> getTotalMovimientos(int anio, int idPoliza);
	
	
	/**
	 * deletePoliza : Elimina informacion de polizas
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	public ResponseDTO<Boolean> deletePoliza(int idPoliza, int tabla, int idTipoPol);
	
	/**
	 * deletePolizaAnio : Elimina informacion de polizas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	public ResponseDTO<Boolean> deletePolizaAnio(int anio, int idPoliza, int idTipoPol);
	
	/**
	 * deleteMovimientosAnio : Elimina informacion de movimientos año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-19
	 */
	public ResponseDTO<Boolean> deleteMovimientosAnio(int anio, int idPoliza);
	
	/**
	 *getRptEntradaFacturaConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	ResponseDTO<List<ImprimirEntradas>> getRptEntradaConsultar(int anio, int idEntrada, int tipo);
	
	/**
	 *getRptEntradaFacturaConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	ResponseDTO<List<ImprimirEntradasFactura>> getRptEntradaFacturaConsultar(int anio, int idEntrada,int idAlmacen, int tipo);
	
	/**
	 *getRptEntradaRemisionConsultar: obtiene informacion de entradas impresion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-02-22
	 */
	ResponseDTO<List<ImprimirEntradasFactura>> getRptEntradaRemisionConsultar(int anio, int idEntrada,int idAlmacen, int tipo);
	
	/**
	 * getConvenios: obtiene informacion de la tabla convenios
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	ResponseDTO<List<Convenios>> getConvenios(int idConvenio);
	
	/**
	 * getGridEntDevolucion: obtiene informacion para generar el grid de entrada por devolucion
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	ResponseDTO<List<ConvenioProveedor>> getGridEntDevolucion();
	
	/**
	 * getRefaccionesPorSurtir: obtiene informacion para generar obtener las refacciones por surtir
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-06
	 */
	ResponseDTO<List<RefaccionesPorSurtir>> getRefaccionesPorSurtir(int idConvenio);
	
	/**
	 * getGrupos: obtiene informacion para los grupos.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-07
	 */
	ResponseDTO<List<Grupos>> getGrupos(int clave);
	
	/**
	 * getGruposIdentificador: obtiene informacion para los grupos.
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-07
	 */
	ResponseDTO<List<Grupos>> getGruposIdentificador(int idGrupo);
	
	/**
	 * getCuerpoConvenio: obtiene el cuerpo del convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	ResponseDTO<List<CuerpoConvenio>> getCuerpoConvenio( int idConvenio, int idRefaccion);
	
	/**
	 * getCatCuentasAnio: obtiene informacion de cat cuentas año
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-15-13
	 */
	ResponseDTO<List<CatCuentasAnio>> getCatCuentasAnio( int anio, String idCuenta);
	
	/**
	 * deleteTablaTemporal: eliminar una tabla temporal
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-03-19
	 */
	public ResponseDTO<Boolean> deleteTablaTemporal();
	
	/**
	 * insertTemporal: inserta registro en tabla temporal
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-03-19
	 */
	public ResponseDTO<Boolean> insertTemporal(TablaTemporal temp);
	
	/**
	 * getGrupoTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	ResponseDTO<List<GetMotivo>> getGrupoTemporal();
	
	/**
	 * getImporteTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	ResponseDTO<List<TablaSumTemporal>> getImporteTemporal();

	/**
	 * getSumPmnTemporal: obtiene informacion de la tabla cuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-03-13
	 */
	ResponseDTO<List<GetMotivo>> getSumPmnTemporal();
	
	/**
	 * updateFacturasOrden:actualiza registro en facturas orden
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-22
	 */
	
	public ResponseDTO<Boolean> updatePrecioRefaccionLlanta( int idRefaccion, Double precio );
	
	/**
	 * getEsFactura: obtiene informacion si es factura
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return  ResponseDTO<Boolean>
	 * @throws Exception 
	 * @date 2024-01-19
	 */
	ResponseDTO<List<DetalleEntradaConsignacion>> getDetalleEntradaConsignacion(int anio, int idEntrada, int idAlmacen);
	
	/**
	 * updateFacturasOrden:actualiza registro en facturas orden
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-25
	 */
	
	public ResponseDTO<Boolean> updateSaldoConvenio( int idConvenio, Double saldoTotal );
	
	/**
	 * insertTemporal: inserta registro en tabla historicoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-25
	 */
	public ResponseDTO<Boolean> insertHistoricoConvenio(HistoricoConvenio temp);
	
	/**
	 * insertTemporal: obtiene las refacciones del cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-26
	 */
	ResponseDTO<List<ListaCuerpoConvenio>> getListCuerpoConvenio(int idConvenio);
	
	/**
	 * updateRefaProveedor:actualiza registro en refaproveedor
	 * 
	 * @version 0.0.1
	 * @author Atzin Moreno
	 * @return Boolean
	 * @date 2024-01-19
	 */
	public ResponseDTO<Boolean> updateExistenciaRefaProveedor(int idRefaccion, int idProveedor, Double existencia);
	
	/**
	 * updateCuerpoConvenio:actualiza registro en cuerpo convenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-27
	 */
	
	public ResponseDTO<Boolean> updateDataCuerpoConvenio(int idRefaccion, int idConvenio, Double pcmn, Double cantidadSurtida);
	
	/**
	 * insertHistorico: inserta registro en tabla histcuerpoconvenio
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-25
	 */
	public ResponseDTO<Boolean> insertHistoricoCuerpoConvenio(HistoricoCuerpoConvenio temp);
	
	/**
	 * getDataEntrada: obtiene los datos para la entrada normal
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-27
	 */
	ResponseDTO<List<GetDataEntradaNormal>> getDataEntradaNormal(int anio, int idEntrada, int tipoEntrada);
	
	/**
	 * getDataEntrada: obtiene los datos para las entradas
	 * 
	 * @version 0.0.1
	 * @author Gabriel Garcia
	 * @return Boolean
	 * @date 2024-03-27
	 */
	ResponseDTO<List<GetDataEntrada>> getDataEntrada(int anio, int idEntrada, int tipoEntrada);
	
}
