package com.grupocastores.SiatEntradas.dto;

import java.util.List;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseDTO<T> {

  private int code;
  private String description;
  private String message;
  private T data;

}
