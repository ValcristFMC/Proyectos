package com.grupocastores.sion.dto;

import java.util.Date;
import io.swagger.annotations.ApiModel;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un clientes", description = "Datos del clientes")
public class clientesDTO 
{
	private int idClienteOcurre;
	private String nombre_o_razonsocial;
	private String apellidos;
	private String rfcCliente;
	private String correo;
	private int telefono;
	private String password;
	private String personaMoral;
	private String representante_legal;
	private String fechaAlta;
	private String fechaMod;
	private Boolean estatus;

	
	public clientesDTO (int idClienteOcurre, String nombre_o_razonsocial, String apellidos, String rfcCliente, String correo, int telefono, String password, String personaMoral, String representante_legal, String fechaAlta, String fechaMod, Boolean estatus) {
		this.idClienteOcurre = idClienteOcurre;
		this.nombre_o_razonsocial = nombre_o_razonsocial;
		this.apellidos = apellidos;
		this.rfcCliente = rfcCliente;
		this.correo = correo;
		this.telefono = telefono;
		this.password = password;
		this.personaMoral = personaMoral;
		this.representante_legal = representante_legal;
		this.estatus = estatus;
		this.fechaAlta = fechaAlta;
		this.fechaMod = fechaMod;		
	}	
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("clientes [idClienteOcurre=").append(idClienteOcurre)
		.append(", nombre_o_razonsocial=").append(nombre_o_razonsocial)
		.append(", apellidos=").append(apellidos)
		.append(", rfcCliente=").append(rfcCliente)
		.append(", correo=").append(correo)
		.append(", telefono=").append(telefono)
		.append(", password=").append(password)
		.append(", personaMoral=").append(personaMoral)
		.append(", representante_legal=").append(representante_legal)
		.append(", estatus=").append(estatus)	
		.append(", fechaAlta").append(fechaAlta)
		.append(", fechaMod").append(fechaMod);
		return strBuilder.toString();
	}
}
