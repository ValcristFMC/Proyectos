package com.grupocastores.sion.service;

import java.util.List;

import com.grupocastores.sion.service.domain.clientes;

/**
 * clientes Service, define el caso de uso del API
 *
 * @author Castores - Desarrollo TI
 *
 */
public interface IclientesService 
{
	public List<clientes> getAllClientes();
	public clientes getById(Integer idCliente);
	public clientes getByLogin(Integer idCliente, String password);
	public clientes save(clientes clientes);
	public void delete(Integer id);
}
