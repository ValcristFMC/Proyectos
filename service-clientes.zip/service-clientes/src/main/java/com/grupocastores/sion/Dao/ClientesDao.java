package com.grupocastores.sion.Dao;

import org.springframework.data.repository.CrudRepository;

import com.grupocastores.sion.service.domain.clientes;



public interface ClientesDao extends CrudRepository<clientes, Long> {

}


