package com.grupocastores.sion.service.repository;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.grupocastores.sion.service.domain.clientes;

/**
 * clientesRepository Repositorio para el almacenamiento de {@link com.grupocastores.sion.service.domain.clientes} 
 *
 * @author Castores - Desarrollo TI
 *
 */
@Repository
public class clientesRepository  extends UtilitiesRepository
{
	@PersistenceContext
	private EntityManager entityManager;
	
	static final String QUERY_USUARIOS= "SELECT * FROM clientes_sion where estatusCliente = 1";
	
	static final String QUERY_USUARIO_BY_ID = "SELECT * FROM clientes_sion where estatusCliente = 1 and idClienteOcurre =\"%s\";')";
	
	static final String QUERY_USUARIO_BY_lOGIN = "SELECT * FROM clientes_sion where estatusCliente = 1 and idClienteOcurre =\"%s\" and password  = \"%s\" ;')";
	
	
	@SuppressWarnings("unchecked")
	public List<clientes> getClientes () throws Exception{
		Query queryclientes = (Query) entityManager.createNativeQuery(String.format(QUERY_USUARIOS), clientes.class);
		List<clientes> listaClientes = ((javax.persistence.Query) queryclientes).getResultList();
		if(!listaClientes.isEmpty())
			return listaClientes;
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<clientes> getClienteById (int id_cliente) throws Exception{
		Query queryclientes = (Query) entityManager.createNativeQuery(String.format(QUERY_USUARIO_BY_ID,id_cliente), clientes.class);
		List<clientes> listaClientes = ((javax.persistence.Query) queryclientes).getResultList();
		if(!listaClientes.isEmpty())
			return listaClientes;
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public List<clientes> getClienteByLogin(int id_cliente, String password) throws Exception{
		Query queryclientes = (Query) entityManager.createNativeQuery(String.format(QUERY_USUARIO_BY_lOGIN,id_cliente,password), clientes.class);
		List<clientes> listaClientes = ((javax.persistence.Query) queryclientes).getResultList();
		if(!listaClientes.isEmpty())
			return listaClientes;
		return null;
	}
	
}
