package com.grupocastores.sion.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.sion.service.domain.clientes;
import com.grupocastores.sion.service.repository.clientesRepository;
import com.grupocastores.sion.Dao.ClientesDao;
import com.grupocastores.sion.service.IclientesService;

/**
 * Implementacion interna de {@link com.grupocastores.sion.service.IclientesService}. Esta clase no se debe acceder directamente
 *
 * @author Castores - Desarrollo TI
 */
@Service
public class clientesServiceImpl implements IclientesService 
{	
	
	Logger logger = LoggerFactory.getLogger(clientesServiceImpl.class);
	
	@Autowired
	private clientesRepository clientesRepository;
	private ClientesDao clientesDao;

	@Override
	public List<clientes> getAllClientes() {
		List <clientes> lstclientes;
		try {
				lstclientes = clientesRepository.getClientes();
				if (lstclientes ==null) {
					throw new Exception ("No se pudo obtener el registro de los clientes");
				}
	    }
		catch (Exception e){
			e.printStackTrace();
			return null;
		}
		return lstclientes;
	}
	
	@Override
	public clientes getById(Integer idCliente) {
		clientes cliente = new clientes();
		
		try {
			cliente = (clientes) clientesRepository.getClienteById(idCliente);
			if (cliente ==null) {
				throw new Exception ("No se pudo obtener el registro del cliente: "+ idCliente);
			}
		}
		catch (Exception e){
			e.printStackTrace();
			return null;
		}
		return cliente;
	}
	
	@Override
	public clientes getByLogin(Integer idCliente, String password) {
		clientes cliente = new clientes();
		
		try {
				cliente = (clientes) clientesRepository.getClienteByLogin(idCliente, password);
				if (cliente ==null) {
					throw new Exception ("No se pudo obtener el registro del cliente: "+ idCliente);
				}
			}
			catch (Exception e){
				e.printStackTrace();
				return null;
			}
			return cliente;
	}
	
	@Override
	public clientes save(clientes clientes) {
		return clientesDao.save(clientes);
	}

	@Override
	public void delete(Integer id) {
		Long longid = id.longValue();
		clientesDao.deleteById(longid);
	}
}
