package com.grupocastores.sion.controller;

import io.swagger.annotations.Api;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.grupocastores.sion.service.domain.clientes;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.grupocastores.sion.service.IclientesService;

@RestController
@RequestMapping(value = "/sion")
@Api(value = "clientesController", produces = "application/json")
public class  clientesController {

	Logger log = LoggerFactory.getLogger(clientesController.class);
	
	@Autowired
	private IclientesService clientesService;
	static final String HEADERBACK = "/sion/{id}";
	private clientes cliente;
	private Map<String, Object> response;
	

	@GetMapping(value = "/findClientes/", produces = "application/json;charset=UTF-8")
	public ResponseEntity<List<clientes>> findClientes() {
		List<clientes> list = clientesService.getAllClientes();
		if (list == null || list.isEmpty())
			return ResponseEntity.noContent().build();
		//return ResponseEntity.ok(list);
		return new ResponseEntity<List<clientes>>(list, HttpStatus.OK);
	}
	
	@HystrixCommand(fallbackMethod = "fallBackMethod")
	@GetMapping(value = "/findClienteById/{id}", produces = "application/json;charset=UTF-8")
	public ResponseEntity<?> findClienteById(@PathVariable(name = "id") Integer id) {
		try {
			cliente = clientesService.getById(id);
			 
		} catch (Exception e) {
		    response = new HashMap<String, Object>();
			response.put("error", "Error en findViaje()"); 	
			response.put("message", e.getMessage());
			response.put("class", this.getClass());
			return new ResponseEntity<Map<String,Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<clientes>(cliente, HttpStatus.OK);
	}
	
	@HystrixCommand(fallbackMethod = "fallBackMethod")
	@GetMapping(value = "/findClienteByLogin", params={"usuario","password"}, produces = "application/json;charset=UTF-8")
	public ResponseEntity<?> findClienteByLogin(@RequestParam(name = "id") Integer id, @RequestParam(name= "password") String password) {
		try {
			cliente = clientesService.getByLogin(id, password);
			 
		} catch (Exception e) {
		    response = new HashMap<String, Object>();
			response.put("error", "Error en findViaje()"); 	
			response.put("message", e.getMessage());
			response.put("class", this.getClass());
			return new ResponseEntity<Map<String,Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<clientes>(cliente, HttpStatus.OK);
	}
	
	@PutMapping("/editClient/{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public clientes editClient(@RequestBody clientes cliente, @PathVariable Integer id ) {
		clientes clientesbd = clientesService.getById(id);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		LocalDateTime fecha_hra_actual = LocalDateTime.now();
		clientesbd.setNombre_o_razonsocial(cliente.getNombre_o_razonsocial());
		clientesbd.setApellidos(cliente.getApellidos());
		clientesbd.setCorreo(cliente.getCorreo());
		String fecha_actual = sdf.format(fecha_hra_actual);
		clientesbd.setFechaMod(fecha_actual);
		clientesbd.setTelefono(cliente.getTelefono());
		clientesbd.setRepresentante_legal(cliente.getRepresentante_legal());
		clientesbd.setEstatus(cliente.getEstatus());
		return clientesService.save(clientesbd);
	}
	
	@PostMapping("/createClient")
	@ResponseStatus(HttpStatus.CREATED)
	public clientes newClient(@RequestBody clientes cliente, @PathVariable Integer id) {
		return clientesService.save(cliente);
	}
	
}
