package com.grupocastores.sion.service.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.grupocastores.sion.dto.clientesDTO;

/**
 * Clase clientes del dominio tiene su correspondiente {@link clientesDTO}
 *
 * @author Castores - Desarrollo TI
 */
@Data
@Entity
@Table(name = "cliente_ocurre")
@EntityListeners(clientes.class)
public class clientes 
{
	@Column(name = "id_cliente_ocurre") 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idClienteOcurre;
	
	@Column(name = "nombre_o_razonsocial") 
	private String nombre_o_razonsocial;
	
	private String apellidos;
	
	@Column(name = "rfc") 
	private String rfcCliente;
	
	@Column(name = "correo_cliente") 
	private String correo;
	
	@Column(name = "telefono_cliente") 
	private int telefono;
	
	private String password;
	
	@Column(name = "persona_moral") 
	private String personaMoral;
	
	@Column(name = "representante_legal") 
	private String representante_legal;
	
	@CreatedDate
	@Column(name = "fecha_alta", nullable = false, updatable = false)
	private String fechaAlta;
	
	@LastModifiedDate
	@Column(name = "fecha_mod", nullable = false, updatable = true)
	private String fechaMod;
	
	@Column(name = "estatus_cliente")
	private Boolean estatus;
	
	
	/**
	 * Metodo estatico para obtener un clientes a partir de un clientesDTO origen
	 * 
	 * @param clientes clientesDTO origen
	 * 
	 * @return clientes
	 */
	public static clientes fromclientesDTO(clientesDTO clientes) {
		clientes rest = new clientes();
		rest.setIdClienteOcurre(clientes.getIdClienteOcurre());
		rest.setNombre_o_razonsocial(clientes.getNombre_o_razonsocial());
		rest.setApellidos(clientes.getApellidos());
		rest.setRfcCliente(clientes.getRfcCliente());
		rest.setTelefono(clientes.getTelefono());
		rest.setPassword(clientes.getPassword());
		rest.setPersonaMoral(clientes.getPersonaMoral());
		rest.setRepresentante_legal(clientes.getRepresentante_legal());
		rest.setFechaAlta(clientes.getFechaAlta());		
		rest.setFechaMod(clientes.getFechaMod());
		rest.setEstatus(clientes.getEstatus());
		return rest;
	}
	
	/**
	 * Metodo para obtener un clientesDTO a partir de un clientes origen
	 * 
	 * @return clientesDTO
	 */
	public clientesDTO toclientesDTO() {
		 clientesDTO dto = new  clientesDTO();
		 dto.setIdClienteOcurre(this.getIdClienteOcurre());
		 dto.setNombre_o_razonsocial(this.getNombre_o_razonsocial());
		 dto.setApellidos(this.getApellidos());
		 dto.setRfcCliente(this.getRfcCliente());
		 dto.setCorreo(this.getCorreo());
		 dto.setTelefono(this.getTelefono());
		 dto.setPassword(this.getPassword());
		 dto.setPersonaMoral(this.getPersonaMoral());
		 dto.setRepresentante_legal(this.getRepresentante_legal());
		 dto.setFechaAlta(this.getFechaAlta());
		 dto.setFechaMod(this.getFechaMod());
		 dto.setEstatus(this.getEstatus());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("clientes [id=").append(idClienteOcurre)
		.append(",nombre_o_razonsocial=").append(nombre_o_razonsocial)
		.append(",apellidos=").append(apellidos)
		.append(",rfcCliente=").append(rfcCliente)
		.append(",correo=").append(correo)
		.append(",telefono=").append(telefono)
		.append(",password=").append(password)
		.append(",personaMoral=").append(personaMoral)
		.append(",representante_legal=").append(representante_legal)
		.append(",estatus=").append(estatus)
		.append(",fechaAlta=").append(fechaAlta)
		.append(",fechaMod=").append(fechaMod);		
		return strBuilder.toString();
	}
}
