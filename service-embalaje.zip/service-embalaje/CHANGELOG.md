# castores-service-empaque-embalaje

## Versión: 1.0.1.0
__Ticket/Proyecto:__ Empaque y Embalaje
__Autor:__ Flavio Urdiales
__Fecha:__ 29/07/2024
__Descripción:__
 - Se agrega metodo para insertar entradas con base a estatus SAP.
 - Se hace puente al MS de SAP para que pueda consultarse en todas las oficinas.

## Versión: 1.0.0.4
__Ticket/Proyecto:__ Empaque y Embalaje
__Autor:__ Liliana Valdovino
__Fecha:__ 16/07/2024
__Descripción:__
 - Se pone formato de hora desde el back, para que el sistema pueda realizar solicitudes desde cualquier tipo de equipo.

## Versión: 1.0.0.3
- __Ticket/Proyecto:__ Embaque y Embalaje
- __Author:__Liliana Valdovino
- __Fecha:__ 28/06/2024
- __Descripción:__ 
  - Se hacen cambios en la consulta para no mostrar 1 materiales
  
## Versión: 1.0.0.2
- __Ticket/Proyecto:__ Embaque y Embalaje
- __Author:__Liliana Valdovino
- __Fecha:__ 25/06/2024
- __Descripción:__ 
  - Se hacen cambios en la consulta para no mostrar 2 materiales

## Versión: 1.0.0.1
- __Ticket/Proyecto:__ Embaque y Embalaje
- __Author:__Alberto Salazar
- __Fecha:__ 17/06/2024
- __Descripción:__ 
  - Se hacen cambios para estandarizar el formato de fecha en el back

## Versión: 1.0.0.0
- __Ticket/Proyecto:__ Embaque y Embalaje
- __Author:__Mario Vega / Liliana Valdovino
- __Fecha:__ 15/05/2024
- __Descripción:__ 
  - Se crea Micro Servicio para el proyecto Empaque y Embalaje