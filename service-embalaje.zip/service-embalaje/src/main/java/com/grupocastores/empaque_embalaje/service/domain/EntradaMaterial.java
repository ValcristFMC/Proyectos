package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.EntradaMaterialDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(EntradaMaterial.class)
public class EntradaMaterial {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "identrada")
	private int idEntrada;
	
	@Column(name = "idmaterial")
    private int idMaterial;
	
	@Column(name = "cantidad")
    private int cantidad;
	
	@Column(name = "idpersonal")
    private int idPersonal;
	
	@Column(name = "fechamod")
    private String fechaModificacion;
	
	@Column(name = "horamod")
    private String horaModificacion;
	
	@Column(name = "preciocompra")
    private double precioCompra;
	
	@Column(name = "idtipomovimiento")
    private int idTipoMovimiento;
	
	@Column(name = "no_nota")
    private String numeroNota;
	
	@Column(name = "idpoliza")
    private int idPoliza;
	
	@Column(name = "idoficina")
    private String idOficina;
	
    public static EntradaMaterial fromEntradaMaterialDTO(EntradaMaterialDTO entradaMaterialDto) {
        EntradaMaterial entradaMaterial = new EntradaMaterial();
        entradaMaterial.setIdEntrada(entradaMaterialDto.getIdEntrada());
        entradaMaterial.setIdMaterial(entradaMaterialDto.getIdMaterial());
        entradaMaterial.setCantidad(entradaMaterialDto.getCantidad());
        entradaMaterial.setIdPersonal(entradaMaterialDto.getIdPersonal());
        entradaMaterial.setFechaModificacion(entradaMaterialDto.getFechaMod());
        entradaMaterial.setHoraModificacion(entradaMaterialDto.getHoraMod());
        entradaMaterial.setPrecioCompra(entradaMaterialDto.getPrecioCompra());
        entradaMaterial.setIdTipoMovimiento(entradaMaterialDto.getIdTipoMovimiento());
        entradaMaterial.setNumeroNota(entradaMaterialDto.getNoNota());
        entradaMaterial.setIdPoliza(entradaMaterialDto.getIdPoliza());
        entradaMaterial.setIdOficina(entradaMaterialDto.getIdOficina());
        return entradaMaterial;
    }

    public EntradaMaterialDTO toEntradaMaterialDTO() {
        EntradaMaterialDTO entradaMaterialDto = new EntradaMaterialDTO();
        entradaMaterialDto.setIdEntrada(this.getIdEntrada());
        entradaMaterialDto.setIdMaterial(this.getIdMaterial());
        entradaMaterialDto.setCantidad(this.getCantidad());
        entradaMaterialDto.setIdPersonal(this.getIdPersonal());
        entradaMaterialDto.setFechaMod(this.getFechaModificacion());
        entradaMaterialDto.setHoraMod(this.getHoraModificacion());
        entradaMaterialDto.setPrecioCompra(this.getPrecioCompra());
        entradaMaterialDto.setIdTipoMovimiento(this.getIdTipoMovimiento());
        entradaMaterialDto.setNoNota(this.getNumeroNota());
        entradaMaterialDto.setIdPoliza(this.getIdPoliza());
        entradaMaterialDto.setIdOficina(this.getIdOficina());
        return entradaMaterialDto;
    }
}
