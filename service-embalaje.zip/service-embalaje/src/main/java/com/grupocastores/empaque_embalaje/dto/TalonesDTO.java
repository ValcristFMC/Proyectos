package com.grupocastores.empaque_embalaje.dto;

import java.math.BigDecimal;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un Talón", description = "Datos del Talón")
public class TalonesDTO {

	private String claTalon;
	private String idOficina;
	private String tabla;
	private int status;
	private String remision;
	private String serie;
	private BigDecimal maniobras;

	public TalonesDTO(String claTalon, String idOficina, String tabla, int status, String remision, String serie,
			BigDecimal maniobras) {
		this.claTalon = claTalon;
		this.idOficina = idOficina;
		this.tabla = tabla;
		this.status = status;
		this.remision = remision;
		this.serie = serie;
		this.maniobras = maniobras;
	}
	
	@Override
	public String toString() {
		return "TalonesDTO [claTalon=" + claTalon + ", idOficina=" + idOficina + ", tabla=" + tabla + ", status="
				+ status + ", remision=" + remision + ", serie=" + serie + ", maniobras=" + maniobras + "]";
	}

}
