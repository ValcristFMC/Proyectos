package com.grupocastores.empaque_embalaje.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.grupocastores.empaque_embalaje.dto.ResponseDTO;
import com.grupocastores.empaque_embalaje.dto.SalidaAlmacenDTO;
import com.grupocastores.empaque_embalaje.service.ISalidaAlmacenService;
import com.grupocastores.empaque_embalaje.service.domain.SalidaAlmacen;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/salidaalmacen")
@Api(value = "SalidaAlmacenController", produces = "application/json")

public class SalidaAlmacenController {

	Logger log = LoggerFactory.getLogger(SalidaAlmacenController.class);
	
	@Autowired
	private ISalidaAlmacenService salidaAlmacenService;
	static final String HEADERBACK = "/SalidaAlmacen/{id}";
	
	@ApiOperation(value = "Guarda los datos de las salidas de almacén")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Registro de Salida creada", response = SalidaAlmacenDTO.class), 
			@ApiResponse(code = 500, message = "Salida no creada", response = ResponseDTO.class)})
	@PostMapping("/guardarSalida")
	public ResponseEntity<?> guardarSalida(
			@ApiParam(value = "Registro de la Salida que se va a crear", required = true) 
			@RequestBody @Valid SalidaAlmacenDTO salidaDto, UriComponentsBuilder builder) {
		try {
			SalidaAlmacen salidaCreada = salidaAlmacenService.save(SalidaAlmacen.fromSalidaAlmacenDTO(salidaDto));
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(salidaCreada.getIdSalida())).toUri());
	
			SalidaAlmacenDTO output = salidaCreada.toSalidaAlmacenDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}
	
	@ApiOperation(value = "Actualiza los datos de las salidas de almacén")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Datos de Salida actualizados", response = SalidaAlmacenDTO.class), 
			@ApiResponse(code = 500, message = "Salida no actualizada", response = ResponseDTO.class)})
	@PutMapping("/actualizarSalida")
	public ResponseEntity<?> actualizarSalida(
			@ApiParam(value = "Registro de la Salida que se va actualizar", required = true) 
			@RequestBody @Valid SalidaAlmacenDTO salidaDto, UriComponentsBuilder builder) {
		try {
			SalidaAlmacen salida = salidaAlmacenService.getSalidaById(salidaDto.getIdSalida());
			salida.setIdMaterial(salidaDto.getIdMaterial());
			salida.setCantidadSolicitada(salidaDto.getCantidadSolicitada());
			salida.setUnidadMedida(salidaDto.getUnidadMedida());
			salida.setClaveMaterial(salidaDto.getClaveMaterial());
			salida.setEstatusSalida(salidaDto.getEstatusSalida());
			salida.setCantidadSurtida(salidaDto.getCantidadSurtida());
			
			SalidaAlmacen salidaActualizada = salidaAlmacenService.update(salida);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(salidaActualizada.getIdSalida())).toUri());
	
			SalidaAlmacenDTO output = salidaActualizada.toSalidaAlmacenDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}
	
	@ApiOperation(value = "Elimina una Salida de almacén")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Registro eliminado", response = SalidaAlmacenDTO.class), 
			@ApiResponse(code = 500, message = "Registro no eliminado", response = ResponseDTO.class) })
	@DeleteMapping(value = "/eliminarSalida")
	public ResponseEntity<?> eliminarSalida(@RequestParam("idSalida") String idSalida) {
		try {
			salidaAlmacenService.delete(new Long(idSalida));
			HttpHeaders headers = new HttpHeaders();
			return new ResponseEntity<>(idSalida, headers, HttpStatus.ACCEPTED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}
}