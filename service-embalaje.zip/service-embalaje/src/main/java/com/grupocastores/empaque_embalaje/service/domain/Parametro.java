package com.grupocastores.empaque_embalaje.service.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Parametro implements Serializable {
	private static final long serialVersionUID = -7805261453725943559L;

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="id_parametro", unique=true, nullable=false, precision=10)
    private Long idParametro;
    
    @Column(nullable=false, length=4)
    private String clave;
    
    @Column(nullable=false, length=80)
    private String nombre;
    
    @Column(length=350)
    private String descripcion;
    
    @Column(nullable=false, length=80)
    private String valor;
    
    @Column(name="fecha_inicio", nullable=false)
    private Timestamp fechaInicio;
    
    @Column(name="fecha_fin")
    private Timestamp fechaFin;
    
    @Column(nullable=false, precision=3)
    private Short nacional;

	@Column(name = "id_oficina", precision = 10)
	private Long idOficina;

	@Column(name = "id_modulo", precision = 10)
	private Long idModulo;

	@Column(name = "id_estatus_parametro", precision = 10)
	private Long idEstatusParametro;
}
