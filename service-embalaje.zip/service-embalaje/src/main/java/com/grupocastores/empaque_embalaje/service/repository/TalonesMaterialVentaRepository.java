package com.grupocastores.empaque_embalaje.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.TalonesMaterialVenta;

@Repository
public interface TalonesMaterialVentaRepository extends JpaRepository<TalonesMaterialVenta, Long> {

	static final String QUERY_TALONES_MATERIAL_VENTA = "SELECT sa.Id_salida, sa.Id_solicitud, Nombre_material = 'material', sa.Id_material, sa.Cantidad_solicitada, "
			+ "sa.Unidad_medida, sa.Clave_material "
			+ "FROM salida_almacen_eye AS sa "
			+ "WHERE sa.Id_solicitud = :idSolicitud";

	@Query(value = QUERY_TALONES_MATERIAL_VENTA, nativeQuery = true)
	List<TalonesMaterialVenta> getTalonesMaterialVenta(String idSolicitud);
}
