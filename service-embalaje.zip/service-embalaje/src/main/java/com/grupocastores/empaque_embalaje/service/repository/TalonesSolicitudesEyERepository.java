package com.grupocastores.empaque_embalaje.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.TalonesSolicitudesEyE;

@Repository
public interface TalonesSolicitudesEyERepository extends JpaRepository<TalonesSolicitudesEyE, Long> {

	static final String QUERY_GET_TALONES_SOLICITUD_BY_ID_SOLICITUD = "SELECT * FROM talones_solicitudes_eye WHERE id_solicitud = :idSolicitud";

	@Query(value = QUERY_GET_TALONES_SOLICITUD_BY_ID_SOLICITUD, nativeQuery = true)
	List<TalonesSolicitudesEyE> getTalonesSolicitudByIdSolicitud(String idSolicitud);
}
