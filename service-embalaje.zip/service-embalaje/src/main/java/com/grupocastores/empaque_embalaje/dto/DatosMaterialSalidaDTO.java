
package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Datos completos sobre los materiales de la solicitud", description = "Datos de las salidas de materiales")
public class DatosMaterialSalidaDTO {

	private Long idSalida;
	private int idSolicitud;
	private int idMaterial;
	private String nombreMaterial;
	private int cantidadSolicitada;
	private String unidadMedida;
	private int claveMaterial;

	
	public DatosMaterialSalidaDTO(Long idSalida, int idSolicitud, int idMaterial, String nombreMaterial, int cantidadSolicitada, String unidadMedida,
			int claveMaterial) {
		this.idSalida = idSalida;
		this.idSolicitud = idSolicitud;
		this.idMaterial = idMaterial;
		this.nombreMaterial = nombreMaterial;
		this.cantidadSolicitada = cantidadSolicitada;
		this.unidadMedida = unidadMedida;
		this.claveMaterial = claveMaterial;	
	}

	@Override
	public String toString() {
		return "SalidaAlmacenDTO [idSalida=" + idSalida + ", idSolicitud=" + idSolicitud + ", idMaterial=" + idMaterial
				+ ", nombreMaterial=" + nombreMaterial +  ", cantidadSolicitada=" + cantidadSolicitada 
				+ ", unidadMedida=" + unidadMedida + ", claveMaterial="	+ claveMaterial + "]";
	}
	
}
