package com.grupocastores.empaque_embalaje.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.SolicitudesEyE;

@Repository
public interface SolicitudesEyERepository extends JpaRepository<SolicitudesEyE, Long> {

	static final String QUERY_ULTIMO_ID_SOLICITUD = "SELECT COALESCE(MAX(id_solicitud), 0) AS Last_id FROM solicitudes_eye";
	static final String QUERY_SOLICITUD_PENDIENTE_ENVIAR = "SELECT TOP 1 * FROM solicitudes_eye WHERE id_oficina = :idOficina AND id_estatus = 6";
	static final String QUERY_GET_SEGUIMIENTO = "SELECT *  FROM solicitudes_eye WHERE folio = :folio";


	@Query(value = QUERY_ULTIMO_ID_SOLICITUD, nativeQuery = true)
	int getUltimoIdSolicitud();

	@Query(value = QUERY_SOLICITUD_PENDIENTE_ENVIAR, nativeQuery = true)
	SolicitudesEyE getSolicitudPendienteDeEnviar(String idOficina);

	@Query(value = QUERY_GET_SEGUIMIENTO, nativeQuery = true)
	SolicitudesEyE getSeguimiento(int folio);
}
