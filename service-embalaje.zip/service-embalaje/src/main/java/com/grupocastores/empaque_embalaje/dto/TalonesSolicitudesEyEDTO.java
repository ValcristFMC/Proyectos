package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de los talones", description = "Datos de los talones")
public class TalonesSolicitudesEyEDTO {

	private long idTalon;
	private String numeroTalon;
	private int idSolicitud;
	private int idSalida;
	
	public TalonesSolicitudesEyEDTO(long idTalon, String numeroTalon, int idSolicitud, int idSalida) {
		this.idTalon = idTalon;
		this.numeroTalon = numeroTalon;
		this.idSolicitud = idSolicitud;
		this.idSalida = idSalida;
	}

	@Override
	public String toString() {
		return "TalonesSolicitudesEyEDTO [idTalon=" + idTalon + ", numeroTalon=" + numeroTalon + ", idSolicitud="
				+ idSolicitud + ", idSalida=" + idSalida + "]";
	}
	
	
}
