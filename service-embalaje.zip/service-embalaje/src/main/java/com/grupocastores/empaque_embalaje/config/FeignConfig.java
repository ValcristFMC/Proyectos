package com.grupocastores.empaque_embalaje.config;

import com.grupocastores.empaque_embalaje.utils.TokenUtil;
import feign.RequestInterceptor;
import feign.RequestTemplate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.grupocastores.empaque_embalaje.service.IParametroService;

@Configuration
public class FeignConfig {

	@Autowired
	private IParametroService parametroService;
	
    private String token;

    @Bean
    public RequestInterceptor requestInterceptor() {
        return new RequestInterceptor() {
            @Override
            public void apply(RequestTemplate template) {
                if (token == null) {
                    token = fetchToken();
                }
                template.header("Authorization", "Bearer " + token);
            }
        };
    }

    private String fetchToken() {
    	TokenUtil token = new TokenUtil();
        token.setUrlToken(parametroService.getParametroUrlToken().getValor());
    	token.setClientID(parametroService.getParametroClienteIdToken().getValor());
    	token.setClientSecret(parametroService.getParametroClientSecretToken().getValor());
    	token.setUserName(parametroService.getParametroUserNameToken().getValor());
    	token.setPassword(parametroService.getParametroPasswordToken().getValor());
    	token.generarToken();
        return token.getToken();
    }
}
