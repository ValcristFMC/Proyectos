package com.grupocastores.empaque_embalaje.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.grupocastores.empaque_embalaje.clients.SapClientFeign;
import com.grupocastores.empaque_embalaje.dto.SeguimientoDTO;
import com.grupocastores.empaque_embalaje.service.ISeguimientoSolicitudesEyEService;
import com.grupocastores.empaque_embalaje.service.domain.SeguimientoSolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.repository.SeguimientoSolicitudesEyERepository;

@Service
public class SeguimientoSolicitudesEyEImpl implements ISeguimientoSolicitudesEyEService {

	@Autowired
	private SeguimientoSolicitudesEyERepository seguimientoSolicitudesEyERepository;
	
	 @Autowired
	    private SapClientFeign sapClient;
    
	@Override
	public List<SeguimientoSolicitudesEyE> getAll() {
		return seguimientoSolicitudesEyERepository.findAll(); 
	}

	@Override
	public SeguimientoSolicitudesEyE save(SeguimientoSolicitudesEyE seguimiento) {
		return seguimientoSolicitudesEyERepository.save(seguimiento);
	}
	
	public SeguimientoDTO consultarSeguimientoSap(Integer folio) {
        try {
            return sapClient.consultarSeguimientoSap(folio);
        } catch (Exception e) {
            String errorMessage = "Error al consultar el seguimiento en SAP";
            throw new RuntimeException(errorMessage, e);
        }
    }
	
	@Override
	public SeguimientoDTO consultarSeguimientosSap(Integer folio) {
		try {
            return sapClient.consultarSeguimientoSap(folio);
		} catch(Exception e) {
			return null;
			
		}
	}
	
	@Override
	public int getSemaforo(int idSistema, int idModulo) {	
		return seguimientoSolicitudesEyERepository.getSemaforo(idSistema, idModulo);
	}

	@Override
	public void updateSemaforo(int idSistema, int idModulo, int semaforo) {
		seguimientoSolicitudesEyERepository.updateSemaforo(idSistema, idModulo, semaforo);
	}
	
	

}
