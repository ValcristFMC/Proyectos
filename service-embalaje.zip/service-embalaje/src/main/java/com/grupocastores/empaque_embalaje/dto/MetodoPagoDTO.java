package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un Metodo de pago", description = "Datos del Metodo de pago")
public class MetodoPagoDTO {
	private String idMetodoPago;
	private String descripcion;
	private String fecha;
	private String hora;
	private int estatus;
	private String clave;
	
	public MetodoPagoDTO(String idMetodoPago, String descripcion, String fecha, String hora, int estatus,
			String clave) {
		this.idMetodoPago = idMetodoPago;
		this.descripcion = descripcion;
		this.fecha = fecha;
		this.hora = hora;
		this.estatus = estatus;
		this.clave = clave;
	}

	@Override
	public String toString() {
		return "MetodoPagoDTO [idMetodoPago=" + idMetodoPago + ", descripcion=" + descripcion + ", fecha=" + fecha
				+ ", hora=" + hora + ", estatus=" + estatus + ", clave=" + clave + "]";
	}
	
}
