package com.grupocastores.empaque_embalaje.service.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.grupocastores.empaque_embalaje.dto.EmpaqueEmbalajeDTO;

/**
 * Clase EmpaqueEmbalaje del dominio tiene su correspondiente {@link EmpaqueEmbalajeDTO}
 *
 * @author Castores - Desarrollo TI
 */
@Data
@Entity
@Table(name = "empaqueEmbalaje")
@EntityListeners(EmpaqueEmbalaje.class)
public class EmpaqueEmbalaje 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "description") 
	private String description;
	
	@CreatedDate
	@Column(name = "created_date", nullable = false, updatable = false)
	private Date createddate;
	
	@LastModifiedDate
	@Column(name = "last_modified_date", nullable = false, updatable = true)
	private Date lastModifiedTime;
	
	@Column(name = "is_active")
	private Boolean isActive;
	
	
	/**
	 * Metodo estatico para obtener un EmpaqueEmbalaje a partir de un EmpaqueEmbalajeDTO origen
	 * 
	 * @param empaqueEmbalaje EmpaqueEmbalajeDTO origen
	 * 
	 * @return EmpaqueEmbalaje
	 */
	public static EmpaqueEmbalaje fromEmpaqueEmbalajeDTO(EmpaqueEmbalajeDTO empaqueEmbalaje) {
		EmpaqueEmbalaje rest = new EmpaqueEmbalaje();
		rest.setId(empaqueEmbalaje.getId());
		rest.setDescription(empaqueEmbalaje.getDescription());
		rest.setCreateddate(empaqueEmbalaje.getCreateddate());		
		rest.setLastModifiedTime(empaqueEmbalaje.getLastModifiedTime());
		rest.setIsActive(empaqueEmbalaje.getIsActive());
		return rest;
	}
	
	/**
	 * Metodo para obtener un EmpaqueEmbalajeDTO a partir de un EmpaqueEmbalaje origen
	 * 
	 * @return EmpaqueEmbalajeDTO
	 */
	public EmpaqueEmbalajeDTO toEmpaqueEmbalajeDTO() {
		 EmpaqueEmbalajeDTO dto = new  EmpaqueEmbalajeDTO();
		 dto.setId(this.getId());
		 dto.setDescription(this.getDescription());
		 dto.setCreateddate(this.getCreateddate());
		 dto.setLastModifiedTime(this.getLastModifiedTime());
		 dto.setIsActive(this.getIsActive());
		return dto;
	}
	
	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("EmpaqueEmbalaje [id=").append(id)
		.append(", description=").append(description)
		.append(",IsActive=").append(isActive)
		.append(",CreatedDate=").append(createddate)
		.append(",LastModifiedTime=").append(lastModifiedTime);		
		return strBuilder.toString();
	}
}
