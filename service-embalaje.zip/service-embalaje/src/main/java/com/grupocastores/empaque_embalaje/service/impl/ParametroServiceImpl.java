package com.grupocastores.empaque_embalaje.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static java.lang.Math.max;
import static java.lang.Math.min;

import com.grupocastores.empaque_embalaje.service.IParametroService;
import com.grupocastores.empaque_embalaje.service.domain.Parametro;
import com.grupocastores.empaque_embalaje.service.repository.ParametroRepository;

@Service
public class ParametroServiceImpl implements IParametroService {
	Logger logger = LoggerFactory.getLogger(ParametroServiceImpl.class);

	@Autowired
	private ParametroRepository parametroRepository;
	
	private Parametro findByClaveAndNacionalAndOficinaAndModulo(String clave, Integer nacional, Long idOficina,
			Long idModulo) {
		return this.parametroRepository.selectParametroByClaveAndNacionalAndOficinaAndModulo(clave,
				this.castFromIntegerToShort(nacional), idOficina, idModulo);
	}
	
	private Short castFromIntegerToShort(Integer value) {
		return (short) min(max(value, Short.MIN_VALUE), Short.MAX_VALUE);
	}
	
	@Override
	public Parametro getParametroUrlToken() {
		return this.findByClaveAndNacionalAndOficinaAndModulo("0001", 1, 1L, 96L);
	} 
	
	@Override
	public Parametro getParametroClienteIdToken() {
		return this.findByClaveAndNacionalAndOficinaAndModulo("0002", 1, 1L, 96L);
	} 
	
	@Override
	public Parametro getParametroClientSecretToken() {
		return this.findByClaveAndNacionalAndOficinaAndModulo("0003", 1, 1L, 96L);
	} 
	
	@Override
	public Parametro getParametroUserNameToken() {
		return this.findByClaveAndNacionalAndOficinaAndModulo("0004", 1, 1L, 96L);
	} 
	
	@Override
	public Parametro getParametroPasswordToken() {
		return this.findByClaveAndNacionalAndOficinaAndModulo("0005", 1, 1L, 96L);
	}

}
