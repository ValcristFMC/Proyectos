package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.DatosSeguimientoDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(DatosSeguimiento.class)
public class DatosSeguimiento {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_seguimiento")
	private Long idSeguimiento;
	
	@Column(name = "Nombre_usuario")
    private String nombreUsuario;
	
	@Column(name = "estatus")
    private String estatus;
	
	@Column(name = "Clave_estatus")
    private String claveEstatus;
	
	@Column(name = "observaciones")
    private String observaciones;
	
	@Column(name = "motivo_rechazo")
	private String motivoRechazo;
	
	@Column(name = "Oficina")
    private String oficina;
	
	@Column(name = "fecha")
    private String fecha;
	
	@Column(name = "hora")
    private String hora;
	
	@Column(name = "Ultimo")
    private int ultimo;
	
	public static DatosSeguimiento fromDatosSeguimientoDTO(DatosSeguimientoDTO seguimientoDTO) {
		DatosSeguimiento rest = new DatosSeguimiento();
		rest.setIdSeguimiento(seguimientoDTO.getIdSeguimiento());
		rest.setNombreUsuario(seguimientoDTO.getNombreUsuario());
		rest.setEstatus(seguimientoDTO.getEstatus());
		rest.setClaveEstatus(seguimientoDTO.getClaveEstatus());
		rest.setObservaciones(seguimientoDTO.getObservaciones());
		rest.setMotivoRechazo(seguimientoDTO.getMotivoRechazo());
		rest.setOficina(seguimientoDTO.getOficina());
		rest.setFecha(seguimientoDTO.getFecha());
		rest.setHora(seguimientoDTO.getHora());
		rest.setUltimo(seguimientoDTO.getUltimo());
		return rest;
	}
	
	public DatosSeguimientoDTO toDatosSeguimientoDTO() {
		DatosSeguimientoDTO dto = new DatosSeguimientoDTO();
		dto.setIdSeguimiento(this.getIdSeguimiento());
		dto.setNombreUsuario(this.getNombreUsuario());
		dto.setEstatus(this.getEstatus());
		dto.setClaveEstatus(this.getClaveEstatus());
		dto.setObservaciones(this.getObservaciones());
		dto.setMotivoRechazo(this.getMotivoRechazo());
		dto.setOficina(this.getOficina());
		dto.setFecha(this.getFecha());
		dto.setHora(this.getHora());
		dto.setUltimo(this.getUltimo());
		return dto;
	}
}
