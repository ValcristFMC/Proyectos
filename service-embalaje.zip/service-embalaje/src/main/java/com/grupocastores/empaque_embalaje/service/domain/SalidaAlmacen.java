package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.SalidaAlmacenDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "salida_almacen_eye")
@EntityListeners(SalidaAlmacen.class)
public class SalidaAlmacen {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id_salida")
	private Long idSalida;
	
	@Column(name = "Id_solicitud")
	private int idSolicitud;
	
	@Column(name = "Id_material")
	private int idMaterial;
	
	@Column(name = "Cantidad_solicitada")
	private int cantidadSolicitada;
	
	@Column(name = "Unidad_medida")
	private String unidadMedida;
	
	@Column(name = "Clave_material")
	private int claveMaterial;
	
	@Column(name = "Estatus_salida")
	private int estatusSalida;
	
	@Column(name = "Cantidad_surtida")
	private int cantidadSurtida;
	
	@Column(name = "Id_empaque_utilizado")
	private int idEmpaqueUtilizado;
	
	public static SalidaAlmacen fromSalidaAlmacenDTO(SalidaAlmacenDTO salidaDTO) {
		SalidaAlmacen rest = new SalidaAlmacen();
		rest.setIdSalida(salidaDTO.getIdSalida());
		rest.setIdSolicitud(salidaDTO.getIdSolicitud());
		rest.setIdMaterial(salidaDTO.getIdMaterial());
		rest.setCantidadSolicitada(salidaDTO.getCantidadSolicitada());
		rest.setUnidadMedida(salidaDTO.getUnidadMedida());
		rest.setClaveMaterial(salidaDTO.getClaveMaterial());
		rest.setEstatusSalida(salidaDTO.getEstatusSalida());
		rest.setCantidadSurtida(salidaDTO.getCantidadSurtida());
		rest.setIdEmpaqueUtilizado(salidaDTO.getIdEmpaqueUtilizado());
		return rest;
	}
	
	public SalidaAlmacenDTO toSalidaAlmacenDTO() {
		SalidaAlmacenDTO dto = new SalidaAlmacenDTO();
		dto.setIdSalida(this.getIdSalida());
		dto.setIdSolicitud(this.getIdSolicitud());
		dto.setIdMaterial(this.getIdMaterial());
		dto.setCantidadSolicitada(this.getCantidadSolicitada());
		dto.setUnidadMedida(this.getUnidadMedida());
		dto.setClaveMaterial(this.getClaveMaterial());
		dto.setEstatusSalida(this.getEstatusSalida());
		dto.setCantidadSurtida(this.getCantidadSurtida());
		dto.setIdEmpaqueUtilizado(this.getIdEmpaqueUtilizado());
		return dto;
	}

}
