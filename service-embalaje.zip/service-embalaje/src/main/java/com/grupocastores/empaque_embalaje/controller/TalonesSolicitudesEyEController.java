package com.grupocastores.empaque_embalaje.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.grupocastores.empaque_embalaje.dto.CatalogoConceptoImporteDTO;
import com.grupocastores.empaque_embalaje.dto.CdOrigenDestinoDTO;
import com.grupocastores.empaque_embalaje.dto.CoDTO;
import com.grupocastores.empaque_embalaje.dto.DetatrDTO;
import com.grupocastores.empaque_embalaje.dto.MetodoPagoDTO;
import com.grupocastores.empaque_embalaje.dto.ResponseDTO;
import com.grupocastores.empaque_embalaje.dto.TalonEnviadoEyeDTO;
import com.grupocastores.empaque_embalaje.dto.TalonesDTO;
import com.grupocastores.empaque_embalaje.dto.TalonesParametrosDTO;
import com.grupocastores.empaque_embalaje.dto.TalonesSolicitudesEyEDTO;
import com.grupocastores.empaque_embalaje.dto.TrDTO;
import com.grupocastores.empaque_embalaje.service.ITalonesSolicitudesEyEService;
import com.grupocastores.empaque_embalaje.service.domain.CatalogoConceptoImporte;
import com.grupocastores.empaque_embalaje.service.domain.CdOrigenDestino;
import com.grupocastores.empaque_embalaje.service.domain.Co;
import com.grupocastores.empaque_embalaje.service.domain.Detatr;
import com.grupocastores.empaque_embalaje.service.domain.MetodoPago;
import com.grupocastores.empaque_embalaje.service.domain.TalonEnviadoEye;
import com.grupocastores.empaque_embalaje.service.domain.Talones;
import com.grupocastores.empaque_embalaje.service.domain.TalonesParametros;
import com.grupocastores.empaque_embalaje.service.domain.TalonesSolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.domain.Tr;
import com.grupocastores.empaque_embalaje.service.impl.FechaServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/talonessolicitudeseye")
@Api(value = "TalonesSolicitudesEyEController", produces = "application/json")
public class TalonesSolicitudesEyEController {

	Logger log = LoggerFactory.getLogger(TalonesSolicitudesEyEController.class);

	@Autowired
	private ITalonesSolicitudesEyEService talonesSolicitudesEyeService;
	static final String HEADERBACK = "/TalonesSolicitudesEyE/{id}";

	@ApiOperation(value = "Guarda los datos de los talones de las solicitudes")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Registro de Talon creado", response = TalonesSolicitudesEyEDTO.class),
			@ApiResponse(code = 500, message = "Talón no creado", response = ResponseDTO.class) })
	@PostMapping("/guardarTalonSolicitudEyE")
	public ResponseEntity<?> guardarTalonSolicitudEyE(
			@ApiParam(value = "Registro del Talón que se va a crear", required = true) @RequestBody @Valid TalonesSolicitudesEyEDTO talonDto,
			UriComponentsBuilder builder) {
		try {
			TalonesSolicitudesEyE talonCreado = talonesSolicitudesEyeService
					.save(TalonesSolicitudesEyE.fromTalonesSolicitudesEyEDTO(talonDto));
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(
					builder.path(HEADERBACK).buildAndExpand(String.valueOf(talonCreado.getIdTalon())).toUri());

			TalonesSolicitudesEyEDTO output = talonCreado.toTalonesSolicitudesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Actualiza los datos de los talones de las solicitudes")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Actualización realizada", response = TalonesSolicitudesEyEDTO.class),
			@ApiResponse(code = 500, message = "Talón no actualizado", response = ResponseDTO.class) })
	@PutMapping("/actualizarTalonSolicitudEyE")
	public ResponseEntity<?> actualizarTalon(
			@ApiParam(value = "Talón que se va actualizar", required = true) @RequestBody @Valid TalonesSolicitudesEyEDTO talonDto,
			UriComponentsBuilder builder) {
		try {
			TalonesSolicitudesEyE talon = talonesSolicitudesEyeService
					.getTalonesSolicitudesEyEById(talonDto.getIdTalon());
			talon.setNumeroTalon(talonDto.getNumeroTalon());

			TalonesSolicitudesEyE talonActualizado = talonesSolicitudesEyeService.update(talon);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(
					builder.path(HEADERBACK).buildAndExpand(String.valueOf(talonActualizado.getIdTalon())).toUri());

			TalonesSolicitudesEyEDTO output = talonActualizado.toTalonesSolicitudesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = " Servicio para talones", tags = { "Controlador TalonesSolicitudesEyEController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el talon", response = ResponseDTO.class),
			@ApiResponse(code = 404, message = "No encontrado") })
	@GetMapping("/getTalonByClaTalon")
	@ResponseBody
	public ResponseEntity<?> getTalonByClaTalon(@RequestParam("claTalon") String claTalon,
			UriComponentsBuilder builder) {
		try {
			Talones talon = talonesSolicitudesEyeService.getTalonesByClaTalon(claTalon);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK).buildAndExpand(talon.getClaTalon()).toUri());
			TalonesDTO output = talon.toTalonesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = " Servicio para tr", tags = { "Controlador TalonesSolicitudesEyEController" })
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Response success para el tr", response = ResponseDTO.class),
			@ApiResponse(code = 404, message = "No encontrado") })
	@GetMapping("/getTrByClaTalon")
	@ResponseBody
	public ResponseEntity<?> getTrByClaTalon(@RequestParam("tabla") String tabla,
			@RequestParam("claTalon") String claTalon, UriComponentsBuilder builder) {
		try {
			String nombreTipoDocumento="";
			Tr tablaTr = talonesSolicitudesEyeService.getTrByClaTalon(tabla, claTalon);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK).buildAndExpand(tablaTr.getClaTalon()).toUri());
			TrDTO output = tablaTr.toTrDTO();
			nombreTipoDocumento = getTipoDocumento(output.getTpDc());
			
			output.setNombreTipoDocumento(nombreTipoDocumento);
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera Ciudad Destino/Origen")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Ciudades obtenidas", response = CdOrigenDestinoDTO.class),
			@ApiResponse(code = 500, message = "No encontrados", response = ResponseDTO.class) })
	@GetMapping("/getCdOrigenDestino")
	@ResponseBody
	public Collection<?> getCdOrigenDestino(@RequestParam("idCiudadOrigen") String idCiudadOrigen,
			@RequestParam("idCiudadDestino") String idCiudadDestino) {
		List<CdOrigenDestinoDTO> lstCiudades = new ArrayList<>();

		for (CdOrigenDestino ciudad : talonesSolicitudesEyeService.getCdOrigenDestino(Integer.parseInt(idCiudadOrigen),
				Integer.parseInt(idCiudadDestino))) {
			lstCiudades.add(ciudad.toCdOrigenDestinoDTO());
		}

		return lstCiudades;
	}

	@ApiOperation(value = "Recupera Parametro")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Parametro obtenido", response = String.class),
			@ApiResponse(code = 500, message = "No encontrado", response = ResponseDTO.class) })
	@GetMapping("/getTalonesParametrosByIdParametro")
	@ResponseBody
	public ResponseEntity<?> getTalonesParametrosByIdParametro(@RequestParam("idParametro") String idParametro,
			UriComponentsBuilder builder) {
		try {
			TalonesParametros parametro = talonesSolicitudesEyeService
					.getTalonesParametrosByIdParametro(Integer.parseInt(idParametro));
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK).buildAndExpand(parametro.getIdParametro()).toUri());

			TalonesParametrosDTO output = parametro.toTalonesParametrosDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera Detatr")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Detatr obtenido", response = DetatrDTO.class),
			@ApiResponse(code = 500, message = "No encontrado", response = ResponseDTO.class) })
	@GetMapping("/getDetatrByClaTalon")
	@ResponseBody
	public ResponseEntity<?> getDetatrByClaTalon(@RequestParam("claTalon") String claTalon,
			UriComponentsBuilder builder) {
		try {
			Detatr detalleTr = talonesSolicitudesEyeService.getDetatrByClaTalon(claTalon);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK).buildAndExpand(detalleTr.getClaTalon()).toUri());

			DetatrDTO output = detalleTr.toDetatrDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera Metodo de pago")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Metodo de pago obtenido", response = MetodoPagoDTO.class),
			@ApiResponse(code = 500, message = "No encontrado", response = ResponseDTO.class) })
	@GetMapping("/getMetodoPagoById")
	@ResponseBody
	public ResponseEntity<?> getMetodoPagoById(@RequestParam("idMetodoPago") String idMetodoPago,
			UriComponentsBuilder builder) {
		try {
			MetodoPago metodoPago = talonesSolicitudesEyeService.getMetodoPagoById(idMetodoPago);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK).buildAndExpand(metodoPago.getIdMetodoPago()).toUri());

			MetodoPagoDTO output = metodoPago.toMetodoPagoDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera Metodo de pago")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Metodo de pago obtenido", response = MetodoPagoDTO.class),
			@ApiResponse(code = 500, message = "No encontrado", response = ResponseDTO.class) })
	@GetMapping("/getMetodoPagoByClave")
	@ResponseBody
	public ResponseEntity<?> getMetodoPagoByClave(@RequestParam("idMetodoPago") String idMetodoPago,
			UriComponentsBuilder builder) {
		try {
			MetodoPago metodoPago = talonesSolicitudesEyeService.getMetodoPagoByClave(idMetodoPago);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK).buildAndExpand(metodoPago.getIdMetodoPago()).toUri());

			MetodoPagoDTO output = metodoPago.toMetodoPagoDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera CatalogoConceptoImporteMMYYYY")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "CatalogoConceptoImporteMMYYYY obtenido", response = CatalogoConceptoImporteDTO.class),
			@ApiResponse(code = 500, message = "No encontrado", response = ResponseDTO.class) })
	@GetMapping("/getCatalogoConceptoImporteByParams")
	@ResponseBody
	public ResponseEntity<?> getCatalogoConceptoImporteByParams(@RequestParam("tabla") String tabla,
			@RequestParam("idConcepto") String idConcepto, @RequestParam("claTalon") String claTalon,
			UriComponentsBuilder builder) {
		try {
			CatalogoConceptoImporte catalogo = talonesSolicitudesEyeService.getCatalogoConceptoImporteByParams(tabla,
					idConcepto, claTalon);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK).buildAndExpand(catalogo.getIdConcepto()).toUri());

			CatalogoConceptoImporteDTO output = catalogo.toCatalogoConceptoImporteDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera el contenido del talón (CoMMYYYY)")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "CoMMYYYY obtenido", response = CoDTO.class),
			@ApiResponse(code = 500, message = "No encontrado", response = ResponseDTO.class) })
	@GetMapping("/getQueContiene")
	@ResponseBody
	public Collection<?> getQueContiene(@RequestParam("tabla") String tabla,
			@RequestParam("claTalon") String claTalon) {
		List<CoDTO> lstTablaCo = new ArrayList<>();

		for (Co tablaCo : talonesSolicitudesEyeService.getQueContiene(tabla, claTalon)) {
			lstTablaCo.add(tablaCo.toCoDTO());
		}

		return lstTablaCo;
	}

	@ApiOperation(value = "Recupera los talones de una solicitud")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Talones obtenidos", response = TalonesSolicitudesEyEDTO.class),
			@ApiResponse(code = 500, message = "No encontrados", response = ResponseDTO.class) })
	@GetMapping("/getTalonesSolicitudByIdSolicitud")
	@ResponseBody
	public Collection<?> getTalonesSolicitudByIdSolicitud(@RequestParam("idSolicitud") String idSolicitud) {
		List<TalonesSolicitudesEyEDTO> lstTalones = new ArrayList<>();

		for (TalonesSolicitudesEyE talon : talonesSolicitudesEyeService.getTalonesSolicitudByIdSolicitud(idSolicitud)) {
			lstTalones.add(talon.toTalonesSolicitudesDTO());
		}

		return lstTalones;
	}

	@ApiOperation(value = "Elimina una Talon de la solcitud")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Registro eliminado", response = TalonesSolicitudesEyE.class),
			@ApiResponse(code = 500, message = "Registro no eliminado", response = ResponseDTO.class) })
	@DeleteMapping(value = "/eliminarTalonSolicitud")
	public ResponseEntity<?> eliminarTalonSolicitud(@RequestParam("idTalon") String idTalon) {
		try {
			talonesSolicitudesEyeService.delete(new Long(idTalon));
			HttpHeaders headers = new HttpHeaders();
			return new ResponseEntity<>(idTalon, headers, HttpStatus.ACCEPTED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Crea un registro TalonEnviadoEye")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Registro de TalonEnviadoEye creado", response = TalonEnviadoEyeDTO.class),
			@ApiResponse(code = 500, message = "No creado", response = ResponseDTO.class) })
	@PostMapping("/guardarTalonEnviadoEye")
	public ResponseEntity<?> guardarTalonEnviadoEye(
			@ApiParam(value = "Registro de TalonEnviadoEye que se va a crear", required = true) @RequestBody @Valid TalonEnviadoEyeDTO talonEnviadoDto,
			UriComponentsBuilder builder) {
		try {
				
			talonEnviadoDto.setFecha(FechaServiceImpl.getFechaActual());
			talonEnviadoDto.setHora(FechaServiceImpl.getHoraActual());
			
			TalonEnviadoEye talonEnviado = talonesSolicitudesEyeService.save(TalonEnviadoEye.fromTalonEnviadoEyeDTO(talonEnviadoDto));

			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(
					builder.path(HEADERBACK).buildAndExpand(String.valueOf(talonEnviado.getIdTalonEnviado())).toUri());

			TalonEnviadoEyeDTO output = talonEnviado.toTalonEnviadoEyeDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera TalonEnviadoEye")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "TalonEnviadoEye obtenido", response = TalonEnviadoEyeDTO.class),
			@ApiResponse(code = 500, message = "No encontrado", response = ResponseDTO.class) })
	@GetMapping("/getTalonEnviadoByNumeroTalon")
	@ResponseBody
	public ResponseEntity<?> getTalonEnviadoByNumeroTalon(@RequestParam("numeroTalon") String numeroTalon, UriComponentsBuilder builder) {
		try {
			TalonEnviadoEye talonEnviado = talonesSolicitudesEyeService.getTalonEnviadoByNumeroTalon(numeroTalon);

			if (talonEnviado == null) {
				talonEnviado = new TalonEnviadoEye();
			}

			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(
					builder.path(HEADERBACK).buildAndExpand(String.valueOf(talonEnviado.getIdTalonEnviado())).toUri());

			TalonEnviadoEyeDTO output = talonEnviado.toTalonEnviadoEyeDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}
	
	public String getTipoDocumento(int tipoDocumento) {
		String tipo = "";

		switch (tipoDocumento) {
		case 1: {
			tipo = "Talon en pesos";
		}
			break;
		case 2: {
			tipo = "Talon en dolares";
		}
			break;
		case 3: {
			tipo = "Talon cancelado en pesos";
		}
			break;
		case 4: {
			tipo = "Talon cancelado en dolares";
		}
			break;
		case 5: {
			tipo = "Reposicion talon en pesos";
		}
			break;
		case 6: {
			tipo = "Reposicion talon en dolares";
		}
			break;
		case 7: {
			tipo = "Control en pesos";
		}
			break;
		case 8: {
			tipo = "Control en dolares";
		}
			break;
		case 9: {
			tipo = "Talon foráneo";
		}
			break;
		case 10: {
			tipo = "---------------------";
		}
			break;
		case 11: {
			tipo = "Control cancelado en pesos";
		}
			break;
		case 12: {
			tipo = "Control cancelado en dolares";
		}
			break;
		case 13: {
			tipo = "Control documentado en pesos";
		}
			break;
		case 14: {
			tipo = "Control documentado en dolares";
		}
			break;
		case 15: {
			tipo = "Reposicion control en pesos";
		}
			break;
		case 16: {
			tipo = "Reposicion control en dolares";
		}
			break;
		case 17: {
			tipo = "Control de Maniobras en Pesos";
		}
			break;
		case 18: {
			tipo = "Control de Maniobras en Dolares";
		}
			break;
		}
		return tipo;
	}
}
