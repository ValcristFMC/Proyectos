package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.SolicitudesDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "solicitudes_eye")
@EntityListeners(SolicitudesEyE.class)
public class SolicitudesEyE {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_solicitud")
	private Long idSolicitud;
	
	@Column(name = "folio")
	private int folio;
	
	@Column(name = "id_personal")
	private int idPersonal;
	
	@Column(name = "id_oficina")
	private int idOficina;
	
	@Column(name = "id_estatus")
	private int idEstatus;
	
	@Column(name = "anexo")
	private String anexo;
	
	@Column(name = "observaciones")
	private String observaciones;
	
	@Column(name = "motivo_rechazo")
	private String motivoRechazo;
	
	@Column(name = "tipo_solicitud")
	private String tipoSolicitud;
	
	@Column(name = "fecha")
	private String fecha;
	
	@Column(name = "hora")
	private String hora;
	
	public static SolicitudesEyE fromSolicitudesEyEDTO(SolicitudesDTO solicitud) {
		SolicitudesEyE rest = new SolicitudesEyE();
		rest.setIdSolicitud(solicitud.getIdSolicitud());
		rest.setFolio(solicitud.getFolio());
		rest.setIdPersonal(solicitud.getIdPersonal());
		rest.setIdOficina(solicitud.getIdOficina());
		rest.setIdEstatus(solicitud.getIdEstatus());
		rest.setAnexo(solicitud.getAnexo());
		rest.setObservaciones(solicitud.getObservaciones());
		rest.setMotivoRechazo(solicitud.getMotivoRechazo());
		rest.setTipoSolicitud(solicitud.getTipoSolicitud());
		rest.setFecha(solicitud.getFecha());
		rest.setHora(solicitud.getHora());
		return rest;
	}
	
	public SolicitudesDTO toSolicitudesDTO() {
		SolicitudesDTO dto = new SolicitudesDTO();
		dto.setIdSolicitud(this.getIdSolicitud());
		dto.setFolio(this.getFolio());
		dto.setIdPersonal(this.getIdPersonal());
		dto.setIdOficina(this.getIdOficina());
		dto.setIdEstatus(this.getIdEstatus());
		dto.setAnexo(this.getAnexo());
		dto.setObservaciones(this.getObservaciones());
		dto.setMotivoRechazo(this.getMotivoRechazo());
		dto.setTipoSolicitud(this.getTipoSolicitud());
		dto.setFecha(this.getFecha());
		dto.setHora(this.getHora());
		
		return dto;
	}
}
