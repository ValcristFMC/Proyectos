package com.grupocastores.empaque_embalaje.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.grupocastores.empaque_embalaje.dto.EmpaqueEmbalajeDTO;
import com.grupocastores.empaque_embalaje.dto.ResponseDTO;
import com.grupocastores.empaque_embalaje.service.IEmpaqueEmbalajeService;
import com.grupocastores.empaque_embalaje.service.domain.EmpaqueEmbalaje;

@RestController
@RequestMapping(value = "/EmpaqueEmbalaje")
@Api(value = "EmpaqueEmbalajeController", produces = "application/json")
public class  EmpaqueEmbalajeController {

	Logger log = LoggerFactory.getLogger(EmpaqueEmbalajeController.class);
	
	@Autowired
	private IEmpaqueEmbalajeService empaqueEmbalajeService;
	static final String HEADERBACK = "/EmpaqueEmbalaje/{id}";
    
	@ApiOperation(value = "Crea un registro EmpaqueEmbalaje")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Registro de EmpaqueEmbalaje creado", response = EmpaqueEmbalajeDTO.class), @ApiResponse(code = 500, message = "No creado", response = ResponseDTO.class) })
	@PostMapping("/create")
	public ResponseEntity<?> create(@ApiParam(value = "Registro de EmpaqueEmbalaje que se va a crear", required = true) 
	@RequestBody @Valid EmpaqueEmbalajeDTO empaqueEmbalajeDto, UriComponentsBuilder builder) {
		try {
			EmpaqueEmbalaje empaqueEmbalajeCreated = empaqueEmbalajeService.save(EmpaqueEmbalaje.fromEmpaqueEmbalajeDTO(empaqueEmbalajeDto));
	
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(empaqueEmbalajeCreated.getId())).toUri());
	
			EmpaqueEmbalajeDTO output = empaqueEmbalajeCreated.toEmpaqueEmbalajeDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Actualiza un EmpaqueEmbalaje")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "EmpaqueEmbalaje actualiza", response = EmpaqueEmbalajeDTO.class), @ApiResponse(code = 500, message = "No actualizado", response = ResponseDTO.class) })
	@PutMapping("/update")
	public ResponseEntity<?> update(@ApiParam(value = "Registro EmpaqueEmbalaje que se va a actualizar", required = true) @RequestBody @Valid EmpaqueEmbalajeDTO empaqueEmbalajeDto, UriComponentsBuilder builder) {
		try {
			EmpaqueEmbalaje empaqueEmbalajeCreated = empaqueEmbalajeService.update(EmpaqueEmbalaje.fromEmpaqueEmbalajeDTO(empaqueEmbalajeDto));
	
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(empaqueEmbalajeCreated.getId())).toUri());
	
			EmpaqueEmbalajeDTO output = empaqueEmbalajeCreated.toEmpaqueEmbalajeDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.ACCEPTED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}
	
	@ApiOperation(value = "Activa/Inactiva un EmpaqueEmbalaje")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Registro cambio entre activo/inactivo actualizado", response = EmpaqueEmbalajeDTO.class), @ApiResponse(code = 500, message = "No actualizado",response = ResponseDTO.class) })
	@PutMapping("/changeStatus/{id}")
	public ResponseEntity<?> chageStatus(@ApiParam(value = "El registro con el ID capturado cambiara entre activo/inactivo", required = true) @PathVariable String id, UriComponentsBuilder builder) {
		try {
			EmpaqueEmbalaje empaqueEmbalajeCreated = empaqueEmbalajeService.changeStatus(new Integer(id));
	
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(empaqueEmbalajeCreated.getId())).toUri());
	
			EmpaqueEmbalajeDTO output = empaqueEmbalajeCreated.toEmpaqueEmbalajeDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.ACCEPTED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}
   
	@ApiOperation(value = "Elimina un EmpaqueEmbalaje")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Registro eliminado", response = EmpaqueEmbalajeDTO.class), @ApiResponse(code = 500, message = "Registro no eliminado", response = ResponseDTO.class) })
	@DeleteMapping(value = "/delete/{id}")
	public ResponseEntity<?> delete(@ApiParam(value = "Id del EmpaqueEmbalaje que se va a crear", required = true) @PathVariable String id) {
		try {
			EmpaqueEmbalaje empaqueEmbalajeDeleted = empaqueEmbalajeService.delete(new Integer(id));
	
			HttpHeaders headers = new HttpHeaders();
			
			EmpaqueEmbalajeDTO output = empaqueEmbalajeDeleted.toEmpaqueEmbalajeDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.ACCEPTED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera EmpaqueEmbalajes")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "EmpaqueEmbalajes obtenidos", response = EmpaqueEmbalajeDTO.class), @ApiResponse(code = 500, message = "No encontrados", response = ResponseDTO.class) })
	@GetMapping("/getAll")
	@ResponseBody
	public Collection<?> getAll() {
		List<EmpaqueEmbalajeDTO> empaqueEmbalajes = new ArrayList<>();
		for (EmpaqueEmbalaje empaqueEmbalaje : empaqueEmbalajeService.getAll()) {
			empaqueEmbalajes.add(empaqueEmbalaje.toEmpaqueEmbalajeDTO());
		}
		return empaqueEmbalajes;
	}
}
