package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion del seguumientod de las solicitudes EyE", description = "Datos del segumiento de solicitudes EyE")
public class DatosSeguimientoDTO {

	private Long idSeguimiento;
    private String nombreUsuario;
    private String estatus;
    private String claveEstatus;
    private String observaciones;
    private String motivoRechazo;
    private String oficina;
    private String fecha;
    private String hora;
    private int ultimo;
    
	public DatosSeguimientoDTO(Long idSeguimiento, String nombreUsuario, String estatus, String claveEstatus,
			String observaciones, String motivoRechazo, String oficina, String fecha, String hora, int ultimo) {
		this.idSeguimiento = idSeguimiento;
		this.nombreUsuario = nombreUsuario;
		this.estatus = estatus;
		this.claveEstatus = claveEstatus;
		this.observaciones = observaciones;
		this.motivoRechazo = motivoRechazo;
		this.oficina = oficina;
		this.fecha = fecha;
		this.hora = hora;
		this.ultimo = ultimo;
	}

	@Override
	public String toString() {
		return "DatosSeguimientoDTO [idSeguimiento=" + idSeguimiento + ", nombreUsuario=" + nombreUsuario + ", estatus="
				+ estatus + ", claveEstatus=" + claveEstatus + ", observaciones=" + observaciones + ", motivoRechazo="
				+ motivoRechazo + ", oficina=" + oficina + ", fecha=" + fecha + ", hora=" + hora + ", ultimo=" + ultimo
				+ "]";
	}
        
}
