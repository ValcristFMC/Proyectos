package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.UnidadMedidaDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "unidadmedida")
@EntityListeners(UnidadMedida.class)
public class UnidadMedida {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idunidadmedida")
    private int idUnidadMedida;
    
	@Column(name = "nombre")
    private String nombre;
    
	@Column(name = "descripcion")
    private String descripcion;
    
	@Column(name = "idpersonal")
    private int idPersonal;
    
	@Column(name = "fechamod")
    private String fechaMod;
    
	@Column(name = "horamod")
    private String horaMod;
    
	@Column(name = "estatus")
    private int estatus;
    
	@Column(name = "esentero")
    private int esEntero;

	public static UnidadMedida fromMaterialesEyEDTO(UnidadMedidaDTO materialesEyEDTO) {
		UnidadMedida uinidadMedida = new UnidadMedida();
        uinidadMedida.setIdUnidadMedida(materialesEyEDTO.getIdUnidadMedida());
        uinidadMedida.setNombre(materialesEyEDTO.getNombre());
        uinidadMedida.setDescripcion(materialesEyEDTO.getDescripcion());
        uinidadMedida.setIdPersonal(materialesEyEDTO.getIdPersonal());
        uinidadMedida.setFechaMod(materialesEyEDTO.getFechaMod());
        uinidadMedida.setHoraMod(materialesEyEDTO.getHoraMod());
        uinidadMedida.setEstatus(materialesEyEDTO.getEstatus());
        uinidadMedida.setEsEntero(materialesEyEDTO.getEsEntero());
        return uinidadMedida;
    }

    public UnidadMedidaDTO toMaterialesEyEDTO() {
    	UnidadMedidaDTO unidadMedidaDto = new UnidadMedidaDTO();
        unidadMedidaDto.setIdUnidadMedida(this.getIdUnidadMedida());
        unidadMedidaDto.setNombre(this.getNombre());
        unidadMedidaDto.setDescripcion(this.getDescripcion());
        unidadMedidaDto.setIdPersonal(this.getIdPersonal());
        unidadMedidaDto.setFechaMod(this.getFechaMod());
        unidadMedidaDto.setHoraMod(this.getHoraMod());
        unidadMedidaDto.setEstatus(this.getEstatus());
        unidadMedidaDto.setEsEntero(this.getEsEntero());
        return unidadMedidaDto;
    }
}
