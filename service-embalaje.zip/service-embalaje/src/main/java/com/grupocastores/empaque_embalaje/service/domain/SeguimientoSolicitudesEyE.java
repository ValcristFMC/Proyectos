package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.SeguimientoSolicitudesEyEDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "seguimiento_solicitudes_eye")
@EntityListeners(SeguimientoSolicitudesEyE.class)
public class SeguimientoSolicitudesEyE {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_seguimiento")
	private Long idSeguimiento;
	
	@Column(name = "id_solicitud")
	private int idSolicitud;
	
	@Column(name = "id_personal")
	private int idPersonal;
	
	@Column(name = "id_oficina")
	private int idOficina;
	
	@Column(name = "id_estatus")
	private int idEstatus;
	
	@Column(name = "fecha")
	private String fecha;
	
	@Column(name = "hora")
	private String hora;
	
	public static SeguimientoSolicitudesEyE fromSeguimientoSolicitudesDTO(SeguimientoSolicitudesEyEDTO seguimientoDTO) {
		SeguimientoSolicitudesEyE rest = new SeguimientoSolicitudesEyE();
		rest.setIdSeguimiento(seguimientoDTO.getIdSeguimiento());
		rest.setIdSolicitud(seguimientoDTO.getIdSolicitud());
		rest.setIdPersonal(seguimientoDTO.getIdPersonal());
		rest.setIdOficina(seguimientoDTO.getIdOficina());
		rest.setIdEstatus(seguimientoDTO.getIdEstatus());
		rest.setFecha(seguimientoDTO.getFecha());
		rest.setHora(seguimientoDTO.getHora());
		return rest;
	}
	
	public SeguimientoSolicitudesEyEDTO toSeguimientoSolicitudesDTO() {
		 SeguimientoSolicitudesEyEDTO dto = new  SeguimientoSolicitudesEyEDTO();
		 dto.setIdSeguimiento(this.getIdSeguimiento());
		 dto.setIdSolicitud(this.getIdSolicitud());
		 dto.setIdPersonal(this.getIdPersonal());
		 dto.setIdOficina(this.getIdOficina());
		 dto.setIdEstatus(this.getIdEstatus());
		 dto.setFecha(this.getFecha());
		 dto.setHora(this.getHora());
		return dto;
	}
}
