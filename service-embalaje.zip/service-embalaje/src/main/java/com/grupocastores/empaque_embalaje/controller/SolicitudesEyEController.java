package com.grupocastores.empaque_embalaje.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import com.grupocastores.empaque_embalaje.dto.CantidadesMaterialPermitidoDTO;
import com.grupocastores.empaque_embalaje.dto.DatosSeguimientoDTO;
import com.grupocastores.empaque_embalaje.dto.EmpaqueUtilizadoDTO;
import com.grupocastores.empaque_embalaje.dto.ReporteSolicitudesMaterialDTO;
import com.grupocastores.empaque_embalaje.dto.ResponseDTO;
import com.grupocastores.empaque_embalaje.dto.SolicitudesDTO;
import com.grupocastores.empaque_embalaje.dto.TalonesMaterialReacondicionamientoDTO;
import com.grupocastores.empaque_embalaje.dto.TalonesMaterialVentaDTO;
import com.grupocastores.empaque_embalaje.dto.TipoEmpaqueDTO;
import com.grupocastores.empaque_embalaje.service.ISolicitudesEyEService;
import com.grupocastores.empaque_embalaje.service.domain.CantidadesMaterialPermitido;
import com.grupocastores.empaque_embalaje.service.domain.DatosSeguimiento;
import com.grupocastores.empaque_embalaje.service.domain.EmpaqueUtilizado;
import com.grupocastores.empaque_embalaje.service.domain.ReporteSolicitudesMaterial;
import com.grupocastores.empaque_embalaje.service.domain.SolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.domain.TalonesMaterialReacondicionamiento;
import com.grupocastores.empaque_embalaje.service.domain.TalonesMaterialVenta;
import com.grupocastores.empaque_embalaje.service.domain.TipoEmpaque;
import com.grupocastores.empaque_embalaje.service.impl.FechaServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/solicitudeseye")
@Api(value = "SolicitrudesEyEController", produces = "application/json")
public class SolicitudesEyEController {

	Logger log = LoggerFactory.getLogger(SolicitudesEyEController.class);

	@Autowired
	private ISolicitudesEyEService solicitudesEyeService;
	static final String HEADERBACK = "/SolicitudesEyE/{id}";

	@ApiOperation(value = "Obtiene todas las solicitudes")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Solicitudes obtenidas", response = SolicitudesDTO.class),
			@ApiResponse(code = 500, message = "Solicitudes no encontradas", response = ResponseDTO.class) })
	@GetMapping("/getSolicitudes")
	public Collection<?> getSolicitudes() {
		List<SolicitudesDTO> lstSolicitudes = new ArrayList<>();

		for (SolicitudesEyE solicitud : solicitudesEyeService.getSolicitudes()) {
			lstSolicitudes.add(solicitud.toSolicitudesDTO());
		}

		return lstSolicitudes;
	}

	@ApiOperation(value = "Obtiene un registro de SolicitudEye")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Solicitud obtenida", response = SolicitudesDTO.class),
			@ApiResponse(code = 500, message = "No encontrada", response = ResponseDTO.class) })
	@GetMapping("/getSolicitudById")
	public ResponseEntity<?> getSolicitudById(@RequestParam("idSolicitud") String idSolicitud,
			UriComponentsBuilder builder) {
		try {
			SolicitudesEyE solicitud = solicitudesEyeService.getSolicitudById(new Long(idSolicitud));

			if (solicitud == null) {
				solicitud = new SolicitudesEyE();
			}

			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(
					builder.path(HEADERBACK).buildAndExpand(String.valueOf(solicitud.getIdSolicitud())).toUri());
			SolicitudesDTO output = solicitud.toSolicitudesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Obtiene el último id de las solicitudes")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Ultimo id obtenido", response = SolicitudesDTO.class),
			@ApiResponse(code = 500, message = "Sin Id", response = ResponseDTO.class) })
	@GetMapping("/getUltimoIdSolicitud")
	public int getUltimoIdSolicitud() {
		return solicitudesEyeService.getUltimoIdSolicitud();
	}

	@ApiOperation(value = "Guarda los datos de la solicitud")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Registro de Soicitud creada", response = SolicitudesDTO.class),
			@ApiResponse(code = 500, message = "Solicitud no creada", response = ResponseDTO.class) })
	@PostMapping("/guardarSolicitud")
	public ResponseEntity<?> guardarSolicitud(
			@ApiParam(value = "Registro de Solicitud que se va a crear", required = true) @Valid SolicitudesDTO solicitudDto,
			@RequestParam(value = "documento", required = false) MultipartFile documento, UriComponentsBuilder builder,
			HttpServletRequest request) {
		try {
			int folio = generarFolioSolicitud();
			String url;
			solicitudDto.setFolio(folio);

			if (documento != null) {
				String nombre = folio + "_" + documento.getOriginalFilename();
				String fileName = nombre;
				url = solicitudesEyeService.uplooadFileAzureStorage(fileName, documento.getInputStream());
				solicitudDto.setAnexo(url);
			}
			
	        solicitudDto.setFecha(FechaServiceImpl.getFechaActual());
	        solicitudDto.setHora(FechaServiceImpl.getHoraActual());
						
			SolicitudesEyE solicitudGuardada = solicitudesEyeService
					.save(SolicitudesEyE.fromSolicitudesEyEDTO(solicitudDto));
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(solicitudGuardada.getIdSolicitud())).toUri());

			SolicitudesDTO output = solicitudGuardada.toSolicitudesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Obtiene una lista personalizada de las solicitudes")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Solicitudes obtenidas", response = ReporteSolicitudesMaterialDTO.class),
			@ApiResponse(code = 500, message = "Solicitudes no encontradas", response = ResponseDTO.class) })
	@GetMapping("/getReporteSolicitudes")
	public Collection<?> getReporteSolicitudes(@RequestParam("idOficina") int idOficina) {
		List<ReporteSolicitudesMaterialDTO> lstSolicitudes = new ArrayList<>();

		if (idOficina == 1) {
			for (ReporteSolicitudesMaterial solicitud : solicitudesEyeService
					.getReporteSolicitudesMaterialCorporativo()) {
				lstSolicitudes.add(solicitud.toReporteSolicitudesDTO());
			}
		} else {
			for (ReporteSolicitudesMaterial solicitud : solicitudesEyeService
					.getReporteSolicitudesMaterial(idOficina)) {
				lstSolicitudes.add(solicitud.toReporteSolicitudesDTO());
			}
		}

		return lstSolicitudes;
	}

	@ApiOperation(value = "Obtiene una lista personalizada de las solicitudes por fecha")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Solicitudes obtenidas", response = ReporteSolicitudesMaterialDTO.class),
			@ApiResponse(code = 500, message = "Solicitudes no encontradas", response = ResponseDTO.class) })
	@GetMapping("/getReporteSolicitudesByFecha")
	public Collection<?> getReporteSolicitudesByFecha(@RequestParam("fechaInicio") String fechaInicio,
			@RequestParam("fechaFin") String fechaFin, @RequestParam("idOficina") int idOficina) {
		List<ReporteSolicitudesMaterialDTO> lstSolicitudes = new ArrayList<>();

		if (idOficina == 1) {
			for (ReporteSolicitudesMaterial solicitud : solicitudesEyeService
					.getReporteSolicitudesByFechaCorporativo(fechaInicio, fechaFin)) {
				lstSolicitudes.add(solicitud.toReporteSolicitudesDTO());
			}
		} else {
			for (ReporteSolicitudesMaterial solicitud : solicitudesEyeService.getReporteSolicitudesByFecha(fechaInicio,
					fechaFin, idOficina)) {
				lstSolicitudes.add(solicitud.toReporteSolicitudesDTO());
			}
		}

		return lstSolicitudes;
	}

	@ApiOperation(value = "Obtiene los talones y las salidas de material")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Datos de los talones y material", response = TalonesMaterialReacondicionamientoDTO.class),
			@ApiResponse(code = 500, message = "Talónes no encontrados", response = ResponseDTO.class) })
	@GetMapping("/getTalonesMaterial")
	public Collection<?> getTalonesMaterial(@RequestParam("idSolicitud") String idSolicitud,
			@RequestParam("tipo") String tipo) {
		List<TalonesMaterialReacondicionamientoDTO> lstTalonesReacomodo = new ArrayList<>();
		List<TalonesMaterialVentaDTO> lstTalonesVenta = new ArrayList<>();

		if (tipo.equals("venta")) {
			for (TalonesMaterialVenta talon : solicitudesEyeService.getTalonesMaterialVenta(idSolicitud)) {
				lstTalonesVenta.add(talon.toTalonMaterialVentaDTO());
			}

			return lstTalonesVenta;
		} else {
			for (TalonesMaterialReacondicionamiento talon : solicitudesEyeService
					.getTalonesMaterialReacondicionamiento(idSolicitud)) {
				lstTalonesReacomodo.add(talon.toTalonMaterialReacondicionamientoDTO());
			}

			return lstTalonesReacomodo;
		}
	}

	@ApiOperation(value = "Actualiza los datos de la solicitud")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Solicitud actualizada", response = SolicitudesDTO.class),
			@ApiResponse(code = 500, message = "Solicitud no actualizada", response = ResponseDTO.class) })
	@PutMapping("/actualizarSolicitud")
	public ResponseEntity<?> actualizarSolicitud(
			@ApiParam(value = "Datos de la Solicitud que se va actualizar", required = true) @Valid SolicitudesDTO solicitudDto,
			@RequestParam(value = "documento", required = false) MultipartFile documento,
			UriComponentsBuilder builder) {
		try {
			SolicitudesEyE solicitud = solicitudesEyeService.getSolicitudById(solicitudDto.getIdSolicitud());
			String url;

			if (documento != null) {
				String nombre = solicitudDto.getFolio() + "_" + documento.getOriginalFilename();
				String fileName = nombre;
				url = solicitudesEyeService.uplooadFileAzureStorage(fileName, documento.getInputStream());
				solicitud.setAnexo(url);
			} else {
				solicitud.setAnexo(solicitudDto.getAnexo());
			}

			solicitud.setIdEstatus(solicitudDto.getIdEstatus());
			solicitud.setObservaciones(solicitudDto.getObservaciones());
			solicitud.setMotivoRechazo(solicitudDto.getMotivoRechazo());

			SolicitudesEyE solicitudActualizada = solicitudesEyeService.update(solicitud);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(solicitudActualizada.getIdSolicitud())).toUri());

			SolicitudesDTO output = solicitudActualizada.toSolicitudesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Obtiene el seguimiento de las solicitudes")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Datos del segumiento de las solicitudes", response = TalonesMaterialReacondicionamientoDTO.class),
			@ApiResponse(code = 500, message = "Datos no encontrados", response = ResponseDTO.class) })
	@GetMapping("/getDatosSeguimientoByIdSolicitud")
	public Collection<?> getDatosSeguimientoByIdSolicitud(@RequestParam("idSolicitud") String idSolicitud) {
		List<DatosSeguimientoDTO> lstDatosSeguimiento = new ArrayList<>();

		for (DatosSeguimiento datosSeguimiento : solicitudesEyeService
				.getDatosSegimientoByIdSolictud(Long.parseLong(idSolicitud))) {
			lstDatosSeguimiento.add(datosSeguimiento.toDatosSeguimientoDTO());
		}

		return lstDatosSeguimiento;
	}

	@ApiOperation(value = "Obtiene la Solicitud pendiente de enviar de una oficina en especifico")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Solicitud obtenida", response = SolicitudesDTO.class),
			@ApiResponse(code = 500, message = "Solicitud no encontrada", response = ResponseDTO.class) })
	@GetMapping("/getSolicitudPendienteDeEnviar")
	public ResponseEntity<?> getSolicitudPendienteDeEnviar(@RequestParam("idOficina") String idOficina,
			UriComponentsBuilder builder) {
		try {
			SolicitudesEyE solicitud = solicitudesEyeService.getSolicitudPendienteDeEnviar(idOficina);
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK).buildAndExpand(solicitud.getIdSolicitud()).toUri());
			SolicitudesDTO output = solicitud.toSolicitudesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Obtiene los tipos de empaque")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Tipos de empaque obtenidos", response = TipoEmpaqueDTO.class),
			@ApiResponse(code = 500, message = "Tipos de empaque no encontrados", response = ResponseDTO.class) })
	@GetMapping("/getTipoEmpaque")
	public Collection<?> getTipoEmpaque(UriComponentsBuilder builder) {
		try {
			List<TipoEmpaqueDTO> lstTipoEmpaque = new ArrayList<>();

			for (TipoEmpaque tipo : solicitudesEyeService.getTipoEmpaque()) {
				lstTipoEmpaque.add(tipo.toTipoEmpaqueDTO());
			}

			return lstTipoEmpaque;
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return new ArrayList<>();
		}
	}

	@ApiOperation(value = "Crea un registro EmpaqueUtilizado")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Registro de EmpaqueUtilizado creado", response = EmpaqueUtilizadoDTO.class),
			@ApiResponse(code = 500, message = "No creado", response = ResponseDTO.class) })
	@PostMapping("/guardarEmpaqueUtilizado")
	public ResponseEntity<?> guardarEmpaqueUtilizado(
			@ApiParam(value = "Registro de EmpaqueUtilizado que se va a crear", required = true) @RequestBody @Valid EmpaqueUtilizadoDTO empaqueDto,
			UriComponentsBuilder builder) {
		try {
			EmpaqueUtilizado empaqueUtilizadoGuardado = solicitudesEyeService
					.guardarEmpaqueUtilizado(EmpaqueUtilizado.fromEmpaqueUtilizadoDTO(empaqueDto));

			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(empaqueUtilizadoGuardado.getIdEmpaqueUtilizado())).toUri());

			EmpaqueUtilizadoDTO output = empaqueUtilizadoGuardado.toEmpaqueUtilizadoDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera CantidadMaterialPermitido")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Cantidad obtenida", response = CantidadesMaterialPermitidoDTO.class),
			@ApiResponse(code = 500, message = "No encontrados", response = ResponseDTO.class) })
	@GetMapping("/getCantidadMaterialPermitido")
	@ResponseBody
	public ResponseEntity<?> getCantidadMaterialPermitido(@RequestParam("idMaterial") String idMaterial,
			@RequestParam("idTipoEmpaque") String idTipoEmpaque, UriComponentsBuilder builder) {
		try {
			CantidadesMaterialPermitido cantidad = solicitudesEyeService
					.getCantidadMaterialPermitido(new Integer(idMaterial), new Integer(idTipoEmpaque));
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(
					builder.path(HEADERBACK).buildAndExpand(String.valueOf(cantidad.getIdMaterial())).toUri());
			CantidadesMaterialPermitidoDTO output = cantidad.toCantidadDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	@ApiOperation(value = "Recupera EmpaquesUtilizados")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "EmpaquesUtilizados obtenidos", response = EmpaqueUtilizadoDTO.class),
			@ApiResponse(code = 500, message = "No encontrados", response = ResponseDTO.class) })
	@GetMapping("/getEmpaquesUtilizados")
	@ResponseBody
	public Collection<?> getEmpaquesUtilizados(@RequestParam("idSolicitud") String idSolicitud,
			@RequestParam("idOficina") String idOficina, UriComponentsBuilder builder) {
		try {
			List<EmpaqueUtilizadoDTO> lstEmpaques = new ArrayList<>();

			for (EmpaqueUtilizado empaque : solicitudesEyeService.getEmpaquesUtilizados(new Integer(idSolicitud),
					new Integer(idOficina))) {
				lstEmpaques.add(empaque.toEmpaqueUtilizadoDTO());
			}

			return lstEmpaques;
		} catch (Exception e) {
			log.error(e.getMessage());
			List<EmpaqueUtilizadoDTO> lstEmpaques = new ArrayList<>();
			return lstEmpaques;
		}
	}

	@ApiOperation(value = "Actualiza un EmpaqueUtilizado")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "EmpaqueUtilizado actualizado", response = EmpaqueUtilizadoDTO.class),
			@ApiResponse(code = 500, message = "No actualizado", response = ResponseDTO.class) })
	@PutMapping("/actualizarEmpaqueUtilizado")
	public ResponseEntity<?> actualizarEmpaqueUtilizado(
			@ApiParam(value = "Registro EmpaqueUtilizado que se va a actualizar", required = true) @RequestBody @Valid EmpaqueUtilizadoDTO empaqueUtilizadoDto,
			UriComponentsBuilder builder) {
		try {
			EmpaqueUtilizado empaqueActualizado = solicitudesEyeService
					.actualizarEmpaqueUtilizado(EmpaqueUtilizado.fromEmpaqueUtilizadoDTO(empaqueUtilizadoDto));
			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(empaqueActualizado.getIdEmpaqueUtilizado())).toUri());

			EmpaqueUtilizadoDTO output = empaqueActualizado.toEmpaqueUtilizadoDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.ACCEPTED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}

	public int generarFolioSolicitud() {
		try {
			int anio = new Date().getYear() + 1900;
			String folio = String.valueOf(anio);
			folio = folio.substring(2);
			String strUltimoId = String.valueOf(this.getUltimoIdSolicitud() + 1);

			for (int i = strUltimoId.length(); i < 4; i++) {
				strUltimoId = "0" + strUltimoId;
			}

			folio += strUltimoId;
			return Integer.parseInt(folio);
		} catch (Exception e) {
			return 0;
		}
	}
}
