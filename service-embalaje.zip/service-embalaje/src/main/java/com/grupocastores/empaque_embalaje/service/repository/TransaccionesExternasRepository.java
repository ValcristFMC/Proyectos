package com.grupocastores.empaque_embalaje.service.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.grupocastores.empaque_embalaje.service.domain.EntradaMaterial;
import com.grupocastores.empaque_embalaje.service.domain.Servidores;
import com.grupocastores.empaque_embalaje.utils.UtilitiesRepository;


@Repository
public class TransaccionesExternasRepository {

	Logger log = LoggerFactory.getLogger(TransaccionesExternasRepository.class);

	@PersistenceContext
	private EntityManager entityManager;


	@Autowired
	private UtilitiesRepository utilitiesRepository;

	static final String QUERY_INSERT_ENTRADA_MATERIAL = "INSERT OPENQUERY (%s, 'SELECT idmaterial, cantidad, idpersonal, fechamod, horamod, preciocompra, "
			+ "idtipomovimiento, no_nota, idpoliza, idoficina  FROM talones.entradamaterial') VALUES(%s, %s, %s, '%s', '%s', %s, %s, '%s', %s, '%s')";

	public boolean guardarEntradaMaterial(String claveOficina, EntradaMaterial entrada) {
		Servidores servidor = utilitiesRepository.getLinkedServerByOfice(claveOficina);
		String ipOficina = servidor.getServidorVinculado();
		String stringInsert = String.format(QUERY_INSERT_ENTRADA_MATERIAL, ipOficina, entrada.getIdMaterial(),
				entrada.getCantidad(), entrada.getIdPersonal(), entrada.getFechaModificacion(),
				entrada.getHoraModificacion(), entrada.getPrecioCompra(), entrada.getIdTipoMovimiento(),
				entrada.getNumeroNota(), entrada.getIdPoliza(), entrada.getIdOficina(), ipOficina);
		return utilitiesRepository.executeStoredProcedure(stringInsert);
	}

	
}
