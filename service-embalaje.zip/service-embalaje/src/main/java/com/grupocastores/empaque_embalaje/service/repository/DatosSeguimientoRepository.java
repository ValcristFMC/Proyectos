package com.grupocastores.empaque_embalaje.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.DatosSeguimiento;

@Repository
public interface DatosSeguimientoRepository extends JpaRepository<DatosSeguimiento, Long>{

	static final String QUERY_DATOS_SEGUIMIENTO = "SELECT ss.id_seguimiento, CONCAT(p.nombre, ' ', p.apellido_paterno, ' ', p.apellido_materno) AS Nombre_usuario, "
			+ "e.estatus, e.clave AS Clave_estatus, s.observaciones, s.motivo_rechazo, o.plaza AS Oficina, ss.fecha, ss.hora, 0 AS Ultimo "
			+ "FROM seguimiento_solicitudes_eye AS ss "
			+ "LEFT JOIN personal As p ON p.id_personal = ss.id_personal "
			+ "JOIN solicitudes_eye AS s ON s.id_solicitud = ss.id_solicitud "
			+ "JOIN estatus_solicitudes_eye AS e ON e.id_estatus = ss.id_estatus "
			+ "LEFT JOIN oficina AS o ON o.id_oficina = ss.id_oficina "
			+ "WHERE ss.id_solicitud = :idSolicitud";

	@Query(value = QUERY_DATOS_SEGUIMIENTO, nativeQuery = true)
	List<DatosSeguimiento> getDatosSegimientoByIdSolictud(Long idSolicitud);
}
