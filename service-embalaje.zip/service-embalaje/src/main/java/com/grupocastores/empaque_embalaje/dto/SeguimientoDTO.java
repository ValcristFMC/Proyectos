package com.grupocastores.empaque_embalaje.dto;

import java.util.List;

public class SeguimientoDTO {

 private String estatus;
 private String tipoSolicitud;
 private List<MaterialDTO> listMaterial;

 // Getters y Setters
 public String getEstatus() {
     return estatus;
 }

 public void setEstatus(String estatus) {
     this.estatus = estatus;
 }

 public String getTipoSolicitud() {
     return tipoSolicitud;
 }

 public void setTipoSolicitud(String tipoSolicitud) {
     this.tipoSolicitud = tipoSolicitud;
 }

 public List<MaterialDTO> getListMaterial() {
     return listMaterial;
 }

 public void setListMaterial(List<MaterialDTO> listMaterial) {
     this.listMaterial = listMaterial;
 }
}


