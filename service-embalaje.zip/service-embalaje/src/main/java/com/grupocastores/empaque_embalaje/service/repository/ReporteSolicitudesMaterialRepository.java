package com.grupocastores.empaque_embalaje.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.ReporteSolicitudesMaterial;

@Repository
public interface ReporteSolicitudesMaterialRepository extends JpaRepository<ReporteSolicitudesMaterial, Long> {

	static final String QUERY_REPORTE_SOLICITUDES_MATERIAL_OFICINA = "SELECT s.id_solicitud, s.folio, s.id_oficina, o.plaza AS Oficina, pm.id_personal_mysql As Id_personal, "
			+ "CONCAT(p.nombre, ' ', p.apellido_paterno, ' ', p.apellido_materno) AS Usuario_solicita, s.tipo_solicitud, "
			+ "s.anexo, s.observaciones, s.fecha, e.estatus, e.clave AS Clave_estatus, No_sap = 0 "
			+ "FROM solicitudes_eye s "
			+ "JOIN oficina o ON o.id_oficina = s.id_oficina "
			+ "JOIN personal AS p ON p.id_personal = s.id_personal "
			+ "JOIN personal_mysql pm ON pm.id_personal = p.id_personal "
			+ "JOIN estatus_solicitudes_eye e ON e.id_estatus = s.id_estatus "
			+ "WHERE s.id_estatus <> 6 AND s.id_oficina = :idOficina ";

	static final String QUERY_REPORTES_SOLICITUDES_MATERIAL_BY_FECHA_OFICINA = "SELECT s.id_solicitud, s.folio, s.id_oficina, o.plaza AS Oficina, pm.id_personal_mysql As Id_personal,"
			+ "CONCAT(p.nombre, ' ', p.apellido_paterno, ' ', p.apellido_materno) AS Usuario_solicita, s.tipo_solicitud, "
			+ "s.anexo, s.observaciones, s.fecha, e.estatus, e.clave AS Clave_estatus, No_sap = 0 "
			+ "FROM solicitudes_eye s "
			+ "JOIN oficina o ON o.id_oficina = s.id_oficina "
			+ "JOIN personal AS p ON p.id_personal = s.id_personal "
			+ "JOIN personal_mysql pm ON pm.id_personal = p.id_personal "
			+ "JOIN estatus_solicitudes_eye e ON e.id_estatus = s.id_estatus "
			+ "WHERE s.id_estatus <> 6 AND s.fecha >= :fechaInicio AND s.fecha <= :fechaFin AND s.id_oficina = :idOficina";
	
	static final String QUERY_REPORTE_SOLICITUDES_MATERIAL = "SELECT s.id_solicitud, s.folio, s.id_oficina, o.plaza AS Oficina, pm.id_personal_mysql As Id_personal, "
			+ "CONCAT(p.nombre, ' ', p.apellido_paterno, ' ', p.apellido_materno) AS Usuario_solicita, s.tipo_solicitud, "
			+ "s.anexo, s.observaciones, s.fecha, e.estatus, e.clave AS Clave_estatus, No_sap = 0 "
			+ "FROM solicitudes_eye s "
			+ "JOIN oficina o ON o.id_oficina = s.id_oficina "
			+ "JOIN personal AS p ON p.id_personal = s.id_personal "
			+ "JOIN personal_mysql pm ON pm.id_personal = p.id_personal "
			+ "JOIN estatus_solicitudes_eye e ON e.id_estatus = s.id_estatus "
			+ "WHERE s.id_estatus <> 6 ";

	static final String QUERY_REPORTES_SOLICITUDES_MATERIAL_BY_FECHA = "SELECT s.id_solicitud, s.folio, s.id_oficina, o.plaza AS Oficina, pm.id_personal_mysql As Id_personal,"
			+ "CONCAT(p.nombre, ' ', p.apellido_paterno, ' ', p.apellido_materno) AS Usuario_solicita, s.tipo_solicitud, "
			+ "s.anexo, s.observaciones, s.fecha, e.estatus, e.clave AS Clave_estatus, No_sap = 0 "
			+ "FROM solicitudes_eye s "
			+ "JOIN oficina o ON o.id_oficina = s.id_oficina "
			+ "JOIN personal AS p ON p.id_personal = s.id_personal "
			+ "JOIN personal_mysql pm ON pm.id_personal = p.id_personal "
			+ "JOIN estatus_solicitudes_eye e ON e.id_estatus = s.id_estatus "
			+ "WHERE s.id_estatus <> 6 AND s.fecha >= :fechaInicio AND s.fecha <= :fechaFin";
	
	
	static final String QUERY_SOLICITUDES_AUTORIZADAS_SALIDA_PARCIAL = "SELECT s.id_solicitud, s.folio, s.id_oficina, o.clave AS Oficina, pm.id_personal_mysql As Id_personal,"
			+ "CONCAT(p.nombre, ' ', p.apellido_paterno, ' ', p.apellido_materno) AS Usuario_solicita, s.tipo_solicitud, "
			+ "s.anexo, s.observaciones, s.fecha, e.estatus, e.clave AS Clave_estatus, No_sap = 0 "
			+ "FROM solicitudes_eye s "
			+ "JOIN oficina o ON o.id_oficina = s.id_oficina "
			+ "JOIN personal AS p ON p.id_personal = s.id_personal "
			+ "JOIN personal_mysql pm ON pm.id_personal = p.id_personal "
			+ "JOIN estatus_solicitudes_eye e ON e.id_estatus = s.id_estatus "
			+ "WHERE s.id_estatus IN (2,5)";
	
	@Query(value = QUERY_REPORTE_SOLICITUDES_MATERIAL_OFICINA, nativeQuery = true)
	List<ReporteSolicitudesMaterial> getReporteSolicitudesMaterial(int idOficina);
	
	@Query(value = QUERY_REPORTES_SOLICITUDES_MATERIAL_BY_FECHA_OFICINA, nativeQuery = true)
	List<ReporteSolicitudesMaterial> getReporteSolicitudesByFecha(String fechaInicio, String fechaFin, int idOficina);
	
	@Query(value = QUERY_REPORTE_SOLICITUDES_MATERIAL, nativeQuery = true)
	List<ReporteSolicitudesMaterial> getReporteSolicitudesMaterialCorporativo();
	
	@Query(value = QUERY_REPORTES_SOLICITUDES_MATERIAL_BY_FECHA, nativeQuery = true)
	List<ReporteSolicitudesMaterial> getReporteSolicitudesByFechaCorporativo(String fechaInicio, String fechaFin);
	
	@Query(value = QUERY_SOLICITUDES_AUTORIZADAS_SALIDA_PARCIAL, nativeQuery = true)
	List<ReporteSolicitudesMaterial> getReporteSolicitudesAutorizadasSolidaParcial();
}
