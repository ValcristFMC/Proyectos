package com.grupocastores.empaque_embalaje.service.impl;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.empaque_embalaje.service.IMaterialesEyEService;
import com.grupocastores.empaque_embalaje.service.domain.EntradaMaterial;
import com.grupocastores.empaque_embalaje.service.domain.MaterialesEyE;
import com.grupocastores.empaque_embalaje.service.domain.UnidadMedida;
import com.grupocastores.empaque_embalaje.service.repository.MaterialesEyERepository;
import com.grupocastores.empaque_embalaje.service.repository.TalonesRepository;
import com.grupocastores.empaque_embalaje.service.repository.TransaccionesExternasRepository;


@Service
public class MaterialesEyEServiceImpl implements IMaterialesEyEService {

	@Autowired
	private MaterialesEyERepository materialesEyERepository;
	
	@Autowired
	private TransaccionesExternasRepository transaccionesExternasRepository;
	
	@Autowired
	private TalonesRepository talonesRepository;
	
	@Override
	public List<MaterialesEyE> getMateriales() {
		return talonesRepository.getMateriales();
	}
	
	@Override
	public List<MaterialesEyE> getMaterialesByNombre(Collection<String> lstMateriales) {
		return talonesRepository.getMaterialesByNombre(lstMateriales);
	}
	
	@Override
	public List<UnidadMedida> getUnidadesMedida() {
		return talonesRepository.getUnidadesMedida();
	}

	@Override
	public MaterialesEyE save(MaterialesEyE materialesEyE) {
		return null;
	}

	@Override
	public MaterialesEyE getMaterialesNombre(int idClave) {
		return talonesRepository.getMaterialesNombre(idClave);
	}
	
	@Override
	public boolean guardarEntradaMaterial(String claveOficina, EntradaMaterial entrada) {
		return transaccionesExternasRepository.guardarEntradaMaterial(claveOficina, entrada);
	}

	@Override
	public int convertirCantidad(String nombreMaterial, int cantidad, String unidadMedida) {
		
		if (nombreMaterial.toLowerCase().equals("cinta canela")) {
			cantidad = unidadMedida.equals("pzas") || unidadMedida.equals("pza") ? cantidad * 150 : cantidad / 150;
		} else if (nombreMaterial.toLowerCase().equals("poliburbuja")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 120 : cantidad / 120;
		} else if (nombreMaterial.toLowerCase().equals("polipack")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 210 : cantidad / 210;
		} else if (nombreMaterial.toLowerCase().equals("fleje")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 864 : cantidad / 864;
		} else if (nombreMaterial.toLowerCase().equals("carton corrugado")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 35 : cantidad / 35;
		} else if (nombreMaterial.toLowerCase().equals("emplaye")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 396 : cantidad / 396;
		} else if (nombreMaterial.toLowerCase().equals("sellos fleje")) {
			cantidad = unidadMedida.equals("bolsas") ? cantidad * 1000 : cantidad / 1000;
		}

		return cantidad;
	}

	@Override
	public int calcularCantidad(int idMaterial, int cantidad) {
	    int cantidadRedondeada = 0;
	    int metrosLineales = 0;

	    switch (idMaterial) {
	        case 2:
	        	metrosLineales = 150;
	            break;
	        case 3:
	        	metrosLineales = 396;
	            break;
	        case 4:
	        	metrosLineales = 120;
	            break;
	        case 5:
	        	metrosLineales = 35;
	            break;
	    }

	    if (metrosLineales > 0) {
	    	cantidadRedondeada = cantidad / metrosLineales;
	        int remainder = cantidad % metrosLineales;
	        if (remainder > 0) {
	        	cantidadRedondeada += 1;
	        }
	    } else {
	    	cantidadRedondeada = cantidad;
	    }

	    return cantidadRedondeada;
	}

	@Override
	public String convertirUnidadMedida(int idMaterial, String unidaMedida) {
		if (unidaMedida.equals("pzas") || unidaMedida.equals("pza")) {
			unidaMedida = idMaterial == 2 ? "mts" : "pza";
			unidaMedida = idMaterial == 7 ? "bolsas" : unidaMedida;
		} else if (unidaMedida.equals("mts")) {
			unidaMedida = idMaterial == 2 ? "pza" : "rollos";
		} else {
			unidaMedida = "mts";
			unidaMedida = idMaterial == 37 || idMaterial == 38 ? "kg" : unidaMedida;
		}
		return unidaMedida;
	}


}
