package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.TalonesParametrosDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "parametros")
@EntityListeners(TalonesParametros.class)
public class TalonesParametros {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idparametro")
	private Long idParametro;
	
	@Column(name = "nombre")
	private String nombre;
	
	@Column(name = "valor")
	private String valor;
	
	public static TalonesParametros fromTalonesParametrosDTO(TalonesParametrosDTO talonesParametrosDTO) {
        TalonesParametros talonesParametros = new TalonesParametros();
        talonesParametros.setIdParametro(talonesParametrosDTO.getIdParametro());
        talonesParametros.setNombre(talonesParametrosDTO.getNombre());
        talonesParametros.setValor(talonesParametrosDTO.getValor());
        return talonesParametros;
    }

    public TalonesParametrosDTO toTalonesParametrosDTO() {
        TalonesParametrosDTO talonesParametrosDTO = new TalonesParametrosDTO();
        talonesParametrosDTO.setIdParametro(this.getIdParametro());
        talonesParametrosDTO.setNombre(this.getNombre());
        talonesParametrosDTO.setValor(this.getValor());
        return talonesParametrosDTO;
    }
}
