package com.grupocastores.empaque_embalaje.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.CantidadesMaterialPermitido;

@Repository
public interface CantidadesMaterialPermitidoRepository extends JpaRepository<CantidadesMaterialPermitido, Integer> {

	static final String QUERY_GET_CANTIDAD_MATERIAL_PERMITIDO = "SELECT * FROM cantidades_material_permitido WHERE Id_material = :idMaterial AND Id_tipo_empaque = :idTipoEmpaque";

	@Query(value = QUERY_GET_CANTIDAD_MATERIAL_PERMITIDO, nativeQuery = true)
	CantidadesMaterialPermitido getCantidadMaterialPermitido(int idMaterial, int idTipoEmpaque);
}
