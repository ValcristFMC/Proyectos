package com.grupocastores.empaque_embalaje.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@FeignClient(name = "castores-service-personal")
public interface PersonalFeignClient {

	@GetMapping(value = "/findPersonalByNombre/{nombre}", produces = "application/json;charset=UTF-8")
	public  ResponseEntity<List<Object>> findPersonalByNombre(@PathVariable(name = "nombre") String nombre);


}

