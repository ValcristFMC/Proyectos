package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de CoMMYYYY", description = "Datos de CoMMYYYY")
public class CoDTO {

	private String claTalon;
    private int bultos;
    private int etiquetas;
    private String empaque;
    private String queContiene;
    private int pesoT;
    private int mts3;
    private int pesoE;
    private int precio;
    private int noConvenio;
    private int precioCalculado;
    private int tipoCobro;
    private int largo;
    private int ancho;
    private int alto;
    
	public CoDTO(String claTalon, int bultos, int etiquetas, String empaque, String queContiene, int pesoT, int mts3,
			int pesoE, int precio, int noConvenio, int precioCalculado, int tipoCobro, int largo, int ancho, int alto) {
		this.claTalon = claTalon;
		this.bultos = bultos;
		this.etiquetas = etiquetas;
		this.empaque = empaque;
		this.queContiene = queContiene;
		this.pesoT = pesoT;
		this.mts3 = mts3;
		this.pesoE = pesoE;
		this.precio = precio;
		this.noConvenio = noConvenio;
		this.precioCalculado = precioCalculado;
		this.tipoCobro = tipoCobro;
		this.largo = largo;
		this.ancho = ancho;
		this.alto = alto;
	}

	@Override
	public String toString() {
		return "CoDTO [claTalon=" + claTalon + ", bultos=" + bultos + ", etiquetas=" + etiquetas + ", empaque="
				+ empaque + ", queContiene=" + queContiene + ", pesoT=" + pesoT + ", mts3=" + mts3 + ", pesoE=" + pesoE
				+ ", precio=" + precio + ", noConvenio=" + noConvenio + ", precioCalculado=" + precioCalculado
				+ ", tipoCobro=" + tipoCobro + ", largo=" + largo + ", ancho=" + ancho + ", alto=" + alto + "]";
	}
        
}
