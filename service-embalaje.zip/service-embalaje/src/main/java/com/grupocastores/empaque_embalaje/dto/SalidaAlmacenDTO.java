package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de las salidas de almacén", description = "Datos de las salidas")
public class SalidaAlmacenDTO {

	private Long idSalida;
	private int idSolicitud;
	private int idMaterial;
	private int cantidadSolicitada;
	private String unidadMedida;
	private int claveMaterial;
	private int estatusSalida;
	private int cantidadSurtida;
	private int idEmpaqueUtilizado;
	
	public SalidaAlmacenDTO(Long idSalida, int idSolicitud, int idMaterial, int cantidadSolicitada, String unidadMedida,
			int claveMaterial, int estatusSalida, int cantidadSurtida, int idEmpaqueUtilizado) {
		this.idSalida = idSalida;
		this.idSolicitud = idSolicitud;
		this.idMaterial = idMaterial;
		this.cantidadSolicitada = cantidadSolicitada;
		this.unidadMedida = unidadMedida;
		this.claveMaterial = claveMaterial;
		this.estatusSalida = estatusSalida;
		this.cantidadSurtida = cantidadSurtida;
		this.idEmpaqueUtilizado = idEmpaqueUtilizado;
	}

	@Override
	public String toString() {
		return "SalidaAlmacenDTO [idSalida=" + idSalida + ", idSolicitud=" + idSolicitud + ", idMaterial=" + idMaterial
				+ ", cantidadSolicitada=" + cantidadSolicitada + ", unidadMedida=" + unidadMedida + ", claveMaterial="
				+ claveMaterial + ", estatusSalida=" + estatusSalida + ", cantidadSurtida=" + cantidadSurtida
				+ ", idEmpaqueUtilizado=" + idEmpaqueUtilizado + "]";
	}
	
}
