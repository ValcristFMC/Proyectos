package com.grupocastores.empaque_embalaje.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.grupocastores.empaque_embalaje.dto.DatosMaterialSalidaDTO;
import com.grupocastores.empaque_embalaje.dto.MaterialesEyEDTO;
import com.grupocastores.empaque_embalaje.dto.ResponseDTO;
import com.grupocastores.empaque_embalaje.dto.SeguimientoSolicitudesEyEDTO;
import com.grupocastores.empaque_embalaje.dto.UnidadMedidaDTO;
import com.grupocastores.empaque_embalaje.service.IMaterialesEyEService;
import com.grupocastores.empaque_embalaje.service.ISalidaAlmacenService;
import com.grupocastores.empaque_embalaje.service.ISolicitudesEyEService;
import com.grupocastores.empaque_embalaje.service.domain.MaterialesEyE;
import com.grupocastores.empaque_embalaje.service.domain.SalidaAlmacen;
import com.grupocastores.empaque_embalaje.service.domain.SolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.domain.UnidadMedida;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/materialeseye")
@Api(value = "MaterialesEyEController", produces = "application/json")

class MaterialesEyEController {

	Logger log = LoggerFactory.getLogger(MaterialesEyEController.class);

	@Autowired
	private IMaterialesEyEService materialesEyeService;
	@Autowired
	private ISalidaAlmacenService salidaAlmacenService;
	@Autowired
	private ISolicitudesEyEService solicitudesEyeService;

	static final String HEADERBACK = "/MaterialesEyE/{id}";

	@ApiOperation(value = "Recupera Materiales de Empaque y Embalaje")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "MaterialesEyE obtenidos", response = MaterialesEyEDTO.class),
			@ApiResponse(code = 500, message = "No encontrados", response = ResponseDTO.class) })
	@GetMapping("/getMateriales")
	public Collection<?> getMateriales() {
		List<MaterialesEyEDTO> lstMaterial = new ArrayList<>();

		for (MaterialesEyE materialesEyE : materialesEyeService.getMateriales()) {
			lstMaterial.add(materialesEyE.toMaterialesEyEDTO());
		}
		return lstMaterial;
	}

	@ApiOperation(value = "Obtiene los materiales de un tipo en específico")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Materiales obtenidos", response = MaterialesEyEDTO.class),
			@ApiResponse(code = 500, message = "Materiales no encontrados", response = ResponseDTO.class) })
	@GetMapping("/getMaterialesByNombre")
	public Collection<?> getMaterialesByNombre(@RequestParam("lstMateriales") Collection<String> materiales) {
		List<MaterialesEyEDTO> lstMateriales = new ArrayList<>();

		for (MaterialesEyE materialesEyE : materialesEyeService.getMaterialesByNombre(materiales)) {
			lstMateriales.add(materialesEyE.toMaterialesEyEDTO());
		}

		return lstMateriales;
	}

	@ApiOperation(value = "Obtiene las Unidades de Medida")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Unidades obtenidas", response = UnidadMedidaDTO.class),
			@ApiResponse(code = 500, message = "Unidades no encontradas", response = ResponseDTO.class) })
	@GetMapping("/getUnidadesMedida")
	public Collection<?> getUnidadesMedida() {
		List<UnidadMedidaDTO> lstUnidades = new ArrayList<>();

		for (UnidadMedida unidad : materialesEyeService.getUnidadesMedida()) {
			lstUnidades.add(unidad.toMaterialesEyEDTO());
		}

		return lstUnidades;
	}

	@ApiOperation(value = "Listado completo de datos material salida")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Se logro mostrar el listado", response = SeguimientoSolicitudesEyEDTO.class),
			@ApiResponse(code = 500, message = "No se mostro listado", response = ResponseDTO.class) })
	@PostMapping("/getMaterialesBySolicitud")
	public Collection<?> getMaterialesBySolicitud(
			@ApiParam(value = "Registro de Seguimiento que se va a actualizar", required = true) @RequestBody @RequestParam int folio) {
		try {

			int idClaveMaterial = 0;

			SolicitudesEyE seguimiento = solicitudesEyeService.getSeguimiento(folio);
			List<SalidaAlmacen> ltsDatosSalidaMaterial = new ArrayList<>();
			List<DatosMaterialSalidaDTO> ltsDatosMaterial = new ArrayList<>();
			MaterialesEyE material = new MaterialesEyE();
			DatosMaterialSalidaDTO datos = new DatosMaterialSalidaDTO();

			ltsDatosSalidaMaterial = salidaAlmacenService.getDatosMaterialSalida(seguimiento.getIdSolicitud());
			for (int i = 0; i < ltsDatosSalidaMaterial.size(); i++) {

				idClaveMaterial = ltsDatosSalidaMaterial.get(i).getClaveMaterial();
				material = materialesEyeService.getMaterialesNombre(idClaveMaterial);

				datos.setIdSalida(ltsDatosSalidaMaterial.get(i).getIdSalida());
				datos.setIdSolicitud(ltsDatosSalidaMaterial.get(i).getIdSolicitud());
				datos.setIdMaterial(ltsDatosSalidaMaterial.get(i).getIdMaterial());
				datos.setNombreMaterial(material.getNombre());
				datos.setCantidadSolicitada(ltsDatosSalidaMaterial.get(i).getCantidadSolicitada());
				datos.setUnidadMedida(ltsDatosSalidaMaterial.get(i).getUnidadMedida());
				datos.setClaveMaterial(ltsDatosSalidaMaterial.get(i).getClaveMaterial());

				ltsDatosMaterial.add(datos);
				datos = new DatosMaterialSalidaDTO();

			}

			return ltsDatosMaterial;
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return null;
		}
	}

	@ApiOperation(value = "Convierte las cantidades de los materiales")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "MaterialesEyE obtenidos", response = MaterialesEyEDTO.class),
			@ApiResponse(code = 500, message = "No encontrados", response = ResponseDTO.class) })
	@GetMapping("/convertirCantidadMateriales")
	public int convertirCantidadMateriales(@RequestParam String nombreMaterial, @RequestParam int cantidad,
			@RequestParam String unidadMedida) {
		
		if (nombreMaterial.toLowerCase().equals("cinta canela")) {
			cantidad = unidadMedida.equals("pzas") || unidadMedida.equals("pza") ? cantidad * 150 : cantidad / 150;
		} else if (nombreMaterial.toLowerCase().equals("poliburbuja")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 120 : cantidad / 120;
		} else if (nombreMaterial.toLowerCase().equals("polipack")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 210 : cantidad / 210;
		} else if (nombreMaterial.toLowerCase().equals("fleje")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 864 : cantidad / 864;
		} else if (nombreMaterial.toLowerCase().equals("carton corrugado")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 35 : cantidad / 35;
		} else if (nombreMaterial.toLowerCase().equals("emplaye")) {
			cantidad = unidadMedida.equals("rollos") ? cantidad * 396 : cantidad / 396;
		} else if (nombreMaterial.toLowerCase().equals("sellos fleje")) {
			cantidad = unidadMedida.equals("bolsas") ? cantidad * 1000 : cantidad / 1000;
		}

		return cantidad;
	}

}