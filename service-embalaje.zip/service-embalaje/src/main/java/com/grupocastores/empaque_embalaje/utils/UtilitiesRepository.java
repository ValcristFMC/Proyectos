package com.grupocastores.empaque_embalaje.utils;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.Servidores;


@Repository
public class UtilitiesRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public static final String db13 = "PRUEBAS13";
	public static final String db23 = "PRUEBAS23";
	public static final String queryGetLinkedServerByIdOficina = 
			"SELECT * FROM syn.dbo.v_Oficinas where Oficina = \'%s\'";
	
	
	public Servidores getLinkedServerByOfice(String idOficina) {
		
		Query query = entityManager.createNativeQuery(String.format(queryGetLinkedServerByIdOficina,
				idOficina),Servidores.class
			);
		if(query.getResultList().isEmpty()) {
			return null;
		}
		return (Servidores) query.getResultList().get(0);
	}

    public static String getDb23() {
        return db23;
    }
    
    public static String getDb13() {
        return db13;
    }
    

	public Boolean executeStoredProcedure(String query) {
		int resp = 0;
		StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("PcrExecSQL");
		storedProcedure.registerStoredProcedureParameter("sql", String.class, ParameterMode.IN);
		storedProcedure.registerStoredProcedureParameter("respuesta", String.class, ParameterMode.OUT);
		storedProcedure.setParameter("sql", query);
		storedProcedure.execute();
		resp = Integer.valueOf((String) storedProcedure.getOutputParameterValue("respuesta"));
		return resp > 0 ? true : false;
	}
    
	
}
