package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.AnexoDTO;

import lombok.Data;

@Data
@Entity
public class ParametrosSistema {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idparametro;
	private int idsistema;
	private String valor;


}
