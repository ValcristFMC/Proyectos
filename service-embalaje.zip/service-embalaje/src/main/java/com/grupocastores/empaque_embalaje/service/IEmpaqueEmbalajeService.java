package com.grupocastores.empaque_embalaje.service;

import java.util.List;

import com.grupocastores.empaque_embalaje.service.domain.EmpaqueEmbalaje;

/**
 * EmpaqueEmbalaje Service, define el caso de uso del API
 *
 * @author Castores - Desarrollo TI
 *
 */
public interface IEmpaqueEmbalajeService 
{
	List<EmpaqueEmbalaje> getAll();

	EmpaqueEmbalaje save(EmpaqueEmbalaje empaqueEmbalaje);

	EmpaqueEmbalaje update(EmpaqueEmbalaje empaqueEmbalaje);

	EmpaqueEmbalaje delete(Integer id);

	EmpaqueEmbalaje changeStatus(Integer id);
}
