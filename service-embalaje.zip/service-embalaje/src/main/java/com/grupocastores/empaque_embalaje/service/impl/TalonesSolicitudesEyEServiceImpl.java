package com.grupocastores.empaque_embalaje.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.empaque_embalaje.service.ITalonesSolicitudesEyEService;
import com.grupocastores.empaque_embalaje.service.domain.CatalogoConceptoImporte;
import com.grupocastores.empaque_embalaje.service.domain.CdOrigenDestino;
import com.grupocastores.empaque_embalaje.service.domain.Co;
import com.grupocastores.empaque_embalaje.service.domain.Detatr;
import com.grupocastores.empaque_embalaje.service.domain.MetodoPago;
import com.grupocastores.empaque_embalaje.service.domain.ParametrosSistema;
import com.grupocastores.empaque_embalaje.service.domain.TalonEnviadoEye;
import com.grupocastores.empaque_embalaje.service.domain.Talones;
import com.grupocastores.empaque_embalaje.service.domain.TalonesParametros;
import com.grupocastores.empaque_embalaje.service.domain.TalonesSolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.domain.Tr;
import com.grupocastores.empaque_embalaje.service.repository.CdOrigenDestinoRepository;
import com.grupocastores.empaque_embalaje.service.repository.TalonEnviadoEyeRepository;
import com.grupocastores.empaque_embalaje.service.repository.TalonesRepository;
import com.grupocastores.empaque_embalaje.service.repository.TalonesSolicitudesEyERepository;

@Service
public class TalonesSolicitudesEyEServiceImpl implements ITalonesSolicitudesEyEService {

	@Autowired
	private TalonesSolicitudesEyERepository talonesSolicitudesEyERepository;

	@Autowired
	private TalonesRepository talonRepository;
	
	@Autowired
	private CdOrigenDestinoRepository cdOrigenDestinoRepository;
	
	@Autowired
	private TalonEnviadoEyeRepository talonEnviadoEyeRepository;

	@Override
	public List<TalonesSolicitudesEyE> getTalonesSolicitudesEyE() {
		return talonesSolicitudesEyERepository.findAll();
	}

	@Override
	public TalonesSolicitudesEyE getTalonesSolicitudesEyEById(long idTalon) {
		return talonesSolicitudesEyERepository.findById(idTalon).orElse(null);
	}
	
	@Override
	public List<TalonesSolicitudesEyE> getTalonesSolicitudByIdSolicitud(String idSolicitud) {
		return talonesSolicitudesEyERepository.getTalonesSolicitudByIdSolicitud(idSolicitud);
	}

	@Override
	public TalonesSolicitudesEyE save(TalonesSolicitudesEyE talonesSolicitudesEyE) {
		return talonesSolicitudesEyERepository.save(talonesSolicitudesEyE);
	}
	
	@Override
	public TalonEnviadoEye save(TalonEnviadoEye talonEnviado) {
		return talonEnviadoEyeRepository.save(talonEnviado);
	}

	@Override
	public TalonesSolicitudesEyE update(TalonesSolicitudesEyE talonSolicitudEyE) {
		return talonesSolicitudesEyERepository.save(talonSolicitudEyE);
	}

	@Override
	public void delete(Long idTalon) {
		talonesSolicitudesEyERepository.deleteById(idTalon);
	}

	@Override
	public Talones getTalonesByClaTalon(String claTalon) {
		return talonRepository.getTalonesByClaTalon(claTalon);
	}
	
	@Override
	public Tr getTrByClaTalon(String tabla, String claTalon) {
		return talonRepository.getTrByClaTalon(tabla, claTalon);
	}
	
	@Override
	public List<CdOrigenDestino> getCdOrigenDestino(int idCiudadOrigen, int idCiudadDestino) {
		return cdOrigenDestinoRepository.getCdOrigenDestino(idCiudadOrigen, idCiudadDestino);
	}
	
	@Override
	public TalonesParametros getTalonesParametrosByIdParametro(int idParametro) {
		return talonRepository.getTalonesParametrosByIdParametro(idParametro);
	}
	
	@Override
	public Detatr getDetatrByClaTalon(String claTalon) {
		return talonRepository.getDetatrByClaTalon(claTalon);
	}
	
	@Override
	public MetodoPago getMetodoPagoById(String idMetodoPago) {
		return talonRepository.getMetodoPagoById(idMetodoPago);
	}
	
	@Override
	public MetodoPago getMetodoPagoByClave(String idMetodoPago) {
		return talonRepository.getMetodoPagoByClave(idMetodoPago);
	}
	
	@Override
	public CatalogoConceptoImporte getCatalogoConceptoImporteByParams(String tabla, String idConcepto, String claTalon) {
		return talonRepository.getCatalogoConceptoImporteByParams(tabla, idConcepto, claTalon);
	}
	
	@Override
	public List<Co> getQueContiene(String tabla, String claTalon) {
		return talonRepository.getQueContiene(tabla, claTalon);
	}
	
	@Override
	public TalonEnviadoEye getTalonEnviadoByNumeroTalon(String numeroTalon) {
		return talonEnviadoEyeRepository.getTalonEnviadoByNumeroTalon(numeroTalon);
	}
	
	@Override
	public List<ParametrosSistema> getParametros(int idSitema, String parametros) {
		return talonRepository.getParametros(idSitema,parametros);
	}


}
