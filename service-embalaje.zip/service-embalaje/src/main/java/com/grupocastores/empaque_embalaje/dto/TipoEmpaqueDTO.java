package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de Tipos de empaque", description = "Datos de los Tipo de empaque")
public class TipoEmpaqueDTO {

	private int idTipoEmpaque;
    private int clave;
    private String nombre;
    private String descripcion;
    private int IdEstatusTipoEmpaque;
    private String fechaRegistro;
    private String fechaModificacion;
    private int idUsuarioModificacion;
    private int idSatClaveUnidad;
    
	public TipoEmpaqueDTO(int idTipoEmpaque, int clave, String nombre, String descripcion, int idEstatusTipoEmpaque,
			String fechaRegistro, String fechaModificacion, int idUsuarioModificacion, int idSatClaveUnidad) {
		this.idTipoEmpaque = idTipoEmpaque;
		this.clave = clave;
		this.nombre = nombre;
		this.descripcion = descripcion;
		IdEstatusTipoEmpaque = idEstatusTipoEmpaque;
		this.fechaRegistro = fechaRegistro;
		this.fechaModificacion = fechaModificacion;
		this.idUsuarioModificacion = idUsuarioModificacion;
		this.idSatClaveUnidad = idSatClaveUnidad;
	}

	@Override
	public String toString() {
		return "TipoEmpaqueDTO [idTipoEmpaque=" + idTipoEmpaque + ", clave=" + clave + ", nombre=" + nombre
				+ ", descripcion=" + descripcion + ", IdEstatusTipoEmpaque=" + IdEstatusTipoEmpaque + ", fechaRegistro="
				+ fechaRegistro + ", fechaModificacion=" + fechaModificacion + ", idUsuarioModificacion="
				+ idUsuarioModificacion + ", idSatClaveUnidad=" + idSatClaveUnidad + "]";
	}
	
}
