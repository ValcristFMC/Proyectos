package com.grupocastores.empaque_embalaje.service;

import com.grupocastores.empaque_embalaje.service.domain.Parametro;

public interface IParametroService {
	
	Parametro getParametroUrlToken();
	
	Parametro getParametroClienteIdToken();
	
	Parametro getParametroClientSecretToken();
	
	Parametro getParametroUserNameToken();
	
	Parametro getParametroPasswordToken();

}
