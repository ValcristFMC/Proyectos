package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion del seguimiento de las solicitudes", description = "Datos del Seguimiento")
public class SeguimientoSolicitudesEyEDTO {

	private Long idSeguimiento;
	private int idSolicitud;
	private int idPersonal;
	private int idOficina;
	private int idEstatus;
	private String fecha;
	private String hora;
	
	public SeguimientoSolicitudesEyEDTO(Long idSeguimiento, int idSolicitud, int idPersonal, int idOficina,
			int idEstatus, String fecha, String hora) {
		this.idSeguimiento = idSeguimiento;
		this.idSolicitud = idSolicitud;
		this.idPersonal = idPersonal;
		this.idOficina = idOficina;
		this.idEstatus = idEstatus;
		this.fecha = fecha;
		this.hora = hora;
	}

	@Override
	public String toString() {
		return "SeguimientoSolicitudesEyEDTO [idSeguimiento=" + idSeguimiento + ", idSolicitud=" + idSolicitud
				+ ", idPersonal=" + idPersonal + ", idOficina=" + idOficina + ", idEstatus=" + idEstatus + ", fecha="
				+ fecha + ", hora=" + hora + "]";
	}	
}
