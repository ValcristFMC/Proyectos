package com.grupocastores.empaque_embalaje.service;

import java.util.Collection;
import java.util.List;

import com.grupocastores.empaque_embalaje.service.domain.EntradaMaterial;
import com.grupocastores.empaque_embalaje.service.domain.MaterialesEyE;
import com.grupocastores.empaque_embalaje.service.domain.UnidadMedida;

public interface IMaterialesEyEService {
	
	List<MaterialesEyE> getMateriales();
	
	List<MaterialesEyE> getMaterialesByNombre(Collection<String> lstMateriales);
	
	List<UnidadMedida> getUnidadesMedida();

	MaterialesEyE save(MaterialesEyE materialesEyE);
	
	MaterialesEyE getMaterialesNombre(int idClave);

	int convertirCantidad(String nombreMaterial, int cantidad, String unidadMedida);

	int calcularCantidad (int idMaterial, int cantidad);

	String convertirUnidadMedida(int idMaterial, String unidadMedida);
	
	boolean guardarEntradaMaterial(String claveOficina, EntradaMaterial entrada);

}
