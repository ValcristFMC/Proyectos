package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un CatalogoConceptoImporteMMYYYY", description = "Datos del CatalogoConceptoImporteMMYYYY")
public class CatalogoConceptoImporteDTO {

	private int idConcepto;
	private String claTalon;
	private double importe;
	private String fechaRegistro;
	private int ajusta;
	private String conceptoAplicado;
	private double porcentajeAplicado;
	private String fechaMod;
	private String horaMod;
	
	public CatalogoConceptoImporteDTO(int idConcepto, String claTalon, double importe, String fechaRegistro, int ajusta,
			String conceptoAplicado, double porcentajeAplicado, String fechaMod, String horaMod) {
		this.idConcepto = idConcepto;
		this.claTalon = claTalon;
		this.importe = importe;
		this.fechaRegistro = fechaRegistro;
		this.ajusta = ajusta;
		this.conceptoAplicado = conceptoAplicado;
		this.porcentajeAplicado = porcentajeAplicado;
		this.fechaMod = fechaMod;
		this.horaMod = horaMod;
	}

	@Override
	public String toString() {
		return "CatalogoConceptoImporteDTO [idConcepto=" + idConcepto + ", claTalon=" + claTalon + ", importe="
				+ importe + ", fechaRegistro=" + fechaRegistro + ", ajusta=" + ajusta + ", conceptoAplicado="
				+ conceptoAplicado + ", porcentajeAplicado=" + porcentajeAplicado + ", fechaMod=" + fechaMod
				+ ", horaMod=" + horaMod + "]";
	}
	
}
