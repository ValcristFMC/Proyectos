package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un EmpaqueUtilizado", description = "Datos del EmpaqueUtilizado")
public class EmpaqueUtilizadoDTO {

	private int idEmpaqueUtilizado;
	private int idSolicitud;
	private int idTipoEmpaque;
	private int cantidad;
	private int idOficina;
	
	public EmpaqueUtilizadoDTO(int idEmpaqueUtilizado, int idSolicitud, int idEmpaque, int cantidad, int idOficina) {
		this.idEmpaqueUtilizado = idEmpaqueUtilizado;
		this.idSolicitud = idSolicitud;
		this.idTipoEmpaque = idEmpaque;
		this.cantidad = cantidad;
		this.idOficina = idOficina;
	}

	@Override
	public String toString() {
		return "EmpaqueUtilizadoDTO [idEmpaqueUtilizado=" + idEmpaqueUtilizado + ", idSolicitud=" + idSolicitud
				+ ", idTipoEmpaque=" + idTipoEmpaque + ", cantidad=" + cantidad + ", idOficina=" + idOficina + "]";
	}

}
