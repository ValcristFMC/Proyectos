package com.grupocastores.empaque_embalaje.service.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobClientBuilder;
import com.grupocastores.empaque_embalaje.dto.TalonesMaterialVentaDTO;
import com.grupocastores.empaque_embalaje.service.ISolicitudesEyEService;
import com.grupocastores.empaque_embalaje.service.domain.CantidadesMaterialPermitido;
import com.grupocastores.empaque_embalaje.service.domain.DatosSeguimiento;
import com.grupocastores.empaque_embalaje.service.domain.EmpaqueUtilizado;
import com.grupocastores.empaque_embalaje.service.domain.ParametrosSistema;
import com.grupocastores.empaque_embalaje.service.domain.ReporteSolicitudesMaterial;
import com.grupocastores.empaque_embalaje.service.domain.SolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.domain.TalonesMaterialReacondicionamiento;
import com.grupocastores.empaque_embalaje.service.domain.TalonesMaterialVenta;
import com.grupocastores.empaque_embalaje.service.domain.TipoEmpaque;
import com.grupocastores.empaque_embalaje.service.repository.CantidadesMaterialPermitidoRepository;
import com.grupocastores.empaque_embalaje.service.repository.DatosSeguimientoRepository;
import com.grupocastores.empaque_embalaje.service.repository.EmpaqueUtilizadoRepository;
import com.grupocastores.empaque_embalaje.service.repository.ReporteSolicitudesMaterialRepository;
import com.grupocastores.empaque_embalaje.service.repository.SolicitudesEyERepository;
import com.grupocastores.empaque_embalaje.service.repository.TalonesMaterialReacondicionamientoRepository;
import com.grupocastores.empaque_embalaje.service.repository.TalonesMaterialVentaRepository;
import com.grupocastores.empaque_embalaje.service.repository.TalonesRepository;
import com.grupocastores.empaque_embalaje.service.repository.TipoEmpaqueRepository;
import com.microsoft.azure.storage.StorageException;

@Service
public class SolicitudesEyEServiceImpl implements ISolicitudesEyEService {

	@Autowired
	private SolicitudesEyERepository solicitudesEyERepository;

	@Autowired
	private ReporteSolicitudesMaterialRepository reporteSolicitudesMaterialRepository;

	@Autowired
	private DatosSeguimientoRepository datosSeguimientoRepository;

	@Autowired
	private TalonesMaterialVentaRepository talonesMaterialVentaRepository;

	@Autowired
	private TalonesMaterialReacondicionamientoRepository talonesMaterialReacondicionamientoRepository;

	@Autowired
	private TipoEmpaqueRepository tipoEmpaqueRepository;

	@Autowired
	private EmpaqueUtilizadoRepository empaqueUtilizadoRepository;

	@Autowired
	private CantidadesMaterialPermitidoRepository cantidadesMaterialPermitidoRepository;

	@Autowired
	private TalonesRepository talonesRepository;

	@Override
	public List<SolicitudesEyE> getSolicitudes() {
		return solicitudesEyERepository.findAll();
	}

	@Override
	public SolicitudesEyE getSolicitudById(Long idSolicitud) {
		return solicitudesEyERepository.findById(idSolicitud).orElse(null);
	}

	@Override
	public int getUltimoIdSolicitud() {
		return solicitudesEyERepository.getUltimoIdSolicitud();
	}

	@Override
	public List<ReporteSolicitudesMaterial> getReporteSolicitudesMaterial(int idOficina) {
		return reporteSolicitudesMaterialRepository.getReporteSolicitudesMaterial(idOficina);
	}

	@Override
	public List<ReporteSolicitudesMaterial> getReporteSolicitudesByFecha(String fechaInicio, String fechaFin, int idOficina) {

		return reporteSolicitudesMaterialRepository.getReporteSolicitudesByFecha(fechaInicio, fechaFin, idOficina);
	}

	@Override
	public List<DatosSeguimiento> getDatosSegimientoByIdSolictud(Long idSolicitud) {
		return datosSeguimientoRepository.getDatosSegimientoByIdSolictud(idSolicitud);
	}

	@Override
	public List<TalonesMaterialVenta> getTalonesMaterialVenta(String idSolicitud) {
		return talonesMaterialVentaRepository.getTalonesMaterialVenta(idSolicitud);
	}
	
	@Override
	public List<TalonesMaterialVentaDTO> getTalonesMaterialReacondicionamientoSeguimiento(String idSolicitud) {
	    List<TalonesMaterialVenta> talones = talonesMaterialVentaRepository.getTalonesMaterialVenta(idSolicitud);

	    Map<Long, TalonesMaterialVentaDTO> talonesAgrupadosMap = talones.stream()
	        .map(TalonesMaterialVenta::toTalonMaterialVentaDTO) 
	        .collect(Collectors.toMap(
	            TalonesMaterialVentaDTO::getIdMaterial,
	            Function.identity(),
	            (existing, replacement) -> {
	                existing.setCantidadSolicitada(existing.getCantidadSolicitada() + replacement.getCantidadSolicitada());
	                return existing;
	            }
	        ));

	    return new ArrayList<>(talonesAgrupadosMap.values());
	}

	@Override
	public List<TalonesMaterialReacondicionamiento> getTalonesMaterialReacondicionamiento(String idSolicitud) {
		return talonesMaterialReacondicionamientoRepository.getTalonesMaterialReacondicionamiento(idSolicitud);
	}

	@Override
	public SolicitudesEyE save(SolicitudesEyE solicitudesEyE) {
		return solicitudesEyERepository.save(solicitudesEyE);
	}

	@Override
	public SolicitudesEyE update(SolicitudesEyE solicitudEyE) {
		return solicitudesEyERepository.save(solicitudEyE);
	}

	@Override
	public SolicitudesEyE getSolicitudPendienteDeEnviar(String idOficina) {
		SolicitudesEyE solicitud = solicitudesEyERepository.getSolicitudPendienteDeEnviar(idOficina);

		if (solicitud == null) {
			solicitud = new SolicitudesEyE();
		}

		return solicitud;
	}

	@Override
	public List<TipoEmpaque> getTipoEmpaque() {
		return tipoEmpaqueRepository.findAll(Sort.by(Sort.Direction.ASC, "nombre"));
	}

	@Override
	public EmpaqueUtilizado guardarEmpaqueUtilizado(EmpaqueUtilizado empaque) {
		return empaqueUtilizadoRepository.save(empaque);
	}

	@Override
	public CantidadesMaterialPermitido getCantidadMaterialPermitido(int idMaterial, int idTipoEmpaque) {
		return cantidadesMaterialPermitidoRepository.getCantidadMaterialPermitido(idMaterial, idTipoEmpaque);
	}

	@Override
	public List<EmpaqueUtilizado> getEmpaquesUtilizados(int idSolicitud, int idOficina) {
		return empaqueUtilizadoRepository.getEmpaquesUtilizados(idSolicitud, idOficina);
	}

	@Override
	public EmpaqueUtilizado actualizarEmpaqueUtilizado(EmpaqueUtilizado empaqueUtilizado) {
		return empaqueUtilizadoRepository.save(empaqueUtilizado);
	}

	@Override
	public SolicitudesEyE getSeguimiento(int folio) {
		return solicitudesEyERepository.getSeguimiento(folio);
	}

	public String uplooadFileAzureStorage(String nameFile, InputStream fileStream)
			throws IOException, StorageException, URISyntaxException {
		String urlCloud = "";

		int idSitema = 999;
		String parametros = ("43,44,45,46");
		List<ParametrosSistema> lstParamentro = talonesRepository.getParametros(idSitema, parametros);

		String connectionString = "DefaultEndpointsProtocol=" + lstParamentro.get(0).getValor() + ";" + "AccountName="
				+ lstParamentro.get(1).getValor() + ";" + "AccountKey=" + lstParamentro.get(2).getValor();

		BlobClient blobClient = new BlobClientBuilder().connectionString(connectionString)
				.containerName(lstParamentro.get(3).getValor()).blobName(nameFile).buildClient();

		blobClient.upload(fileStream, fileStream.available(), true);
		urlCloud = blobClient.getBlobUrl();
		return  urlCloud;

	}
	
	
	@Override
	public List<ReporteSolicitudesMaterial> getReporteSolicitudesMaterialCorporativo() {
		return reporteSolicitudesMaterialRepository.getReporteSolicitudesMaterialCorporativo();
	}

	@Override
	public List<ReporteSolicitudesMaterial> getReporteSolicitudesByFechaCorporativo(String fechaInicio, String fechaFin) {

		return reporteSolicitudesMaterialRepository.getReporteSolicitudesByFechaCorporativo(fechaInicio, fechaFin);
	}
	
	@Override
	public List<ReporteSolicitudesMaterial> getReporteSolicitudesAutorizadasSolidaParcial() {

		return reporteSolicitudesMaterialRepository.getReporteSolicitudesAutorizadasSolidaParcial();
	}
	


}
