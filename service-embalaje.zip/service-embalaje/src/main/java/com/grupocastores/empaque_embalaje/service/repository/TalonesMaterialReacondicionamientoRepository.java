package com.grupocastores.empaque_embalaje.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.TalonesMaterialReacondicionamiento;

@Repository
public interface TalonesMaterialReacondicionamientoRepository extends JpaRepository<TalonesMaterialReacondicionamiento, Long> {

	static final String QUERY_TAOLONES_MATERIAL_REACONDICIONAMIENTO = "SELECT t.id_talon, t.numero_talon, sa.id_solicitud, sa.id_salida, Nombre_material = 'material', "
			+ "sa.id_material, sa.cantidad_solicitada, sa.unidad_medida, sa.clave_material, sa.id_empaque_utilizado "
			+ "FROM salida_almacen_eye AS sa "
			+ "JOIN talones_solicitudes_eye AS t ON t.id_solicitud = sa.id_solicitud AND t.id_salida = sa.id_salida "
			+ "WHERE sa.id_solicitud = :idSolicitud";

	@Query(value = QUERY_TAOLONES_MATERIAL_REACONDICIONAMIENTO, nativeQuery = true)
	List<TalonesMaterialReacondicionamiento> getTalonesMaterialReacondicionamiento(String idSolicitud);
}
