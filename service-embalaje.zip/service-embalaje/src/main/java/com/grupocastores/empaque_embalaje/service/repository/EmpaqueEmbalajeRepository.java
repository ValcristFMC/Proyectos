package com.grupocastores.empaque_embalaje.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.EmpaqueEmbalaje;

/**
 * EmpaqueEmbalajeRepository Repositorio para el almacenamiento de {@link com.grupocastores.empaque_embalaje.service.domain.EmpaqueEmbalaje} 
 *
 * @author Castores - Desarrollo TI
 *
 */
@Repository
public interface EmpaqueEmbalajeRepository  extends JpaRepository<EmpaqueEmbalaje, Integer> 
{
	List<EmpaqueEmbalaje> findByDescription(boolean description);
}
