package com.grupocastores.empaque_embalaje.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.SalidaAlmacen;


@Repository
public interface SalidaAlmacenRepository extends JpaRepository<SalidaAlmacen, Long> {
	

	static final String QUERY_GET_DATOS_SALIDA = "SELECT * FROM salida_almacen_eye WHERE Id_solicitud= :idSolicitud";
	
	@Query(value = QUERY_GET_DATOS_SALIDA, nativeQuery = true)
	List<SalidaAlmacen> getDatosMaterialSalida(Long idSolicitud);

}
