package com.grupocastores.empaque_embalaje.service;

import java.util.List;

import com.grupocastores.empaque_embalaje.dto.SeguimientoDTO;
import com.grupocastores.empaque_embalaje.service.domain.SeguimientoSolicitudesEyE;

public interface ISeguimientoSolicitudesEyEService {

	List<SeguimientoSolicitudesEyE> getAll();

	SeguimientoSolicitudesEyE save(SeguimientoSolicitudesEyE seguimiento);
	
	SeguimientoDTO consultarSeguimientoSap(Integer folio);
	
	SeguimientoDTO consultarSeguimientosSap(Integer folio);
	
	int getSemaforo(int idSistema, int idModulo);
	
	void updateSemaforo(int idSistema, int idModulo, int semaforo);

}
