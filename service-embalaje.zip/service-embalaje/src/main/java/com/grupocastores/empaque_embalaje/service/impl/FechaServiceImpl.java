package com.grupocastores.empaque_embalaje.service.impl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class FechaServiceImpl {
	
	public static String getFechaActual() {
		try {
			LocalDate fechaActual = LocalDate.now();
	        DateTimeFormatter fechaFormateada = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	        String strFecha = fechaActual.format(fechaFormateada);	
	        return strFecha;
		} catch (Exception e) {
			return "";
		}				
	}
	
	public static String getHoraActual() {
	    try {
	        LocalTime horaActual = LocalTime.now();
	        DateTimeFormatter horaFormateada = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");
	        return horaActual.format(horaFormateada);
	    } catch (Exception e) {
	        return "";
	    }
	}

}
