package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.DetatrDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "detatr")
@EntityListeners(Detatr.class)
public class Detatr {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cla_talon")
	private String claTalon;

	@Column(name = "idpersonalcotiza")
	private int idPersonalCotiza;

	@Column(name = "idpersonalrecibe")
	private int idPersonalRecibe;

	@Column(name = "porcentaje")
	private double porcentaje;

	@Column(name = "importeporcentaje")
	private double importePorcentaje;

	@Column(name = "idcotizacion")
	private String idCotizacion;

	@Column(name = "fechacita")
	private String fechaCita;

	@Column(name = "motivocancelacion")
	private int motivoCancelacion;

	@Column(name = "metodopago")
	private String metodoPago;

	@Column(name = "nocuentapago")
	private String noCuentaPago;

	@Column(name = "materialpeligroso")
	private int materialPeligroso;

	@Column(name = "tiposeguro")
	private int tipoSeguro;

	@Column(name = "moduloelaboracion")
	private int moduloElaboracion;

	@Column(name = "km")
	private double km;

	@Column(name = "idtiporecorrido")
	private int idTipoRecorrido;

	@Column(name = "kmtiporecorrido")
	private double kmTipoRecorrido;

	@Column(name = "facturado")
	private int facturado;

	@Column(name = "porcquimico")
	private double porcQuimico;

	@Column(name = "etiseguro")
	private String etiSeguro;

	@Column(name = "idseguro")
	private int idSeguro;

	@Column(name = "tiposervicio")
	private int tipoServicio;

	@Column(name = "idtipomaniobra")
	private int idTipoManiobra;

	@Column(name = "viajepasaliquidar")
	private int viajePasaLiquidar;

	@Column(name = "especificacionescarga")
	private String especificacionesCarga;

	@Column(name = "horariopaqueteria")
	private String horarioPaqueteria;

	@Column(name = "horariocompleto")
	private String horarioCompleto;

	@Column(name = "condicionesespeciales")
	private String condicionesEspeciales;

	@Column(name = "polizacautivo")
	private String polizaCautivo;

	@Column(name = "obsmaniobras")
	private String obsManiobras;

	@Column(name = "otrosdatos")
	private String otrosDatos;

	@Column(name = "coloniazonificacion")
	private String coloniaZonificacion;

	@Column(name = "cpzonificacion")
	private String cpZonificacion;

	@Column(name = "serviciotalon")
	private int servicioTalon;

	@Column(name = "remision_electronica")
	private String remisionElectronica;

	@Column(name = "etiiva")
	private String etiIva;

	public static Detatr fromDetatrDTO(DetatrDTO detatrDTO) {
		Detatr detatr = new Detatr();
		detatr.setClaTalon(detatrDTO.getClaTalon());
		detatr.setIdPersonalCotiza(detatrDTO.getIdPersonalCotiza());
		detatr.setIdPersonalRecibe(detatrDTO.getIdPersonalRecibe());
		detatr.setPorcentaje(detatrDTO.getPorcentaje());
		detatr.setImportePorcentaje(detatrDTO.getImportePorcentaje());
		detatr.setIdCotizacion(detatrDTO.getIdCotizacion());
		detatr.setFechaCita(detatrDTO.getFechaCita());
		detatr.setMotivoCancelacion(detatrDTO.getMotivoCancelacion());
		detatr.setMetodoPago(detatrDTO.getMetodoPago());
		detatr.setNoCuentaPago(detatrDTO.getNoCuentaPago());
		detatr.setMaterialPeligroso(detatrDTO.getMaterialPeligroso());
		detatr.setTipoSeguro(detatrDTO.getTipoSeguro());
		detatr.setModuloElaboracion(detatrDTO.getModuloElaboracion());
		detatr.setKm(detatrDTO.getKm());
		detatr.setIdTipoRecorrido(detatrDTO.getIdTipoRecorrido());
		detatr.setKmTipoRecorrido(detatrDTO.getKmTipoRecorrido());
		detatr.setFacturado(detatrDTO.getFacturado());
		detatr.setPorcQuimico(detatrDTO.getPorcQuimico());
		detatr.setEtiSeguro(detatrDTO.getEtiSeguro());
		detatr.setIdSeguro(detatrDTO.getIdSeguro());
		detatr.setTipoServicio(detatrDTO.getTipoServicio());
		detatr.setIdTipoManiobra(detatrDTO.getIdTipoManiobra());
		detatr.setViajePasaLiquidar(detatrDTO.getViajePasaLiquidar());
		detatr.setEspecificacionesCarga(detatrDTO.getEspecificacionesCarga());
		detatr.setHorarioPaqueteria(detatrDTO.getHorarioPaqueteria());
		detatr.setHorarioCompleto(detatrDTO.getHorarioCompleto());
		detatr.setCondicionesEspeciales(detatrDTO.getCondicionesEspeciales());
		detatr.setPolizaCautivo(detatrDTO.getPolizaCautivo());
		detatr.setObsManiobras(detatrDTO.getObsManiobras());
		detatr.setOtrosDatos(detatrDTO.getOtrosDatos());
		detatr.setColoniaZonificacion(detatrDTO.getColoniaZonificacion());
		detatr.setCpZonificacion(detatrDTO.getCpZonificacion());
		detatr.setServicioTalon(detatrDTO.getServicioTalon());
		detatr.setRemisionElectronica(detatrDTO.getRemisionElectronica());
		detatr.setEtiIva(detatrDTO.getEtiIva());
		return detatr;
	}

	public DetatrDTO toDetatrDTO() {
		DetatrDTO detatrDTO = new DetatrDTO();
		detatrDTO.setClaTalon(this.getClaTalon());
		detatrDTO.setIdPersonalCotiza(this.getIdPersonalCotiza());
		detatrDTO.setIdPersonalRecibe(this.getIdPersonalRecibe());
		detatrDTO.setPorcentaje(this.getPorcentaje());
		detatrDTO.setImportePorcentaje(this.getImportePorcentaje());
		detatrDTO.setIdCotizacion(this.getIdCotizacion());
		detatrDTO.setFechaCita(this.getFechaCita());
		detatrDTO.setMotivoCancelacion(this.getMotivoCancelacion());
		detatrDTO.setMetodoPago(this.getMetodoPago());
		detatrDTO.setNoCuentaPago(this.getNoCuentaPago());
		detatrDTO.setMaterialPeligroso(this.getMaterialPeligroso());
		detatrDTO.setTipoSeguro(this.getTipoSeguro());
		detatrDTO.setModuloElaboracion(this.getModuloElaboracion());
		detatrDTO.setKm(this.getKm());
		detatrDTO.setIdTipoRecorrido(this.getIdTipoRecorrido());
		detatrDTO.setKmTipoRecorrido(this.getKmTipoRecorrido());
		detatrDTO.setFacturado(this.getFacturado());
		detatrDTO.setPorcQuimico(this.getPorcQuimico());
		detatrDTO.setEtiSeguro(this.getEtiSeguro());
		detatrDTO.setIdSeguro(this.getIdSeguro());
		detatrDTO.setTipoServicio(this.getTipoServicio());
		detatrDTO.setIdTipoManiobra(this.getIdTipoManiobra());
		detatrDTO.setViajePasaLiquidar(this.getViajePasaLiquidar());
		detatrDTO.setEspecificacionesCarga(this.getEspecificacionesCarga());
		detatrDTO.setHorarioPaqueteria(this.getHorarioPaqueteria());
		detatrDTO.setHorarioCompleto(this.getHorarioCompleto());
		detatrDTO.setCondicionesEspeciales(this.getCondicionesEspeciales());
		detatrDTO.setPolizaCautivo(this.getPolizaCautivo());
		detatrDTO.setObsManiobras(this.getObsManiobras());
		detatrDTO.setOtrosDatos(this.getOtrosDatos());
		detatrDTO.setColoniaZonificacion(this.getColoniaZonificacion());
		detatrDTO.setCpZonificacion(this.getCpZonificacion());
		detatrDTO.setServicioTalon(this.getServicioTalon());
		detatrDTO.setRemisionElectronica(this.getRemisionElectronica());
		detatrDTO.setEtiIva(this.getEtiIva());
		return detatrDTO;
	}

}
