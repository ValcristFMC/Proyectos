package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.CatalogoConceptoImporteDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(CatalogoConceptoImporte.class)
public class CatalogoConceptoImporte {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idconcepto")
	private int idConcepto;
	
	@Column(name = "cla_talon")
	private String claTalon;
	
	@Column(name = "importe")
	private double importe;
	
	@Column(name = "fecha_registro")
	private String fechaRegistro;
	
	@Column(name = "ajusta")
	private int ajusta;
	
	@Column(name = "concepto_aplicado")
	private String conceptoAplicado;
	
	@Column(name = "porcentaje_aplicado")
	private double porcentajeAplicado;
	
	@Column(name = "fechamod")
	private String fechaMod;
	
	@Column(name = "horamod")
	private String horaMod;
	
	public static CatalogoConceptoImporte fromCatalogoConceptoImporteDTO(CatalogoConceptoImporteDTO catalogoConceptoImporteDTO) {
	    CatalogoConceptoImporte catalogoConceptoImporte = new CatalogoConceptoImporte();
	    catalogoConceptoImporte.setIdConcepto(catalogoConceptoImporteDTO.getIdConcepto());
	    catalogoConceptoImporte.setClaTalon(catalogoConceptoImporteDTO.getClaTalon());
	    catalogoConceptoImporte.setImporte(catalogoConceptoImporteDTO.getImporte());
	    catalogoConceptoImporte.setFechaRegistro(catalogoConceptoImporteDTO.getFechaRegistro());
	    catalogoConceptoImporte.setAjusta(catalogoConceptoImporteDTO.getAjusta());
	    catalogoConceptoImporte.setConceptoAplicado(catalogoConceptoImporteDTO.getConceptoAplicado());
	    catalogoConceptoImporte.setPorcentajeAplicado(catalogoConceptoImporteDTO.getPorcentajeAplicado());
	    catalogoConceptoImporte.setFechaMod(catalogoConceptoImporteDTO.getFechaMod());
	    catalogoConceptoImporte.setHoraMod(catalogoConceptoImporteDTO.getHoraMod());
	    return catalogoConceptoImporte;
	}

	public CatalogoConceptoImporteDTO toCatalogoConceptoImporteDTO() {
	    CatalogoConceptoImporteDTO catalogoConceptoImporteDTO = new CatalogoConceptoImporteDTO();
	    catalogoConceptoImporteDTO.setIdConcepto(this.getIdConcepto());
	    catalogoConceptoImporteDTO.setClaTalon(this.getClaTalon());
	    catalogoConceptoImporteDTO.setImporte(this.getImporte());
	    catalogoConceptoImporteDTO.setFechaRegistro(this.getFechaRegistro());
	    catalogoConceptoImporteDTO.setAjusta(this.getAjusta());
	    catalogoConceptoImporteDTO.setConceptoAplicado(this.getConceptoAplicado());
	    catalogoConceptoImporteDTO.setPorcentajeAplicado(this.getPorcentajeAplicado());
	    catalogoConceptoImporteDTO.setFechaMod(this.getFechaMod());
	    catalogoConceptoImporteDTO.setHoraMod(this.getHoraMod());
	    return catalogoConceptoImporteDTO;
	}

}
