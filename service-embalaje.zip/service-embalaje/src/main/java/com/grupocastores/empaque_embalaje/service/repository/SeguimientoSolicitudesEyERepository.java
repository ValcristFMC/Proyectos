package com.grupocastores.empaque_embalaje.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import com.grupocastores.empaque_embalaje.service.domain.SeguimientoSolicitudesEyE;


@Repository
public interface SeguimientoSolicitudesEyERepository extends JpaRepository<SeguimientoSolicitudesEyE, Long> {
	
	static final String QUERY_SEMAFORO = "SELECT id_estatus FROM semaforo s WHERE id_sistema= :idSistema AND id_modulo = :idModulo";
	static final String QUERY_UPDATE_SEMAFORO = "UPDATE semaforo SET id_estatus = :semaforo WHERE id_sistema = :idSistema AND id_modulo = :idModulo";
	
	@Query(value = QUERY_SEMAFORO, nativeQuery = true)
	int getSemaforo(int idSistema, int idModulo);	

	 @Modifying
	 @Transactional
	 @Query(value = QUERY_UPDATE_SEMAFORO, nativeQuery = true)
	 void updateSemaforo(int idSistema, int idModulo, int semaforo);


}