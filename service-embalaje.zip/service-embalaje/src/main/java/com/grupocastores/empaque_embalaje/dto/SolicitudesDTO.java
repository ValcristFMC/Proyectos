package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de las solicitudes", description = "Datos de las solicitudes")
public class SolicitudesDTO {

	private Long idSolicitud;
	private int folio;
	private int idPersonal;
	private int idOficina;
	private int idEstatus;
	private String anexo;
	private String observaciones;
	private String motivoRechazo;
	private String tipoSolicitud;
	private String fecha;
	private String hora;
	
	public SolicitudesDTO(Long idSolicitud, int folio, int idPersonal, int idOficina, int idEstatus, String anexo,
			String observaciones, String motivoRechazo, String tipoSolicitud, String fecha, String hora) {
		this.idSolicitud = idSolicitud;
		this.folio = folio;
		this.idPersonal = idPersonal;
		this.idOficina = idOficina;
		this.idEstatus = idEstatus;
		this.anexo = anexo;
		this.observaciones = observaciones;
		this.motivoRechazo = motivoRechazo;
		this.tipoSolicitud = tipoSolicitud;
		this.fecha = fecha;
		this.hora = hora;
	}

	@Override
	public String toString() {
		return "SolicitudesDTO [idSolicitud=" + idSolicitud + ", folio=" + folio + ", idPersonal=" + idPersonal
				+ ", idOficina=" + idOficina + ", idEstatus=" + idEstatus + ", anexo=" + anexo + ", observaciones="
				+ observaciones + ", motivoRechazo=" + motivoRechazo + ", tipoSolicitud=" + tipoSolicitud + ", fecha="
				+ fecha + ", hora=" + hora + "]";
	}
	
}
