package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.MaterialesEyEDTO;

import lombok.Data;

@Entity
@Data
@Table(name = "materiales_eye")
@EntityListeners(MaterialesEyE.class)
public class MaterialesEyE {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idmaterial")
    private Long idMaterial;
	
	@Column(name = "clavematerial")
	private int claveMaterial;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "idunidadmedida")
    private int idUnidadMedida;

    @Column(name = "preciocompra")
    private double precioCompra;

    @Column(name = "precioventa")
    private double precioVenta;

    @Column(name = "idpersonal")
    private int idPersonal;

    @Column(name = "fechamod")
    private String fechaMod;

    @Column(name = "horamod")
    private String horaMod;

    @Column(name = "estatus")
    private int estatus;

    @Column(name = "medidacompras")
    private double medidaCompras;

    @Column(name = "medidaconversion")
    private double medidaConversion;

    @Column(name = "validaexistencia")
    private int validaExistencia;
    
    public static MaterialesEyE fromMaterialesEyEDTO(MaterialesEyEDTO materialesEyEDTO) {
        MaterialesEyE materialesEyE = new MaterialesEyE();
        materialesEyE.setIdMaterial(materialesEyEDTO.getIdMaterial());
        materialesEyE.setClaveMaterial(materialesEyEDTO.getClaveMaterial());
        materialesEyE.setNombre(materialesEyEDTO.getNombre());
        materialesEyE.setDescripcion(materialesEyEDTO.getDescripcion());
        materialesEyE.setIdUnidadMedida(materialesEyEDTO.getIdUnidadMedida());
        materialesEyE.setPrecioCompra(materialesEyEDTO.getPrecioCompra());
        materialesEyE.setPrecioVenta(materialesEyEDTO.getPrecioVenta());
        materialesEyE.setIdPersonal(materialesEyEDTO.getIdPersonal());
        materialesEyE.setFechaMod(materialesEyEDTO.getFechaMod());
        materialesEyE.setHoraMod(materialesEyEDTO.getHoraMod());
        materialesEyE.setEstatus(materialesEyEDTO.getEstatus());
        materialesEyE.setMedidaCompras(materialesEyEDTO.getMedidaCompras());
        materialesEyE.setMedidaConversion(materialesEyEDTO.getMedidaConversion());
        materialesEyE.setValidaExistencia(materialesEyEDTO.getValidaExistencia());
        return materialesEyE;
    }

    public MaterialesEyEDTO toMaterialesEyEDTO() {
        MaterialesEyEDTO materialesEyEDTO = new MaterialesEyEDTO();
        materialesEyEDTO.setIdMaterial(this.getIdMaterial());
        materialesEyEDTO.setClaveMaterial(this.getClaveMaterial());
        materialesEyEDTO.setNombre(this.getNombre());
        materialesEyEDTO.setDescripcion(this.getDescripcion());
        materialesEyEDTO.setIdUnidadMedida(this.getIdUnidadMedida());
        materialesEyEDTO.setPrecioCompra(this.getPrecioCompra());
        materialesEyEDTO.setPrecioVenta(this.getPrecioVenta());
        materialesEyEDTO.setIdPersonal(this.getIdPersonal());
        materialesEyEDTO.setFechaMod(this.getFechaMod());
        materialesEyEDTO.setHoraMod(this.getHoraMod());
        materialesEyEDTO.setEstatus(this.getEstatus());
        materialesEyEDTO.setMedidaCompras(this.getMedidaCompras());
        materialesEyEDTO.setMedidaConversion(this.getMedidaConversion());
        materialesEyEDTO.setValidaExistencia(this.getValidaExistencia());
        return materialesEyEDTO;
    }
}
