package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un Detatr", description = "Datos del Detatr")
public class DetatrDTO {
	private String claTalon;
	private int idPersonalCotiza;
	private int idPersonalRecibe;
	private double porcentaje;
	private double importePorcentaje;
	private String idCotizacion;
	private String fechaCita;
	private int motivoCancelacion;
	private String metodoPago;
	private String noCuentaPago;
	private int materialPeligroso;
	private int tipoSeguro;
	private int moduloElaboracion;
	private double km;
	private int idTipoRecorrido;
	private double kmTipoRecorrido;
	private int facturado;
	private double porcQuimico;
	private String etiSeguro;
	private int idSeguro;
	private int tipoServicio;
	private int idTipoManiobra;
	private int viajePasaLiquidar;
	private String especificacionesCarga;
	private String horarioPaqueteria;
	private String horarioCompleto;
	private String condicionesEspeciales;
	private String polizaCautivo;
	private String obsManiobras;
	private String otrosDatos;
	private String coloniaZonificacion;
	private String cpZonificacion;
	private int servicioTalon;
	private String remisionElectronica;
	private String etiIva;
	
	public DetatrDTO(String claTalon, int idPersonalCotiza, int idPersonalRecibe, double porcentaje,
			double importePorcentaje, String idCotizacion, String fechaCita, int motivoCancelacion, String metodoPago,
			String noCuentaPago, int materialPeligroso, int tipoSeguro, int moduloElaboracion, double km,
			int idTipoRecorrido, double kmTipoRecorrido, int facturado, double porcQuimico, String etiSeguro,
			int idSeguro, int tipoServicio, int idTipoManiobra, int viajePasaLiquidar, String especificacionesCarga,
			String horarioPaqueteria, String horarioCompleto, String condicionesEspeciales, String polizaCautivo,
			String obsManiobras, String otrosDatos, String coloniaZonificacion, String cpZonificacion,
			int servicioTalon, String remisionElectronica, String etiIva) {
		this.claTalon = claTalon;
		this.idPersonalCotiza = idPersonalCotiza;
		this.idPersonalRecibe = idPersonalRecibe;
		this.porcentaje = porcentaje;
		this.importePorcentaje = importePorcentaje;
		this.idCotizacion = idCotizacion;
		this.fechaCita = fechaCita;
		this.motivoCancelacion = motivoCancelacion;
		this.metodoPago = metodoPago;
		this.noCuentaPago = noCuentaPago;
		this.materialPeligroso = materialPeligroso;
		this.tipoSeguro = tipoSeguro;
		this.moduloElaboracion = moduloElaboracion;
		this.km = km;
		this.idTipoRecorrido = idTipoRecorrido;
		this.kmTipoRecorrido = kmTipoRecorrido;
		this.facturado = facturado;
		this.porcQuimico = porcQuimico;
		this.etiSeguro = etiSeguro;
		this.idSeguro = idSeguro;
		this.tipoServicio = tipoServicio;
		this.idTipoManiobra = idTipoManiobra;
		this.viajePasaLiquidar = viajePasaLiquidar;
		this.especificacionesCarga = especificacionesCarga;
		this.horarioPaqueteria = horarioPaqueteria;
		this.horarioCompleto = horarioCompleto;
		this.condicionesEspeciales = condicionesEspeciales;
		this.polizaCautivo = polizaCautivo;
		this.obsManiobras = obsManiobras;
		this.otrosDatos = otrosDatos;
		this.coloniaZonificacion = coloniaZonificacion;
		this.cpZonificacion = cpZonificacion;
		this.servicioTalon = servicioTalon;
		this.remisionElectronica = remisionElectronica;
		this.etiIva = etiIva;
	}

	@Override
	public String toString() {
		return "DetatrDTO [claTalon=" + claTalon + ", idPersonalCotiza=" + idPersonalCotiza + ", idPersonalRecibe="
				+ idPersonalRecibe + ", porcentaje=" + porcentaje + ", importePorcentaje=" + importePorcentaje
				+ ", idCotizacion=" + idCotizacion + ", fechaCita=" + fechaCita + ", motivoCancelacion="
				+ motivoCancelacion + ", metodoPago=" + metodoPago + ", noCuentaPago=" + noCuentaPago
				+ ", materialPeligroso=" + materialPeligroso + ", tipoSeguro=" + tipoSeguro + ", moduloElaboracion="
				+ moduloElaboracion + ", km=" + km + ", idTipoRecorrido=" + idTipoRecorrido + ", kmTipoRecorrido="
				+ kmTipoRecorrido + ", facturado=" + facturado + ", porcQuimico=" + porcQuimico + ", etiSeguro="
				+ etiSeguro + ", idSeguro=" + idSeguro + ", tipoServicio=" + tipoServicio + ", idTipoManiobra="
				+ idTipoManiobra + ", viajePasaLiquidar=" + viajePasaLiquidar + ", especificacionesCarga="
				+ especificacionesCarga + ", horarioPaqueteria=" + horarioPaqueteria + ", horarioCompleto="
				+ horarioCompleto + ", condicionesEspeciales=" + condicionesEspeciales + ", polizaCautivo="
				+ polizaCautivo + ", obsManiobras=" + obsManiobras + ", otrosDatos=" + otrosDatos
				+ ", coloniaZonificacion=" + coloniaZonificacion + ", cpZonificacion=" + cpZonificacion
				+ ", servicioTalon=" + servicioTalon + ", remisionElectronica=" + remisionElectronica + ", etiIva="
				+ etiIva + "]";
	}
	
}
