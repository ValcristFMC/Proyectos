package com.grupocastores.empaque_embalaje.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.grupocastores.empaque_embalaje.dto.TalonesMaterialVentaDTO;
import com.grupocastores.empaque_embalaje.service.domain.Anexo;
import com.grupocastores.empaque_embalaje.service.domain.CantidadesMaterialPermitido;
import com.grupocastores.empaque_embalaje.service.domain.DatosSeguimiento;
import com.grupocastores.empaque_embalaje.service.domain.EmpaqueUtilizado;
import com.grupocastores.empaque_embalaje.service.domain.ReporteSolicitudesMaterial;
import com.grupocastores.empaque_embalaje.service.domain.SolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.domain.TalonesMaterialReacondicionamiento;
import com.grupocastores.empaque_embalaje.service.domain.TalonesMaterialVenta;
import com.grupocastores.empaque_embalaje.service.domain.TipoEmpaque;
import com.microsoft.azure.storage.StorageException;

public interface ISolicitudesEyEService {

	List<SolicitudesEyE> getSolicitudes();

	SolicitudesEyE getSolicitudById(Long idSolicitud);

	int getUltimoIdSolicitud();

	List<ReporteSolicitudesMaterial> getReporteSolicitudesMaterial(int idOficina);

	List<ReporteSolicitudesMaterial> getReporteSolicitudesByFecha(String fechaInicio, String fechaFin, int idOficina);

	List<DatosSeguimiento> getDatosSegimientoByIdSolictud(Long idSolicitud);

	List<TalonesMaterialVenta> getTalonesMaterialVenta(String idSolicitud);
	
	List<TalonesMaterialVentaDTO> getTalonesMaterialReacondicionamientoSeguimiento(String idSolicitud);

	List<TalonesMaterialReacondicionamiento> getTalonesMaterialReacondicionamiento(String idSolicitud);

	SolicitudesEyE getSolicitudPendienteDeEnviar(String idOficina);

	SolicitudesEyE save(SolicitudesEyE solicitudesEyE);

	SolicitudesEyE update(SolicitudesEyE solicitudesEyE);

	List<TipoEmpaque> getTipoEmpaque();

	EmpaqueUtilizado guardarEmpaqueUtilizado(EmpaqueUtilizado empaqueUtilizado);

	CantidadesMaterialPermitido getCantidadMaterialPermitido(int idMaterial, int idTipoEmpaque);

	List<EmpaqueUtilizado> getEmpaquesUtilizados(int idSolicitud, int idOficina);

	EmpaqueUtilizado actualizarEmpaqueUtilizado(EmpaqueUtilizado empaqueUtilizado);

	SolicitudesEyE getSeguimiento(int folio);

	String uplooadFileAzureStorage(String nameFile, InputStream fileStream)
			throws IOException, StorageException, URISyntaxException;

	List<ReporteSolicitudesMaterial> getReporteSolicitudesMaterialCorporativo();

	List<ReporteSolicitudesMaterial> getReporteSolicitudesByFechaCorporativo(String fechaInicio, String fechaFin);
	
	List<ReporteSolicitudesMaterial> getReporteSolicitudesAutorizadasSolidaParcial();

	
}
