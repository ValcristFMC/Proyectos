package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.TalonesMaterialVentaDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(TalonesMaterialVenta.class)
public class TalonesMaterialVenta {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id_salida")
	private Long idSalida;
	
	@Column(name = "Id_solicitud")
	private Long idSolicitud;
	
	@Column(name = "Nombre_material")
	private String nombreMaterial;
	
	@Column(name = "Id_material")
	private long idMaterial;
	
	@Column(name = "Cantidad_solicitada")
	private int cantidadSolicitada;
	
	@Column(name = "Unidad_medida")
	private String unidadMedida;
	
	@Column(name = "Clave_material")
	private int claveMaterial;

	public static TalonesMaterialVenta fromTalonMaterialVentaDTO(TalonesMaterialVenta talonMaterialDTO) {
		TalonesMaterialVenta rest = new TalonesMaterialVenta();
		rest.setIdSalida(talonMaterialDTO.getIdSalida());
		rest.setIdSolicitud(talonMaterialDTO.getIdSolicitud());
		rest.setNombreMaterial(talonMaterialDTO.getNombreMaterial());
		rest.setIdMaterial(talonMaterialDTO.getIdMaterial());
		rest.setCantidadSolicitada(talonMaterialDTO.getCantidadSolicitada());
		rest.setUnidadMedida(talonMaterialDTO.getUnidadMedida());
		rest.setClaveMaterial(talonMaterialDTO.getClaveMaterial());
		return rest;
	}
	
	public TalonesMaterialVentaDTO toTalonMaterialVentaDTO() {
		TalonesMaterialVentaDTO dto = new TalonesMaterialVentaDTO();
		dto.setIdSalida(this.getIdSalida());
		dto.setIdSolicitud(this.getIdSolicitud());
		dto.setNombreMaterial(this.getNombreMaterial());
		dto.setIdMaterial(this.getIdMaterial());
		dto.setCantidadSolicitada(this.getCantidadSolicitada());
		dto.setUnidadMedida(this.getUnidadMedida());
		dto.setClaveMaterial(this.getClaveMaterial());
		return dto;
	}
}
