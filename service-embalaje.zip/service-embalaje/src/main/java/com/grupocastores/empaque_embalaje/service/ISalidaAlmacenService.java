package com.grupocastores.empaque_embalaje.service;

import java.util.List;

import com.grupocastores.empaque_embalaje.service.domain.SalidaAlmacen;

public interface ISalidaAlmacenService {

	List<SalidaAlmacen> getSalidas();
	
	SalidaAlmacen getSalidaById(long idSalida);

	SalidaAlmacen save(SalidaAlmacen salidaAlmacen);

	SalidaAlmacen update(SalidaAlmacen salidaAlmacen);

	void delete(Long idSalida);
	
	List<SalidaAlmacen> getDatosMaterialSalida(Long idSolicitud);
}
