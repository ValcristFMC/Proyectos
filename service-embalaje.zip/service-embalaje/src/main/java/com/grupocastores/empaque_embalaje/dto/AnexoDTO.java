package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion del archivo anexado", description = "Datos del archivo")
public class AnexoDTO {

	private int code;
	private String mensaje;
	private String nombreAnexo;
	
	public AnexoDTO(int code, String mensaje, String nombreAnexo) {
		this.code = code;
		this.mensaje = mensaje;
		this.nombreAnexo = nombreAnexo;
	}

	@Override
	public String toString() {
		return "AnexoDTO [code=" + code + ", status=" + mensaje + ", nombreAnexo=" + nombreAnexo + "]";
	}
}
