package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;

import lombok.Data;

@Data
@ApiModel(value = "Respuesta generica", description = "Objeto para respuestas de tipo incorrecto")
public class ResponseDTO {
	
	String message;
	
	public ResponseDTO(String mensaje) {
		this.setMessage(mensaje);
	}

}
