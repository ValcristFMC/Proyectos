package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.CantidadesMaterialPermitidoDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "cantidades_material_permitido")
@EntityListeners(CantidadesMaterialPermitido.class)
public class CantidadesMaterialPermitido {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Cantidad")
	private int cantidad;
	
	@Column(name = "Id_material")
	private int idMaterial;
	
	@Column(name = "Id_tipo_empaque")
	private int idTipoEmpaque;
	
	public static CantidadesMaterialPermitido fromCantidadesDTO(CantidadesMaterialPermitidoDTO cantidadDto) {
		CantidadesMaterialPermitido rest = new CantidadesMaterialPermitido();
		rest.setCantidad(cantidadDto.getCantidad());
		rest.setIdMaterial(cantidadDto.getIdMaterial());
		rest.setIdTipoEmpaque(cantidadDto.getIdTipoEmpaque());
		
		return rest;
	}
	
	public CantidadesMaterialPermitidoDTO toCantidadDTO() {
		CantidadesMaterialPermitidoDTO dto = new CantidadesMaterialPermitidoDTO();
		dto.setCantidad(this.getCantidad());
		dto.setIdMaterial(this.getIdMaterial());
		dto.setIdTipoEmpaque(this.getIdTipoEmpaque());
		
		
		return dto;
	}
}
