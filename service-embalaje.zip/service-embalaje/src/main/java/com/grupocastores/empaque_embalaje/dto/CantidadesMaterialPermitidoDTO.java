package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de las CantidadesMaterialPermitido", description = "Datos de CantidadesMaterialPermitido")
public class CantidadesMaterialPermitidoDTO {

	private int cantidad;
	private int idMaterial;
	private int idTipoEmpaque;
	
	public CantidadesMaterialPermitidoDTO(int cantidad, int idMaterial, int idTipoEmpaque) {
		this.cantidad = cantidad;
		this.idMaterial = idMaterial;
		this.idTipoEmpaque = idTipoEmpaque;
	}

	@Override
	public String toString() {
		return "CantidadesMaterialPermitidoDTO [cantidad=" + cantidad + ", idMaterial=" + idMaterial
				+ ", idTipoEmpaque=" + idTipoEmpaque + "]";
	}

}
