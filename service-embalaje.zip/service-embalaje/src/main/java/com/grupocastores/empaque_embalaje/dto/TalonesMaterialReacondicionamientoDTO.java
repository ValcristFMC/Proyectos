package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de los talones y salidas de material reacondicionamiento", description = "Datos de los talones")
public class TalonesMaterialReacondicionamientoDTO {

	private long idTalon;
	private String numeroTalon;
	private long idSolicitud;
	private long idSalida;
	private String nombreMaterial;
	private long idMaterial;
	private int cantidadSolicitada;
	private String unidadMedida;
	private int claveMaterial;
	private int idEmpaqueUtilizado;
	
	public TalonesMaterialReacondicionamientoDTO(long idTalon, String numeroTalon, long idSolicitud, long idSalida,
			String nombreMaterial, long idMaterial, int cantidadSolicitada, String unidadMedida, int claveMaterial,
			int idEmpaqueUtilizado) {
		this.idTalon = idTalon;
		this.numeroTalon = numeroTalon;
		this.idSolicitud = idSolicitud;
		this.idSalida = idSalida;
		this.nombreMaterial = nombreMaterial;
		this.idMaterial = idMaterial;
		this.cantidadSolicitada = cantidadSolicitada;
		this.unidadMedida = unidadMedida;
		this.claveMaterial = claveMaterial;
		this.idEmpaqueUtilizado = idEmpaqueUtilizado;
	}

	@Override
	public String toString() {
		return "TalonesMaterialReacondicionamientoDTO [idTalon=" + idTalon + ", numeroTalon=" + numeroTalon
				+ ", idSolicitud=" + idSolicitud + ", idSalida=" + idSalida + ", nombreMaterial=" + nombreMaterial
				+ ", idMaterial=" + idMaterial + ", cantidadSolicitada=" + cantidadSolicitada + ", unidadMedida="
				+ unidadMedida + ", claveMaterial=" + claveMaterial + ", idEmpaqueUtilizado=" + idEmpaqueUtilizado
				+ "]";
	}
	
}
