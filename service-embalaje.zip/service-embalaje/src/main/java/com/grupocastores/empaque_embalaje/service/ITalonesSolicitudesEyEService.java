package com.grupocastores.empaque_embalaje.service;

import java.util.List;

import com.grupocastores.empaque_embalaje.service.domain.CatalogoConceptoImporte;
import com.grupocastores.empaque_embalaje.service.domain.CdOrigenDestino;
import com.grupocastores.empaque_embalaje.service.domain.Co;
import com.grupocastores.empaque_embalaje.service.domain.Detatr;
import com.grupocastores.empaque_embalaje.service.domain.MetodoPago;
import com.grupocastores.empaque_embalaje.service.domain.ParametrosSistema;
import com.grupocastores.empaque_embalaje.service.domain.TalonEnviadoEye;
import com.grupocastores.empaque_embalaje.service.domain.Talones;
import com.grupocastores.empaque_embalaje.service.domain.TalonesParametros;
import com.grupocastores.empaque_embalaje.service.domain.TalonesSolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.domain.Tr;

public interface ITalonesSolicitudesEyEService {

	List<TalonesSolicitudesEyE> getTalonesSolicitudesEyE();
	
	List<TalonesSolicitudesEyE> getTalonesSolicitudByIdSolicitud(String idSolicitud);
	
	TalonesSolicitudesEyE getTalonesSolicitudesEyEById(long idTalon);
	
	Talones getTalonesByClaTalon(String claTalon);
	
	Tr getTrByClaTalon(String tabla, String claTalon);
	
	List<CdOrigenDestino> getCdOrigenDestino(int idCiudadOrigen, int idCiudadDestino);
	
	Detatr getDetatrByClaTalon(String claTalon);
	
	MetodoPago getMetodoPagoById(String idMetodoPago);
	
	MetodoPago getMetodoPagoByClave(String idMetodoPago);
	
	TalonesParametros getTalonesParametrosByIdParametro(int idParametro);
	
	CatalogoConceptoImporte getCatalogoConceptoImporteByParams(String tabla, String idConcepto, String claTalon);
	
	List<Co> getQueContiene(String tabla, String claTalon);
	
	TalonEnviadoEye getTalonEnviadoByNumeroTalon(String numeroTalon);

	TalonesSolicitudesEyE save(TalonesSolicitudesEyE talonesSolicitudesEyE);
	
	TalonEnviadoEye save(TalonEnviadoEye talonEnviado);

	TalonesSolicitudesEyE update(TalonesSolicitudesEyE talonesSolicitudesEyE);

	void delete(Long id);

	List<ParametrosSistema> getParametros(int idSitema, String parametros);
}
