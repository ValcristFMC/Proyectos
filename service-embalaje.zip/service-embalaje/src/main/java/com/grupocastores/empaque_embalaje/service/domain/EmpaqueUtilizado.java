package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.EmpaqueUtilizadoDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "empaques_utilizados")
@EntityListeners(EmpaqueEmbalaje.class)
public class EmpaqueUtilizado {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id_empaque_utilizado")
	private int idEmpaqueUtilizado;
	
	@Column(name = "Id_solicitud")
	private int idSolicitud;
	
	@Column(name = "Id_tipo_empaque")
	private int idTipoEmpaque;
	
	@Column(name = "Cantidad")
	private int cantidad;
	
	@Column(name = "Id_oficina")
	private int idOficina;
	
	public static EmpaqueUtilizado fromEmpaqueUtilizadoDTO(EmpaqueUtilizadoDTO empaqueUtilizadoDTO) {
		EmpaqueUtilizado rest = new EmpaqueUtilizado();
		rest.setIdEmpaqueUtilizado(empaqueUtilizadoDTO.getIdEmpaqueUtilizado());
		rest.setIdSolicitud(empaqueUtilizadoDTO.getIdSolicitud());
		rest.setIdTipoEmpaque(empaqueUtilizadoDTO.getIdTipoEmpaque());
		rest.setCantidad(empaqueUtilizadoDTO.getCantidad());
		rest.setIdOficina(empaqueUtilizadoDTO.getIdOficina());
		return rest;
	}
	
	public EmpaqueUtilizadoDTO toEmpaqueUtilizadoDTO() {
		EmpaqueUtilizadoDTO dto = new EmpaqueUtilizadoDTO();
		dto.setIdEmpaqueUtilizado(this.getIdEmpaqueUtilizado());
		dto.setIdSolicitud(this.getIdSolicitud());
		dto.setIdTipoEmpaque(this.getIdTipoEmpaque());
		dto.setCantidad(this.getCantidad());
		dto.setIdOficina(this.getIdOficina());
		return dto;
	}
}
