package com.grupocastores.empaque_embalaje.dto;

import java.util.List;

public class MaterialDTO {

 private int material;
 private int cantidad;
 private List<SurtidoDTO> listSurtido;

 // Getters and Setters
 public int getMaterial() {
     return material;
 }

 public void setMaterial(int material) {
     this.material = material;
 }

 public int getCantidad() {
     return cantidad;
 }

 public void setCantidad(int cantidad) {
     this.cantidad = cantidad;
 }

 public List<SurtidoDTO> getListSurtido() {
     return listSurtido;
 }

 public void setListSurtido(List<SurtidoDTO> listSurtido) {
     this.listSurtido = listSurtido;
 }
}
