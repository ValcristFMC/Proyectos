package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de las Unidades de Medida", description = "Datos de las Unidades de Medida")
public class UnidadMedidaDTO {

	private int idUnidadMedida;
	private String nombre;
	private String descripcion;
	private int idPersonal;
	private String fechaMod;
	private String horaMod;
	private int estatus;
	private int esEntero;
	
	public UnidadMedidaDTO(int idUnidadMedida, String nombre, String descripcion, int idPersonal, String fechaMod,
			String horaMod, int estatus, int esEntero) {
		this.idUnidadMedida = idUnidadMedida;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.idPersonal = idPersonal;
		this.fechaMod = fechaMod;
		this.horaMod = horaMod;
		this.estatus = estatus;
		this.esEntero = esEntero;
	}

	@Override
	public String toString() {
		return "UnidadMedidaDTO [idUnidadMedida=" + idUnidadMedida + ", nombre=" + nombre + ", descripcion="
				+ descripcion + ", idPersonal=" + idPersonal + ", fechaMod=" + fechaMod + ", horaMod=" + horaMod
				+ ", estatus=" + estatus + ", esEntero=" + esEntero + "]";
	}
		
}
