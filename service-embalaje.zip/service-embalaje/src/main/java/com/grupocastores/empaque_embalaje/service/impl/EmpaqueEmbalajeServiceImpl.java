package com.grupocastores.empaque_embalaje.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.empaque_embalaje.service.IEmpaqueEmbalajeService;
import com.grupocastores.empaque_embalaje.service.domain.EmpaqueEmbalaje;
import com.grupocastores.empaque_embalaje.service.repository.EmpaqueEmbalajeRepository;

/**
 * Implementacion interna de {@link com.grupocastores.empaque_embalaje.service.IEmpaqueEmbalajeService}. Esta clase no se debe acceder directamente
 *
 * @author Castores - Desarrollo TI
 */
@Service
public class EmpaqueEmbalajeServiceImpl implements IEmpaqueEmbalajeService 
{	
	@Autowired
	private EmpaqueEmbalajeRepository empaqueEmbalajeRepository;

	@Override
	public List<EmpaqueEmbalaje> getAll() {
		return empaqueEmbalajeRepository.findAll();
	}

	@Override
	public EmpaqueEmbalaje save(EmpaqueEmbalaje empaqueEmbalaje) {
		empaqueEmbalaje.setCreateddate(Calendar.getInstance().getTime());
		empaqueEmbalaje.setLastModifiedTime(Calendar.getInstance().getTime());
		return empaqueEmbalajeRepository.save(empaqueEmbalaje);
	}

	@Override
	public EmpaqueEmbalaje update(EmpaqueEmbalaje empaqueEmbalaje) {
		empaqueEmbalaje.setLastModifiedTime(Calendar.getInstance().getTime());
		return empaqueEmbalajeRepository.save(empaqueEmbalaje);
	}

	@Override
	public EmpaqueEmbalaje delete(Integer id) {
		EmpaqueEmbalaje empaqueEmbalaje = getById(id);

		List<EmpaqueEmbalaje > lstEmpaqueEmbalaje = new ArrayList<>();

		lstEmpaqueEmbalaje.add(empaqueEmbalaje);
		empaqueEmbalajeRepository.delete(empaqueEmbalaje);

		return empaqueEmbalaje;
	}
	@Override
	public EmpaqueEmbalaje changeStatus(Integer id) {
		EmpaqueEmbalaje empaqueEmbalaje = getById(id);
		empaqueEmbalaje.setIsActive(empaqueEmbalaje.getIsActive()== Boolean.TRUE ? Boolean.FALSE : Boolean.TRUE);
		return empaqueEmbalajeRepository.save(empaqueEmbalaje);
	}
	
	public EmpaqueEmbalaje getById(Integer id) {
		return empaqueEmbalajeRepository.getById(id); 
	}
	
}
