package com.grupocastores.empaque_embalaje.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.TipoEmpaque;

@Repository
public interface TipoEmpaqueRepository extends JpaRepository<TipoEmpaque, Integer> {

}
