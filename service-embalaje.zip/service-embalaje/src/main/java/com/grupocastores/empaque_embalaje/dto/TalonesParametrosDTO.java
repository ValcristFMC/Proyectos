package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un Parametro", description = "Datos del Parametro")
public class TalonesParametrosDTO {

	private Long idParametro;
	private String nombre;
	private String valor;
	
	public TalonesParametrosDTO(Long idParametro, String nombre, String valor) {
		this.idParametro = idParametro;
		this.nombre = nombre;
		this.valor = valor;
	}

	@Override
	public String toString() {
		return "TalonesParametrosDTO [idParametro=" + idParametro + ", nombre=" + nombre + ", valor=" + valor + "]";
	}
	
}
