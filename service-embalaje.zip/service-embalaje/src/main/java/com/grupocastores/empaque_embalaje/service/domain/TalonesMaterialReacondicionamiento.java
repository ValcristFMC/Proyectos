package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.TalonesMaterialReacondicionamientoDTO;
import com.grupocastores.empaque_embalaje.dto.TalonesSolicitudesEyEDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(TalonesMaterialReacondicionamiento.class)
public class TalonesMaterialReacondicionamiento {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_talon")
	private long idTalon;
	
	@Column(name = "numero_talon")
	private String numeroTalon;
	
	@Column(name = "id_solicitud")
	private Long idSolicitud;
	
	@Column(name = "id_salida")
	private long idSalida;
	
	@Column(name = "Nombre_material")
	private String nombreMaterial;
	
	@Column(name = "id_material")
	private long idMaterial;
	
	@Column(name = "cantidad_solicitada")
	private int cantidadSolicitada;
	
	@Column(name = "unidad_medida")
	private String unidadMedida;
	
	@Column(name = "clave_material")
	private int claveMaterial;
	
	@Column(name = "id_empaque_utilizado")
	private int idEmpaqueUtilizado;

	public static TalonesMaterialReacondicionamiento fromTalonMaterialReacondicionamientoDTO(TalonesMaterialReacondicionamiento talonSalidaDTO) {
		TalonesMaterialReacondicionamiento rest = new TalonesMaterialReacondicionamiento();
		rest.setIdTalon(talonSalidaDTO.getIdTalon());
		rest.setNumeroTalon(talonSalidaDTO.getNumeroTalon());
		rest.setIdSolicitud(talonSalidaDTO.getIdSolicitud());
		rest.setIdSalida(talonSalidaDTO.getIdSalida());
		rest.setNombreMaterial(talonSalidaDTO.getNombreMaterial());
		rest.setIdMaterial(talonSalidaDTO.getIdMaterial());
		rest.setCantidadSolicitada(talonSalidaDTO.getCantidadSolicitada());
		rest.setUnidadMedida(talonSalidaDTO.getUnidadMedida());
		rest.setClaveMaterial(talonSalidaDTO.getClaveMaterial());
		rest.setIdEmpaqueUtilizado(talonSalidaDTO.getIdEmpaqueUtilizado());
		return rest;
	}
	
	public TalonesMaterialReacondicionamientoDTO toTalonMaterialReacondicionamientoDTO() {
		TalonesMaterialReacondicionamientoDTO dto = new TalonesMaterialReacondicionamientoDTO();
		dto.setIdTalon(this.getIdTalon());
		dto.setNumeroTalon(this.getNumeroTalon());
		dto.setIdSolicitud(this.getIdSolicitud());
		dto.setIdSalida(this.getIdSalida());
		dto.setNombreMaterial(this.getNombreMaterial());
		dto.setIdMaterial(this.getIdMaterial());
		dto.setCantidadSolicitada(this.getCantidadSolicitada());
		dto.setUnidadMedida(this.getUnidadMedida());
		dto.setClaveMaterial(this.getClaveMaterial());
		dto.setIdEmpaqueUtilizado(this.getIdEmpaqueUtilizado());
		return dto;
	}
}
