package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un Talón enviado", description = "Datos de un Talón enviado")
public class TalonEnviadoEyeDTO {
	
	private int idTalonEnviado;
	private String numeroTalon;
	private int idSolicitud;
	private int idOficina;
	private int idPersonal;
	private String fecha;
	private String hora;
	
	public TalonEnviadoEyeDTO(int idTalonEnviado, String numeroTalon, int idSolicitud, int idOficina, int idPersonal,
			String fecha, String hora) {
		this.idTalonEnviado = idTalonEnviado;
		this.numeroTalon = numeroTalon;
		this.idSolicitud = idSolicitud;
		this.idOficina = idOficina;
		this.idPersonal = idPersonal;
		this.fecha = fecha;
		this.hora = hora;
	}

	@Override
	public String toString() {
		return "TalonEnviadoEyeDTO [idTalonEnviado=" + idTalonEnviado + ", numeroTalon=" + numeroTalon + ", idSolicitud="
				+ idSolicitud + ", idOficina=" + idOficina + ", idPersonal=" + idPersonal + ", fecha=" + fecha + ", hora="
				+ hora + "]";
	}

}
