package com.grupocastores.empaque_embalaje.utils;
import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.message.types.GrantType;

public class TokenUtil {

	private String token = "";
	private String urlToken = "";
	private String clientID = "";
	private String clientSecret = "";
	private String userName = "";
	private String password = "";
	
	public void generarToken() {
		token = "";
        try {
            OAuthClient client = new OAuthClient(new URLConnectionClient());
            OAuthClientRequest request
                    = OAuthClientRequest.tokenLocation(urlToken)
                            .setGrantType(GrantType.PASSWORD)
                            .setClientId(clientID)
                            .setClientSecret(clientSecret)
                            .setUsername(userName)
                            .setPassword(password)
                            .buildQueryMessage();
            request.addHeader("Authorization", "Basic Q2FzdG9yZUh1YkFkbWluOkNhc3RvcmVzMjAyMEAh");
            request.addHeader("Accept", "application/json");
            request.addHeader("Content-Type", "application/json");
            token = client.accessToken(request, OAuthJSONAccessTokenResponse.class).getAccessToken();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	public TokenUtil(String urlToken, String clientID, String clientSecret, String userName, String password) {
		this.urlToken = urlToken;
		this.clientID = clientID;
		this.clientSecret = clientSecret;
		this.userName = userName;
		this.password = password;
	}
	
	public TokenUtil() {
		this.urlToken = "";
		this.clientID = "";
		this.clientSecret = "";
		this.userName = "";
		this.password = "";
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getUrlToken() {
		return urlToken;
	}
	public void setUrlToken(String urlToken) {
		this.urlToken = urlToken;
	}
	public String getClientID() {
		return clientID;
	}
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}
	public String getClientSecret() {
		return clientSecret;
	}
	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
