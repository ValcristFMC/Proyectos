package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.TalonEnviadoEyeDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "talones_enviados_eye")
@EntityListeners(TalonEnviadoEye.class)
public class TalonEnviadoEye {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_talon_enviado")
	private int idTalonEnviado;

	@Column(name = "numero_talon")
	private String numeroTalon;

	@Column(name = "id_solicitud")
	private int idSolicitud;

	@Column(name = "id_oficina")
	private int idOficina;

	@Column(name = "id_personal")
	private int idPersonal;

	@Column(name = "fecha")
	private String fecha;

	@Column(name = "hora")
	private String hora;

	public static TalonEnviadoEye fromTalonEnviadoEyeDTO(TalonEnviadoEyeDTO talonEnviadoEyeDTO) {
		TalonEnviadoEye talonEnviadoEye = new TalonEnviadoEye();
		talonEnviadoEye.setIdTalonEnviado(talonEnviadoEyeDTO.getIdTalonEnviado());
		talonEnviadoEye.setNumeroTalon(talonEnviadoEyeDTO.getNumeroTalon());
		talonEnviadoEye.setIdSolicitud(talonEnviadoEyeDTO.getIdSolicitud());
		talonEnviadoEye.setIdOficina(talonEnviadoEyeDTO.getIdOficina());
		talonEnviadoEye.setIdPersonal(talonEnviadoEyeDTO.getIdPersonal());
		talonEnviadoEye.setFecha(talonEnviadoEyeDTO.getFecha());
		talonEnviadoEye.setHora(talonEnviadoEyeDTO.getHora());
		return talonEnviadoEye;
	}

	public TalonEnviadoEyeDTO toTalonEnviadoEyeDTO() {
		TalonEnviadoEyeDTO talonEnviadoEyeDTO = new TalonEnviadoEyeDTO();
		talonEnviadoEyeDTO.setIdTalonEnviado(this.getIdTalonEnviado());
		talonEnviadoEyeDTO.setNumeroTalon(this.getNumeroTalon());
		talonEnviadoEyeDTO.setIdSolicitud(this.getIdSolicitud());
		talonEnviadoEyeDTO.setIdOficina(this.getIdOficina());
		talonEnviadoEyeDTO.setIdPersonal(this.getIdPersonal());
		talonEnviadoEyeDTO.setFecha(this.getFecha());
		talonEnviadoEyeDTO.setHora(this.getHora());
		return talonEnviadoEyeDTO;
	}
}
