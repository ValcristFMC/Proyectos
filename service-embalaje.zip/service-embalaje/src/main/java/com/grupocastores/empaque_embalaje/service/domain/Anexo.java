package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.AnexoDTO;
import com.grupocastores.empaque_embalaje.dto.MaterialesEyEDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(Anexo.class)
public class Anexo {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int code;
	private String mensaje;
	private String nombreAnexo;
	
	public AnexoDTO toAnexoDTO() {
		AnexoDTO dto = new AnexoDTO();
		dto.setCode(this.getCode());
		dto.setMensaje(this.getMensaje());
		dto.setNombreAnexo(this.getNombreAnexo());
		
		return dto;
	}
}
