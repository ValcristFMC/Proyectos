package com.grupocastores.empaque_embalaje.service.domain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.TalonesDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "talones")
@EntityListeners(Talones.class)
public class Talones {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cla_talon")
	private String claTalon;

	@Column(name = "idoficina")
	private String idOficina;

	@Column(name = "tabla")
	private String tabla;

	@Column(name = "status")
	private int status;

	@Column(name = "remision")
	private String remision;

	@Column(name = "serie")
	private String serie;

	@Column(name = "maniobras")
	private BigDecimal maniobras;

	public static Talones fromTalonesDTO(TalonesDTO talonDTO) {
        Talones talon = new Talones();
        talon.setClaTalon(talonDTO.getClaTalon());
        talon.setIdOficina(talonDTO.getIdOficina());
        talon.setTabla(talonDTO.getTabla());
        talon.setStatus(talonDTO.getStatus());
        talon.setRemision(talonDTO.getRemision());
        talon.setSerie(talonDTO.getSerie());
        talon.setManiobras(talonDTO.getManiobras());
     
        return talon;
    }

    public TalonesDTO toTalonesDTO() {
        TalonesDTO talonDTO = new TalonesDTO();
        talonDTO.setClaTalon(this.getClaTalon());
        talonDTO.setIdOficina(this.getIdOficina());
        talonDTO.setTabla(this.getTabla());
        talonDTO.setStatus(this.getStatus());
        talonDTO.setRemision(this.getRemision());
        talonDTO.setSerie(this.getSerie());
        talonDTO.setManiobras(this.getManiobras());
      
        return talonDTO;
    }
}
