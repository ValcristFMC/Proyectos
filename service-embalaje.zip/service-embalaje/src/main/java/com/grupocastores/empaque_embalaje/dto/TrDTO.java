package com.grupocastores.empaque_embalaje.dto;

import java.math.BigDecimal;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de un Tr", description = "Datos del Tr")
public class TrDTO {

	private String claTalon;
	private int tpDc;
	private int reembarque;
	private String fecha;
	private String hora;
	private String remision;
	private String noGuia;
	private String fechaEnvio;
	private int idPersonal;
	private String rfcOrigen;
	private String nomOrigen;
	private String calleOrigen;
	private String coloniaOrigen;
	private String cpOrigen;
	private String telOrigen;
	private int cdOrigen;
	private int depenOrigen;
	private String rfcDestino;
	private String nomDestino;
	private String calleDestino;
	private String coloniaDestino;
	private String cpDestino;
	private String telDestino;
	private int cdDestino;
	private int depenDestino;
	private String seRecogera;
	private String seEntregara;
	private BigDecimal cpt;
	private BigDecimal valDecl;
	private BigDecimal porSeguro;
	private int tipoPago;
	private String talonASust;
	private Integer idConvenio;
	private BigDecimal sumaFlete;
	private BigDecimal porDescuento;
	private BigDecimal ivaRet;
	private String poliza;
	private BigDecimal casetas;
	private BigDecimal recoleccion;
	private BigDecimal entrega;
	private BigDecimal maniobras;
	private BigDecimal otrosCargos;
	private BigDecimal gps;
	private BigDecimal iva;
	private BigDecimal otrasLineas;
	private String observaciones;
	private String idOficina;
	private String calleRec;
	private String noExtRec;
	private String noIntRec;
	private String colRec;
	private String delRec;
	private String cpRec;
	private String telRec;
	private String calleDes;
	private String noExtDes;
	private String noIntDes;
	private String colDes;
	private String delDes;
	private String cpDes;
	private String telDes;
	private String ubicacion;
	private String serie;
	private int tipoRemitente;
	private int idRemitente;
	private int tipoDestinatario;
	private int idDestinatario;
	private int completo;
	private String obsOtros;
	private int ocurre;
	private String noExtRte;
	private String noIntRte;
	private String noExtDest;
	private String noIntDest;
	private int idCdRec;
	private int idCdDes;
	private double cmt;
	private int tipoUnidad;
	private int idPrecioDiesel;
	private BigDecimal cpac;
	private BigDecimal ferry;
	private String idOfIrte;
	private String idOfIdest;
	private int idSucRte;
	private int idSucDest;
	private BigDecimal revac;
	private BigDecimal importeSeguro;
	private BigDecimal importeSubtotal;
	private BigDecimal importeIva;
	private BigDecimal importeIvaRet;
	private BigDecimal importeTotal;
	private int estatusSat;
	private int idDocumentoSat;
	private int idClasificacionDoc;
	private String nombreTipoDocumento;
	
	public TrDTO(String claTalon, int tpDc, int reembarque, String fecha, String hora, String remision, String noGuia,
			String fechaEnvio, int idPersonal, String rfcOrigen, String nomOrigen, String calleOrigen,
			String coloniaOrigen, String cpOrigen, String telOrigen, int cdOrigen, int depenOrigen, String rfcDestino,
			String nomDestino, String calleDestino, String coloniaDestino, String cpDestino, String telDestino,
			int cdDestino, int depenDestino, String seRecogera, String seEntregara, BigDecimal cpt, BigDecimal valDecl,
			BigDecimal porSeguro, int tipoPago, String talonASust, Integer idConvenio, BigDecimal sumaFlete,
			BigDecimal porDescuento, BigDecimal ivaRet, String poliza, BigDecimal casetas, BigDecimal recoleccion,
			BigDecimal entrega, BigDecimal maniobras, BigDecimal otrosCargos, BigDecimal gps, BigDecimal iva,
			BigDecimal otrasLineas, String observaciones, String idOficina, String calleRec, String noExtRec,
			String noIntRec, String colRec, String delRec, String cpRec, String telRec, String calleDes,
			String noExtDes, String noIntDes, String colDes, String delDes, String cpDes, String telDes,
			String ubicacion, String serie, int tipoRemitente, int idRemitente, int tipoDestinatario,
			int idDestinatario, int completo, String obsOtros, int ocurre, String noExtRte, String noIntRte,
			String noExtDest, String noIntDest, int idCdRec, int idCdDes, double cmt, int tipoUnidad,
			int idPrecioDiesel, BigDecimal cpac, BigDecimal ferry, String idOfIrte, String idOfIdest, int idSucRte,
			int idSucDest, BigDecimal revac, BigDecimal importeSeguro, BigDecimal importeSubtotal,
			BigDecimal importeIva, BigDecimal importeIvaRet, BigDecimal importeTotal, int estatusSat,
			int idDocumentoSat, int idClasificacionDoc,String nombreTipoDocumento) {
		this.claTalon = claTalon;
		this.tpDc = tpDc;
		this.reembarque = reembarque;
		this.fecha = fecha;
		this.hora = hora;
		this.remision = remision;
		this.noGuia = noGuia;
		this.fechaEnvio = fechaEnvio;
		this.idPersonal = idPersonal;
		this.rfcOrigen = rfcOrigen;
		this.nomOrigen = nomOrigen;
		this.calleOrigen = calleOrigen;
		this.coloniaOrigen = coloniaOrigen;
		this.cpOrigen = cpOrigen;
		this.telOrigen = telOrigen;
		this.cdOrigen = cdOrigen;
		this.depenOrigen = depenOrigen;
		this.rfcDestino = rfcDestino;
		this.nomDestino = nomDestino;
		this.calleDestino = calleDestino;
		this.coloniaDestino = coloniaDestino;
		this.cpDestino = cpDestino;
		this.telDestino = telDestino;
		this.cdDestino = cdDestino;
		this.depenDestino = depenDestino;
		this.seRecogera = seRecogera;
		this.seEntregara = seEntregara;
		this.cpt = cpt;
		this.valDecl = valDecl;
		this.porSeguro = porSeguro;
		this.tipoPago = tipoPago;
		this.talonASust = talonASust;
		this.idConvenio = idConvenio;
		this.sumaFlete = sumaFlete;
		this.porDescuento = porDescuento;
		this.ivaRet = ivaRet;
		this.poliza = poliza;
		this.casetas = casetas;
		this.recoleccion = recoleccion;
		this.entrega = entrega;
		this.maniobras = maniobras;
		this.otrosCargos = otrosCargos;
		this.gps = gps;
		this.iva = iva;
		this.otrasLineas = otrasLineas;
		this.observaciones = observaciones;
		this.idOficina = idOficina;
		this.calleRec = calleRec;
		this.noExtRec = noExtRec;
		this.noIntRec = noIntRec;
		this.colRec = colRec;
		this.delRec = delRec;
		this.cpRec = cpRec;
		this.telRec = telRec;
		this.calleDes = calleDes;
		this.noExtDes = noExtDes;
		this.noIntDes = noIntDes;
		this.colDes = colDes;
		this.delDes = delDes;
		this.cpDes = cpDes;
		this.telDes = telDes;
		this.ubicacion = ubicacion;
		this.serie = serie;
		this.tipoRemitente = tipoRemitente;
		this.idRemitente = idRemitente;
		this.tipoDestinatario = tipoDestinatario;
		this.idDestinatario = idDestinatario;
		this.completo = completo;
		this.obsOtros = obsOtros;
		this.ocurre = ocurre;
		this.noExtRte = noExtRte;
		this.noIntRte = noIntRte;
		this.noExtDest = noExtDest;
		this.noIntDest = noIntDest;
		this.idCdRec = idCdRec;
		this.idCdDes = idCdDes;
		this.cmt = cmt;
		this.tipoUnidad = tipoUnidad;
		this.idPrecioDiesel = idPrecioDiesel;
		this.cpac = cpac;
		this.ferry = ferry;
		this.idOfIrte = idOfIrte;
		this.idOfIdest = idOfIdest;
		this.idSucRte = idSucRte;
		this.idSucDest = idSucDest;
		this.revac = revac;
		this.importeSeguro = importeSeguro;
		this.importeSubtotal = importeSubtotal;
		this.importeIva = importeIva;
		this.importeIvaRet = importeIvaRet;
		this.importeTotal = importeTotal;
		this.estatusSat = estatusSat;
		this.idDocumentoSat = idDocumentoSat;
		this.idClasificacionDoc = idClasificacionDoc;
		this.nombreTipoDocumento = nombreTipoDocumento;
	}
	
	@Override
	public String toString() {
		return "TrDTO [claTalon=" + claTalon + ", tpDc=" + tpDc + ", reembarque=" + reembarque + ", fecha=" + fecha
				+ ", hora=" + hora + ", remision=" + remision + ", noGuia=" + noGuia + ", fechaEnvio=" + fechaEnvio
				+ ", idPersonal=" + idPersonal + ", rfcOrigen=" + rfcOrigen + ", nomOrigen=" + nomOrigen
				+ ", calleOrigen=" + calleOrigen + ", coloniaOrigen=" + coloniaOrigen + ", cpOrigen=" + cpOrigen
				+ ", telOrigen=" + telOrigen + ", cdOrigen=" + cdOrigen + ", depenOrigen=" + depenOrigen
				+ ", rfcDestino=" + rfcDestino + ", nomDestino=" + nomDestino + ", calleDestino=" + calleDestino
				+ ", coloniaDestino=" + coloniaDestino + ", cpDestino=" + cpDestino + ", telDestino=" + telDestino
				+ ", cdDestino=" + cdDestino + ", depenDestino=" + depenDestino + ", seRecogera=" + seRecogera
				+ ", seEntregara=" + seEntregara + ", cpt=" + cpt + ", valDecl=" + valDecl + ", porSeguro=" + porSeguro
				+ ", tipoPago=" + tipoPago + ", talonASust=" + talonASust + ", idConvenio=" + idConvenio
				+ ", sumaFlete=" + sumaFlete + ", porDescuento=" + porDescuento + ", ivaRet=" + ivaRet + ", poliza="
				+ poliza + ", casetas=" + casetas + ", recoleccion=" + recoleccion + ", entrega=" + entrega
				+ ", maniobras=" + maniobras + ", otrosCargos=" + otrosCargos + ", gps=" + gps + ", iva=" + iva
				+ ", otrasLineas=" + otrasLineas + ", observaciones=" + observaciones + ", idOficina=" + idOficina
				+ ", calleRec=" + calleRec + ", noExtRec=" + noExtRec + ", noIntRec=" + noIntRec + ", colRec=" + colRec
				+ ", delRec=" + delRec + ", cpRec=" + cpRec + ", telRec=" + telRec + ", calleDes=" + calleDes
				+ ", noExtDes=" + noExtDes + ", noIntDes=" + noIntDes + ", colDes=" + colDes + ", delDes=" + delDes
				+ ", cpDes=" + cpDes + ", telDes=" + telDes + ", ubicacion=" + ubicacion + ", serie=" + serie
				+ ", tipoRemitente=" + tipoRemitente + ", idRemitente=" + idRemitente + ", tipoDestinatario="
				+ tipoDestinatario + ", idDestinatario=" + idDestinatario + ", completo=" + completo + ", obsOtros="
				+ obsOtros + ", ocurre=" + ocurre + ", noExtRte=" + noExtRte + ", noIntRte=" + noIntRte + ", noExtDest="
				+ noExtDest + ", noIntDest=" + noIntDest + ", idCdRec=" + idCdRec + ", idCdDes=" + idCdDes + ", cmt="
				+ cmt + ", tipoUnidad=" + tipoUnidad + ", idPrecioDiesel=" + idPrecioDiesel + ", cpac=" + cpac
				+ ", ferry=" + ferry + ", idOfIrte=" + idOfIrte + ", idOfIdest=" + idOfIdest + ", idSucRte=" + idSucRte
				+ ", idSucDest=" + idSucDest + ", revac=" + revac + ", importeSeguro=" + importeSeguro
				+ ", importeSubtotal=" + importeSubtotal + ", importeIva=" + importeIva + ", importeIvaRet="
				+ importeIvaRet + ", importeTotal=" + importeTotal + ", estatusSat=" + estatusSat + ", idDocumentoSat="
				+ idDocumentoSat + ", idClasificacionDoc=" + idClasificacionDoc + ", nombreTipoDocumento=" + nombreTipoDocumento +"]";
	}
		
}
