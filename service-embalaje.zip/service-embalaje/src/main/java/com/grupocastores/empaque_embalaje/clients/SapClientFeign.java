package com.grupocastores.empaque_embalaje.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.grupocastores.empaque_embalaje.dto.SeguimientoDTO;


@FeignClient(name = "sapService", url = "http://10.3.1.234:8090/castores/services/sap/solicitud-eye/v1/")
public interface SapClientFeign {

    @GetMapping("/estatusSolicitudMaterial?idSolicitud={folio}")
    SeguimientoDTO consultarSeguimientoSap(
            @PathVariable("folio") Integer folio);
}