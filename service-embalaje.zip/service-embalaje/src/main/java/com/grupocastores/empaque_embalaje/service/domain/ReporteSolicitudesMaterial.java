package com.grupocastores.empaque_embalaje.service.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.ReporteSolicitudesMaterialDTO;
import com.grupocastores.empaque_embalaje.dto.SolicitudesDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(ReporteSolicitudesMaterial.class)
public class ReporteSolicitudesMaterial {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_solicitud")
	private Long idSolicitud;
	
	@Column(name = "folio")
	private int folio;
	
	@Column(name = "id_oficina")
	private int idOficina;
	
	@Column(name = "Oficina")
    private String oficina;
	
	@Column(name = "Id_personal")
	private int idPersonal;
	
	@Column(name = "Usuario_solicita")
	private String usuarioSolicita;
	
	@Column(name = "tipo_solicitud")
    private String tipoSolicitud;
	
	@Column(name = "anexo")
	private String anexo;
	
	@Column(name = "observaciones")
	private String observaciones;
	
	@Column(name = "fecha")
    private String fecha;
	
	@Column(name = "estatus")
    private String estatus;
	
	@Column(name = "Clave_estatus")
    private String claveEstatus;
	
	@Column(name = "No_sap")
    private int noSap;
    
    public ReporteSolicitudesMaterialDTO toReporteSolicitudesDTO() {
    	ReporteSolicitudesMaterialDTO dto = new ReporteSolicitudesMaterialDTO();
    	dto.setIdSolicitud(this.getIdSolicitud());
		dto.setFolio(this.getFolio());
		dto.setIdOficina(this.getIdOficina());
		dto.setOficina(this.getOficina());
		dto.setIdPersonal(this.getIdPersonal());
		dto.setUsuarioSolicita(this.getUsuarioSolicita());
		dto.setTipoSolicitud(this.getTipoSolicitud());
		dto.setAnexo(this.getAnexo());
		dto.setObservaciones(this.getObservaciones());
		dto.setFecha(this.getFecha());
		dto.setEstatus(this.getEstatus());
		dto.setClaveEstatus(this.getClaveEstatus());
		dto.setNoSap(this.getNoSap());
		
		return dto;
	}
}
