package com.grupocastores.empaque_embalaje.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.grupocastores.empaque_embalaje.service.ISalidaAlmacenService;
import com.grupocastores.empaque_embalaje.service.domain.SalidaAlmacen;
import com.grupocastores.empaque_embalaje.service.repository.SalidaAlmacenRepository;

@Service
public class SalidaAlmacenServiceImpl implements ISalidaAlmacenService{

	@Autowired
	private SalidaAlmacenRepository salidaAlmacenRepository;
	
	@Override
	public List<SalidaAlmacen> getSalidas() {
		return salidaAlmacenRepository.findAll();
	}

	@Override
	public SalidaAlmacen getSalidaById(long idSalida) {
		return salidaAlmacenRepository.findById(idSalida).orElse(null);
	}
	
	@Override
	public SalidaAlmacen save(SalidaAlmacen salidaAlmacen) {
		return salidaAlmacenRepository.save(salidaAlmacen);
	}

	@Override
	public SalidaAlmacen update(SalidaAlmacen salidaAlmacen) {
		return salidaAlmacenRepository.save(salidaAlmacen);
	}
	
	@Override
	public void delete(Long idSalida) {
		salidaAlmacenRepository.deleteById(idSalida);
	}

	@Override
	public List<SalidaAlmacen> getDatosMaterialSalida(Long idSolicitud) {
		return  salidaAlmacenRepository.getDatosMaterialSalida(idSolicitud);
	}

}
