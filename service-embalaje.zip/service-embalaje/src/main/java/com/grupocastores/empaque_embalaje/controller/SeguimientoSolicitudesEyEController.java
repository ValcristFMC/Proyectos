package com.grupocastores.empaque_embalaje.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.grupocastores.empaque_embalaje.dto.ResponseDTO;
import com.grupocastores.empaque_embalaje.dto.SeguimientoDTO;
import com.grupocastores.empaque_embalaje.dto.SeguimientoSolicitudesEyEDTO;
import com.grupocastores.empaque_embalaje.dto.TalonesMaterialVentaDTO;
import com.grupocastores.empaque_embalaje.service.IMaterialesEyEService;
import com.grupocastores.empaque_embalaje.service.ISeguimientoSolicitudesEyEService;
import com.grupocastores.empaque_embalaje.service.ISolicitudesEyEService;
import com.grupocastores.empaque_embalaje.service.domain.EntradaMaterial;
import com.grupocastores.empaque_embalaje.service.domain.MaterialesEyE;
import com.grupocastores.empaque_embalaje.service.domain.ReporteSolicitudesMaterial;
import com.grupocastores.empaque_embalaje.service.domain.SeguimientoSolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.domain.SolicitudesEyE;
import com.grupocastores.empaque_embalaje.service.domain.TalonesMaterialVenta;
import com.grupocastores.empaque_embalaje.service.impl.FechaServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/seguimientoSolicitudes")
@Api(value = "SeguimientoSolicitudesEyEController", produces = "application/json")

public class SeguimientoSolicitudesEyEController {

	Logger log = LoggerFactory.getLogger(EmpaqueEmbalajeController.class);

	@Autowired
	private ISeguimientoSolicitudesEyEService seguimientoSolicitudesEyeService;
	static final String HEADERBACK = "/SeguimientoSolicitudesEyE/{id}";

	@Autowired
	private IMaterialesEyEService materialesEyeService;
	
	@Autowired
	private ISolicitudesEyEService solicitudesEyeService;
	
	@ApiOperation(value = "Crea un registro Seguimiento")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Registro de Seguimiento creado", response = SeguimientoSolicitudesEyEDTO.class),
			@ApiResponse(code = 500, message = "No creado", response = ResponseDTO.class) })
	@PostMapping("/guardarSeguimiento")
	public ResponseEntity<?> guardarSeguimiento(
			@ApiParam(value = "Registro de Seguimiento que se va a crear", required = true) @RequestBody @Valid SeguimientoSolicitudesEyEDTO seguimientoDto,
			UriComponentsBuilder builder) {
		try {
	        seguimientoDto.setFecha(FechaServiceImpl.getFechaActual());
	        seguimientoDto.setHora(FechaServiceImpl.getHoraActual());
	        
			SeguimientoSolicitudesEyE seguimientoGuardado = seguimientoSolicitudesEyeService.save(SeguimientoSolicitudesEyE.fromSeguimientoSolicitudesDTO(seguimientoDto));

			HttpHeaders headers = new HttpHeaders();
			headers.setLocation(builder.path(HEADERBACK)
					.buildAndExpand(String.valueOf(seguimientoGuardado.getIdSeguimiento())).toUri());

			SeguimientoSolicitudesEyEDTO output = seguimientoGuardado.toSeguimientoSolicitudesDTO();
			return new ResponseEntity<>(output, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return ResponseEntity.internalServerError().body(new ResponseDTO(e.getLocalizedMessage()));
		}
	}
	
	@ApiOperation(value = "Consulta el seguimiento en SAP")
	@ApiResponses(value = {
	    @ApiResponse(code = 200, message = "Datos de seguimiento obtenidos", response = SeguimientoDTO.class),
	    @ApiResponse(code = 404, message = "No encontrado", response = ResponseDTO.class),
	    @ApiResponse(code = 500, message = "Error al consultar", response = ResponseDTO.class)
	})
	@GetMapping("/seguimiento/{folio}")
	public ResponseEntity<?> consultarSeguimientoSap(
	        @ApiParam(value = "Folio para consultar el seguimiento en SAP", required = true) 
	        @PathVariable Integer folio) {
	    try {
	        SeguimientoDTO seguimiento = seguimientoSolicitudesEyeService.consultarSeguimientoSap(folio);
	        if (seguimiento != null) {
	            return ResponseEntity.ok(seguimiento);
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                    .body(new ResponseDTO("No se encontró información para el folio proporcionado"));
	        }
	    } catch (Exception e) {
	        log.error("/seguimiento/{folio}", e);
	        return ResponseEntity.internalServerError()
	                .body(new ResponseDTO(e.getLocalizedMessage()));
	    }
	}
	
	@ApiOperation(value = "Consulta el estatus del modulo")
	@ApiResponses(value = {
	    @ApiResponse(code = 200, message = "Estatus del modulo obtenido", response = Integer.class),
	    @ApiResponse(code = 500, message = "Error al consultar", response = ResponseDTO.class)
	})
	@GetMapping("/getSemaforo")
	public int getSemaforo(
		@ApiParam(value = "Id del sistema", required = true)
		@RequestParam int idSistema,
		@ApiParam(value = "Id del modulo", required = true)
		@RequestParam int idModulo
	) {
		try {
			int estatusModulo = seguimientoSolicitudesEyeService.getSemaforo(idSistema, idModulo);
			return estatusModulo;
		} catch (Exception e) {
			log.error(HEADERBACK, e);
			return 0;
		}
	}
	

	@ApiOperation(value = "Insertar entrada con base a estatus SAP")
	@ApiResponses(value = {
	    @ApiResponse(code = 200, message = "Operacion realiza", response =  ResponseDTO.class),
	    @ApiResponse(code = 404, message = "No encontrado", response = ResponseDTO.class),
	    @ApiResponse(code = 500, message = "Error al realizar operacion", response = ResponseDTO.class)
	})
	@GetMapping("/checarEstatus")
	public ResponseEntity<?> checarEstatusSap(){
		 try {
			 	List<EntradaMaterial> lstEntradas = new ArrayList<>();
 				int estatusModulo = seguimientoSolicitudesEyeService.getSemaforo(18, 96);
				
				if(estatusModulo != 1) { 
		            return ResponseEntity.ok(lstEntradas);
				}
				
				List<ReporteSolicitudesMaterial> lstSolicitudes = solicitudesEyeService.getReporteSolicitudesAutorizadasSolidaParcial();
				seguimientoSolicitudesEyeService.updateSemaforo(18, 96, 4);
				for (ReporteSolicitudesMaterial solicitud : lstSolicitudes) {
					SeguimientoDTO seguimiento = seguimientoSolicitudesEyeService.consultarSeguimientosSap(solicitud.getFolio());
					if (seguimiento != null && seguimiento.getTipoSolicitud() != null) {
						SolicitudesEyE solicitudActual = solicitudesEyeService.getSolicitudById(solicitud.getIdSolicitud());
						int estatus = seguimiento.getTipoSolicitud().equals("Parcial") ? 5 : 4;

						if (solicitudActual.getIdEstatus() != estatus) {
							solicitudActual.setIdEstatus(estatus);
							solicitudesEyeService.update(solicitudActual);
							SeguimientoSolicitudesEyEDTO seguimientoSolicitud = new SeguimientoSolicitudesEyEDTO();
							seguimientoSolicitud.setFecha(FechaServiceImpl.getFechaActual());
							seguimientoSolicitud.setHora(FechaServiceImpl.getHoraActual());
							seguimientoSolicitud.setIdEstatus(estatus);
							seguimientoSolicitud.setIdSolicitud(solicitud.getIdSolicitud().intValue());
							seguimientoSolicitud.setIdPersonal(solicitud.getIdPersonal());
							seguimientoSolicitud.setIdOficina(solicitud.getIdOficina());
							seguimientoSolicitudesEyeService.save(SeguimientoSolicitudesEyE.fromSeguimientoSolicitudesDTO(seguimientoSolicitud));
							if(estatus == 4) { 

								if(solicitudActual.getTipoSolicitud().equals("venta")){
									for(TalonesMaterialVenta talon : solicitudesEyeService.getTalonesMaterialVenta(solicitudActual.getIdSolicitud().toString())) {
										MaterialesEyE material = materialesEyeService.getMaterialesNombre(talon.getClaveMaterial());
										EntradaMaterial entrada = new EntradaMaterial();
										entrada.setCantidad(materialesEyeService.convertirCantidad(material.getNombre(), talon.getCantidadSolicitada(), talon.getUnidadMedida()));
										entrada.setIdMaterial((int) talon.getIdMaterial());
										entrada.setIdPersonal(solicitud.getIdPersonal());
										entrada.setFechaModificacion(FechaServiceImpl.getFechaActual());
										entrada.setHoraModificacion(FechaServiceImpl.getHoraActual());
										entrada.setPrecioCompra(material.getPrecioCompra());
										entrada.setIdTipoMovimiento(8);
										entrada.setNumeroNota("0");
										entrada.setIdPoliza(-2);
										entrada.setIdOficina(solicitud.getOficina());
										lstEntradas.add(entrada);
										materialesEyeService.guardarEntradaMaterial(solicitud.getOficina(),entrada);
									} 

								} else {
									for(TalonesMaterialVentaDTO talon : solicitudesEyeService.getTalonesMaterialReacondicionamientoSeguimiento(solicitudActual.getIdSolicitud().toString())) {
										MaterialesEyE material = materialesEyeService.getMaterialesNombre(talon.getClaveMaterial());
										EntradaMaterial entrada = new EntradaMaterial();
										entrada.setCantidad(materialesEyeService.convertirCantidad(material.getNombre(), materialesEyeService.calcularCantidad((int) talon.getIdMaterial(), talon.getCantidadSolicitada()) , materialesEyeService.convertirUnidadMedida((int) talon.getIdMaterial(),talon.getUnidadMedida())));
										entrada.setIdMaterial((int) talon.getIdMaterial());
										entrada.setIdPersonal(solicitud.getIdPersonal());
										entrada.setFechaModificacion(FechaServiceImpl.getFechaActual());
										entrada.setHoraModificacion(FechaServiceImpl.getHoraActual());
										entrada.setPrecioCompra(material.getPrecioCompra());
										entrada.setIdTipoMovimiento(8);
										entrada.setNumeroNota("0");
										entrada.setIdPoliza(-2);
										entrada.setIdOficina(solicitud.getOficina());
										lstEntradas.add(entrada);
										materialesEyeService.guardarEntradaMaterial(solicitud.getOficina(),entrada);
									}
									
								}


							}

						}

					}
				   }
					seguimientoSolicitudesEyeService.updateSemaforo(18, 96, 1);
		            return ResponseEntity.ok(lstEntradas);
			    }catch (Exception e) {
		        log.error("/checarEstatus", e);
				seguimientoSolicitudesEyeService.updateSemaforo(18, 96, 1);
		        return ResponseEntity.internalServerError()
		                .body(new ResponseDTO(e.getLocalizedMessage()));
		    }
	}
	
}
