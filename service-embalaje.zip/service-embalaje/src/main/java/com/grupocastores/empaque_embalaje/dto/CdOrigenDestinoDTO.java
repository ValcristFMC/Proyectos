package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de la ciudad destino/origen", description = "Datos de la ciudad destino/origen")
public class CdOrigenDestinoDTO {

	private Long idCiudad;
	private int idEstado;
	private String ciudad;
	private String estado;
	
	public CdOrigenDestinoDTO(Long idCiudad, int idEstado, String ciudad, String estado) {
		this.idCiudad = idCiudad;
		this.idEstado = idEstado;
		this.ciudad = ciudad;
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "CdOrigenDestinoDTO [idCiudad=" + idCiudad + ", idEstado=" + idEstado + ", ciudad=" + ciudad
				+ ", estado=" + estado + "]";
	}	
}
