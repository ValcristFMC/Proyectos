package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.CdOrigenDestinoDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(CdOrigenDestino.class)
public class CdOrigenDestino {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id_ciudad")
	private Long idCiudad;
	
	@Column(name = "Id_estado")
	private int idEstado;
	
	@Column(name = "Ciudad")
	private String ciudad;
	
	@Column(name = "Estado")
	private String estado;
	
	public static CdOrigenDestino fromCdOrigenDestinoDTO(CdOrigenDestinoDTO cdOrigenDestinoDTO) {
        CdOrigenDestino cdOrigenDestino = new CdOrigenDestino();
        cdOrigenDestino.setIdCiudad(cdOrigenDestinoDTO.getIdCiudad());
        cdOrigenDestino.setIdEstado(cdOrigenDestinoDTO.getIdEstado());
        cdOrigenDestino.setCiudad(cdOrigenDestinoDTO.getCiudad());
        cdOrigenDestino.setEstado(cdOrigenDestinoDTO.getEstado());
        return cdOrigenDestino;
    }
	
	public CdOrigenDestinoDTO toCdOrigenDestinoDTO() {
        CdOrigenDestinoDTO cdOrigenDestinoDTO = new CdOrigenDestinoDTO();
        cdOrigenDestinoDTO.setIdCiudad(this.getIdCiudad());
        cdOrigenDestinoDTO.setIdEstado(this.getIdEstado());
        cdOrigenDestinoDTO.setCiudad(this.getCiudad());
        cdOrigenDestinoDTO.setEstado(this.getEstado());
        return cdOrigenDestinoDTO;
    }
}
