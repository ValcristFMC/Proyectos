package com.grupocastores.empaque_embalaje.service.repository;

import java.time.temporal.Temporal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.CatalogoConceptoImporte;
import com.grupocastores.empaque_embalaje.service.domain.Co;
import com.grupocastores.empaque_embalaje.service.domain.Detatr;
import com.grupocastores.empaque_embalaje.service.domain.MaterialesEyE;
import com.grupocastores.empaque_embalaje.service.domain.MetodoPago;
import com.grupocastores.empaque_embalaje.service.domain.ParametrosSistema;
import com.grupocastores.empaque_embalaje.service.domain.Talones;
import com.grupocastores.empaque_embalaje.service.domain.TalonesParametros;
import com.grupocastores.empaque_embalaje.service.domain.Tr;
import com.grupocastores.empaque_embalaje.service.domain.UnidadMedida;
import com.grupocastores.empaque_embalaje.utils.UtilitiesRepository;

@Repository
public class TalonesRepository {

	Logger log = LoggerFactory.getLogger(TalonesRepository.class);

	@PersistenceContext
	private EntityManager entityManager;

	public static final String db23 = "PRODUCCION23";
	public static final String db13 = "PRODUCCION13";

	@Autowired
	private UtilitiesRepository utilitiesRepository;

	static final String QUERY_GET_TALONES_BY_CLA_TALON = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.talones WHERE cla_talon = \"%s\"');";
	static final String QUERY_GET_TR_BY_CLA_TALON = "SELECT * FROM OPENQUERY (%s, 'SELECT cla_talon,tp_dc,reembarque,fecha,hora,remision,no_guia,fecha_envio,idpersonal,rfcorigen,nomorigen,calleorigen,coloniaorigen,cporigen,telorigen,cdorigen,depenorigen,rfcdestino,nomdestino,calledestino,coloniadestino,cpdestino,teldestino,cddestino,dependestino,serecogera,seentregara,cpt,val_decl,porseguro,tipopago,talon_a_sust,idconvenio,suma_flete,por_descuento,iva_ret,poliza,casetas,recoleccion,entrega,maniobras,otroscargos,gps,iva,otras_lineas,observaciones,idoficina,callerec,noextrec,nointrec,colrec,delrec,cprec,telrec,calledes,noextdes,nointdes,coldes,deldes,cpdes,teldes,ubicacion,serie,tiporemitente,idremitente,tipodestinatario,iddestinatario,completo,obsotros,ocurre,noextrte,nointrte,noextdest,nointdest,idcdrec,idcddes,cmt,tipounidad,idprecio_diesel,cpac,ferry,idofirte,idofidest,idsucrte,idsucdest,revac,importeseguro,importesubtotal,importeiva,importeiva_ret,importetotal,estatussat,iddocumentosat,idclasificaciondoc, \" \" AS nombre_tipo_documento  FROM talones.tr%s WHERE cla_talon = %s');";
	static final String QUERY_GET_TALON_PARAMETRO_BY_ID_PARAMETRO = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.parametros WHERE idparametro = %s');";
	static final String QUERY_GET_DETA_TR_BY_CLA_TALON = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.detatr WHERE cla_talon = %s');";
	static final String QUERY_GET_METODO_PAGO_BY_ID = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM clientes.metodopago WHERE idmetodopago = %s');";
	static final String QUERY_GET_METODO_PAGO_BY_CLAVE = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM clientes.metodopago WHERE clave IN(%s)');";
	static final String QUERY_GET_CATALOGO_CONCEPTO_IMPORTE_BY_PARAMS = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.catalogo_concepto_importe%s "
			+ "WHERE idconcepto = %s AND cla_talon = \"%s\"');";
	static final String QUERY_GET_QUE_CONTIENE = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.co%s WHERE cla_talon = \"%s\"');";
	static final String QUERY_GET_MATERIALES = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.materiales WHERE nombre != \"\" AND estatus = 1 AND  idmaterial NOT IN(\"18\") UNION SELECT * FROM talones.materiales_eye  WHERE nombre != \"\" AND estatus = 1')";
	static final String QUERY_GET_MATERIALES_BY_NOMBRE = "SELECT * FROM OPENQUERY (%s,'SELECT * FROM  talones.materiales WHERE nombre != \"\" AND estatus = 1 AND nombre IN(%s) AND  idmaterial NOT IN(\"18\") UNION SELECT * FROM  talones.materiales_eye WHERE nombre != \"\" AND estatus = 1 AND nombre IN(%s)')";
	static final String QUERY_GET_UNIDADES_MEDIDA = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.unidadmedida')";
	static final String QUERY_GET_MATERIALES_BY_CLAVE = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM talones.materiales WHERE clavematerial = %s AND estatus = 1 UNION SELECT * FROM  talones.materiales_eye WHERE clavematerial = %s AND estatus = 1')";

	static final String QUERY_GET_PARAMETROS_SISTEMA = "SELECT * FROM OPENQUERY (%s, 'SELECT * FROM castores.parametros_sistemas WHERE idsistema=%s AND idparametro IN (%s) ORDER BY idparametro ASC')";

	public Talones getTalonesByClaTalon(String claTalon) {
		Query query = entityManager.createNativeQuery(
				String.format(QUERY_GET_TALONES_BY_CLA_TALON, db23, claTalon, utilitiesRepository.getDb23()),
				Talones.class);

		if (query.getResultList().size() > 0) {
			return (Talones) query.getResultList().get(0);
		} else {
			Talones talon = new Talones();
			return talon;
		}
	}

	public Tr getTrByClaTalon(String tabla, String claTalon) {
		Query query = entityManager.createNativeQuery(
				String.format(QUERY_GET_TR_BY_CLA_TALON, db23, tabla, claTalon, utilitiesRepository.getDb23()),
				Tr.class);
		if (query.getResultList().size() > 0) {
			return (Tr) query.getResultList().get(0);
		} else {
			Tr tr = new Tr();
			return tr;
		}
	}

	public TalonesParametros getTalonesParametrosByIdParametro(int idParametro) {
		Query query = entityManager.createNativeQuery(String.format(QUERY_GET_TALON_PARAMETRO_BY_ID_PARAMETRO, db23,
				idParametro, utilitiesRepository.getDb23()), TalonesParametros.class);
		return (TalonesParametros) query.getResultList().get(0);
	}

	public Detatr getDetatrByClaTalon(String claTalon) {
		Query query = entityManager.createNativeQuery(
				String.format(QUERY_GET_DETA_TR_BY_CLA_TALON, db23, claTalon, utilitiesRepository.getDb23()),
				Detatr.class);

		if (query.getResultList().size() > 0) {
			return (Detatr) query.getResultList().get(0);
		} else {
			Detatr detatr = new Detatr();
			return detatr;
		}
	}

	public MetodoPago getMetodoPagoById(String idMetodoPago) {
		Query query = entityManager.createNativeQuery(
				String.format(QUERY_GET_METODO_PAGO_BY_ID, db23, idMetodoPago, utilitiesRepository.getDb23()),
				MetodoPago.class);
		return (MetodoPago) query.getResultList().get(0);
	}

	public MetodoPago getMetodoPagoByClave(String idMetodoPago) {
		Query query = entityManager.createNativeQuery(
				String.format(QUERY_GET_METODO_PAGO_BY_CLAVE, db23, idMetodoPago, utilitiesRepository.getDb23()),
				MetodoPago.class);
		return (MetodoPago) query.getResultList().get(0);
	}

	public CatalogoConceptoImporte getCatalogoConceptoImporteByParams(String tabla, String idConcepto,
			String claTalon) {
		Query query = entityManager.createNativeQuery(String.format(QUERY_GET_CATALOGO_CONCEPTO_IMPORTE_BY_PARAMS, db23,
				tabla, idConcepto, claTalon, utilitiesRepository.getDb23()), CatalogoConceptoImporte.class);

		if (query.getResultList().size() > 0) {
			return (CatalogoConceptoImporte) query.getResultList().get(0);
		} else {
			CatalogoConceptoImporte catalogo = new CatalogoConceptoImporte();
			return catalogo;
		}
	}

	public List<Co> getQueContiene(String tabla, String claTalon) {
		Query query = entityManager.createNativeQuery(
				String.format(QUERY_GET_QUE_CONTIENE, db23, tabla, claTalon, utilitiesRepository.getDb23()), Co.class);

		if (query.getResultList().size() > 0) {
			return (List<Co>) query.getResultList();
		} else {
			List<Co> lstTablaCo = new ArrayList<>();
			return lstTablaCo;
		}
	}

	public List<MaterialesEyE> getMaterialesByNombre(Collection<String> materiales) {
		try {
			String cadenaMat = "";
			int contador = 1;

			for (String material : materiales) {
				cadenaMat = cadenaMat + '"' + material + '"';

				if (contador < materiales.size()) {
					cadenaMat = cadenaMat + ", ";
				}

				contador++;
			}

			Query query = entityManager.createNativeQuery(String.format(QUERY_GET_MATERIALES_BY_NOMBRE, db23, cadenaMat,
					cadenaMat, utilitiesRepository.getDb23()), MaterialesEyE.class);

			if (query.getResultList().size() > 0) {
				return (List<MaterialesEyE>) query.getResultList();
			} else {
				List<MaterialesEyE> lstMateriales = new ArrayList<>();
				return lstMateriales;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			List<MaterialesEyE> lstMateriales = new ArrayList<>();
			return lstMateriales;
		}
	}

	public List<UnidadMedida> getUnidadesMedida() {
		try {
			Query query = entityManager.createNativeQuery(
					String.format(QUERY_GET_UNIDADES_MEDIDA, db23, utilitiesRepository.getDb23()), UnidadMedida.class);

			if (query.getResultList().size() > 0) {
				return (List<UnidadMedida>) query.getResultList();
			} else {
				List<UnidadMedida> lstUnidades = new ArrayList<>();
				return lstUnidades;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			List<UnidadMedida> lstUnidades = new ArrayList<>();
			return lstUnidades;
		}
	}

	public List<MaterialesEyE> getMateriales() {
		try {
			Query query = entityManager.createNativeQuery(
					String.format(QUERY_GET_MATERIALES, db23, utilitiesRepository.getDb23()), MaterialesEyE.class);

			if (query.getResultList().size() > 0) {
				return (List<MaterialesEyE>) query.getResultList();
			} else {
				List<MaterialesEyE> lstMateriales = new ArrayList<>();
				return lstMateriales;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			List<MaterialesEyE> lstMateriales = new ArrayList<>();
			return lstMateriales;
		}
	}

	public MaterialesEyE getMaterialesNombre(int idClave) {
		try {
			MaterialesEyE material = new MaterialesEyE();

			Query query = entityManager.createNativeQuery(
					String.format(QUERY_GET_MATERIALES_BY_CLAVE, db23, idClave, idClave, utilitiesRepository.getDb23()),
					MaterialesEyE.class);

			material = (MaterialesEyE) ((javax.persistence.Query) query).getResultList().get(0);

			return material;

		} catch (Exception e) {
			log.error(e.getMessage());
			MaterialesEyE material = new MaterialesEyE();
			return material;
		}
	}

	public List<ParametrosSistema> getParametros(int idSitema, String parametros) {
		try {
			Query query = entityManager.createNativeQuery(String.format(QUERY_GET_PARAMETROS_SISTEMA, db13, idSitema,
					parametros, utilitiesRepository.getDb13()), ParametrosSistema.class);

			if (query.getResultList().size() > 0) {
				return (List<ParametrosSistema>) query.getResultList();
			} else {
				List<ParametrosSistema> lstParametros = new ArrayList<>();
				return lstParametros;
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			List<ParametrosSistema> lstParametros = new ArrayList<>();
			return lstParametros;
		}
	}
}
