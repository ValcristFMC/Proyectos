package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.MetodoPagoDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "metodopago")
@EntityListeners(MetodoPago.class)
public class MetodoPago {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idmetodopago")
	private String idMetodoPago;
	
	@Column(name = "descripcion")
	private String descripcion;
	
	@Column(name = "fecha")
	private String fecha;
	
	@Column(name = "hora")
	private String hora;
	
	@Column(name = "estatus")
	private int estatus;
	
	@Column(name = "clave")
	private String clave;
	
	public static MetodoPago fromMetodoPagoDTO(MetodoPagoDTO metodoPagoDTO) {
	    MetodoPago metodoPago = new MetodoPago();
	    metodoPago.setIdMetodoPago(metodoPagoDTO.getIdMetodoPago());
	    metodoPago.setDescripcion(metodoPagoDTO.getDescripcion());
	    metodoPago.setFecha(metodoPagoDTO.getFecha());
	    metodoPago.setHora(metodoPagoDTO.getHora());
	    metodoPago.setEstatus(metodoPagoDTO.getEstatus());
	    metodoPago.setClave(metodoPagoDTO.getClave());
	    return metodoPago;
	}

	public MetodoPagoDTO toMetodoPagoDTO() {
	    MetodoPagoDTO metodoPagoDTO = new MetodoPagoDTO();
	    metodoPagoDTO.setIdMetodoPago(this.getIdMetodoPago());
	    metodoPagoDTO.setDescripcion(this.getDescripcion());
	    metodoPagoDTO.setFecha(this.getFecha());
	    metodoPagoDTO.setHora(this.getHora());
	    metodoPagoDTO.setEstatus(this.getEstatus());
	    metodoPagoDTO.setClave(this.getClave());
	    return metodoPagoDTO;
	}

}
