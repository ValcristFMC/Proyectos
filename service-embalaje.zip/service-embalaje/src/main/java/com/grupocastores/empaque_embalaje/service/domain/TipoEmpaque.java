package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.TipoEmpaqueDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "tipo_empaque")
@EntityListeners(TipoEmpaque.class)
public class TipoEmpaque {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_tipo_empaque")
	private int idTipoEmpaque;
	
	@Column(name = "clave")
    private int clave;
	
	@Column(name = "nombre")
    private String nombre;
	
	@Column(name = "descripcion")
    private String descripcion;
	
	@Column(name = "id_estatus_tipo_empaque")
    private int IdEstatusTipoEmpaque;
	
	@Column(name = "fecha_registro")
    private String fechaRegistro;
	
	@Column(name = "fecha_modificacion")
    private String fechaModificacion;
	
	@Column(name = "id_usuario_modificacion")
    private int idUsuarioModificacion;
	
	@Column(name = "id_sat_clave_unidad")
    private int idSatClaveUnidad;
    
    public static TipoEmpaque fromTipoEmpaqueDTO(TipoEmpaqueDTO tipoEmpaqueDto) {
    	TipoEmpaque tipoEmpaque = new TipoEmpaque();
    	tipoEmpaque.setIdTipoEmpaque(tipoEmpaqueDto.getIdTipoEmpaque());
    	tipoEmpaque.setClave(tipoEmpaqueDto.getClave());
    	tipoEmpaque.setNombre(tipoEmpaqueDto.getNombre());
    	tipoEmpaque.setDescripcion(tipoEmpaqueDto.getDescripcion());
    	tipoEmpaque.setIdEstatusTipoEmpaque(tipoEmpaqueDto.getIdEstatusTipoEmpaque());
    	tipoEmpaque.setFechaRegistro(tipoEmpaqueDto.getFechaRegistro());
    	tipoEmpaque.setFechaModificacion(tipoEmpaqueDto.getFechaModificacion());
    	tipoEmpaque.setIdUsuarioModificacion(tipoEmpaqueDto.getIdUsuarioModificacion());
    	tipoEmpaque.setIdSatClaveUnidad(tipoEmpaqueDto.getIdSatClaveUnidad());
    	
    	return tipoEmpaque;
    }
    
    public TipoEmpaqueDTO toTipoEmpaqueDTO() {
    	TipoEmpaqueDTO dtoTipoEmpaque = new TipoEmpaqueDTO();
    	dtoTipoEmpaque.setIdTipoEmpaque(this.getIdTipoEmpaque());
    	dtoTipoEmpaque.setClave(this.getClave());
    	dtoTipoEmpaque.setNombre(this.getNombre());
    	dtoTipoEmpaque.setDescripcion(this.getDescripcion());
    	dtoTipoEmpaque.setIdEstatusTipoEmpaque(this.getIdEstatusTipoEmpaque());
    	dtoTipoEmpaque.setFechaRegistro(this.getFechaRegistro());
    	dtoTipoEmpaque.setFechaModificacion(this.getFechaModificacion());
    	dtoTipoEmpaque.setIdUsuarioModificacion(this.getIdUsuarioModificacion());
    	dtoTipoEmpaque.setIdSatClaveUnidad(this.getIdSatClaveUnidad());
    	
    	return dtoTipoEmpaque;
    }
}
