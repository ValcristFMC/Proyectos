package com.grupocastores.empaque_embalaje.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.EmpaqueUtilizado;

@Repository
public interface EmpaqueUtilizadoRepository extends JpaRepository<EmpaqueUtilizado, Integer> {

	static final String QUERY_GET_EMPAQUES_UTILIZADOS = "SELECT * FROM empaques_utilizados WHERE Id_solicitud = :idSolicitud AND Id_oficina = :idOficina";
	
	@Query(value = QUERY_GET_EMPAQUES_UTILIZADOS, nativeQuery = true)
	List<EmpaqueUtilizado> getEmpaquesUtilizados(int idSolicitud, int idOficina);
}
