package com.grupocastores.empaque_embalaje.service.domain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.TrDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(Tr.class)
public class Tr {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cla_talon")
	private String claTalon;

	@Column(name = "tp_dc")
	private int tpDc;

	@Column(name = "reembarque")
	private int reembarque;

	@Column(name = "fecha")
	private String fecha;

	@Column(name = "hora")
	private String hora;

	@Column(name = "remision")
	private String remision;

	@Column(name = "no_guia")
	private String noGuia;

	@Column(name = "fecha_envio")
	private String fechaEnvio;

	@Column(name = "idpersonal")
	private int idPersonal;

	@Column(name = "rfcorigen")
	private String rfcOrigen;

	@Column(name = "nomorigen")
	private String nomOrigen;

	@Column(name = "calleorigen")
	private String calleOrigen;

	@Column(name = "coloniaorigen")
	private String coloniaOrigen;

	@Column(name = "cporigen")
	private String cpOrigen;

	@Column(name = "telorigen")
	private String telOrigen;

	@Column(name = "cdorigen")
	private int cdOrigen;

	@Column(name = "depenorigen")
	private int depenOrigen;

	@Column(name = "rfcdestino")
	private String rfcDestino;

	@Column(name = "nomdestino")
	private String nomDestino;

	@Column(name = "calledestino")
	private String calleDestino;

	@Column(name = "coloniadestino")
	private String coloniaDestino;

	@Column(name = "cpdestino")
	private String cpDestino;

	@Column(name = "teldestino")
	private String telDestino;

	@Column(name = "cddestino")
	private int cdDestino;

	@Column(name = "dependestino")
	private int depenDestino;

	@Column(name = "serecogera")
	private String seRecogera;

	@Column(name = "seentregara")
	private String seEntregara;

	@Column(name = "cpt")
	private BigDecimal cpt;

	@Column(name = "val_decl")
	private BigDecimal valDecl;

	@Column(name = "porseguro")
	private BigDecimal porSeguro;

	@Column(name = "tipopago")
	private int tipoPago;

	@Column(name = "talon_a_sust")
	private String talonASust;

	@Column(name = "idconvenio")
	private Integer idConvenio;

	@Column(name = "suma_flete")
	private BigDecimal sumaFlete;

	@Column(name = "por_descuento")
	private BigDecimal porDescuento;

	@Column(name = "iva_ret")
	private BigDecimal ivaRet;

	@Column(name = "poliza")
	private String poliza;

	@Column(name = "casetas")
	private BigDecimal casetas;

	@Column(name = "recoleccion")
	private BigDecimal recoleccion;

	@Column(name = "entrega")
	private BigDecimal entrega;

	@Column(name = "maniobras")
	private BigDecimal maniobras;

	@Column(name = "otroscargos")
	private BigDecimal otrosCargos;

	@Column(name = "gps")
	private BigDecimal gps;

	@Column(name = "iva")
	private BigDecimal iva;

	@Column(name = "otras_lineas")
	private BigDecimal otrasLineas;

	@Column(name = "observaciones")
	private String observaciones;

	@Column(name = "idoficina")
	private String idOficina;

	@Column(name = "callerec")
	private String calleRec;

	@Column(name = "noextrec")
	private String noExtRec;

	@Column(name = "nointrec")
	private String noIntRec;

	@Column(name = "colrec")
	private String colRec;

	@Column(name = "delrec")
	private String delRec;

	@Column(name = "cprec")
	private String cpRec;

	@Column(name = "telrec")
	private String telRec;

	@Column(name = "calledes")
	private String calleDes;

	@Column(name = "noextdes")
	private String noExtDes;

	@Column(name = "nointdes")
	private String noIntDes;

	@Column(name = "coldes")
	private String colDes;

	@Column(name = "deldes")
	private String delDes;

	@Column(name = "cpdes")
	private String cpDes;

	@Column(name = "teldes")
	private String telDes;

	@Column(name = "ubicacion")
	private String ubicacion;

	@Column(name = "serie")
	private String serie;

	@Column(name = "tiporemitente")
	private int tipoRemitente;

	@Column(name = "idremitente")
	private int idRemitente;

	@Column(name = "tipodestinatario")
	private int tipoDestinatario;

	@Column(name = "iddestinatario")
	private int idDestinatario;

	@Column(name = "completo")
	private int completo;

	@Column(name = "obsotros")
	private String obsOtros;

	@Column(name = "ocurre")
	private int ocurre;

	@Column(name = "noextrte")
	private String noExtRte;

	@Column(name = "nointrte")
	private String noIntRte;

	@Column(name = "noextdest")
	private String noExtDest;

	@Column(name = "nointdest")
	private String noIntDest;

	@Column(name = "idcdrec")
	private int idCdRec;

	@Column(name = "idcddes")
	private int idCdDes;

	@Column(name = "cmt")
	private double cmt;

	@Column(name = "tipounidad")
	private int tipoUnidad;

	@Column(name = "idprecio_diesel")
	private int idPrecioDiesel;

	@Column(name = "cpac")
	private BigDecimal cpac;

	@Column(name = "ferry")
	private BigDecimal ferry;

	@Column(name = "idofirte")
	private String idOfIrte;

	@Column(name = "idofidest")
	private String idOfIdest;

	@Column(name = "idsucrte")
	private int idSucRte;

	@Column(name = "idsucdest")
	private int idSucDest;

	@Column(name = "revac")
	private BigDecimal revac;

	@Column(name = "importeseguro")
	private BigDecimal importeSeguro;

	@Column(name = "importesubtotal")
	private BigDecimal importeSubtotal;

	@Column(name = "importeiva")
	private BigDecimal importeIva;

	@Column(name = "importeiva_ret")
	private BigDecimal importeIvaRet;

	@Column(name = "importetotal")
	private BigDecimal importeTotal;

	@Column(name = "estatussat")
	private int estatusSat;

	@Column(name = "iddocumentosat")
	private int idDocumentoSat;

	@Column(name = "idclasificaciondoc")
	private int idClasificacionDoc;
	
	@Column(name = "nombre_tipo_documento")
	private String nombreTipoDocumento;
	
	public static Tr fromTrDTO(TrDTO trDTO) {
	    Tr tr = new Tr();
	    tr.setClaTalon(trDTO.getClaTalon());
	    tr.setTpDc(trDTO.getTpDc());
	    tr.setReembarque(trDTO.getReembarque());
	    tr.setFecha(trDTO.getFecha());
	    tr.setHora(trDTO.getHora());
	    tr.setRemision(trDTO.getRemision());
	    tr.setNoGuia(trDTO.getNoGuia());
	    tr.setFechaEnvio(trDTO.getFechaEnvio());
	    tr.setIdPersonal(trDTO.getIdPersonal());
	    tr.setRfcOrigen(trDTO.getRfcOrigen());
	    tr.setNomOrigen(trDTO.getNomOrigen());
	    tr.setCalleOrigen(trDTO.getCalleOrigen());
	    tr.setColoniaOrigen(trDTO.getColoniaOrigen());
	    tr.setCpOrigen(trDTO.getCpOrigen());
	    tr.setTelOrigen(trDTO.getTelOrigen());
	    tr.setCdOrigen(trDTO.getCdOrigen());
	    tr.setDepenOrigen(trDTO.getDepenOrigen());
	    tr.setRfcDestino(trDTO.getRfcDestino());
	    tr.setNomDestino(trDTO.getNomDestino());
	    tr.setCalleDestino(trDTO.getCalleDestino());
	    tr.setColoniaDestino(trDTO.getColoniaDestino());
	    tr.setCpDestino(trDTO.getCpDestino());
	    tr.setTelDestino(trDTO.getTelDestino());
	    tr.setCdDestino(trDTO.getCdDestino());
	    tr.setDepenDestino(trDTO.getDepenDestino());
	    tr.setSeRecogera(trDTO.getSeRecogera());
	    tr.setSeEntregara(trDTO.getSeEntregara());
	    tr.setCpt(trDTO.getCpt());
	    tr.setValDecl(trDTO.getValDecl());
	    tr.setPorSeguro(trDTO.getPorSeguro());
	    tr.setTipoPago(trDTO.getTipoPago());
	    tr.setTalonASust(trDTO.getTalonASust());
	    tr.setIdConvenio(trDTO.getIdConvenio());
	    tr.setSumaFlete(trDTO.getSumaFlete());
	    tr.setPorDescuento(trDTO.getPorDescuento());
	    tr.setIvaRet(trDTO.getIvaRet());
	    tr.setPoliza(trDTO.getPoliza());
	    tr.setCasetas(trDTO.getCasetas());
	    tr.setRecoleccion(trDTO.getRecoleccion());
	    tr.setEntrega(trDTO.getEntrega());
	    tr.setManiobras(trDTO.getManiobras());
	    tr.setOtrosCargos(trDTO.getOtrosCargos());
	    tr.setGps(trDTO.getGps());
	    tr.setIva(trDTO.getIva());
	    tr.setOtrasLineas(trDTO.getOtrasLineas());
	    tr.setObservaciones(trDTO.getObservaciones());
	    tr.setIdOficina(trDTO.getIdOficina());
	    tr.setCalleRec(trDTO.getCalleRec());
	    tr.setNoExtRec(trDTO.getNoExtRec());
	    tr.setNoIntRec(trDTO.getNoIntRec());
	    tr.setColRec(trDTO.getColRec());
	    tr.setDelRec(trDTO.getDelRec());
	    tr.setCpRec(trDTO.getCpRec());
	    tr.setTelRec(trDTO.getTelRec());
	    tr.setCalleDes(trDTO.getCalleDes());
	    tr.setNoExtDes(trDTO.getNoExtDes());
	    tr.setNoIntDes(trDTO.getNoIntDes());
	    tr.setColDes(trDTO.getColDes());
	    tr.setDelDes(trDTO.getDelDes());
	    tr.setCpDes(trDTO.getCpDes());
	    tr.setTelDes(trDTO.getTelDes());
	    tr.setUbicacion(trDTO.getUbicacion());
	    tr.setSerie(trDTO.getSerie());
	    tr.setTipoRemitente(trDTO.getTipoRemitente());
	    tr.setIdRemitente(trDTO.getIdRemitente());
	    tr.setTipoDestinatario(trDTO.getTipoDestinatario());
	    tr.setIdDestinatario(trDTO.getIdDestinatario());
	    tr.setCompleto(trDTO.getCompleto());
	    tr.setObsOtros(trDTO.getObsOtros());
	    tr.setOcurre(trDTO.getOcurre());
	    tr.setNoExtRte(trDTO.getNoExtRte());
	    tr.setNoIntRte(trDTO.getNoIntRte());
	    tr.setNoExtDest(trDTO.getNoExtDest());
	    tr.setNoIntDest(trDTO.getNoIntDest());
	    tr.setIdCdRec(trDTO.getIdCdRec());
	    tr.setIdCdDes(trDTO.getIdCdDes());
	    tr.setCmt(trDTO.getCmt());
	    tr.setTipoUnidad(trDTO.getTipoUnidad());
	    tr.setIdPrecioDiesel(trDTO.getIdPrecioDiesel());
	    tr.setCpac(trDTO.getCpac());
	    tr.setFerry(trDTO.getFerry());
	    tr.setIdOfIrte(trDTO.getIdOfIrte());
	    tr.setIdOfIdest(trDTO.getIdOfIdest());
	    tr.setIdSucRte(trDTO.getIdSucRte());
	    tr.setIdSucDest(trDTO.getIdSucDest());
	    tr.setRevac(trDTO.getRevac());
	    tr.setImporteSeguro(trDTO.getImporteSeguro());
	    tr.setImporteSubtotal(trDTO.getImporteSubtotal());
	    tr.setImporteIva(trDTO.getImporteIva());
	    tr.setImporteIvaRet(trDTO.getImporteIvaRet());
	    tr.setImporteTotal(trDTO.getImporteTotal());
	    tr.setEstatusSat(trDTO.getEstatusSat());
	    tr.setIdDocumentoSat(trDTO.getIdDocumentoSat());
	    tr.setIdClasificacionDoc(trDTO.getIdClasificacionDoc());
	    tr.setNombreTipoDocumento(trDTO.getNombreTipoDocumento());
	    
	    return tr;
	}
	
	public TrDTO toTrDTO() {
	    TrDTO trDTO = new TrDTO();
	    trDTO.setClaTalon(this.getClaTalon());
	    trDTO.setTpDc(this.getTpDc());
	    trDTO.setReembarque(this.getReembarque());
	    trDTO.setFecha(this.getFecha());
	    trDTO.setHora(this.getHora());
	    trDTO.setRemision(this.getRemision());
	    trDTO.setNoGuia(this.getNoGuia());
	    trDTO.setFechaEnvio(this.getFechaEnvio());
	    trDTO.setIdPersonal(this.getIdPersonal());
	    trDTO.setRfcOrigen(this.getRfcOrigen());
	    trDTO.setNomOrigen(this.getNomOrigen());
	    trDTO.setCalleOrigen(this.getCalleOrigen());
	    trDTO.setColoniaOrigen(this.getColoniaOrigen());
	    trDTO.setCpOrigen(this.getCpOrigen());
	    trDTO.setTelOrigen(this.getTelOrigen());
	    trDTO.setCdOrigen(this.getCdOrigen());
	    trDTO.setDepenOrigen(this.getDepenOrigen());
	    trDTO.setRfcDestino(this.getRfcDestino());
	    trDTO.setNomDestino(this.getNomDestino());
	    trDTO.setCalleDestino(this.getCalleDestino());
	    trDTO.setColoniaDestino(this.getColoniaDestino());
	    trDTO.setCpDestino(this.getCpDestino());
	    trDTO.setTelDestino(this.getTelDestino());
	    trDTO.setCdDestino(this.getCdDestino());
	    trDTO.setDepenDestino(this.getDepenDestino());
	    trDTO.setSeRecogera(this.getSeRecogera());
	    trDTO.setSeEntregara(this.getSeEntregara());
	    trDTO.setCpt(this.getCpt());
	    trDTO.setValDecl(this.getValDecl());
	    trDTO.setPorSeguro(this.getPorSeguro());
	    trDTO.setTipoPago(this.getTipoPago());
	    trDTO.setTalonASust(this.getTalonASust());
	    trDTO.setIdConvenio(this.getIdConvenio());
	    trDTO.setSumaFlete(this.getSumaFlete());
	    trDTO.setPorDescuento(this.getPorDescuento());
	    trDTO.setIvaRet(this.getIvaRet());
	    trDTO.setPoliza(this.getPoliza());
	    trDTO.setCasetas(this.getCasetas());
	    trDTO.setRecoleccion(this.getRecoleccion());
	    trDTO.setEntrega(this.getEntrega());
	    trDTO.setManiobras(this.getManiobras());
	    trDTO.setOtrosCargos(this.getOtrosCargos());
	    trDTO.setGps(this.getGps());
	    trDTO.setIva(this.getIva());
	    trDTO.setOtrasLineas(this.getOtrasLineas());
	    trDTO.setObservaciones(this.getObservaciones());
	    trDTO.setIdOficina(this.getIdOficina());
	    trDTO.setCalleRec(this.getCalleRec());
	    trDTO.setNoExtRec(this.getNoExtRec());
	    trDTO.setNoIntRec(this.getNoIntRec());
	    trDTO.setColRec(this.getColRec());
	    trDTO.setDelRec(this.getDelRec());
	    trDTO.setCpRec(this.getCpRec());
	    trDTO.setTelRec(this.getTelRec());
	    trDTO.setCalleDes(this.getCalleDes());
	    trDTO.setNoExtDes(this.getNoExtDes());
	    trDTO.setNoIntDes(this.getNoIntDes());
	    trDTO.setColDes(this.getColDes());
	    trDTO.setDelDes(this.getDelDes());
	    trDTO.setCpDes(this.getCpDes());
	    trDTO.setTelDes(this.getTelDes());
	    trDTO.setUbicacion(this.getUbicacion());
	    trDTO.setSerie(this.getSerie());
	    trDTO.setTipoRemitente(this.getTipoRemitente());
	    trDTO.setIdRemitente(this.getIdRemitente());
	    trDTO.setTipoDestinatario(this.getTipoDestinatario());
	    trDTO.setIdDestinatario(this.getIdDestinatario());
	    trDTO.setCompleto(this.getCompleto());
	    trDTO.setObsOtros(this.getObsOtros());
	    trDTO.setOcurre(this.getOcurre());
	    trDTO.setNoExtRte(this.getNoExtRte());
	    trDTO.setNoIntRte(this.getNoIntRte());
	    trDTO.setNoExtDest(this.getNoExtDest());
	    trDTO.setNoIntDest(this.getNoIntDest());
	    trDTO.setIdCdRec(this.getIdCdRec());
	    trDTO.setIdCdDes(this.getIdCdDes());
	    trDTO.setCmt(this.getCmt());
	    trDTO.setTipoUnidad(this.getTipoUnidad());
	    trDTO.setIdPrecioDiesel(this.getIdPrecioDiesel());
	    trDTO.setCpac(this.getCpac());
	    trDTO.setFerry(this.getFerry());
	    trDTO.setIdOfIrte(this.getIdOfIrte());
	    trDTO.setIdOfIdest(this.getIdOfIdest());
	    trDTO.setIdSucRte(this.getIdSucRte());
	    trDTO.setIdSucDest(this.getIdSucDest());
	    trDTO.setRevac(this.getRevac());
	    trDTO.setImporteSeguro(this.getImporteSeguro());
	    trDTO.setImporteSubtotal(this.getImporteSubtotal());
	    trDTO.setImporteIva(this.getImporteIva());
	    trDTO.setImporteIvaRet(this.getImporteIvaRet());
	    trDTO.setImporteTotal(this.getImporteTotal());
	    trDTO.setEstatusSat(this.getEstatusSat());
	    trDTO.setIdDocumentoSat(this.getIdDocumentoSat());
	    trDTO.setIdClasificacionDoc(this.getIdClasificacionDoc());
	    trDTO.setNombreTipoDocumento(trDTO.getNombreTipoDocumento());
	    
	    return trDTO;
	}

}
