package com.grupocastores.empaque_embalaje.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.CdOrigenDestino;

@Repository
public interface CdOrigenDestinoRepository extends JpaRepository<CdOrigenDestino, Long> {

	static final String QUERY_CIUDAD_ORIGEN_DESTINO = "SELECT c.id_ciudad AS Id_ciudad, e.id_estado AS Id_estado, "
			+ "CONCAT(TRIM(c.nombre), ', ', e.abreviacion) AS Ciudad, e.nombre AS Estado "
			+ "FROM ciudad AS c "
			+ "JOIN estado AS e ON e.id_estado = c.id_estado "
			+ "WHERE c.id_ciudad IN(:idCiudadOrigen, :idCiudadDestino)";

	@Query(value = QUERY_CIUDAD_ORIGEN_DESTINO, nativeQuery = true)
	List<CdOrigenDestino> getCdOrigenDestino(int idCiudadOrigen, int idCiudadDestino);
}
