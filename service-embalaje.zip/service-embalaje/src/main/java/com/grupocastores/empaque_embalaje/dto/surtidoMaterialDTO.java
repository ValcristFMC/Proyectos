package com.grupocastores.empaque_embalaje.dto;

public class surtidoMaterialDTO {

        private int idTalon;
        private String numeroTalon;
        private int idSolicitud;
        private int idSalida;
        private String nombreMaterial;
        private int idMaterial;
        private double cantidadSolicitada;
        private String unidadMedida;
        private int claveMaterial;
        private int idEmpaqueUtilizado;
    
        // Getters and Setters
        public int getIdTalon() {
            return idTalon;
        }
    
        public void setIdTalon(int idTalon) {
            this.idTalon = idTalon;
        }
    
        public String getNumeroTalon() {
            return numeroTalon;
        }
    
        public void setNumeroTalon(String numeroTalon) {
            this.numeroTalon = numeroTalon;
        }
    
        public int getIdSolicitud() {
            return idSolicitud;
        }
    
        public void setIdSolicitud(int idSolicitud) {
            this.idSolicitud = idSolicitud;
        }
    
        public int getIdSalida() {
            return idSalida;
        }
    
        public void setIdSalida(int idSalida) {
            this.idSalida = idSalida;
        }
    
        public String getNombreMaterial() {
            return nombreMaterial;
        }
    
        public void setNombreMaterial(String nombreMaterial) {
            this.nombreMaterial = nombreMaterial;
        }
    
        public int getIdMaterial() {
            return idMaterial;
        }
    
        public void setIdMaterial(int idMaterial) {
            this.idMaterial = idMaterial;
        }
    
        public double getCantidadSolicitada() {
            return cantidadSolicitada;
        }
    
        public void setCantidadSolicitada(double cantidadSolicitada) {
            this.cantidadSolicitada = cantidadSolicitada;
        }
    
        public String getUnidadMedida() {
            return unidadMedida;
        }
    
        public void setUnidadMedida(String unidadMedida) {
            this.unidadMedida = unidadMedida;
        }
    
        public int getClaveMaterial() {
            return claveMaterial;
        }
    
        public void setClaveMaterial(int claveMaterial) {
            this.claveMaterial = claveMaterial;
        }
    
        public int getIdEmpaqueUtilizado() {
            return idEmpaqueUtilizado;
        }
    
        public void setIdEmpaqueUtilizado(int idEmpaqueUtilizado) {
            this.idEmpaqueUtilizado = idEmpaqueUtilizado;
        }
    }
