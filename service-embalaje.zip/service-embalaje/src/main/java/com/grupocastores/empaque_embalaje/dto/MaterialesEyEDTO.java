package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de los Materiales", description = "Datos de los Materiales")
public class MaterialesEyEDTO {
	
	private Long idMaterial;
	private int claveMaterial;
    private String nombre;
    private String descripcion;
    private int idUnidadMedida;
    private double precioCompra;
    private double precioVenta;
    private int idPersonal;
    private String fechaMod;
    private String horaMod;
    private int estatus;
    private double medidaCompras;
    private double medidaConversion;
    private int validaExistencia;
    
	public MaterialesEyEDTO(Long idMaterial, int claveMaterial, String nombre, String descripcion, int idUnidadMedida,
			double precioCompra, double precioVenta, int idPersonal, String fechaMod, String horaMod, int estatus,
			double medidaCompras, double medidaConversion, int validaExistencia) {
		this.idMaterial = idMaterial;
		this.claveMaterial = claveMaterial;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.idUnidadMedida = idUnidadMedida;
		this.precioCompra = precioCompra;
		this.precioVenta = precioVenta;
		this.idPersonal = idPersonal;
		this.fechaMod = fechaMod;
		this.horaMod = horaMod;
		this.estatus = estatus;
		this.medidaCompras = medidaCompras;
		this.medidaConversion = medidaConversion;
		this.validaExistencia = validaExistencia;
	}

	@Override
	public String toString() {
		return "MaterialesEyEDTO [idMaterial=" + idMaterial + ", claveMaterial=" + claveMaterial + ", nombre=" + nombre
				+ ", descripcion=" + descripcion + ", idUnidadMedida=" + idUnidadMedida + ", precioCompra="
				+ precioCompra + ", precioVenta=" + precioVenta + ", idPersonal=" + idPersonal + ", fechaMod="
				+ fechaMod + ", horaMod=" + horaMod + ", estatus=" + estatus + ", medidaCompras=" + medidaCompras
				+ ", medidaConversion=" + medidaConversion + ", validaExistencia=" + validaExistencia + "]";
	}
    
}
