package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de las solicitudes", description = "Datos de las solicitudes")
public class ReporteSolicitudesMaterialDTO {
	
	private Long idSolicitud;
	private int folio;
	private int idOficina;
    private String oficina;
    private int idPersonal;
    private String usuarioSolicita;
    private String tipoSolicitud;
    private String anexo;
    private String observaciones;
    private String fecha;
    private String estatus;
    private String claveEstatus;
    private int noSap;
    
	public ReporteSolicitudesMaterialDTO(Long idSolicitud, int folio, int idOficina, String oficina,  int idPersonal,
			String usuarioSolicita, String tipoSolicitud, String anexo, String observaciones, String fecha,
			String estatus, String claveEstatus, int noSap) {
		this.idSolicitud = idSolicitud;
		this.folio = folio;
		this.idOficina = idOficina;
		this.oficina = oficina;
		this.idPersonal = idPersonal;
		this.usuarioSolicita = usuarioSolicita;
		this.tipoSolicitud = tipoSolicitud;
		this.anexo = anexo;
		this.observaciones = observaciones;
		this.fecha = fecha;
		this.estatus = estatus;
		this.claveEstatus = claveEstatus;
		this.noSap = noSap;
	}

	@Override
	public String toString() {
		return "ReporteSolicitudesMaterialDTO [idSolicitud=" + idSolicitud + ", folio=" + folio + ", idOficina="
				+ idOficina + ", oficina=" + oficina + ", idPersonal=" + idPersonal + ", usuarioSolicita=" + usuarioSolicita + ", tipoSolicitud="
				+ tipoSolicitud + ", anexo=" + anexo + ", observaciones=" + observaciones + ", fecha=" + fecha
				+ ", estatus=" + estatus + ", claveEstatus=" + claveEstatus + ", noSap=" + noSap + "]";
	}
	
}
