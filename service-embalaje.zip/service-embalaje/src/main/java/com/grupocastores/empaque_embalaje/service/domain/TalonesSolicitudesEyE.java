package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.grupocastores.empaque_embalaje.dto.SolicitudesDTO;
import com.grupocastores.empaque_embalaje.dto.TalonesSolicitudesEyEDTO;

import lombok.Data;

@Data
@Entity
@Table(name = "talones_solicitudes_eye")
@EntityListeners(TalonesSolicitudesEyE.class)
public class TalonesSolicitudesEyE {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_talon")
	private long idTalon;

	@Column(name = "numero_talon")
	private String numeroTalon;
	
	@Column(name = "id_solicitud")
	private int idSolicitud;
	
	@Column(name = "id_salida")
	private int idSalida;
	
	public static TalonesSolicitudesEyE fromTalonesSolicitudesEyEDTO(TalonesSolicitudesEyEDTO talonesDTO) {
		TalonesSolicitudesEyE rest = new TalonesSolicitudesEyE();
		rest.setIdTalon(talonesDTO.getIdTalon());
		rest.setNumeroTalon(talonesDTO.getNumeroTalon());
		rest.setIdSolicitud(talonesDTO.getIdSolicitud());
		rest.setIdSalida(talonesDTO.getIdSalida());
		return rest;
	}
	
	public TalonesSolicitudesEyEDTO toTalonesSolicitudesDTO() {
		TalonesSolicitudesEyEDTO dto = new TalonesSolicitudesEyEDTO();
		dto.setIdTalon(this.getIdTalon());
		dto.setNumeroTalon(this.getNumeroTalon());
		dto.setIdSolicitud(this.getIdSolicitud());
		dto.setIdSalida(this.getIdSalida());
		return dto;
	}
}
