package com.grupocastores.empaque_embalaje.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.Parametro;

@Repository
public interface ParametroRepository extends JpaRepository<Parametro, Long> {
	
	static final String selectParametroByClaveAndNacionalAndOficinaAndModulo = "SELECT * "
			+ "FROM parametro p "
			+ "WHERE p.clave = :clave "
			+ "AND p.nacional = :nacional "
			+ "AND p.id_oficina = :idOficina "
			+ "AND p.id_modulo = :idModulo ;";
	
	@Query(value = selectParametroByClaveAndNacionalAndOficinaAndModulo, nativeQuery = true)
	Parametro selectParametroByClaveAndNacionalAndOficinaAndModulo(@Param("clave") String clave,
			@Param("nacional") Short nacional, @Param("idOficina") Long idOficina, @Param("idModulo") Long idModulo);

}