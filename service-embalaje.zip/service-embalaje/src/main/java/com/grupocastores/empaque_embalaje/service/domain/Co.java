package com.grupocastores.empaque_embalaje.service.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.grupocastores.empaque_embalaje.dto.CoDTO;

import lombok.Data;

@Data
@Entity
@EntityListeners(Co.class)
public class Co {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cla_talon")
	private String claTalon;
	
	@Column(name = "bultos")
    private int bultos;
	
	@Column(name = "etiquetas")
    private int etiquetas;
	
	@Column(name = "empaque")
    private String empaque;
	
	@Column(name = "que_contiene")
    private String queContiene;
	
	@Column(name = "pesot")
    private int pesoT;
	
	@Column(name = "mts3")
    private int mts3;
	
	@Column(name = "pesoe")
    private int pesoE;
	
	@Column(name = "precio")
    private int precio;
	
	@Column(name = "noconvenio")
    private int noConvenio;
	
	@Column(name = "preciocalculado")
    private int precioCalculado;
	
	@Column(name = "tipocobro")
    private int tipoCobro;
	
	@Column(name = "largo")
    private int largo;
	
	@Column(name = "ancho")
    private int ancho;
	
	@Column(name = "alto")
    private int alto;
	
	public static Co fromCoDTO(CoDTO coDTO) {
	    Co co = new Co();
	    co.setClaTalon(coDTO.getClaTalon());
	    co.setBultos(coDTO.getBultos());
	    co.setEtiquetas(coDTO.getEtiquetas());
	    co.setEmpaque(coDTO.getEmpaque());
	    co.setQueContiene(coDTO.getQueContiene());
	    co.setPesoT(coDTO.getPesoT());
	    co.setMts3(coDTO.getMts3());
	    co.setPesoE(coDTO.getPesoE());
	    co.setPrecio(coDTO.getPrecio());
	    co.setNoConvenio(coDTO.getNoConvenio());
	    co.setPrecioCalculado(coDTO.getPrecioCalculado());
	    co.setTipoCobro(coDTO.getTipoCobro());
	    co.setLargo(coDTO.getLargo());
	    co.setAncho(coDTO.getAncho());
	    co.setAlto(coDTO.getAlto());
	    return co;
	}

	public CoDTO toCoDTO() {
	    CoDTO coDTO = new CoDTO();
	    coDTO.setClaTalon(this.getClaTalon());
	    coDTO.setBultos(this.getBultos());
	    coDTO.setEtiquetas(this.getEtiquetas());
	    coDTO.setEmpaque(this.getEmpaque());
	    coDTO.setQueContiene(this.getQueContiene());
	    coDTO.setPesoT(this.getPesoT());
	    coDTO.setMts3(this.getMts3());
	    coDTO.setPesoE(this.getPesoE());
	    coDTO.setPrecio(this.getPrecio());
	    coDTO.setNoConvenio(this.getNoConvenio());
	    coDTO.setPrecioCalculado(this.getPrecioCalculado());
	    coDTO.setTipoCobro(this.getTipoCobro());
	    coDTO.setLargo(this.getLargo());
	    coDTO.setAncho(this.getAncho());
	    coDTO.setAlto(this.getAlto());
	    return coDTO;
	}

}
