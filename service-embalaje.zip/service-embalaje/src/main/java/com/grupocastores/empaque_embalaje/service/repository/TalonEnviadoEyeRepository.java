package com.grupocastores.empaque_embalaje.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupocastores.empaque_embalaje.service.domain.TalonEnviadoEye;

@Repository
public interface TalonEnviadoEyeRepository extends JpaRepository<TalonEnviadoEye, Integer> {

	static final String QUERY_GET_TALONES_ENVIADO_BY_NO_TALON = "SELECT * FROM talones_enviados_eye WHERE numero_talon = :numeroTalon";

	@Query(value = QUERY_GET_TALONES_ENVIADO_BY_NO_TALON, nativeQuery = true)
	TalonEnviadoEye getTalonEnviadoByNumeroTalon(String numeroTalon);
}
