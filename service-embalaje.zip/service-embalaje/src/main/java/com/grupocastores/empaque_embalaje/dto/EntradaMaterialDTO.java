package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de una Entrada de material", description = "Datos de una Entrada de material")
public class EntradaMaterialDTO {

	private int idEntrada;
    private int idMaterial;
    private int cantidad;
    private int idPersonal;
    private String fechaMod;
    private String horaMod;
    private double precioCompra;
    private int idTipoMovimiento;
    private String noNota;
    private int idPoliza;
    private String idOficina;
    
	public EntradaMaterialDTO(int idEntrada, int idMaterial, int cantidad, int idPersonal, String fechaMod,
			String horaMod, double precioCompra, int idTipoMovimiento, String noNota, int idPoliza, String idOficina) {
		this.idEntrada = idEntrada;
		this.idMaterial = idMaterial;
		this.cantidad = cantidad;
		this.idPersonal = idPersonal;
		this.fechaMod = fechaMod;
		this.horaMod = horaMod;
		this.precioCompra = precioCompra;
		this.idTipoMovimiento = idTipoMovimiento;
		this.noNota = noNota;
		this.idPoliza = idPoliza;
		this.idOficina = idOficina;
	}

	@Override
	public String toString() {
		return "EntradaMaterialDTO [idEntrada=" + idEntrada + ", idMaterial=" + idMaterial + ", cantidad=" + cantidad
				+ ", idPersonal=" + idPersonal + ", fechaMod=" + fechaMod + ", horaMod=" + horaMod + ", precioCompra="
				+ precioCompra + ", idTipoMovimiento=" + idTipoMovimiento + ", noNota=" + noNota + ", idPoliza="
				+ idPoliza + ", idOficina=" + idOficina + "]";
	}
    
}
