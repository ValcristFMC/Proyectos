package com.grupocastores.empaque_embalaje.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@ApiModel(value = "Informacion de los talones y salidas de material venta", description = "Datos de los talones")
public class TalonesMaterialVentaDTO {

	private Long idSalida;
	private long idSolicitud;
	private String nombreMaterial;
	private long idMaterial;
	private int cantidadSolicitada;
	private String unidadMedida;
	private int claveMaterial;
	
	public TalonesMaterialVentaDTO(Long idSalida, long idSolicitud, String nombreMaterial, long idMaterial,
			int cantidadSolicitada, String unidadMedida, int claveMaterial) {
		this.idSalida = idSalida;
		this.idSolicitud = idSolicitud;
		this.nombreMaterial = nombreMaterial;
		this.idMaterial = idMaterial;
		this.cantidadSolicitada = cantidadSolicitada;
		this.unidadMedida = unidadMedida;
		this.claveMaterial = claveMaterial;
	}

	@Override
	public String toString() {
		return "TalonesMaterialVentaDTO [idSalida=" + idSalida + ", idSolicitud=" + idSolicitud + ", nombreMaterial="
				+ nombreMaterial + ", idMaterial=" + idMaterial + ", cantidadSolicitada=" + cantidadSolicitada
				+ ", unidadMedida=" + unidadMedida + ", claveMaterial=" + claveMaterial + "]";
	}
		
}
