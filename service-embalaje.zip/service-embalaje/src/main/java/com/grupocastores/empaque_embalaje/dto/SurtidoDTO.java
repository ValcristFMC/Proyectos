package com.grupocastores.empaque_embalaje.dto;

public class SurtidoDTO {

 private String talon;
 private String docLogistico;
 private String cantidadSurtida;
 private String fechaRegistro;
 private String horaRegistro;

 // Getters and Setters
 public String getTalon() {
     return talon;
 }

 public void setTalon(String talon) {
     this.talon = talon;
 }

 public String getDocLogistico() {
     return docLogistico;
 }

 public void setDocLogistico(String docLogistico) {
     this.docLogistico = docLogistico;
 }

 public String getCantidadSurtida() {
     return cantidadSurtida;
 }

 public void setCantidadSurtida(String cantidadSurtida) {
     this.cantidadSurtida = cantidadSurtida;
 }

 public String getFechaRegistro() {
     return fechaRegistro;
 }

 public void setFechaRegistro(String fechaRegistro) {
     this.fechaRegistro = fechaRegistro;
 }

 public String getHoraRegistro() {
     return horaRegistro;
 }

 public void setHoraRegistro(String horaRegistro) {
     this.horaRegistro = horaRegistro;
 }
}
