# castores-service-empaque-embalaje

## Versión: 1.0.1.0
__Ticket/Proyecto:__ Empaque y Embalaje
__Autor:__ Flavio Urdiales
__Fecha:__ 29/07/2024
__Descripción:__
 - Se agrega metodo para insertar entradas con base a estatus SAP.
 - Se hace puente al MS de SAP para que pueda consultarse en todas las oficinas.
--------

## Configuración técnica
- __IDE:__ Spring Tools Suite 4
- __Lenguaje:__ Java 8 Sping Boot

## Librerías
### Internas
-

### Externas
-
-------------

## Documentación
- Generar peticiones en postman