package com.grupocastores.service.Viaje.dto;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="semaforo")
public class Semaforo implements Serializable {

	private static final long serialVersionUID = -4849063986266354023L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="id_semaforo")
	private int id_semaforo;
	
	@Column(name ="id_oficina")
	private int id_oficina;
	
	@Column(name ="id_sistema")
	private int id_sistema;
	
	@Column(name ="id_modulo")
	private int id_modulo;
	
	@Column(name ="Descripcion")
	private String Descripcion;
	
	@Column(name ="estatus")
	private int estatus;
	
	@Column(name ="fecha_modificacion")
	private LocalDateTime fecha_modificacion;
	
	@Column(name ="fecha_alta")
	private Date fecha_alta;

	public int getId_semaforo() {
		return id_semaforo;
	}

	public void setId_semaforo(int id_semaforo) {
		this.id_semaforo = id_semaforo;
	}

	public int getId_oficina() {
		return id_oficina;
	}

	public void setId_oficina(int id_oficina) {
		this.id_oficina = id_oficina;
	}

	public int getId_sistema() {
		return id_sistema;
	}

	public void setId_sistema(int id_sistema) {
		this.id_sistema = id_sistema;
	}

	public int getId_modulo() {
		return id_modulo;
	}

	public void setId_modulo(int id_modulo) {
		this.id_modulo = id_modulo;
	}

	public String getDescripcion() {
		return Descripcion;
	}

	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}

	public LocalDateTime getFecha_modificacion() {
		return fecha_modificacion;
	}

	public void setFecha_modificacion(LocalDateTime localDateTime) {
		this.fecha_modificacion = localDateTime;
	}

	public Date getFecha_alta() {
		return fecha_alta;
	}

	public void setFecha_alta(Date fecha_alta) {
		this.fecha_alta = fecha_alta;
	}

	public int getEstatus() {
		return estatus;
	}

	public void setEstatus(int estatus) {
		this.estatus = estatus;
	}
	
	
	
	
}
