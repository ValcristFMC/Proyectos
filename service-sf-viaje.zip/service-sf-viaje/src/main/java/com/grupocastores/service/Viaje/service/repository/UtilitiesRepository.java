package com.grupocastores.service.Viaje.service.repository;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

public class UtilitiesRepository {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public static final String DB_23 = "PRODUCCION23";
	public static final String DB_13 = "PRODUCCION13";
	public static final String queryGetLinkedServerByIdOficina = 
			"SELECT * FROM syn.dbo.v_Oficinas where Oficina = \'%s\'";
	
	
	public Boolean executeStoredProcedure(String query) {
		int resp = 0;
		StoredProcedureQuery storedProcedure = entityManager.createStoredProcedureQuery("PcrExecSQL");
		storedProcedure.registerStoredProcedureParameter("sql", String.class, ParameterMode.IN);
		storedProcedure.registerStoredProcedureParameter("respuesta", String.class, ParameterMode.OUT);
		storedProcedure.setParameter("sql", query);
		storedProcedure.execute();
		resp = Integer.valueOf((String) storedProcedure.getOutputParameterValue("respuesta"));
		return resp > 0 ? true : false;
	}

}
