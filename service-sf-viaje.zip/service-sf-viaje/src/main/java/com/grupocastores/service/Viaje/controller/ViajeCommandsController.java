package com.grupocastores.service.Viaje.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.grupocastores.service.Viaje.service.domain.Viaje;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.grupocastores.service.Viaje.service.ViajeService;
import com.grupocastores.service.Viaje.dto.ViajeDTO;

@RestController
@RequestMapping(value = "/service/Viaje")
@Api(value = "ViajeCommandsController", produces = "application/json")
/**
 * Controlador de commands 
 *
 * @author Castores - Desarrollo TI
 */
public class  ViajeCommandsController {

	Logger logger = LoggerFactory.getLogger(ViajeCommandsController.class);
	private Map<String, Object> response;
	
	@Autowired
	private ViajeService viajeService;
	static final String HEADERBACK = "/service/Viaje/{folio}";
	
	private Viaje viaje;

	@HystrixCommand(fallbackMethod = "fallBackMethod")
	@GetMapping(value = "/findViaje/{folio}", produces = "application/json;charset=UTF-8")
	public ResponseEntity<?> findViaje(@PathVariable(name = "folio")String folio) {
		try {
			 viaje = viajeService.findViaje(folio);
		} catch (Exception e) {
		    response = new HashMap<String, Object>();
			response.put("error", "Error en findViaje()"); 	
			response.put("message", e.getMessage());
			response.put("class", this.getClass());
			return new ResponseEntity<Map<String,Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<Viaje>(viaje, HttpStatus.OK);
	}
	
	@GetMapping(value = "/findViajes/", produces = "application/json;charset=UTF-8")
	public ResponseEntity<List<Viaje>> findOpotunidades() {
		List<Viaje> list = viajeService.findViajes();
		if (list == null || list.isEmpty())
			return ResponseEntity.noContent().build();
		//return ResponseEntity.ok(list);
		return new ResponseEntity<List<Viaje>>(list, HttpStatus.OK);
	}
	

	@PostMapping(value = "ServiceViaje", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Viaje> sendViaje(@RequestBody List<Viaje> viajes, UriComponentsBuilder builder) {

		try {
			viajeService.sendViajes(viajes);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setConnection("/insertar_Viaje/");
		return new ResponseEntity<Viaje>(viaje, headers, HttpStatus.CREATED);
	}
}
