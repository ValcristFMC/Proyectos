package com.grupocastores.service.Viaje.dto;

import java.util.Date;

import javax.persistence.Column;

import io.swagger.annotations.ApiModel;

/**
 * Data Transfer Object para el {@link com.grupocastores.service.Viaje.service.domain.Viaje} del modelo de dominio
 *
 * @author Castores - Desarrollo TI
 */
@ApiModel(value = "Informacion de un Viaje", description = "Datos del Viaje")
public class ViajeDTO 
{
	private String Idviaje;
	private String Idoficina;
	private String Nombre;
	private String Unidad;
	private String Fecha_cita_carga;
	private String Fecha_cita_descarga;
	private String Estatus;

	/**
	 * Constructor de ViajeDTO sin argumentos
	 */
	public ViajeDTO () {
		
	}
	/**
	 * Constructor de ViajeDTO con todos los atributos como argumentos
	 * 
	 * @param id the id to set
	 * @param description the description to set
	 * 
	 */
	public ViajeDTO(/*String idviaje, String idoficina,*/ String nombre, String unidad, String fecha_cita_carga, String fecha_cita_descarga, String estatus) {
		super();
		/*Idviaje = idviaje;
		Idoficina = idoficina;*/
		Nombre = nombre;
		Unidad = unidad;
		Fecha_cita_carga = fecha_cita_carga;
		Fecha_cita_descarga = fecha_cita_descarga;
		Estatus = estatus;
	}
		
	/**
	 * @return the id
	 */
	/*
	public String getIdviaje() {
		return Idviaje;
	}
	public void setIdviaje(String idviaje) {
		Idviaje = idviaje;
	}
	public String getIdoficina() {
		return Idoficina;
	}
	public void setIdoficina(String idoficina) {
		Idoficina = idoficina;
	}	*/
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public String getUnidad() {
		return Unidad;
	}
	public void setUnidad(String unidad) {
		Unidad = unidad;
	}
	public String getFecha_cita_carga() {
		return Fecha_cita_carga;
	}
	public void setFecha_cita_carga(String fecha_cita_carga) {
		Fecha_cita_carga = fecha_cita_carga;
	}
	public String getFecha_cita_descarga() {
		return Fecha_cita_descarga;
	}
	public void setFecha_cita_descarga(String fecha_cita_descarga) {
		Fecha_cita_descarga = fecha_cita_descarga;
	}
	public String getEstatus() {
		return Estatus;
	}
	public void setEstatus(String estatus) {
		Estatus = estatus;
	}
	
}
