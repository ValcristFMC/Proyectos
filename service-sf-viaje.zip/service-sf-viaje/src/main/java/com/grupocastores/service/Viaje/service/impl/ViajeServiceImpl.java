package com.grupocastores.service.Viaje.service.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.grupocastores.service.Viaje.service.domain.Viaje;
import com.grupocastores.service.Viaje.service.domain.Respuesta;
import com.grupocastores.service.Viaje.service.repository.ViajeRepository;
import com.grupocastores.service.Viaje.dto.Semaforo;
import com.grupocastores.service.Viaje.DAO.SemaforoDao;
import com.grupocastores.service.Viaje.service.ViajeService;

/**
 * Implementacion interna de {@link com.grupocastores.service.Viaje.service.ViajeService}. Esta clase no se debe acceder directamente
 *
 * @author Castores - Desarrollo TI
 */
@Service
public class ViajeServiceImpl implements ViajeService 
{
	Logger logger = LoggerFactory.getLogger(ViajeServiceImpl.class);
	public String hora_fecha, horaUlt, fechaUlt, horaNew, fechaNew, respuesta, resp, msg;
	public int id_ms = 0, act=0;
	
	@Autowired
	private ViajeRepository viajeRepository;
	@Autowired(required = true)
	private SemaforoDao semaforoDao;
	
	@Override
	public Viaje findViaje(String folio) {
		Viaje viaje = new Viaje();
		try {
			
			viaje = viajeRepository.findViaje(folio);
			if (viaje ==null) {
				throw new Exception ("No se pudo obtener el registro del viaje: "+ folio);
			}
		}
		catch (Exception e){
			e.printStackTrace();
			return null;
		}
		return viaje;
	}
	
	
	@Override
	public List<Viaje> findViajes() {		
		try {
			
			System.out.println("Ejecutando findViajes()");
			id_ms = 7;
			
			horaUlt = viajeRepository.findHora_MS(id_ms);
			fechaUlt = viajeRepository.findFecha_MS(id_ms);
			
			hora_fecha = fechaUlt+ " "+ horaUlt;

			System.out.println(hora_fecha);
			
			List<Viaje> listaViajes = viajeRepository.findViajes(hora_fecha);
			if(listaViajes == null || listaViajes.isEmpty()){
				return null;
			}
			
			List<Viaje> viajes = new ArrayList<>();
			listaViajes.stream().forEach(item -> {	
				viajes.add(item);
			});
			
			horaNew = viajeRepository.findHoraViaje(viajes.get(viajes.size()-1).getNombre());
			fechaNew = viajeRepository.findFechaViaje(viajes.get(viajes.size()-1).getNombre());
			
			System.out.println(horaNew +" "+ fechaNew);
			
			respuesta = sendViajes(viajes);
			
			String [] partes = respuesta.split("@");
			resp = partes[0];
			msg = partes[1];

			
			System.out.println("finalizando findViajes()");
			return viajes;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	

	@Override
	public String sendViajes(List<Viaje> viajes) throws URISyntaxException {
		
		String token = "";
		String response ="", message = "";
		id_ms = 6;
		
		String resp ="";
		try {
			System.out.println("Ejecutando sendViajes()");
			
			System.out.println(viajes.toString());
			
			token = viajeRepository.findToken();
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
			headers.set("Authorization", "Bearer "+ token);
	
			URI url = new URI("https://castores--castordev.sandbox.my.salesforce.com/services/apexrest/insertar_Viaje/");
			
			HttpEntity<List<Viaje>> requestEntity = new HttpEntity<>(viajes, headers);
	
			RestTemplate restTemplate = new RestTemplate();
			//System.out.println("URL: " + url);
			//System.out.println("request: " + requestEntity.toString());
			Respuesta[] responseEntity = restTemplate.postForObject(url, requestEntity, Respuesta[].class);
	
			System.out.println("response: " + responseEntity.length);
			if (responseEntity.length > 0) {
	
				for (int i = 0; i < responseEntity.length; i++) {
				  if (responseEntity[i].code != "200") {
					  //System.out.println("error");
					  response += "{"+responseEntity[i].code+"}";
					  message += "{["+responseEntity[i].technicalErrorMessage + "]-" + responseEntity[i].message+"}";
				  }
				  else {
					  response = responseEntity[i].code;
					  message = "OK";
				  }
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		resp = response + "@" + message;
		
		
		System.out.println(resp);
		System.out.println("finalizando sendViajes()");
		return resp;
	}
	

	@Scheduled(initialDelay = 1000 * 60 * 1, fixedDelay = 1000 * 60 * 1)
	@Override
	public void metodo() {

		System.out.println("Ejecutando metodo()");
		int id_sistema = 1;
		int id_modulo = 7;

		Calendar fecha = Calendar.getInstance();
		TimeZone tz = fecha.getTimeZone();
		ZoneId zid = tz == null ? ZoneId.systemDefault() : tz.toZoneId();

		List<Semaforo> listSemaforo;
		try {
			listSemaforo = viajeRepository.getSemaforo(id_sistema, id_modulo);
			
			for (Semaforo semaforo : listSemaforo) {

				if (semaforo.getEstatus() == 1) {

					try {
						semaforo.setEstatus(4);
						semaforo.setFecha_modificacion(LocalDateTime.ofInstant(fecha.toInstant(), zid));
						semaforoDao.save(semaforo);
						List<Viaje> list = findViajes();

						System.out.println("finalizando metodo()");
						semaforo.setEstatus(1);
						semaforo.setFecha_modificacion(LocalDateTime.ofInstant(fecha.toInstant(), zid));
						semaforoDao.save(semaforo);

					} catch (Exception e) {
						semaforo.setEstatus(1);
						semaforo.setFecha_modificacion(LocalDateTime.ofInstant(fecha.toInstant(), zid));
						semaforoDao.save(semaforo);
					}
				}
				else {
					System.out.println(semaforo.getEstatus());
					semaforo.setEstatus(1);
					semaforo.setFecha_modificacion(LocalDateTime.ofInstant(fecha.toInstant(), zid));
					semaforoDao.save(semaforo);
				}
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}
}
