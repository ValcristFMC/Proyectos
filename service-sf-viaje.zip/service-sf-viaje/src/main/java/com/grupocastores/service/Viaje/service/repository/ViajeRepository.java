package com.grupocastores.service.Viaje.service.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.grupocastores.service.Viaje.dto.Semaforo;
import com.grupocastores.service.Viaje.service.domain.Viaje;

/**
 * ViajeRepository Repositorio para el almacenamiento de {@link com.grupocastores.service.Viaje.service.domain.Viaje} 
 *
 * @author Castores - Desarrollo TI
 *
 */
@Repository
public class ViajeRepository extends UtilitiesRepository
{
	@PersistenceContext
	private EntityManager entityManager;
	
	static final String queryGetViaje = "SELECT * FROM OPENQUERY(" + DB_23 +
			", 'SELECT folio,idunidad,CONCAT(CAST(fechacarga AS CHAR), \" \", CAST(horacarga AS CHAR)) AS carga,CONCAT(CAST(fechacarga AS CHAR), \" \", CAST(horacarga AS CHAR)) AS descarga, estatus FROM talones.viajes WHERE folio = %s; ')";
	
	static final String queryGetViajes = "SELECT * FROM OPENQUERY(" + DB_23 +
			", 'SELECT folio,idunidad,CONCAT(CAST(fechacarga AS CHAR), \" \", CAST(horacarga AS CHAR)) AS carga,CONCAT(CAST(fechacarga AS CHAR), \" \", CAST(horacarga AS CHAR)) AS descarga, estatus FROM talones.viajes WHERE CONCAT(fechamod, \" \",horamod) BETWEEN \"%s\" AND NOW() ORDER BY fechamod,horamod ASC LIMIT 100; ');";

	static final String queryHoraViaje = "SELECT * FROM OPENQUERY(" + DB_23 +
			", 'SELECT CAST(horamod AS CHAR) AS hora FROM talones.viajes WHERE folio = %s;')";
	
	static final String queryFechaViaje = "SELECT * FROM OPENQUERY(" + DB_23 +
			", 'SELECT CAST(fechamod AS CHAR) AS hora FROM talones.viajes WHERE folio = %s;')";

	static final String queryGetHora_MS = "SELECT * FROM OPENQUERY(" + DB_23 +
			", 'SELECT CAST(s.hora_new AS CHAR) FROM castores.bitacora_ejecucion_ms s  WHERE s.id_ms=\"%s\";')";
	
	static final String queryGetFecha_MS = "SELECT * FROM OPENQUERY(" + DB_23 +
			", 'SELECT CAST(s.fecha_new AS CHAR) FROM castores.bitacora_ejecucion_ms s  WHERE s.id_ms=\"%s\";')";
	
	static final String queryGetHora_Fecha_MS = "SELECT * FROM OPENQUERY(" + DB_23 +
			", 'SELECT CONCAT(CAST(s.ult_fecha AS CHAR),\" \",CAST( s.ult_hora AS CHAR)) AS fhUltima FROM castores.bitacora_ejecucion_ms s  WHERE s.id_ms=\"%s\";')";
	
	static final String queryGetSemaforo = "SELECT * FROM dbo.semaforo WHERE id_sistema=%s and id_modulo=%s;";
	
	static final String queryToken =
			"SELECT * FROM OPENQUERY("+ DB_13 +", 'SELECT message FROM castores.bitacora_ejecucion_ms WHERE id_ms=\"13\" AND nombre_ms =\"service-auth\";')";
	
	static final String querySetUpdateEjecucion= 
			"UPDATE OPENQUERY("+ DB_23 +", 'SELECT ult_fecha, ult_hora, fecha_new, hora_new, response, message from castores.bitacora_ejecucion_ms  WHERE id_ms=\"%s\";') SET ult_fecha=\'%s\', ult_hora = \'%s\',fecha_new=\'%s', hora_new = \'%s\',response = \'%s\', message = \'%s\'";
	
	
	@SuppressWarnings("unchecked")
	public Viaje findViaje (String folio){
		Query queryViaje = entityManager.createNativeQuery(String.format(queryGetViaje, folio), Viaje.class);
		List<Viaje> listaViaje = ((javax.persistence.Query) queryViaje).getResultList();
		return (Viaje) listaViaje.get(0);
	}
	
	@SuppressWarnings("unchecked")
	public List<Viaje> findViajes (String hora_fecha){
		Query queryViajes = entityManager.createNativeQuery(String.format(queryGetViajes,hora_fecha), Viaje.class);
		List<Viaje> listaViajes = ((javax.persistence.Query) queryViajes).getResultList();
		if(!listaViajes.isEmpty())
			return listaViajes;
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public String findHoraViaje (String folio) throws Exception{
		Query queryViajeHora = entityManager.createNativeQuery(String.format(queryHoraViaje, folio));
		List<String> horaViaje = ((javax.persistence.Query) queryViajeHora).getResultList();
		String hora = horaViaje.get(0);
		return hora;
	}
	
	@SuppressWarnings("unchecked")
	public String findFechaViaje (String folio) throws Exception{
		Query queryOportunidadFecha = entityManager.createNativeQuery(String.format(queryFechaViaje, folio));
		List<String> fechaOportunidad = ((javax.persistence.Query) queryOportunidadFecha).getResultList();
		String fecha = fechaOportunidad.get(0);
		return fecha;
	}
	
	@SuppressWarnings("unchecked")
	public String findHora_MS (int id_ms) throws Exception{
		Query queryMSHora = entityManager.createNativeQuery(String.format(queryGetHora_MS,id_ms));
		List<String> horaMS = ((javax.persistence.Query) queryMSHora).getResultList();
		String Hora = horaMS.get(0);
		return Hora;
	}
	
	@SuppressWarnings("unchecked")
	public String findFecha_MS (int id_ms) throws Exception{
		Query queryMSFecha = entityManager.createNativeQuery(String.format(queryGetFecha_MS,id_ms));
		List<String> fechaMS = ((javax.persistence.Query) queryMSFecha).getResultList();
		String Fecha = fechaMS.get(0);
		return Fecha;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Semaforo> getSemaforo (int id_sistema, int id_modulo) throws Exception{
		Query queryviajes = entityManager.createNativeQuery(String.format(queryGetSemaforo,id_sistema,id_modulo), Semaforo.class);
		List<Semaforo> listaViajes = ((javax.persistence.Query) queryviajes).getResultList();
		if(!listaViajes.isEmpty())
			return listaViajes;
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public String findToken() throws Exception {
		Query query3 = entityManager.createNativeQuery(String.format(queryToken));
		if (executeStoredProcedure(queryToken) == false)
			throw new Exception("la respuesta de la consulta es vacia, no se pudo obtener la informacion");
		List<String> tokenList = ((javax.persistence.Query) query3).getResultList();
		String token = tokenList.get(0);
		return token;
	}
	
	 @SuppressWarnings("unchecked")
		public int UpdateEjecucion(int id_ms, String fechaU, String horaU, String fechaN, String horaN, String resp, String msg) throws Exception {
		 Query query2 = entityManager.createNativeQuery(String.format(querySetUpdateEjecucion,id_ms, fechaU, horaU, fechaN, horaN, resp, msg));

		 int listCuenta = ((javax.persistence.Query) query2).executeUpdate();
		 return listCuenta;
	 }
}
