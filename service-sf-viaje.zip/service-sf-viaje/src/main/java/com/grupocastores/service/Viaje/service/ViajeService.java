package com.grupocastores.service.Viaje.service;

import java.net.URISyntaxException;
import java.util.List;

import com.grupocastores.service.Viaje.service.domain.Viaje;

/**
 * Viaje Service, define el caso de uso del API
 *
 * @author Castores - Desarrollo TI
 *
 */
public interface ViajeService 
{
	public Viaje findViaje(String folio);
	public List<Viaje> findViajes();
	public String sendViajes(List<Viaje> viajes) throws URISyntaxException;
	public void metodo();
}
