package com.grupocastores.service.Viaje.service.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import com.grupocastores.service.Viaje.dto.ViajeDTO;

/**
 * Clase Viaje del dominio tiene su correspondiente {@link ViajeDTO}
 *
 * @author Castores - Desarrollo TI
 */
@Entity
@Table(name = "viaje")
@EntityListeners(Viaje.class)
public class Viaje 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	/*@Column(name = "idviaje") 
	private String idviaje;
	
	@Id
	@Column(name = "idoficina") 
	private String idoficina;*/
	
	@Column(name = "folio") 
	private String Nombre;

	@Column(name = "idunidad") 
	private String Unidad;
	
	@Column(name = "carga") 
	private String Fecha_cita_carga;
	
	@Column(name = "descarga") 
	private String Fecha_cita_descarga;

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getUnidad() {
		return Unidad;
	}

	public void setUnidad(String unidad) {
		Unidad = unidad;
	}

	public String getFecha_cita_carga() {
		return Fecha_cita_carga;
	}

	public void setFecha_cita_carga(String fecha_cita_carga) {
		Fecha_cita_carga = fecha_cita_carga;
	}

	public String getFecha_cita_descarga() {
		return Fecha_cita_descarga;
	}

	public void setFecha_cita_descarga(String fecha_cita_descarga) {
		Fecha_cita_descarga = fecha_cita_descarga;
	}
	
	public String getEstatus() {
		return Estatus;
	}

	public void setEstatus(String estatus) {
		Estatus = estatus;
	}

	@Column(name = "estatus") 
	private String Estatus;

	/**
	 * Metodo estatico para obtener un Viaje a partir de un ViajeDTO origen
	 * 
	 * @param viaje ViajeDTO origen
	 * 
	 * @return Viaje
	 */
	public static Viaje fromViajeDTO(ViajeDTO viaje) {
		Viaje rest = new Viaje();
		rest.setNombre(viaje.getNombre());
		rest.setNombre(viaje.getNombre());
		rest.setNombre(viaje.getNombre());
		rest.setUnidad(viaje.getUnidad());
		rest.setFecha_cita_carga(viaje.getFecha_cita_carga());
		rest.setFecha_cita_descarga(viaje.getFecha_cita_descarga());
		rest.setEstatus(viaje.getEstatus());
		return rest;
	}
	
	/**
	 * Metodo para obtener un ViajeDTO a partir de un Viaje origen
	 * 
	 * @return ViajeDTO
	 */
	public ViajeDTO toViajeDTO() {
		ViajeDTO dto = new  ViajeDTO();
		dto.setNombre(this.getNombre());
		dto.setUnidad(this.getUnidad());
		dto.setFecha_cita_carga(this.getFecha_cita_carga());
		dto.setFecha_cita_descarga(this.getFecha_cita_descarga());
		dto.setEstatus(this.getEstatus());
		return dto;
	}

}
