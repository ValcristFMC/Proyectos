package com.grupocastores.service.Viaje.DAO;

import org.springframework.data.repository.CrudRepository;

import com.grupocastores.service.Viaje.dto.Semaforo;



public interface SemaforoDao extends CrudRepository<Semaforo, Long> {

}

