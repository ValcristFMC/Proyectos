package com.grupocastores.service.Viaje.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;

@RestController
@RequestMapping(value = "/service/Viaje")
@Api(value = "ViajeQueriesController", produces = "application/json")
/**
 * Controlador de queries 
 *
 * @author Castores - Desarrollo TI
 */
public class ViajeQueriesController {

	Logger logger = LoggerFactory.getLogger(ViajeQueriesController.class);

}
