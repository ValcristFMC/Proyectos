package com.grupocastores.service.Viaje.service.domain;

public class Respuesta {
	
	public String technicalErrorMessage;	
	public String success;	
	public String recordUpdated;
	public String message;
	public String code;
	public String errorCode;
	
	public Respuesta() {
		
	}
	
	public Respuesta(String technicalErrorMessage, String success, String recordUpdated, String message, String code, String errorCode) {
		super();
		this.technicalErrorMessage = technicalErrorMessage;
		this.success = success;
		this.recordUpdated = recordUpdated;
		this.message = message;
		this.code = code;
		this.errorCode = errorCode;
	}

	
	public String getTechnicalErrorMessage() {
		return technicalErrorMessage;
	}

	public void setTechnicalErrorMessage(String technicalErrorMessage) {
		this.technicalErrorMessage = technicalErrorMessage;
	}

	public String getSuccess() {
		return success;
	}

	public void setSuccess(String success) {
		this.success = success;
	}

	public String getRecordUpdated() {
		return recordUpdated;
	}

	public void setRecordUpdated(String recordUpdated) {
		this.recordUpdated = recordUpdated;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public String geterrorCode() {
		return code;
	}

	public void seterrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	

}
